from starter import Callback, EarlyStopping, ModelCheckpoint, Trainer

VAL = [1.0, 0.8, 0.85, 0.7, 0.71, 0.72, 0.73, 0.5]


def make(callbacks, val=VAL):
    model = {"w": [0], "epoch": -1}

    def train_epoch(epoch):
        model["w"][0] += 1
        model["epoch"] = epoch
        return {"loss": 1.0 / (epoch + 1)}

    def evaluate(epoch):
        return {"val_loss": val[epoch], "val_acc": 1 - val[epoch]}

    def set_state(state):
        model.clear()
        model.update(state)

    return model, Trainer(train_epoch, evaluate, lambda: model, set_state, callbacks)


def test_history_without_callbacks():
    _, tr = make([])
    hist = tr.fit(3)
    assert hist == {"loss": [1.0, 0.5, 1 / 3], "val_loss": [1.0, 0.8, 0.85], "val_acc": [0.0, 1 - 0.8, 1 - 0.85]}


def test_early_stopping_and_restore():
    es = EarlyStopping(patience=3)
    model, tr = make([es])
    hist = tr.fit(8)
    assert len(hist["val_loss"]) == 7
    assert es.best == 0.7 and es.best_epoch == 3 and es.stopped_epoch == 6
    assert model["epoch"] == 3 and model["w"] == [4]


def test_min_delta_and_max_mode():
    es = EarlyStopping(monitor="val_acc", mode="max", patience=2, min_delta=0.15, restore_best=False)
    model, tr = make([es])
    hist = tr.fit(8)
    assert es.best_epoch == 1 and es.stopped_epoch == 3 and len(hist["loss"]) == 4
    assert model["epoch"] == 3


def test_checkpoint():
    ck = ModelCheckpoint()
    _, tr = make([ck])
    tr.fit(8)
    assert [(e, v) for e, v, _ in ck.saved] == [(0, 1.0), (1, 0.8), (3, 0.7), (7, 0.5)]
    assert ck.saved[0][2]["w"] == [1] and ck.saved[-1][2]["w"] == [8]
    ck_all = ModelCheckpoint(save_best_only=False)
    _, tr = make([ck_all])
    tr.fit(3)
    assert len(ck_all.saved) == 3


def test_callback_order_and_hooks():
    events = []

    class Recorder(Callback):
        def __init__(self, name):
            self.name = name

        def on_train_begin(self, trainer):
            events.append(("begin", self.name))

        def on_epoch_end(self, trainer, epoch, logs):
            events.append((epoch, self.name))
            if self.name == "b" and epoch == 1:
                trainer.stop_training = True

        def on_train_end(self, trainer):
            events.append(("end", self.name))

    _, tr = make([Recorder("a"), Recorder("b")])
    tr.fit(5)
    assert events == [("begin", "a"), ("begin", "b"), (0, "a"), (0, "b"), (1, "a"), (1, "b"), ("end", "a"), ("end", "b")]
    tr.fit(1)
    assert events[-1] == ("end", "b") and (0, "a") in events[8:]


def test_errors():
    _, tr = make([EarlyStopping(monitor="nope")])
    try:
        tr.fit(2)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError")
    try:
        EarlyStopping(mode="avg")
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
    bare = Trainer(lambda e: {"loss": 1.0})
    try:
        bare.get_state()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except RuntimeError:
        pass
    else:
        raise AssertionError("expected RuntimeError")
