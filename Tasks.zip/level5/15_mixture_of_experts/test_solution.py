import math
import time

import numpy as np

from starter import MoELayer

rng = np.random.default_rng(0)


def manual(moe, x, k, cap_factor=None):
    z = x @ moe.W_gate
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    N, E = p.shape
    chosen = [list(np.argsort(-p[n], kind="stable")[:k]) for n in range(N)]
    cap = math.ceil(cap_factor * N * k / E) if cap_factor else None
    load = [0] * E
    ok = {}
    for r in range(k):
        for n in range(N):
            e = chosen[n][r]
            if cap is None or load[e] < cap:
                load[e] += 1
                ok[(n, r)] = True
    y = np.zeros_like(x)
    for n in range(N):
        g = p[n, chosen[n]] / p[n, chosen[n]].sum()
        for r in range(k):
            if ok.get((n, r)):
                e = chosen[n][r]
                h = np.maximum(x[n] @ moe.W1[e] + moe.b1[e], 0)
                y[n] += g[r] * (h @ moe.W2[e] + moe.b2[e])
    dropped = N * k - len(ok)
    return y, np.array(load), dropped, p, chosen


def test_parameters_order():
    moe = MoELayer(6, 10, 4, seed=3)
    r = np.random.default_rng(3)
    np.testing.assert_allclose(moe.W_gate, r.normal(0, 0.1, (6, 4)))
    np.testing.assert_allclose(moe.W1[0], r.normal(0, 0.1, (6, 10)))
    np.testing.assert_allclose(moe.W2[0], r.normal(0, 0.1, (10, 6)))
    assert moe.W1.shape == (4, 6, 10) and moe.b2.shape == (4, 6)


def test_forward_no_capacity():
    moe = MoELayer(6, 10, 4, top_k=2, seed=1)
    x = rng.normal(size=(30, 6)) * 3
    y = moe.forward(x)
    ry, counts, dropped, p, chosen = manual(moe, x, 2)
    np.testing.assert_allclose(y, ry, atol=1e-10)
    np.testing.assert_allclose(moe.router_probs, p)
    np.testing.assert_array_equal(moe.topk_indices, np.array(chosen))
    assert moe.dropped == 0 and moe.expert_counts.sum() == 60


def test_forward_with_capacity():
    moe = MoELayer(6, 10, 4, top_k=2, capacity_factor=0.5, seed=2)
    x = rng.normal(size=(40, 6)) * 5
    y = moe.forward(x)
    ry, counts, dropped, _, _ = manual(moe, x, 2, 0.5)
    np.testing.assert_allclose(y, ry, atol=1e-10)
    np.testing.assert_array_equal(moe.expert_counts, counts)
    assert moe.dropped == dropped > 0
    assert moe.expert_counts.max() <= math.ceil(0.5 * 40 * 2 / 4)


def test_top1_and_aux_loss():
    moe = MoELayer(4, 8, 3, top_k=1, seed=4)
    x = rng.normal(size=(50, 4))
    y = moe.forward(x)
    p = moe.router_probs
    top = p.argmax(1)
    for n in (0, 7, 33):
        np.testing.assert_allclose(y[n], moe.expert(top[n], x[n:n + 1])[0], atol=1e-12)
    f = np.bincount(top, minlength=3) / 50
    assert np.isclose(moe.aux_loss, 3 * np.sum(f * p.mean(0)))
    uniform = MoELayer(4, 8, 3, top_k=1, seed=4)
    uniform.W_gate[:] = 0
    uniform.forward(x)
    assert np.isclose(uniform.aux_loss, 1.0)


def test_invalid_and_speed():
    try:
        MoELayer(4, 4, 2, top_k=3)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
    moe = MoELayer(64, 128, 8, top_k=2, capacity_factor=1.25)
    x = rng.normal(size=(4096, 64))
    t0 = time.perf_counter()
    y = moe.forward(x)
    assert y.shape == (4096, 64) and time.perf_counter() - t0 < 5
