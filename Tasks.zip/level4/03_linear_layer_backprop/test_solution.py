import numpy as np

from starter import Linear, MSELoss, ReLU, Sequential, train_regressor

rng = np.random.default_rng(1)


def test_linear_init_and_forward():
    lin = Linear(4, 3, seed=5)
    assert lin.W.shape == (4, 3) and lin.b.shape == (3,)
    assert np.all(np.abs(lin.W) <= 0.5) and np.all(lin.b == 0)
    np.testing.assert_allclose(lin.W, np.random.default_rng(5).uniform(-0.5, 0.5, size=(4, 3)))
    x = rng.normal(size=(2, 4))
    np.testing.assert_allclose(lin.forward(x), x @ lin.W)


def test_full_gradient_check():
    model = Sequential(Linear(3, 5, seed=0), ReLU(), Linear(5, 2, seed=1))
    loss_fn = MSELoss()
    x = rng.normal(size=(6, 3))
    y = rng.normal(size=(6, 2))
    loss_fn.forward(model.forward(x), y)
    dx = model.backward(loss_fn.backward())
    eps = 1e-6
    for p, g in zip(model.params(), model.grads()):
        num = np.zeros_like(p)
        for idx in np.ndindex(p.shape):
            old = p[idx]
            p[idx] = old + eps
            lp = loss_fn.forward(model.forward(x), y)
            p[idx] = old - eps
            lm = loss_fn.forward(model.forward(x), y)
            p[idx] = old
            num[idx] = (lp - lm) / (2 * eps)
        np.testing.assert_allclose(g, num, rtol=1e-5, atol=1e-8)
    num_dx = np.zeros_like(x)
    for idx in np.ndindex(x.shape):
        xp, xm = x.copy(), x.copy()
        xp[idx] += eps
        xm[idx] -= eps
        num_dx[idx] = (loss_fn.forward(model.forward(xp), y) - loss_fn.forward(model.forward(xm), y)) / (2 * eps)
    np.testing.assert_allclose(dx, num_dx, rtol=1e-5, atol=1e-8)


def test_params_grads_identity():
    model = Sequential(Linear(2, 2), ReLU(), Linear(2, 1))
    assert len(model.params()) == 4 and len(model.grads()) == 4
    w = model.params()[0]
    assert w is model.layers[0].W
    model.forward(np.ones((1, 2)))
    model.backward(np.ones((1, 1)))
    assert model.grads()[0] is model.layers[0].grads()[0]


def test_mse():
    loss = MSELoss()
    assert np.isclose(loss.forward(np.array([[1.0, 2.0]]), np.array([[0.0, 0.0]])), 2.5)
    np.testing.assert_allclose(loss.backward(), [[1.0, 2.0]])


def test_training_fits_nonlinear():
    X = np.linspace(-2, 2, 64).reshape(-1, 1)
    y = np.abs(X)
    model = Sequential(Linear(1, 16, seed=2), ReLU(), Linear(16, 1, seed=3))
    w_obj = model.params()[0]
    losses = train_regressor(model, X, y, lr=0.05, epochs=2000)
    assert losses[-1] < 0.01 < losses[0]
    assert model.params()[0] is w_obj
