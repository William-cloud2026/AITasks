import numpy as np

from starter import SemanticCache

VOCAB = ["capital", "france", "paris", "weather", "today", "germany", "berlin", "what", "is", "the"]


class Embedder:
    def __init__(self):
        self.calls = 0

    def __call__(self, text):
        self.calls += 1
        words = text.lower().replace("?", "").split()
        return np.array([words.count(w) for w in VOCAB], dtype=float)


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_hit_and_miss():
    emb = Embedder()
    c = SemanticCache(emb, threshold=0.6)
    c.put("what is the capital of france", "Paris")
    assert c.get("What is the capital of France?") == "Paris"
    assert c.get("capital france") == "Paris"
    assert c.get("weather today") is None
    assert (c.hits, c.misses) == (2, 1)
    assert emb.calls == 4


def test_threshold_and_best_match():
    c = SemanticCache(Embedder(), threshold=0.95)
    c.put("capital france", "Paris")
    c.put("capital germany", "Berlin")
    assert c.get("capital germany") == "Berlin"
    assert c.get("capital france paris") is None
    c2 = SemanticCache(Embedder(), threshold=0.5)
    c2.put("capital france", "Paris")
    c2.put("capital germany", "Berlin")
    assert c2.get("france capital") == "Paris"


def test_zero_vector_never_matches():
    c3 = SemanticCache(Embedder(), threshold=0.1)
    c3.put("xyz", "nothing")
    assert c3.get("qqq") is None


def test_lru_eviction():
    c = SemanticCache(Embedder(), threshold=0.99, max_entries=2)
    c.put("capital france", "Paris")
    c.put("capital germany", "Berlin")
    assert c.get("capital france") == "Paris"
    c.put("weather today", "Sunny")
    assert len(c) == 2
    assert c.get("capital germany") is None
    assert c.get("capital france") == "Paris"


def test_replace_same_query():
    c = SemanticCache(Embedder(), threshold=0.99, max_entries=2)
    c.put("capital france", "Paris")
    c.put("capital germany", "Berlin")
    c.put("capital france", "Paris!")
    c.put("weather today", "Sunny")
    assert c.get("capital france") == "Paris!"
    assert c.get("capital germany") is None
    assert len(c) == 2


def test_ttl():
    clk = Clock()
    c = SemanticCache(Embedder(), threshold=0.9, ttl=10, clock=clk)
    c.put("capital france", "Paris")
    clk.t = 9.9
    assert c.get("capital france") == "Paris"
    clk.t = 10.0
    assert c.get("capital france") is None
    assert len(c) == 0
