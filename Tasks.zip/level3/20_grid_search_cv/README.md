# L3-20 · Hyperparameter Grid Search with Cross-Validation

**Level:** 3 · **Topics:** experiment orchestration, model selection · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `parameter_grid(param_grid) -> list[dict]`
`param_grid` is a dict `{name: list_of_values}` **or** a list of such dicts (results concatenated in order).
Keys are processed in **sorted** order; the cartesian product iterates the **last** sorted key fastest
(like `itertools.product`). Values keep their given order. `{}` → `[{}]`.

### `class GridSearchCV(make_model, param_grid, cv=3, scoring=None)`
- `make_model(**params)` returns an object with `fit(X, y)` and `predict(X)`.
- `cv` is the number of **contiguous, unshuffled** folds: the first `n % cv` folds get one extra sample.
- `scoring(y_true, y_pred)` → higher is better; default = accuracy.
- `fit(X, y)`:
  - For each parameter combination (in `parameter_grid` order), score on each fold (fresh model per fold).
  - `results_`: list of dicts `{"params", "scores" (list), "mean_score", "std_score" (population std)}`.
  - `best_index_`: **first** combination with the maximum mean score; `best_params_`, `best_score_`.
  - Refit a fresh model with the best params on all data → `best_model_`. Return `self`.
- `predict(X)` delegates to `best_model_`.
