import numpy as np

from starter import alibi_bias, alibi_slopes, apply_rope, sinusoidal_encoding

rng = np.random.default_rng(0)


def test_sinusoidal():
    pe = sinusoidal_encoding(50, 16)
    assert pe.shape == (50, 16)
    np.testing.assert_allclose(pe[0, 0::2], 0)
    np.testing.assert_allclose(pe[0, 1::2], 1)
    np.testing.assert_allclose(pe[7, 4], np.sin(7 / 10000 ** (4 / 16)))
    np.testing.assert_allclose(pe[7, 5], np.cos(7 / 10000 ** (4 / 16)))


def test_rope_exact_small():
    x = np.array([[1.0, 2.0, 3.0, 4.0]] * 2)
    out = apply_rope(x)
    np.testing.assert_allclose(out[0], x[0])
    a0, a1 = 1.0, 1.0 * 10000 ** (-0.5)
    expected = [1 * np.cos(a0) - 3 * np.sin(a0), 2 * np.cos(a1) - 4 * np.sin(a1),
                1 * np.sin(a0) + 3 * np.cos(a0), 2 * np.sin(a1) + 4 * np.cos(a1)]
    np.testing.assert_allclose(out[1], expected)


def test_rope_norm_and_relative():
    q = rng.normal(size=(2, 3, 10, 8))
    out = apply_rope(q)
    np.testing.assert_allclose(np.linalg.norm(out, axis=-1), np.linalg.norm(q, axis=-1))
    a, b = rng.normal(size=8), rng.normal(size=8)
    def dot(m, n):
        return apply_rope(a[None], positions=[m]) [0] @ apply_rope(b[None], positions=[n])[0]
    assert np.isclose(dot(5, 2), dot(103, 100))
    assert np.isclose(dot(0, 0), a @ b)


def test_rope_custom_positions_and_base():
    x = rng.normal(size=(4, 6))
    np.testing.assert_allclose(apply_rope(x, positions=np.arange(4)), apply_rope(x))
    assert not np.allclose(apply_rope(x, base=100.0), apply_rope(x))


def test_alibi():
    np.testing.assert_allclose(alibi_slopes(8), [2 ** -1, 2 ** -2, 2 ** -3, 2 ** -4, 2 ** -5, 2 ** -6, 2 ** -7, 2 ** -8])
    b = alibi_bias(4, 3)
    assert b.shape == (4, 3, 3)
    np.testing.assert_allclose(b[0], 0.25 * np.array([[0, 1, 2], [-1, 0, 1], [-2, -1, 0]]))


def test_errors():
    for fn in (lambda: sinusoidal_encoding(4, 5), lambda: apply_rope(np.zeros((2, 3))), lambda: alibi_slopes(6)):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
