# L5-01 · Mini-GPT Forward Pass

**Level:** 5 · **Topics:** transformer architecture, weight layouts, causal LM inference · **Time:** ~90 min · **Allowed:** Python stdlib + numpy

## Task
Implement a GPT-2-style decoder-only transformer **forward pass** from a dict of numpy weights.

### Config
`config = {"vocab_size": V, "d_model": d, "n_heads": H, "n_layers": L, "max_seq_len": T_max}`

### Weights (`weights` dict)
| Key | Shape |
|---|---|
| `wte` | `(V, d)` token embeddings (also the **tied** output projection) |
| `wpe` | `(T_max, d)` learned position embeddings |
| `h{i}.ln1.g`, `h{i}.ln1.b`, `h{i}.ln2.g`, `h{i}.ln2.b` | `(d,)` |
| `h{i}.attn.w_qkv`, `h{i}.attn.b_qkv` | `(d, 3d)`, `(3d,)` — columns `[0:d]` = Q, `[d:2d]` = K, `[2d:3d]` = V |
| `h{i}.attn.w_o`, `h{i}.attn.b_o` | `(d, d)`, `(d,)` |
| `h{i}.mlp.w1`, `h{i}.mlp.b1`, `h{i}.mlp.w2`, `h{i}.mlp.b2` | `(d, 4d)`, `(4d,)`, `(4d, d)`, `(d,)` |
| `lnf.g`, `lnf.b` | `(d,)` final LayerNorm |

### Computation (pre-LN)
```
x = wte[ids] + wpe[0:T]
for each layer i:
    a = LN1(x);  q, k, v = split(a @ w_qkv + b_qkv)
    heads: head h uses feature columns h*dh:(h+1)*dh of q, k, v   (dh = d / H)
    causal softmax(q kᵀ / sqrt(dh)) v  → concat heads → @ w_o + b_o
    x = x + attn_out
    m = LN2(x);  x = x + (GELU(m @ w1 + b1) @ w2 + b2)
logits = LNf(x) @ wte.T
```
LayerNorm: biased variance, `eps = 1e-5`. GELU: tanh approximation.

### API
- `gpt_forward(ids, weights, config) -> logits`: `ids` int array `(T,)` → `(T, V)`, or `(B, T)` → `(B, T, V)`.
  `T > max_seq_len` → `ValueError`.
- `count_parameters(config) -> int`: total number of scalars in the weights dict above.
