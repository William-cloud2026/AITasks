import numpy as np

from starter import BatchNorm1d

rng = np.random.default_rng(0)
X = rng.normal(3, 2, size=(8, 4))


def test_training_forward():
    bn = BatchNorm1d(4)
    y = bn.forward(X)
    np.testing.assert_allclose(y.mean(0), 0, atol=1e-10)
    np.testing.assert_allclose(y.var(0), X.var(0) / (X.var(0) + 1e-5), rtol=1e-8)
    bn.gamma[:] = 2
    bn.beta[:] = -1
    y = bn.forward(X)
    np.testing.assert_allclose(y.mean(0), -1, atol=1e-10)


def test_running_stats():
    bn = BatchNorm1d(4, momentum=0.2)
    bn.forward(X)
    bn.forward(X + 1)
    m1 = 0.8 * 0 + 0.2 * X.mean(0)
    m2 = 0.8 * m1 + 0.2 * (X + 1).mean(0)
    v1 = 0.8 * 1 + 0.2 * X.var(0, ddof=1)
    v2 = 0.8 * v1 + 0.2 * X.var(0, ddof=1)
    np.testing.assert_allclose(bn.running_mean, m2)
    np.testing.assert_allclose(bn.running_var, v2)


def test_eval_mode():
    bn = BatchNorm1d(4)
    bn.forward(X)
    bn.eval()
    rm, rv = bn.running_mean.copy(), bn.running_var.copy()
    y = bn.forward(X[:1])
    np.testing.assert_allclose(y, (X[:1] - rm) / np.sqrt(rv + 1e-5))
    np.testing.assert_array_equal(bn.running_mean, rm)
    assert bn.train() is bn and bn.training


def test_backward_numeric():
    bn = BatchNorm1d(4)
    bn.gamma = rng.normal(size=4)
    bn.beta = rng.normal(size=4)
    g = rng.normal(size=X.shape)
    bn.forward(X)
    dx = bn.backward(g)

    def loss(x=X, gamma=None, beta=None):
        b = BatchNorm1d(4)
        b.gamma = bn.gamma if gamma is None else gamma
        b.beta = bn.beta if beta is None else beta
        return (b.forward(x) * g).sum()

    eps = 1e-6
    num = np.zeros_like(X)
    for idx in np.ndindex(X.shape):
        xp, xm = X.copy(), X.copy()
        xp[idx] += eps
        xm[idx] -= eps
        num[idx] = (loss(xp) - loss(xm)) / (2 * eps)
    np.testing.assert_allclose(dx, num, rtol=1e-5, atol=1e-7)
    for name in ("gamma", "beta"):
        base = getattr(bn, name)
        numg = np.zeros(4)
        for i in range(4):
            p, m = base.copy(), base.copy()
            p[i] += eps
            m[i] -= eps
            numg[i] = (loss(**{name: p}) - loss(**{name: m})) / (2 * eps)
        np.testing.assert_allclose(getattr(bn, "d" + name), numg, rtol=1e-5, atol=1e-7)


def test_single_sample_training_error():
    try:
        BatchNorm1d(3).forward(np.ones((1, 3)))
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
