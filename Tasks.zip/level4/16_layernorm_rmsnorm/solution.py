import numpy as np


class LayerNorm:
    """Layer normalization over the last dimension."""

    def __init__(self, d, eps=1e-5):
        self.gamma, self.beta, self.eps = np.ones(d), np.zeros(d), eps

    def forward(self, x):
        x = np.asarray(x, dtype=float)
        mu = x.mean(-1, keepdims=True)
        self.inv = 1.0 / np.sqrt(x.var(-1, keepdims=True) + self.eps)
        self.xh = (x - mu) * self.inv
        return self.gamma * self.xh + self.beta

    def backward(self, dout):
        lead = tuple(range(dout.ndim - 1))
        self.dgamma = (dout * self.xh).sum(lead)
        self.dbeta = dout.sum(lead)
        g = dout * self.gamma
        return self.inv * (g - g.mean(-1, keepdims=True) - self.xh * (g * self.xh).mean(-1, keepdims=True))


class RMSNorm:
    """Root-mean-square normalization over the last dimension."""

    def __init__(self, d, eps=1e-6):
        self.gamma, self.eps = np.ones(d), eps

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        self.inv = 1.0 / np.sqrt((self.x ** 2).mean(-1, keepdims=True) + self.eps)
        return self.gamma * self.x * self.inv

    def backward(self, dout):
        lead = tuple(range(dout.ndim - 1))
        xh = self.x * self.inv
        self.dgamma = (dout * xh).sum(lead)
        g = dout * self.gamma
        return self.inv * (g - xh * (g * xh).mean(-1, keepdims=True))
