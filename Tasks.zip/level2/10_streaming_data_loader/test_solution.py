import itertools
import json
import os
import tempfile

from starter import interleave, read_jsonl, shuffle_buffer


def write(lines):
    fd, path = tempfile.mkstemp(suffix=".jsonl")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path


def test_read_jsonl():
    path = write([json.dumps({"text": "héllo", "label": 1}), "", "  ", json.dumps([1, 2])])
    try:
        assert list(read_jsonl(path)) == [{"text": "héllo", "label": 1}, [1, 2]]
    finally:
        os.remove(path)


def test_read_jsonl_error_line():
    path = write(['{"a": 1}', "", "{broken"])
    try:
        gen = read_jsonl(path)
        assert next(gen) == {"a": 1}
        try:
            next(gen)
        except ValueError as e:
            assert "line 3" in str(e)
        else:
            raise AssertionError("expected ValueError")
    finally:
        os.remove(path)


def test_shuffle_permutation_and_seed():
    data = list(range(1000))
    a = list(shuffle_buffer(data, 50, seed=7))
    b = list(shuffle_buffer(data, 50, seed=7))
    assert a == b
    assert sorted(a) == data
    assert a != data


def test_shuffle_locality():
    data = list(range(2000))
    k = 16
    out = list(shuffle_buffer(data, k, seed=1))
    for pos, item in enumerate(out):
        assert pos >= item - k + 1


def test_shuffle_edge_cases():
    assert list(shuffle_buffer(range(10), 1, seed=0)) == list(range(10))
    assert sorted(shuffle_buffer(range(5), 100, seed=0)) == list(range(5))
    assert list(shuffle_buffer([], 3)) == []
    try:
        shuffle_buffer([1], 0)
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError at call time")


def test_shuffle_lazy():
    out = list(itertools.islice(shuffle_buffer(itertools.count(), 8, seed=0), 20))
    assert len(set(out)) == 20


def test_interleave():
    assert list(interleave("abc", [1], (True, False))) == ["a", 1, True, "b", False, "c"]
    assert list(interleave()) == []
    assert list(itertools.islice(interleave(itertools.count(), "xy"), 6)) == [0, "x", 1, "y", 2, 3]
