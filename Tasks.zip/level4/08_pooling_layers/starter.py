# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

def maxpool2d_forward(x, kernel_size, stride=None):
    """Max pooling."""
    raise NotImplementedError('TODO')

def maxpool2d_backward(dout, cache):
    """Route gradients to the first argmax of each window."""
    raise NotImplementedError('TODO')

def avgpool2d_forward(x, kernel_size, stride=None):
    """Average pooling."""
    raise NotImplementedError('TODO')

def avgpool2d_backward(dout, cache):
    """Spread gradients evenly over each window."""
    raise NotImplementedError('TODO')

def global_avg_pool(x):
    """Mean over spatial dims."""
    raise NotImplementedError('TODO')

def global_avg_pool_backward(dout, x_shape):
    """Gradient of global_avg_pool."""
    raise NotImplementedError('TODO')
