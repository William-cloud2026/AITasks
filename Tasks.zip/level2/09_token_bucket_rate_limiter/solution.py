import time


class TokenBucket:
    """Continuous-refill token bucket."""

    def __init__(self, rate, capacity, clock=time.monotonic):
        if rate <= 0 or capacity <= 0:
            raise ValueError("rate and capacity must be > 0")
        self.rate = rate
        self.capacity = capacity
        self.clock = clock
        self._tokens = float(capacity)
        self._last = clock()

    def _refill(self):
        now = self.clock()
        self._tokens = min(self.capacity, self._tokens + (now - self._last) * self.rate)
        self._last = now

    def _check(self, tokens):
        if tokens <= 0 or tokens > self.capacity:
            raise ValueError("tokens must be in (0, capacity]")

    def available(self):
        """Current token count."""
        self._refill()
        return self._tokens

    def try_acquire(self, tokens=1):
        """Consume tokens if available."""
        self._check(tokens)
        self._refill()
        if self._tokens >= tokens:
            self._tokens -= tokens
            return True
        return False

    def wait_time(self, tokens=1):
        """Seconds until tokens are available."""
        self._check(tokens)
        self._refill()
        return max(0.0, (tokens - self._tokens) / self.rate)


class MultiKeyLimiter:
    """Independent token bucket per key."""

    def __init__(self, rate, capacity, clock=time.monotonic):
        if rate <= 0 or capacity <= 0:
            raise ValueError("rate and capacity must be > 0")
        self.rate, self.capacity, self.clock = rate, capacity, clock
        self._buckets = {}

    def try_acquire(self, key, tokens=1):
        """Acquire from the bucket for `key`."""
        b = self._buckets.get(key)
        if b is None:
            b = self._buckets[key] = TokenBucket(self.rate, self.capacity, self.clock)
        return b.try_acquire(tokens)
