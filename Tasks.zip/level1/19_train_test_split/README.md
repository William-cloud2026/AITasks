# L1-19 · Train/Test Split

**Level:** 1 · **Topics:** randomness, reproducibility, ML data handling · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
Implement `train_test_split(data, test_size=0.25, seed=None, shuffle=True, stratify=None) -> (train, test)`.

- `data` is a sequence; return two **lists**.
- `test_size`:
  - `float` in `(0, 1)` → `n_test = ceil(len(data) * test_size)`
  - `int` in `[1, len(data) - 1]` → `n_test = test_size`
  - anything else → `ValueError`. Also `len(data) < 2` → `ValueError`.
- `shuffle=False` → `train = data[:n - n_test]`, `test = data[n - n_test:]` (order preserved).
- `shuffle=True` → use `random.Random(seed)` (never the global `random` state). The same seed must produce the
  same split; every item appears in exactly one of the two outputs.
- `stratify` (optional, only with `shuffle=True`): a sequence of labels aligned with `data`. For each label, put
  `round(count_label * n_test / n)` of its items in the test set (so class proportions are preserved approximately).
  In this mode the size of test may differ slightly from `n_test`.
