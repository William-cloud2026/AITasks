import numpy as np

from starter import PCA

rng = np.random.default_rng(3)
A = rng.normal(size=(5, 5))
X = rng.normal(size=(300, 5)) @ np.diag([5, 3, 1, 0.5, 0.1]) @ np.linalg.qr(A)[0] + 7


def test_variances_match_covariance_eigs():
    p = PCA().fit(X)
    eig = np.sort(np.linalg.eigvalsh(np.cov(X, rowvar=False)))[::-1]
    np.testing.assert_allclose(p.explained_variance_, eig, rtol=1e-8)
    np.testing.assert_allclose(p.explained_variance_ratio_.sum(), 1.0)
    np.testing.assert_allclose(p.mean_, X.mean(0))


def test_components_orthonormal_and_signs():
    p = PCA(3).fit(X)
    C = p.components_
    assert C.shape == (3, 5) and p.n_components_ == 3
    np.testing.assert_allclose(C @ C.T, np.eye(3), atol=1e-10)
    for row in C:
        assert row[np.argmax(np.abs(row))] > 0


def test_reconstruction():
    p = PCA().fit(X)
    np.testing.assert_allclose(p.inverse_transform(p.transform(X)), X, atol=1e-8)
    p2 = PCA(2).fit(X)
    err2 = np.mean((p2.inverse_transform(p2.transform(X)) - X) ** 2)
    p4 = PCA(4).fit(X)
    err4 = np.mean((p4.inverse_transform(p4.transform(X)) - X) ** 2)
    assert err4 < err2


def test_float_components():
    full = PCA().fit(X)
    cum = np.cumsum(full.explained_variance_ratio_)
    p = PCA(0.9).fit(X)
    k = p.n_components_
    assert cum[k - 1] >= 0.9 and (k == 1 or cum[k - 2] < 0.9)


def test_whiten():
    p = PCA(3, whiten=True)
    Z = p.fit_transform(X)
    np.testing.assert_allclose(np.var(Z, axis=0, ddof=1), 1.0, rtol=1e-8)
    np.testing.assert_allclose(p.inverse_transform(Z), PCA(3).fit(X).inverse_transform(PCA(3).fit_transform(X)),
                               atol=1e-8)


def test_invalid():
    for nc in (0, 6, 1.5, -0.2):
        try:
            PCA(nc).fit(X)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {nc}")
