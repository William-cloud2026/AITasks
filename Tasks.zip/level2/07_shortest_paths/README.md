# L2-07 · Shortest Paths (BFS & Dijkstra)

**Level:** 2 · **Topics:** graphs, queues, heaps · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
### `bfs_path(graph, start, goal) -> list | None`
`graph` is an unweighted adjacency dict `{node: [neighbors...]}` (neighbors may be missing as keys — treat them
as having no outgoing edges). Return the shortest path as a list of nodes `[start, ..., goal]`, `None` if
unreachable. `start == goal` → `[start]`. Explore neighbors in the given list order.

### `dijkstra(graph, start) -> (dist, prev)`
`graph` is weighted: `{node: {neighbor: weight}}`. Return `dist` (node → shortest distance, only reachable nodes)
and `prev` (node → predecessor on a shortest path; `start` is not a key). Any negative weight → `ValueError`.
`start` not in graph → `KeyError`.

### `shortest_path(graph, start, goal) -> (cost, path)`
Uses `dijkstra`. Unreachable → `(math.inf, [])`.
