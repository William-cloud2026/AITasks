import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


def _windows(x, k, stride):
    stride = stride or k
    if x.shape[2] < k or x.shape[3] < k:
        raise ValueError("kernel larger than input")
    return sliding_window_view(x, (k, k), axis=(2, 3))[:, :, ::stride, ::stride], stride


def maxpool2d_forward(x, kernel_size, stride=None):
    """Max pooling."""
    x = np.asarray(x, dtype=float)
    win, stride = _windows(x, kernel_size, stride)
    N, C, Ho, Wo, k, _ = win.shape
    flat = win.reshape(N, C, Ho, Wo, k * k)
    arg = flat.argmax(-1)
    out = np.take_along_axis(flat, arg[..., None], -1)[..., 0]
    return out, (x.shape, arg, kernel_size, stride)


def maxpool2d_backward(dout, cache):
    """Route gradients to the first argmax of each window."""
    shape, arg, k, stride = cache
    N, C, Ho, Wo = arg.shape
    dx = np.zeros(shape)
    rows = (np.arange(Ho) * stride)[None, None, :, None] + arg // k
    cols = (np.arange(Wo) * stride)[None, None, None, :] + arg % k
    n = np.arange(N)[:, None, None, None]
    c = np.arange(C)[None, :, None, None]
    np.add.at(dx, (np.broadcast_to(n, arg.shape), np.broadcast_to(c, arg.shape), rows, cols), dout)
    return dx


def avgpool2d_forward(x, kernel_size, stride=None):
    """Average pooling."""
    x = np.asarray(x, dtype=float)
    win, stride = _windows(x, kernel_size, stride)
    return win.mean(axis=(-1, -2)), (x.shape, kernel_size, stride)


def avgpool2d_backward(dout, cache):
    """Spread gradients evenly over each window."""
    shape, k, stride = cache
    dx = np.zeros(shape)
    Ho, Wo = dout.shape[2], dout.shape[3]
    share = dout / (k * k)
    for p in range(k):
        for q in range(k):
            dx[:, :, p:p + stride * Ho:stride, q:q + stride * Wo:stride] += share
    return dx


def global_avg_pool(x):
    """Mean over spatial dims."""
    return np.asarray(x, dtype=float).mean(axis=(2, 3))


def global_avg_pool_backward(dout, x_shape):
    """Gradient of global_avg_pool."""
    H, W = x_shape[2], x_shape[3]
    return np.broadcast_to(dout[:, :, None, None] / (H * W), x_shape).copy()
