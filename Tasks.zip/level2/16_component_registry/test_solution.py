import copy

from starter import Registry


def make():
    reg = Registry("layers")

    @reg.register("linear")
    class Linear:
        def __init__(self, dim, act=None):
            self.dim, self.act = dim, act

    @reg.register()
    class ReLU:
        pass

    @reg.register
    class Sequential:
        def __init__(self, layers):
            self.layers = layers

    @reg.register("scaled")
    def scaled(x, k=2):
        return x * k

    return reg, Linear, ReLU, Sequential


def test_register_forms():
    reg, Linear, ReLU, Sequential = make()
    assert reg.names() == ["ReLU", "Sequential", "linear", "scaled"]
    assert reg.get("linear") is Linear and reg.get("ReLU") is ReLU and reg.get("Sequential") is Sequential
    assert "linear" in reg and "nope" not in reg and len(reg) == 4
    assert Linear.__name__ == "Linear"


def test_build_recursive():
    reg, Linear, ReLU, Sequential = make()
    cfg = {"type": "Sequential", "layers": [{"type": "linear", "dim": 4, "act": {"type": "ReLU"}},
                                            {"type": "linear", "dim": 2}, 7]}
    before = copy.deepcopy(cfg)
    m = reg.build(cfg)
    assert isinstance(m, Sequential)
    assert isinstance(m.layers[0], Linear) and isinstance(m.layers[0].act, ReLU)
    assert m.layers[1].dim == 2 and m.layers[2] == 7
    assert cfg == before
    assert reg.build({"type": "scaled", "x": 5}) == 10


def test_errors():
    reg, *_ = make()
    try:
        reg.register("linear")(object)
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError for duplicate")
    try:
        reg.get("lineer")
    except KeyError as e:
        assert "did you mean 'linear'" in str(e)
    else:
        raise AssertionError("expected KeyError")
    try:
        reg.build({"dim": 3})
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
