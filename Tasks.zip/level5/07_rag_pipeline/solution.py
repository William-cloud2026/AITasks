import re


def _default_count(text):
    return len(text.split())


def build_prompt(question, chunks, max_context_tokens, count_tokens=None):
    """Pack chunks into a prompt within a token budget."""
    count = count_tokens or _default_count
    used, total = [], 0
    for ch in chunks:
        n = count(ch["text"])
        if total + n > max_context_tokens:
            break
        used.append(ch)
        total += n
    lines = ["Answer the question using only the context below. Cite sources as [n].", "", "Context:"]
    lines += [f"[{i}] {ch['text']}" for i, ch in enumerate(used, 1)]
    lines += ["", f"Question: {question}", "Answer:"]
    return "\n".join(lines), used


def extract_citations(answer):
    """Sorted unique citation numbers."""
    nums = set()
    for group in re.findall(r"\[(\d+(?:\s*,\s*\d+)*)\]", answer):
        nums.update(int(x) for x in re.split(r"\s*,\s*", group))
    return sorted(nums)


class RAGPipeline:
    """Retrieve, pack, generate, validate citations."""

    def __init__(self, retriever, llm, max_context_tokens=500, top_k=5, count_tokens=None):
        self.retriever, self.llm = retriever, llm
        self.max_context_tokens, self.top_k, self.count_tokens = max_context_tokens, top_k, count_tokens

    def answer(self, question):
        """Answer a question with citations."""
        chunks = self.retriever(question, self.top_k)
        prompt, used = build_prompt(question, chunks, self.max_context_tokens, self.count_tokens)
        if not used:
            return {"answer": "I don't know.", "used_chunks": [], "citations": [], "invalid_citations": [],
                    "prompt": None}
        text = self.llm(prompt).strip()
        nums = extract_citations(text)
        valid = [n for n in nums if 1 <= n <= len(used)]
        return {
            "answer": text,
            "used_chunks": [c["id"] for c in used],
            "citations": [used[n - 1]["id"] for n in valid],
            "invalid_citations": [n for n in nums if not 1 <= n <= len(used)],
            "prompt": prompt,
        }
