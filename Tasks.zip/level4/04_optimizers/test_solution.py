import numpy as np

from starter import SGD, Adam, AdamW, RMSProp

G = [np.array([1.0, -2.0]), np.array([0.5, 0.5]), np.array([-1.0, 3.0])]


def run(opt_cls, steps=3, **kw):
    p = np.array([1.0, 1.0])
    obj = p
    opt = opt_cls([p], **kw)
    for g in G[:steps]:
        opt.step([g])
    assert p is obj
    return p


def test_sgd_plain_and_wd():
    np.testing.assert_allclose(run(SGD, lr=0.1), [1 - 0.1 * 0.5, 1 - 0.1 * 1.5])
    p = run(SGD, steps=1, lr=0.1, weight_decay=0.5)
    np.testing.assert_allclose(p, [1 - 0.1 * 1.5, 1 - 0.1 * (-1.5)])


def test_sgd_momentum_nesterov():
    for nesterov in (False, True):
        p = np.array([1.0, 1.0])
        buf = None
        for g in G:
            buf = g.copy() if buf is None else 0.9 * buf + g
            p = p - 0.1 * ((g + 0.9 * buf) if nesterov else buf)
        np.testing.assert_allclose(run(SGD, lr=0.1, momentum=0.9, nesterov=nesterov), p)


def test_rmsprop():
    p, v = np.array([1.0, 1.0]), np.zeros(2)
    for g in G:
        v = 0.9 * v + 0.1 * g * g
        p = p - 0.01 * g / (np.sqrt(v) + 1e-8)
    np.testing.assert_allclose(run(RMSProp, lr=0.01, alpha=0.9), p)


def adam_ref(decoupled, wd):
    p, m, v = np.array([1.0, 1.0]), np.zeros(2), np.zeros(2)
    for t, g in enumerate(G, 1):
        if decoupled:
            p = p * (1 - 0.01 * wd)
        else:
            g = g + wd * p
        m = 0.9 * m + 0.1 * g
        v = 0.999 * v + 0.001 * g * g
        p = p - 0.01 * (m / (1 - 0.9 ** t)) / (np.sqrt(v / (1 - 0.999 ** t)) + 1e-8)
    return p


def test_adam_and_adamw():
    np.testing.assert_allclose(run(Adam, lr=0.01), adam_ref(False, 0.0))
    np.testing.assert_allclose(run(Adam, lr=0.01, weight_decay=0.1), adam_ref(False, 0.1))
    np.testing.assert_allclose(run(AdamW, lr=0.01, weight_decay=0.1), adam_ref(True, 0.1))
    first = run(Adam, steps=1, lr=0.01)
    np.testing.assert_allclose(first, [1 - 0.01, 1 + 0.01], rtol=1e-6)


def test_mutable_lr_and_multiple_params():
    a, b = np.zeros(2), np.ones((2, 2))
    opt = SGD([a, b], lr=1.0)
    opt.lr = 0.5
    opt.step([np.ones(2), np.ones((2, 2))])
    np.testing.assert_allclose(a, -0.5)
    np.testing.assert_allclose(b, 0.5)


def test_rosenbrock_adam():
    p = np.array([-1.5, 2.0])
    opt = Adam([p], lr=0.02)
    for _ in range(5000):
        x, y = p
        g = np.array([-2 * (1 - x) - 400 * x * (y - x * x), 200 * (y - x * x)])
        opt.step([g])
    np.testing.assert_allclose(p, [1.0, 1.0], atol=0.05)


def test_validation():
    p = [np.zeros(1)]
    for fn in (lambda: SGD(p, lr=-1), lambda: SGD(p, lr=0.1, nesterov=True), lambda: Adam(p, betas=(1.0, 0.9)),
               lambda: SGD(p, lr=0.1, momentum=-0.5)):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
