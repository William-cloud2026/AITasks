# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import numbers

class Vector:
    """Immutable numeric vector."""
    __slots__ = ('_c',)

    def __init__(self, components):
        raise NotImplementedError('TODO')

    def __setattr__(self, name, value):
        raise NotImplementedError('TODO')

    def __delattr__(self, name):
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')

    def __iter__(self):
        raise NotImplementedError('TODO')

    def __getitem__(self, idx):
        raise NotImplementedError('TODO')

    def __add__(self, other):
        raise NotImplementedError('TODO')

    def __sub__(self, other):
        raise NotImplementedError('TODO')

    def __mul__(self, k):
        raise NotImplementedError('TODO')
    __rmul__ = __mul__

    def __truediv__(self, k):
        raise NotImplementedError('TODO')

    def __matmul__(self, other):
        raise NotImplementedError('TODO')

    def __neg__(self):
        raise NotImplementedError('TODO')

    def __abs__(self):
        raise NotImplementedError('TODO')

    def __eq__(self, other):
        raise NotImplementedError('TODO')

    def __hash__(self):
        raise NotImplementedError('TODO')

    def normalized(self):
        """Unit-length copy."""
        raise NotImplementedError('TODO')

    def cosine(self, other):
        """Cosine similarity."""
        raise NotImplementedError('TODO')

    def __repr__(self):
        raise NotImplementedError('TODO')
