import numpy as np


class BatchNorm1d:
    """Batch normalization over the batch dimension."""

    def __init__(self, num_features, eps=1e-5, momentum=0.1):
        self.eps, self.momentum = eps, momentum
        self.gamma = np.ones(num_features)
        self.beta = np.zeros(num_features)
        self.running_mean = np.zeros(num_features)
        self.running_var = np.ones(num_features)
        self.training = True

    def train(self):
        """Switch to training mode."""
        self.training = True
        return self

    def eval(self):
        """Switch to evaluation mode."""
        self.training = False
        return self

    def forward(self, x):
        """Normalize x."""
        x = np.asarray(x, dtype=float)
        if self.training:
            n = len(x)
            if n < 2:
                raise ValueError("need at least 2 samples in training mode")
            mean = x.mean(0)
            var = x.var(0)
            self.running_mean = (1 - self.momentum) * self.running_mean + self.momentum * mean
            self.running_var = (1 - self.momentum) * self.running_var + self.momentum * var * n / (n - 1)
        else:
            mean, var = self.running_mean, self.running_var
        self.inv_std = 1.0 / np.sqrt(var + self.eps)
        self.x_hat = (x - mean) * self.inv_std
        return self.gamma * self.x_hat + self.beta

    def backward(self, dout):
        """Gradients for a training-mode forward."""
        n = len(dout)
        self.dgamma = (dout * self.x_hat).sum(0)
        self.dbeta = dout.sum(0)
        dxh = dout * self.gamma
        return self.inv_std / n * (n * dxh - dxh.sum(0) - self.x_hat * (dxh * self.x_hat).sum(0))
