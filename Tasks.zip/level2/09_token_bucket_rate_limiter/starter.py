# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import time

class TokenBucket:
    """Continuous-refill token bucket."""

    def __init__(self, rate, capacity, clock=time.monotonic):
        raise NotImplementedError('TODO')

    def available(self):
        """Current token count."""
        raise NotImplementedError('TODO')

    def try_acquire(self, tokens=1):
        """Consume tokens if available."""
        raise NotImplementedError('TODO')

    def wait_time(self, tokens=1):
        """Seconds until tokens are available."""
        raise NotImplementedError('TODO')

class MultiKeyLimiter:
    """Independent token bucket per key."""

    def __init__(self, rate, capacity, clock=time.monotonic):
        raise NotImplementedError('TODO')

    def try_acquire(self, key, tokens=1):
        """Acquire from the bucket for `key`."""
        raise NotImplementedError('TODO')
