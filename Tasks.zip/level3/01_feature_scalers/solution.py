import numpy as np


def _as_2d(X):
    X = np.asarray(X, dtype=float)
    if X.ndim != 2:
        raise ValueError("expected a 2-D array")
    return X


class StandardScaler:
    """Standardize features to zero mean and unit variance."""

    def __init__(self, with_mean=True, with_std=True):
        self.with_mean = with_mean
        self.with_std = with_std
        self.mean_ = None

    def fit(self, X):
        """Compute mean and std."""
        X = _as_2d(X)
        self.mean_ = X.mean(axis=0)
        self.var_ = X.var(axis=0)
        scale = np.sqrt(self.var_)
        scale[scale == 0] = 1.0
        self.scale_ = scale
        return self

    def _check(self, X):
        if self.mean_ is None:
            raise RuntimeError("not fitted")
        X = _as_2d(X)
        if X.shape[1] != self.mean_.shape[0]:
            raise ValueError("feature count mismatch")
        return X

    def transform(self, X):
        """Standardize X."""
        X = self._check(X).copy()
        if self.with_mean:
            X = X - self.mean_
        if self.with_std:
            X = X / self.scale_
        return X

    def inverse_transform(self, X):
        """Undo standardization."""
        X = self._check(X).copy()
        if self.with_std:
            X = X * self.scale_
        if self.with_mean:
            X = X + self.mean_
        return X

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)


class MinMaxScaler:
    """Scale features to a given range."""

    def __init__(self, feature_range=(0, 1)):
        lo, hi = feature_range
        if lo >= hi:
            raise ValueError("invalid feature_range")
        self.feature_range = (lo, hi)
        self.scale_ = None

    def fit(self, X):
        """Compute per-feature min/max."""
        X = _as_2d(X)
        lo, hi = self.feature_range
        self.data_min_ = X.min(axis=0)
        self.data_max_ = X.max(axis=0)
        rng = self.data_max_ - self.data_min_
        rng[rng == 0] = 1.0
        self.scale_ = (hi - lo) / rng
        self.min_ = lo - self.data_min_ * self.scale_
        return self

    def _check(self, X):
        if self.scale_ is None:
            raise RuntimeError("not fitted")
        X = _as_2d(X)
        if X.shape[1] != self.scale_.shape[0]:
            raise ValueError("feature count mismatch")
        return X

    def transform(self, X):
        """Scale X."""
        return self._check(X) * self.scale_ + self.min_

    def inverse_transform(self, X):
        """Undo scaling."""
        return (self._check(X) - self.min_) / self.scale_

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)
