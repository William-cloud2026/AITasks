import numpy as np

from starter import GaussianAnomalyDetector, iqr_outliers, zscore_outliers


def test_zscore():
    x = np.array([10.0] * 20 + [50.0])
    mask = zscore_outliers(x)
    assert mask.tolist() == [False] * 20 + [True]
    assert not zscore_outliers(np.ones(5)).any()
    assert zscore_outliers([1, 2, 3], threshold=1.0).tolist() == [True, False, True]


def test_iqr():
    x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 100], dtype=float)
    assert iqr_outliers(x).tolist() == [False] * 8 + [True]
    assert iqr_outliers(x, k=100).sum() == 0


def test_mahalanobis():
    rng = np.random.default_rng(0)
    X = rng.multivariate_normal([0, 0], [[4, 1.9], [1.9, 1]], size=2000)
    det = GaussianAnomalyDetector(contamination=0.05).fit(X)
    np.testing.assert_allclose(det.mean_, X.mean(0))
    np.testing.assert_allclose(det.cov_, np.cov(X, rowvar=False, bias=True) + 1e-6 * np.eye(2))
    pts = np.array([[1.0, 2.0], [0.5, -0.2]])
    P = np.linalg.inv(det.cov_)
    ref = [np.sqrt((p - det.mean_) @ P @ (p - det.mean_)) for p in pts]
    np.testing.assert_allclose(det.score_samples(pts), ref)


def test_correlation_matters():
    rng = np.random.default_rng(1)
    X = rng.multivariate_normal([0, 0], [[1, 0.95], [0.95, 1]], size=3000)
    det = GaussianAnomalyDetector(contamination=0.01).fit(X)
    assert det.predict([[2.0, -2.0]])[0] == 1
    assert det.predict([[2.0, 2.0]])[0] == 0


def test_contamination_rate():
    rng = np.random.default_rng(2)
    X = rng.normal(size=(1000, 3))
    det = GaussianAnomalyDetector(contamination=0.1).fit(X)
    rate = det.predict(X).mean()
    assert 0.09 <= rate <= 0.11
    assert np.isclose(det.threshold_, np.quantile(det.score_samples(X), 0.9))


def test_invalid_contamination():
    for c in (0, 0.6, -1):
        try:
            GaussianAnomalyDetector(contamination=c)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
