import csv
import io
import re

_INT = re.compile(r"[+-]?\d+")
_FLOAT = re.compile(r"[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?")


def convert(value):
    """Convert one raw string field using the README rules."""
    v = value.strip()
    if v == "":
        return None
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    if _INT.fullmatch(v):
        return int(v)
    if _FLOAT.fullmatch(v):
        return float(v)
    return v


def parse_csv(text, delimiter=","):
    """Parse CSV text into a list of typed dicts."""
    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    header = None
    rows = []
    for row in reader:
        line_no = reader.line_num
        if not row or all(not f.strip() for f in row):
            continue
        if header is None:
            header = [h.strip() for h in row]
            if any(not h for h in header) or len(set(header)) != len(header):
                raise ValueError("empty or duplicate header names")
            continue
        if len(row) != len(header):
            raise ValueError(f"line {line_no}: expected {len(header)} fields, got {len(row)}")
        rows.append({h: convert(v) for h, v in zip(header, row)})
    return rows
