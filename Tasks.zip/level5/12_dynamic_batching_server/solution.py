import asyncio
import inspect


class DynamicBatcher:
    """Collects concurrent requests into model batches."""

    def __init__(self, model_fn, max_batch_size=8, max_wait_ms=5.0):
        self.model_fn = model_fn
        self.max_batch_size = max_batch_size
        self.max_wait = max_wait_ms / 1000.0
        self.batch_sizes = []
        self._queue = None
        self._worker = None
        self._running = False

    async def start(self):
        """Start the background worker."""
        self._queue = asyncio.Queue()
        self._running = True
        self._worker = asyncio.create_task(self._loop())

    async def stop(self):
        """Drain the queue and stop the worker."""
        self._running = False
        await self._queue.put(None)
        await self._worker

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *exc):
        await self.stop()

    async def submit(self, item):
        """Submit one request and wait for its result."""
        if not self._running:
            raise RuntimeError("batcher is not running")
        fut = asyncio.get_running_loop().create_future()
        await self._queue.put((item, fut))
        return await fut

    async def _loop(self):
        loop = asyncio.get_running_loop()
        stopping = False
        while not stopping:
            first = await self._queue.get()
            if first is None:
                break
            batch = [first]
            deadline = loop.time() + self.max_wait
            while len(batch) < self.max_batch_size:
                timeout = deadline - loop.time()
                try:
                    nxt = self._queue.get_nowait() if timeout <= 0 else await asyncio.wait_for(self._queue.get(), timeout)
                except (asyncio.QueueEmpty, asyncio.TimeoutError):
                    break
                if nxt is None:
                    stopping = True
                    break
                batch.append(nxt)
            await self._run(batch)
        while not self._queue.empty():
            item = self._queue.get_nowait()
            if item is not None:
                await self._run([item])

    async def _run(self, batch):
        inputs = [x for x, _ in batch]
        self.batch_sizes.append(len(batch))
        try:
            out = self.model_fn(inputs)
            if inspect.isawaitable(out):
                out = await out
            out = list(out)
            if len(out) != len(batch):
                raise ValueError("model returned wrong number of outputs")
        except Exception as exc:
            for _, fut in batch:
                if not fut.done():
                    fut.set_exception(exc)
            return
        for (_, fut), y in zip(batch, out):
            if not fut.done():
                fut.set_result(y)
