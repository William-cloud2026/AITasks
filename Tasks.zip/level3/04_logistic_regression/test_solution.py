import warnings

import numpy as np

from starter import LogisticRegression, bce_loss_and_grad, sigmoid

rng = np.random.default_rng(2)
X = np.vstack([rng.normal(-1.5, 1, size=(100, 2)), rng.normal(1.5, 1, size=(100, 2))])
y = np.array([0] * 100 + [1] * 100)


def test_sigmoid_stable():
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            v = sigmoid(np.array([-1e4, -50.0, 0.0, 50.0, 1e4]))
    np.testing.assert_allclose(v, [0, 1 / (1 + np.exp(50)), 0.5, 1 / (1 + np.exp(-50)), 1], atol=1e-15)
    assert abs(float(sigmoid(0.0)) - 0.5) < 1e-15


def test_loss_and_grad():
    w, b = np.array([0.3, -0.2]), 0.1
    loss, gw, gb = bce_loss_and_grad(X, y, w, b, l2=0.5)
    p = 1 / (1 + np.exp(-(X @ w + b)))
    ref = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)) + 0.25 * w @ w
    assert np.isclose(loss, ref)
    eps = 1e-6
    for i in range(2):
        e = np.zeros(2)
        e[i] = eps
        num = (bce_loss_and_grad(X, y, w + e, b, 0.5)[0] - bce_loss_and_grad(X, y, w - e, b, 0.5)[0]) / (2 * eps)
        assert np.isclose(gw[i], num, rtol=1e-5)
    num_b = (bce_loss_and_grad(X, y, w, b + eps, 0.5)[0] - bce_loss_and_grad(X, y, w, b - eps, 0.5)[0]) / (2 * eps)
    assert np.isclose(gb, num_b, rtol=1e-5)


def test_loss_extreme_logits_finite():
    with np.errstate(over="raise"):
        loss, _, _ = bce_loss_and_grad(np.array([[1000.0], [-1000.0]]), np.array([0, 1]), np.array([1.0]), 0.0)
    assert np.isclose(loss, 1000.0)


def test_fit_accuracy_and_history():
    m = LogisticRegression(lr=0.5, epochs=300).fit(X, y)
    assert np.mean(m.predict(X) == y) > 0.95
    h = np.array(m.loss_history_)
    assert len(h) == 300 and h[-1] < h[0] and np.all(np.diff(h) <= 1e-12)
    p = m.predict_proba(X)
    assert p.shape == (200,) and np.all((p > 0) & (p < 1))


def test_string_labels_and_threshold():
    labels = np.where(y == 1, "spam", "ham")
    m = LogisticRegression(lr=0.5, epochs=200).fit(X, labels)
    assert list(m.classes_) == ["ham", "spam"]
    assert set(m.predict(X)) <= {"ham", "spam"}
    assert np.all(m.predict(X, threshold=0.0) == "spam")


def test_bad_classes():
    try:
        LogisticRegression().fit(X, np.zeros(200))
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
