import unicodedata
from collections import Counter


def normalize_text(text, lowercase=True, strip_accents=True, remove_punctuation=True):
    """Normalize text according to the README pipeline."""
    if strip_accents:
        text = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))
    if lowercase:
        text = text.lower()
    if remove_punctuation:
        text = "".join(" " if unicodedata.category(c).startswith("P") else c for c in text)
    return " ".join(text.split())


def tokenize(text):
    """Normalize then split on whitespace."""
    return normalize_text(text).split()


def vocabulary(texts, min_count=1):
    """Build a frequency-sorted token->id mapping."""
    counts = Counter(t for text in texts for t in tokenize(text))
    kept = sorted((t for t, c in counts.items() if c >= min_count), key=lambda t: (-counts[t], t))
    return {t: i for i, t in enumerate(kept)}
