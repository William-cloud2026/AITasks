# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class Linear:
    """Fully connected layer."""

    def __init__(self, in_features, out_features, seed=0):
        raise NotImplementedError('TODO')

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, dout):
        raise NotImplementedError('TODO')

    def params(self):
        raise NotImplementedError('TODO')

    def grads(self):
        raise NotImplementedError('TODO')

class ReLU:
    """ReLU layer."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, dout):
        raise NotImplementedError('TODO')

    def params(self):
        raise NotImplementedError('TODO')

    def grads(self):
        raise NotImplementedError('TODO')

class Sequential:
    """Chain of layers."""

    def __init__(self, *layers):
        raise NotImplementedError('TODO')

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, dout):
        raise NotImplementedError('TODO')

    def params(self):
        raise NotImplementedError('TODO')

    def grads(self):
        raise NotImplementedError('TODO')

class MSELoss:
    """Mean squared error."""

    def forward(self, pred, target):
        raise NotImplementedError('TODO')

    def backward(self):
        raise NotImplementedError('TODO')

def train_regressor(model, X, y, lr=0.05, epochs=500):
    """Full-batch SGD training loop."""
    raise NotImplementedError('TODO')
