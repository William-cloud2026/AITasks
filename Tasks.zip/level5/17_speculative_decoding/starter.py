# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def speculative_decode(target_logits_fn, draft_logits_fn, prompt, max_new_tokens, k=4, eos_id=None):
    """Greedy speculative decoding."""
    raise NotImplementedError('TODO')
