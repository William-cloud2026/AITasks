# L4-08 · Pooling Layers (Forward & Backward)

**Level:** 4 · **Topics:** CNNs, gradient routing, vectorization · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
Layout NCHW, no padding. `stride=None` means `stride = kernel_size`. Output size
`H_out = (H − k) // stride + 1`. Kernel larger than the input → `ValueError`.

| Function | Behaviour |
|---|---|
| `maxpool2d_forward(x, kernel_size, stride=None) -> (out, cache)` | max over each window |
| `maxpool2d_backward(dout, cache) -> dx` | the gradient of each window goes **only to the first** maximal element in row-major order within that window; with overlapping windows contributions **add up** |
| `avgpool2d_forward(x, kernel_size, stride=None) -> (out, cache)` | mean over each window |
| `avgpool2d_backward(dout, cache) -> dx` | spread evenly over the window (accumulating on overlaps) |
| `global_avg_pool(x) -> out (N, C)` and `global_avg_pool_backward(dout, x_shape) -> dx` | mean over `H, W` |
