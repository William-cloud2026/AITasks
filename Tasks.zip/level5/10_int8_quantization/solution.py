import numpy as np


def quantize_symmetric(x, bits=8, axis=None):
    """Symmetric (zero-point 0) quantization."""
    if not 2 <= bits <= 8:
        raise ValueError("bits must be in 2..8")
    x = np.asarray(x, dtype=float)
    qmax = 2 ** (bits - 1) - 1
    if axis is None:
        m = float(np.abs(x).max()) if x.size else 0.0
        scale = m / qmax if m > 0 else 1.0
    else:
        axis = axis % x.ndim
        other = tuple(i for i in range(x.ndim) if i != axis)
        m = np.abs(x).max(axis=other, keepdims=True)
        scale = np.where(m > 0, m / qmax, 1.0)
    q = np.clip(np.round(x / scale), -qmax, qmax).astype(np.int8)
    return q, scale


def quantize_asymmetric(x, bits=8):
    """Affine quantization to unsigned integers."""
    if not 2 <= bits <= 8:
        raise ValueError("bits must be in 2..8")
    x = np.asarray(x, dtype=float)
    qmax = 2 ** bits - 1
    lo, hi = min(float(x.min()), 0.0), max(float(x.max()), 0.0)
    scale = (hi - lo) / qmax if hi > lo else 1.0
    zp = int(np.clip(np.round(-lo / scale), 0, qmax))
    q = np.clip(np.round(x / scale) + zp, 0, qmax).astype(np.uint8)
    return q, scale, zp


def dequantize(q, scale, zero_point=0):
    """Map integers back to floats."""
    return (np.asarray(q, dtype=float) - zero_point) * scale


def quantized_matmul(xq, x_scale, wq, w_scale):
    """Integer matmul with int32 accumulation."""
    acc = np.asarray(xq).astype(np.int32) @ np.asarray(wq).astype(np.int32)
    return acc * (x_scale * np.asarray(w_scale, dtype=float))


def quantize_linear_layer(W, bits=8):
    """Per-output-channel symmetric weight quantization."""
    return quantize_symmetric(W, bits, axis=1)
