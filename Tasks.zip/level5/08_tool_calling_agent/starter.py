# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import json
import re

class ToolError(Exception):
    """Raised when a tool call is invalid or fails."""

class ToolRegistry:
    """Named tools with argument schemas."""

    def __init__(self):
        raise NotImplementedError('TODO')

    def register(self, name, fn, schema, description=''):
        """Add a tool."""
        raise NotImplementedError('TODO')

    def call(self, name, arguments):
        """Validate arguments and run a tool."""
        raise NotImplementedError('TODO')

    def describe(self):
        """Human/LLM-readable tool list."""
        raise NotImplementedError('TODO')

def parse_action(text):
    """Classify an LLM reply as final / tool / invalid."""
    raise NotImplementedError('TODO')

class Agent:
    """ReAct-style loop over an injected LLM."""

    def __init__(self, llm, registry, max_steps=5, system_prompt=None):
        raise NotImplementedError('TODO')

    def run(self, task):
        """Run the agent until a final answer or max_steps."""
        raise NotImplementedError('TODO')
