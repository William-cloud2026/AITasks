# L2-16 · Component Registry & Config-Driven Builder

**Level:** 2 · **Topics:** decorators, factories, recursion, plugin patterns · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
ML frameworks register models/optimizers by name and build them from configs. Implement `class Registry(name)`.

| Member | Behaviour |
|---|---|
| `register(name=None)` | decorator registering a class/function. Forms: `@reg.register("mlp")`, `@reg.register()` and bare `@reg.register` (the latter two use `obj.__name__`). Returns the original object. Duplicate name → `KeyError` |
| `get(name)` | registered object. Unknown → `KeyError` whose message contains `did you mean 'X'` when `difflib.get_close_matches(name, names, n=1)` finds `X` |
| `build(config)` | `config` is a dict with a `"type"` key; remaining keys are keyword args. Any **dict value with a `"type"` key** (also inside lists) is built recursively first. Missing `"type"` → `ValueError`. Must not mutate `config` |
| `names()` | sorted list of names |
| `name in reg`, `len(reg)` | membership / count |

## Example
```python
MODELS = Registry("models")

@MODELS.register("linear")
class Linear:
    def __init__(self, dim, act=None): ...

MODELS.build({"type": "linear", "dim": 4, "act": {"type": "relu"}})
```
