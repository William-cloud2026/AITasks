import numpy as np

from starter import RNN, clip_grad_norm

rng = np.random.default_rng(0)


def test_init_and_forward():
    rnn = RNN(3, 4, seed=2)
    r = np.random.default_rng(2)
    np.testing.assert_allclose(rnn.Wx, r.uniform(-0.5, 0.5, size=(3, 4)))
    np.testing.assert_allclose(rnn.Wh, r.uniform(-0.5, 0.5, size=(4, 4)))
    x = rng.normal(size=(5, 2, 3))
    hs = rnn.forward(x)
    assert hs.shape == (5, 2, 4)
    h = np.zeros((2, 4))
    for t in range(5):
        h = np.tanh(x[t] @ rnn.Wx + h @ rnn.Wh + rnn.b)
    np.testing.assert_allclose(hs[-1], h)


def test_bptt_numeric():
    rnn = RNN(3, 4, seed=1)
    x = rng.normal(size=(6, 2, 3))
    h0 = rng.normal(size=(2, 4))
    g = rng.normal(size=(6, 2, 4))
    rnn.forward(x, h0)
    dx, dh0 = rnn.backward(g)
    grads = {"Wx": rnn.dWx.copy(), "Wh": rnn.dWh.copy(), "b": rnn.db.copy()}
    eps = 1e-6

    def loss():
        return (rnn.forward(x, h0) * g).sum()

    for name, arr in (("Wx", rnn.Wx), ("Wh", rnn.Wh), ("b", rnn.b), ("x", x), ("h0", h0)):
        num = np.zeros_like(arr)
        for idx in np.ndindex(arr.shape):
            old = arr[idx]
            arr[idx] = old + eps
            lp = loss()
            arr[idx] = old - eps
            lm = loss()
            arr[idx] = old
            num[idx] = (lp - lm) / (2 * eps)
        analytic = {"x": dx, "h0": dh0}.get(name, grads.get(name))
        np.testing.assert_allclose(analytic, num, rtol=1e-5, atol=1e-7, err_msg=name)


def test_only_last_step_gradient():
    rnn = RNN(2, 3)
    x = rng.normal(size=(4, 1, 2))
    rnn.forward(x)
    g = np.zeros((4, 1, 3))
    g[-1] = 1
    dx, _ = rnn.backward(g)
    assert np.all(np.abs(dx[0]) > 0)


def test_clip_grad_norm():
    a, b = np.array([3.0, 0.0]), np.array([[4.0]])
    ida = a
    total = clip_grad_norm([a, b], 1.0)
    assert np.isclose(total, 5.0) and a is ida
    np.testing.assert_allclose(a, [0.6, 0.0])
    np.testing.assert_allclose(b, [[0.8]])
    c = np.array([0.1, 0.2])
    assert np.isclose(clip_grad_norm([c], 1.0), np.sqrt(0.05))
    np.testing.assert_allclose(c, [0.1, 0.2])
