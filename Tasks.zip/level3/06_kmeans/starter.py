# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class KMeans:
    """Lloyd's k-means with k-means++ initialization."""

    def __init__(self, n_clusters, init='k-means++', n_init=10, max_iter=300, tol=1e-06, seed=0):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Cluster X."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Nearest center index."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Distances to centers."""
        raise NotImplementedError('TODO')
