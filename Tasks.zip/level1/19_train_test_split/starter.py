# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import random

def train_test_split(data, test_size=0.25, seed=None, shuffle=True, stratify=None):
    """Split data into (train, test) lists."""
    raise NotImplementedError('TODO')
