# L3-11 · Probabilistic & Ranking Metrics

**Level:** 3 · **Topics:** ROC, precision-recall, ties, O(n log n) algorithms · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
`y_true` is binary (`0/1`), `scores`/`probs` are real numbers. All functions take array-likes.

| Function | Definition |
|---|---|
| `roc_auc_score(y_true, scores)` | P(score of random positive > score of random negative), ties count ½. Only one class present → `ValueError`. Must be O(n log n) (test: 200 000 samples) |
| `roc_curve(y_true, scores)` | `(fpr, tpr, thresholds)`: thresholds = `[inf]` followed by the distinct scores in **descending** order; point `i` uses the rule `score >= thresholds[i]` |
| `average_precision_score(y_true, scores)` | `Σ_k (R_k − R_{k−1})·P_k` over distinct thresholds in descending order (`R_0 = 0`). No positives → `ValueError` |
| `log_loss(y_true, probs, eps=1e-15)` | mean binary cross-entropy with probs clipped to `[eps, 1 − eps]` |
| `brier_score(y_true, probs)` | `mean((p − y)²)` |

## Example
```python
roc_auc_score([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8])            # 0.75
average_precision_score([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8])  # 0.8333...
```
