# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def causal_mask(T):
    """Lower-triangular boolean mask."""
    raise NotImplementedError('TODO')

def scaled_dot_product_attention(q, k, v, mask=None):
    """Masked softmax attention."""
    raise NotImplementedError('TODO')

class MultiHeadAttention:
    """Multi-head attention with learned projections."""

    def __init__(self, d_model, n_heads, seed=0):
        raise NotImplementedError('TODO')

    def forward(self, x_q, x_kv=None, mask=None):
        """Attention forward pass."""
        raise NotImplementedError('TODO')
