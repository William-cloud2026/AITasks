# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
from collections import Counter
import numpy as np

class NGramLM:
    """Add-k smoothed n-gram language model."""

    def __init__(self, n=2, k=1.0):
        raise NotImplementedError('TODO')

    def fit(self, sentences):
        """Count n-grams."""
        raise NotImplementedError('TODO')

    def prob(self, word, context=()):
        """Smoothed conditional probability."""
        raise NotImplementedError('TODO')

    def sentence_logprob(self, sentence):
        """Log probability including </s>."""
        raise NotImplementedError('TODO')

    def perplexity(self, sentences):
        """Corpus perplexity."""
        raise NotImplementedError('TODO')

    def generate(self, max_len=20, seed=None):
        """Sample a sentence."""
        raise NotImplementedError('TODO')
