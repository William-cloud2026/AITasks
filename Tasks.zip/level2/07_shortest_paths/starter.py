# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import heapq
import math
from collections import deque

def bfs_path(graph, start, goal):
    """Shortest unweighted path or None."""
    raise NotImplementedError('TODO')

def dijkstra(graph, start):
    """Single-source shortest paths with non-negative weights."""
    raise NotImplementedError('TODO')

def shortest_path(graph, start, goal):
    """(cost, path) from start to goal."""
    raise NotImplementedError('TODO')
