# L1-10 · Chunking & Sliding Windows

**Level:** 1 · **Topics:** generators, iterators, laziness · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
Both functions accept **any iterable** (including infinite iterators) and must be **lazy**: they must not
consume more input than needed to produce the next item.

### `chunked(iterable, n)`
Yield consecutive **lists** of length `n`; the last chunk may be shorter. Empty input yields nothing.

### `sliding_window(iterable, n)`
Yield **tuples** of `n` consecutive items, advancing by one. If the input has fewer than `n` items, yield nothing.

### Validation
`n < 1` → `ValueError`, raised **immediately when the function is called** (not on first `next()`).

## Example
```python
list(chunked(range(7), 3))          # [[0, 1, 2], [3, 4, 5], [6]]
list(sliding_window("abcd", 2))     # [('a', 'b'), ('b', 'c'), ('c', 'd')]
```
