# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re

def luhn_valid(number):
    """Luhn checksum."""
    raise NotImplementedError('TODO')

def find_pii(text, types=None):
    """Detect PII spans with overlap resolution."""
    raise NotImplementedError('TODO')

def redact(text, types=None):
    """Replace PII with [TYPE] markers."""
    raise NotImplementedError('TODO')
