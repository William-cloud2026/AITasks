# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class ReLU:
    """Rectified linear unit."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class LeakyReLU:
    """Leaky ReLU."""

    def __init__(self, alpha=0.01):
        raise NotImplementedError('TODO')

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class Sigmoid:
    """Logistic sigmoid."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class Tanh:
    """Hyperbolic tangent."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class GELU:
    """GELU (tanh approximation)."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class Softplus:
    """log(1 + exp(x))."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')

class SiLU:
    """x * sigmoid(x)."""

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, grad_out):
        raise NotImplementedError('TODO')
