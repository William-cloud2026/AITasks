import numpy as np


def _scores(Q, X, metric):
    if metric == "l2":
        return np.maximum((Q ** 2).sum(1)[:, None] + (X ** 2).sum(1)[None] - 2 * Q @ X.T, 0.0)
    if metric == "cosine":
        Qn = Q / np.maximum(np.linalg.norm(Q, axis=1, keepdims=True), 1e-12)
        Xn = X / np.maximum(np.linalg.norm(X, axis=1, keepdims=True), 1e-12)
        return Qn @ Xn.T
    return Q @ X.T


def _topk(S, ids, k, metric):
    n = S.shape[1]
    order = np.argsort(S if metric == "l2" else -S, axis=1, kind="stable")[:, :k]
    sc = np.take_along_axis(S, order, 1)
    out_ids = np.asarray(ids)[order] if n else np.zeros((len(S), 0), dtype=int)
    if n < k:
        pad = np.inf if metric == "l2" else -np.inf
        sc = np.hstack([sc, np.full((len(S), k - n), pad)])
        out_ids = np.hstack([out_ids, np.full((len(S), k - n), -1)])
    return sc, out_ids.astype(int)


class FlatIndex:
    """Exact nearest-neighbor search."""

    def __init__(self, dim, metric="cosine"):
        if metric not in ("cosine", "ip", "l2"):
            raise ValueError("unknown metric")
        self.dim, self.metric = dim, metric
        self.X = np.zeros((0, dim))
        self.ids = np.zeros(0, dtype=int)

    def add(self, vectors, ids=None):
        """Append vectors."""
        V = np.asarray(vectors, dtype=float).reshape(-1, np.shape(vectors)[-1])
        if V.shape[1] != self.dim:
            raise ValueError("dimension mismatch")
        if ids is None:
            ids = np.arange(len(self.X), len(self.X) + len(V))
        self.X = np.vstack([self.X, V])
        self.ids = np.concatenate([self.ids, np.asarray(ids, dtype=int)])

    def search(self, queries, k):
        """Top-k scores and ids."""
        Q = np.atleast_2d(np.asarray(queries, dtype=float))
        return _topk(_scores(Q, self.X, self.metric), self.ids, k, self.metric)

    def __len__(self):
        return len(self.X)


class IVFIndex:
    """Inverted-file index with k-means coarse quantizer."""

    def __init__(self, dim, n_lists, metric="l2", n_probe=1, seed=0):
        if metric not in ("cosine", "ip", "l2"):
            raise ValueError("unknown metric")
        self.dim, self.n_lists, self.metric, self.n_probe, self.seed = dim, n_lists, metric, n_probe, seed
        self.centroids = None
        self.lists = [[] for _ in range(n_lists)]
        self.X = np.zeros((0, dim))
        self.ids = np.zeros(0, dtype=int)

    @property
    def is_trained(self):
        return self.centroids is not None

    def train(self, vectors, n_iter=20):
        """Learn coarse centroids with k-means."""
        X = np.asarray(vectors, dtype=float)
        rng = np.random.default_rng(self.seed)
        C = X[rng.choice(len(X), self.n_lists, replace=False)].copy()
        for _ in range(n_iter):
            lab = _scores(X, C, "l2").argmin(1)
            for j in range(self.n_lists):
                if np.any(lab == j):
                    C[j] = X[lab == j].mean(0)
        self.centroids = C

    def add(self, vectors, ids=None):
        """Assign vectors to inverted lists."""
        if not self.is_trained:
            raise RuntimeError("index not trained")
        V = np.asarray(vectors, dtype=float)
        if V.shape[1] != self.dim:
            raise ValueError("dimension mismatch")
        if ids is None:
            ids = np.arange(len(self.X), len(self.X) + len(V))
        start = len(self.X)
        self.X = np.vstack([self.X, V])
        self.ids = np.concatenate([self.ids, np.asarray(ids, dtype=int)])
        for pos, c in enumerate(_scores(V, self.centroids, "l2").argmin(1)):
            self.lists[c].append(start + pos)

    def search(self, queries, k):
        """Approximate top-k search."""
        Q = np.atleast_2d(np.asarray(queries, dtype=float))
        probes = np.argsort(_scores(Q, self.centroids, "l2"), axis=1, kind="stable")[:, :self.n_probe]
        all_s, all_i = [], []
        for q, pr in zip(Q, probes):
            rows = np.array(sorted(r for c in pr for r in self.lists[c]), dtype=int)
            s, i = _topk(_scores(q[None], self.X[rows].reshape(-1, self.dim), self.metric), self.ids[rows], k,
                         self.metric)
            all_s.append(s[0])
            all_i.append(i[0])
        return np.array(all_s), np.array(all_i)

    def __len__(self):
        return len(self.X)
