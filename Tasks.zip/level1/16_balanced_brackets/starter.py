# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def first_error_index(s):
    """Index of the first bracket error, or -1."""
    raise NotImplementedError('TODO')

def is_balanced(s):
    """True if brackets are balanced."""
    raise NotImplementedError('TODO')
