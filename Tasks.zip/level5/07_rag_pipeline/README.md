# L5-07 · RAG Pipeline: Context Packing & Citation Validation

**Level:** 5 · **Topics:** retrieval-augmented generation, prompt budgeting, output validation, dependency injection · **Time:** ~60 min · **Allowed:** Python stdlib

## Task
### `build_prompt(question, chunks, max_context_tokens, count_tokens=None) -> (prompt, used)`
- `chunks`: list of dicts `{"id", "text", "score"}` (already ranked). `count_tokens(text)` defaults to
  `len(text.split())`.
- Include chunks **in order**, stopping at the first chunk whose text would push the total (sum of chunk token counts)
  over `max_context_tokens`. `used` is the list of included chunk dicts.
- Exact prompt format (`n` is 1-based within the prompt):
```
Answer the question using only the context below. Cite sources as [n].

Context:
[1] <text of chunk 1>
[2] <text of chunk 2>

Question: <question>
Answer:
```
  i.e. lines joined by `"\n"`; with no chunks the `Context:` line is followed directly by the empty line.

### `extract_citations(answer) -> list[int]`
Find citation markers `[n]` and grouped markers like `[1, 3]` / `[2,4]` (regex `\[(\d+(?:\s*,\s*\d+)*)\]`). Return the
sorted unique integers.

### `class RAGPipeline(retriever, llm, max_context_tokens=500, top_k=5, count_tokens=None)`
`retriever(question, k) -> list[chunk]`, `llm(prompt) -> str`.

`answer(question) -> dict` with keys:
- `"answer"`: the LLM output stripped; if the retriever returned no chunks (or none fit), answer `"I don't know."`
  **without** calling the LLM.
- `"used_chunks"`: ids of included chunks, `"citations"`: chunk ids for the valid citation numbers (in ascending
  number order), `"invalid_citations"`: citation numbers outside `1..len(used)`, `"prompt"`: the prompt (or `None`).
