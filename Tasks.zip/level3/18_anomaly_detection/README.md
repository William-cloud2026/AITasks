# L3-18 · Statistical Anomaly Detection

**Level:** 3 · **Topics:** robust statistics, covariance, Mahalanobis distance · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `zscore_outliers(x, threshold=3.0) -> bool array`
`|x − mean| / std > threshold` using the population std; if `std == 0` nothing is an outlier.

### `iqr_outliers(x, k=1.5) -> bool array`
`Q1, Q3 = np.percentile(x, [25, 75])` (default linear interpolation); outliers are `< Q1 − k·IQR` or `> Q3 + k·IQR`.

### `class GaussianAnomalyDetector(contamination=0.05, reg=1e-6)`
- `contamination` must be in `(0, 0.5]` else `ValueError`.
- `fit(X)`: `mean_`, `cov_ = np.cov(X, rowvar=False, bias=True) + reg·I`, `precision_ = inv(cov_)`,
  `threshold_ = np.quantile(score_samples(X), 1 − contamination)`.
- `score_samples(X)` → Mahalanobis distance `sqrt((x − μ)ᵀ Σ⁻¹ (x − μ))` for each row (vectorized).
- `predict(X)` → `1` (anomaly) if score `> threshold_` else `0`.
