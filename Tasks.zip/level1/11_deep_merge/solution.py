import copy


def deep_merge(base, override, list_strategy="replace"):
    """Recursively merge override into a deep copy of base."""
    if list_strategy not in ("replace", "concat"):
        raise ValueError(f"unknown list_strategy: {list_strategy}")
    result = copy.deepcopy(base)
    for key, val in override.items():
        cur = result.get(key)
        if isinstance(cur, dict) and isinstance(val, dict):
            result[key] = deep_merge(cur, val, list_strategy)
        elif isinstance(cur, list) and isinstance(val, list) and list_strategy == "concat":
            result[key] = cur + copy.deepcopy(val)
        else:
            result[key] = copy.deepcopy(val)
    return result
