import math

import numpy as np

from starter import NGramLM

SENTS = [["i", "like", "cats"], ["i", "like", "dogs"], ["you", "like", "cats"]]


def test_vocab_and_bigram_probs():
    lm = NGramLM(n=2, k=1.0).fit(SENTS)
    assert lm.vocab == {"i", "like", "cats", "dogs", "you", "</s>", "<unk>"}
    V = 7
    assert math.isclose(lm.prob("i"), (2 + 1) / (3 + V))
    assert math.isclose(lm.prob("cats", ["i", "like"]), (2 + 1) / (3 + V))
    assert math.isclose(lm.prob("</s>", ["cats"]), (2 + 1) / (2 + V))
    assert math.isclose(lm.prob("zebra", ["like"]), 1 / (3 + V))


def test_probs_sum_to_one():
    for n in (1, 2, 3):
        lm = NGramLM(n=n, k=0.5).fit(SENTS)
        for ctx in ([], ["i"], ["i", "like"], ["unknown", "like"]):
            total = sum(lm.prob(w, ctx) for w in lm.vocab)
            assert math.isclose(total, 1.0), (n, ctx)


def test_trigram_context_padding():
    lm = NGramLM(n=3, k=1.0).fit(SENTS)
    V = 7
    assert math.isclose(lm.prob("i", []), (2 + 1) / (3 + V))
    assert math.isclose(lm.prob("like", ["i"]), (2 + 1) / (2 + V))
    assert math.isclose(lm.prob("dogs", ["you", "i", "like"]), (1 + 1) / (2 + V))


def test_unigram():
    lm = NGramLM(n=1, k=1.0).fit(SENTS)
    assert math.isclose(lm.prob("like", ["whatever"]), (3 + 1) / (12 + 7))


def test_logprob_and_perplexity():
    lm = NGramLM(n=2).fit(SENTS)
    s = ["i", "like", "dogs"]
    expected = sum(math.log(lm.prob(w, s[:i] if i else [])) for i, w in enumerate(s)) + math.log(lm.prob("</s>", s))
    assert math.isclose(lm.sentence_logprob(s), expected)
    ppl = lm.perplexity([s, ["you", "like", "cats"]])
    lp = lm.sentence_logprob(s) + lm.sentence_logprob(["you", "like", "cats"])
    assert math.isclose(ppl, math.exp(-lp / 8))
    assert lm.perplexity(SENTS) < NGramLM(n=1).fit(SENTS).perplexity(SENTS)


def test_generate():
    lm = NGramLM(n=2, k=0.01).fit(SENTS * 10)
    a = lm.generate(seed=3)
    assert a == lm.generate(seed=3)
    assert "</s>" not in a and "<s>" not in a and 0 < len(a) <= 20
    assert all(w in lm.vocab for w in a)
    assert len(lm.generate(max_len=2, seed=1)) <= 2


def test_invalid():
    for kw in ({"n": 0}, {"k": 0}):
        try:
            NGramLM(**kw)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
