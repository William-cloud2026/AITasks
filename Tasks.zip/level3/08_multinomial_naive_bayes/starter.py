# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re
import numpy as np

def count_vectorize(docs, vocabulary=None):
    """Bag-of-words count matrix."""
    raise NotImplementedError('TODO')

class MultinomialNB:
    """Multinomial naive Bayes with additive smoothing."""

    def __init__(self, alpha=1.0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Estimate class priors and feature likelihoods."""
        raise NotImplementedError('TODO')

    def predict_log_proba(self, X):
        """Normalized log posteriors."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Posterior probabilities."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Most probable class."""
        raise NotImplementedError('TODO')
