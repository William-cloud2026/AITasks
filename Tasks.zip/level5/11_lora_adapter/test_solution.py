import numpy as np

from starter import LoRALinear

rng = np.random.default_rng(0)
W0 = rng.normal(size=(12, 10))
B0 = rng.normal(size=10)
X = rng.normal(size=(5, 12))


def expect(fn, exc):
    try:
        fn()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except exc:
        return
    raise AssertionError(f"expected {exc.__name__}")


def test_init_identity_and_copies():
    lora = LoRALinear(W0, B0, r=3, alpha=6, seed=2)
    np.testing.assert_allclose(lora.forward(X), X @ W0 + B0)
    np.testing.assert_allclose(lora.A, np.random.default_rng(2).normal(0, 0.02, size=(12, 3)))
    assert lora.scaling == 2.0 and lora.trainable_parameters() == 3 * 22
    lora.W[0, 0] = 999
    assert W0[0, 0] != 999


def test_gradients():
    lora = LoRALinear(W0, B0, r=2, alpha=4)
    lora.B = rng.normal(size=(2, 10))
    g = rng.normal(size=(5, 10))
    lora.forward(X)
    dx = lora.backward(g)
    eps = 1e-6
    for name, grad in (("A", lora.dA.copy()), ("B", lora.dB.copy())):
        arr = getattr(lora, name)
        num = np.zeros_like(arr)
        for idx in np.ndindex(arr.shape):
            old = arr[idx]
            arr[idx] = old + eps
            lp = (lora.forward(X) * g).sum()
            arr[idx] = old - eps
            lm = (lora.forward(X) * g).sum()
            arr[idx] = old
            num[idx] = (lp - lm) / (2 * eps)
        np.testing.assert_allclose(grad, num, rtol=1e-5, atol=1e-8)
    full = W0 + lora.delta_weight()
    np.testing.assert_allclose(dx, g @ full.T, atol=1e-10)


def test_merge_unmerge():
    lora = LoRALinear(W0, B0, r=2)
    lora.B = rng.normal(size=(2, 10))
    before = lora.forward(X)
    lora.merge()
    np.testing.assert_allclose(lora.forward(X), before, atol=1e-10)
    np.testing.assert_allclose(lora.W, W0 + lora.delta_weight())
    expect(lora.merge, RuntimeError)
    expect(lambda: lora.backward(np.ones((5, 10))), RuntimeError)
    lora.unmerge()
    np.testing.assert_allclose(lora.W, W0, atol=1e-12)
    expect(lora.unmerge, RuntimeError)


def test_invalid_rank():
    expect(lambda: LoRALinear(W0, B0, r=0), ValueError)
    expect(lambda: LoRALinear(W0, B0, r=11), ValueError)


def test_finetune_low_rank_target():
    u, v = rng.normal(size=(12, 1)), rng.normal(size=(1, 10))
    target_W = W0 + 0.5 * u @ v
    Xtr = rng.normal(size=(200, 12))
    Y = Xtr @ target_W + B0
    lora = LoRALinear(W0, B0, r=1, alpha=1.0, seed=0)
    first = None
    for _ in range(3000):
        pred = lora.forward(Xtr)
        diff = pred - Y
        loss = np.mean(diff ** 2)
        first = loss if first is None else first
        lora.backward(2 * diff / diff.size)
        lora.A -= 0.5 * lora.dA
        lora.B -= 0.5 * lora.dB
    assert loss < 1e-3 * first
    np.testing.assert_array_equal(lora.W, W0)
