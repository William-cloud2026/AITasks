# L4-02 · Activation Functions (Forward & Backward)

**Level:** 4 · **Topics:** non-linearities, derivatives, numerical stability · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
Implement layer classes with `forward(x)` (caches what it needs) and `backward(grad_out) -> grad_in`, element-wise
on arrays of any shape:

| Class | Forward |
|---|---|
| `ReLU()` | `max(0, x)`; derivative at 0 is 0 |
| `LeakyReLU(alpha=0.01)` | `x` if `x > 0` else `alpha·x` |
| `Sigmoid()` | stable `1 / (1 + e^{−x})` |
| `Tanh()` | `tanh(x)` |
| `GELU()` | tanh approximation `0.5·x·(1 + tanh(√(2/π)·(x + 0.044715·x³)))` |
| `Softplus()` | `log(1 + e^x)` computed stably (`np.logaddexp`) |
| `SiLU()` | `x · sigmoid(x)` |

No overflow warnings for `|x|` up to `1e3`.
