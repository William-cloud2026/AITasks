import math


class Value:
    """Scalar with reverse-mode automatic differentiation."""

    def __init__(self, data, _parents=(), _op=""):
        self.data = float(data)
        self.grad = 0.0
        self._parents = _parents
        self._backward = lambda: None
        self._op = _op

    @staticmethod
    def _wrap(x):
        return x if isinstance(x, Value) else Value(x)

    def __add__(self, other):
        other = self._wrap(other)
        out = Value(self.data + other.data, (self, other), "+")

        def bw():
            self.grad += out.grad
            other.grad += out.grad

        out._backward = bw
        return out

    def __mul__(self, other):
        other = self._wrap(other)
        out = Value(self.data * other.data, (self, other), "*")

        def bw():
            self.grad += other.data * out.grad
            other.grad += self.data * out.grad

        out._backward = bw
        return out

    def __pow__(self, k):
        if not isinstance(k, (int, float)) or isinstance(k, bool):
            raise TypeError("exponent must be an int or float constant")
        out = Value(self.data ** k, (self,), "**")

        def bw():
            self.grad += k * self.data ** (k - 1) * out.grad

        out._backward = bw
        return out

    def _unary(self, value, local_grad, op):
        out = Value(value, (self,), op)

        def bw():
            self.grad += local_grad * out.grad

        out._backward = bw
        return out

    def exp(self):
        """e ** self."""
        e = math.exp(self.data)
        return self._unary(e, e, "exp")

    def log(self):
        """Natural log."""
        return self._unary(math.log(self.data), 1.0 / self.data, "log")

    def tanh(self):
        """Hyperbolic tangent."""
        t = math.tanh(self.data)
        return self._unary(t, 1 - t * t, "tanh")

    def relu(self):
        """max(0, x)."""
        return self._unary(max(0.0, self.data), 1.0 if self.data > 0 else 0.0, "relu")

    def sigmoid(self):
        """Logistic function."""
        x = self.data
        s = 1 / (1 + math.exp(-x)) if x >= 0 else math.exp(x) / (1 + math.exp(x))
        return self._unary(s, s * (1 - s), "sigmoid")

    def __neg__(self):
        return self * -1

    def __radd__(self, other):
        return self + other

    def __sub__(self, other):
        return self + (-self._wrap(other))

    def __rsub__(self, other):
        return self._wrap(other) + (-self)

    def __rmul__(self, other):
        return self * other

    def __truediv__(self, other):
        return self * self._wrap(other) ** -1

    def __rtruediv__(self, other):
        return self._wrap(other) * self ** -1

    def backward(self):
        """Back-propagate from this node."""
        order, seen = [], set()
        stack = [(self, False)]
        while stack:
            node, done = stack.pop()
            if done:
                order.append(node)
                continue
            if id(node) in seen:
                continue
            seen.add(id(node))
            stack.append((node, True))
            for p in node._parents:
                if id(p) not in seen:
                    stack.append((p, False))
        self.grad = 1.0
        for node in reversed(order):
            node._backward()

    def __repr__(self):
        return f"Value(data={self.data}, grad={self.grad})"
