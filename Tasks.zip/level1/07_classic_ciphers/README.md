# L1-07 · Caesar & Vigenère Ciphers

**Level:** 1 · **Topics:** ord/chr, modular arithmetic · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
Only ASCII letters `A-Z` / `a-z` are transformed; every other character passes through unchanged.
Letter case is preserved.

### `caesar(text, shift) -> str`
Shift letters by `shift` positions (any integer, may be negative or > 26).

### `vigenere_encrypt(text, key) -> str` and `vigenere_decrypt(text, key) -> str`
- `key` consists of ASCII letters only (case-insensitive, `A`/`a` = shift 0). Empty or non-letter key → `ValueError`.
- The key position advances **only when a letter is processed** (non-letters do not consume key characters).

## Example
```python
caesar("Hello, World!", 3)                 # 'Khoor, Zruog!'
vigenere_encrypt("ATTACK AT DAWN", "lemon")  # 'LXFOPV EF RNHR'
```
