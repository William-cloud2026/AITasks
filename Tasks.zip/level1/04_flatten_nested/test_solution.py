from starter import flatten


def test_full():
    assert flatten([1, [2, (3, [4])], "ab"]) == [1, 2, 3, 4, "ab"]


def test_depth():
    data = [1, [2, [3, [4]]]]
    assert flatten(data, depth=0) == [1, [2, [3, [4]]]]
    assert flatten(data, depth=1) == [1, 2, [3, [4]]]
    assert flatten(data, depth=2) == [1, 2, 3, [4]]
    assert flatten(data, depth=10) == [1, 2, 3, 4]


def test_atoms():
    assert flatten(["abc", b"x", {"k": 1}, {1}]) == ["abc", b"x", {"k": 1}, {1}]


def test_empty_inner():
    assert flatten([[], [[]], ()]) == []


def test_no_mutation():
    data = [1, [2, 3]]
    flatten(data)
    assert data == [1, [2, 3]]


def test_deep():
    x = [0]
    for i in range(1, 500):
        x = [x, i]
    assert flatten(x) == list(range(500))


def test_errors():
    for fn, exc in [(lambda: flatten("abc"), TypeError), (lambda: flatten([1], depth=-1), ValueError)]:
        try:
            fn()
        except exc:
            continue
        raise AssertionError(f"expected {exc.__name__}")
