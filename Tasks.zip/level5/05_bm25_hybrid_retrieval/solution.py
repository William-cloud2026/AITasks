import math
import re
from collections import Counter


def _tok(text):
    return re.findall(r"\w+", text.lower())


class BM25:
    """Okapi BM25 ranking."""

    def __init__(self, k1=1.5, b=0.75):
        self.k1, self.b = k1, b

    def fit(self, docs):
        """Index documents."""
        self.tfs = [Counter(_tok(d)) for d in docs]
        self.lens = [sum(tf.values()) for tf in self.tfs]
        self.N = len(docs)
        self.avgdl = sum(self.lens) / self.N if self.N else 0.0
        self.df = Counter(t for tf in self.tfs for t in tf)
        return self

    def idf(self, term):
        """Lucene-style idf."""
        df = self.df.get(term, 0)
        return math.log((self.N - df + 0.5) / (df + 0.5) + 1)

    def score(self, query, doc_index):
        """BM25 score of one document."""
        tf = self.tfs[doc_index]
        dl = self.lens[doc_index]
        s = 0.0
        for t in set(_tok(query)):
            f = tf.get(t, 0)
            if f:
                s += self.idf(t) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
        return s

    def search(self, query, k=10):
        """Top-k (index, score)."""
        scored = [(i, self.score(query, i)) for i in range(self.N)]
        scored = [x for x in scored if x[1] > 0]
        scored.sort(key=lambda x: (-x[1], x[0]))
        return scored[:k]


def reciprocal_rank_fusion(rankings, k=60, top_n=None):
    """Fuse ranked lists with RRF."""
    scores, best_rank, first_seen = {}, {}, {}
    order = 0
    for ranking in rankings:
        for r, d in enumerate(ranking, 1):
            scores[d] = scores.get(d, 0.0) + 1.0 / (k + r)
            best_rank[d] = min(best_rank.get(d, r), r)
            if d not in first_seen:
                first_seen[d] = order
                order += 1
    items = sorted(scores, key=lambda d: (-scores[d], best_rank[d], first_seen[d]))
    out = [(d, scores[d]) for d in items]
    return out if top_n is None else out[:top_n]


def hybrid_search(bm25, dense_scores, query, k=10, rrf_k=60):
    """Fuse BM25 and dense rankings."""
    lexical = [i for i, _ in bm25.search(query, k=bm25.N)]
    dense = sorted(range(len(dense_scores)), key=lambda i: (-dense_scores[i], i))
    return reciprocal_rank_fusion([lexical, dense], k=rrf_k, top_n=k)
