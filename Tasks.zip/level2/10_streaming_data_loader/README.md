# L2-10 · Streaming Data Loader

**Level:** 2 · **Topics:** generators, files, buffered shuffling · **Time:** ~40 min · **Allowed:** Python stdlib

## Task
Building blocks for streaming large training datasets that do not fit in memory.

### `read_jsonl(path)`
Generator yielding one parsed object per non-blank line of a UTF-8 file. Invalid JSON → `ValueError` whose message
contains `line N` (1-based physical line number). The file must be opened lazily and closed when the generator
finishes.

### `shuffle_buffer(iterable, buffer_size, seed=None)`
Approximate streaming shuffle (like `tf.data.Dataset.shuffle`):
fill a buffer with the first `buffer_size` items; then repeatedly pick a random buffer slot with
`random.Random(seed)`, yield that item and replace it with the next input item; when input is exhausted, yield
the remaining buffer items in random order. Requirements checked by tests:
- output is a permutation of the input; same seed → same output;
- the item at input index `i` is never yielded at an output position `< i - buffer_size + 1` (an item cannot move
  **earlier** by more than `buffer_size - 1` positions);
- `buffer_size == 1` → identity; `buffer_size < 1` → `ValueError` (raised at call time);
- must be lazy (works on infinite iterators).

### `interleave(*iterables)`
Round-robin over several iterables (`a0, b0, c0, a1, b1, ...`), skipping exhausted ones until all are exhausted.
