# L4-14 · Scaled Dot-Product & Multi-Head Attention

**Level:** 4 · **Topics:** transformers, masking, batched tensor ops · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
### `causal_mask(T) -> bool (T, T)`
`True` where key position `j <= i` (allowed).

### `scaled_dot_product_attention(q, k, v, mask=None) -> (out, weights)`
- `q (..., Tq, d)`, `k (..., Tk, d)`, `v (..., Tk, dv)`; leading batch/head dims broadcast.
- `scores = q kᵀ / sqrt(d)`; `mask` is a boolean array broadcastable to `(..., Tq, Tk)`, **`True` = may attend**.
- `weights = softmax(scores)` over keys with masked positions getting weight exactly `0`.
  A query row with **no** allowed key gets all-zero weights and a zero output (no NaN, no warning).
- `out = weights @ v`.

### `class MultiHeadAttention(d_model, n_heads, seed=0)`
- `d_model % n_heads != 0` → `ValueError`. `rng = np.random.default_rng(seed)`; weights `Wq, Wk, Wv, Wo`
  each `(d_model, d_model)` drawn in that order with `rng.normal(0, 0.02, ...)`; biases `bq, bk, bv, bo` zeros.
- `forward(x_q, x_kv=None, mask=None)`: `x_q (B, Tq, d_model)`, `x_kv` defaults to `x_q` (self-attention).
  Project (`x @ W + b`), split into heads → `(B, H, T, d_head)` (head `h` uses feature columns
  `h·d_head:(h+1)·d_head`), attend, merge heads back to `(B, Tq, d_model)`, project with `Wo, bo`.
  `mask` broadcastable to `(B, H, Tq, Tk)`. Store the weights `(B, H, Tq, Tk)` in `self.last_attn`.
