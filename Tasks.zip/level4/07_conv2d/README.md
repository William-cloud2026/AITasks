# L4-07 · 2-D Convolution (Forward & Backward)

**Level:** 4 · **Topics:** CNNs, im2col / strided tricks, vectorization · **Time:** ~75 min · **Allowed:** Python stdlib + numpy

## Task
Layout is **NCHW**. Implement (cross-correlation, like every DL framework):

### `conv2d_forward(x, w, b, stride=1, padding=0) -> (out, cache)`
- `x`: `(N, C, H, W)`, `w`: `(F, C, KH, KW)`, `b`: `(F,)`; zero padding on all four sides.
- `out`: `(N, F, H_out, W_out)` with `H_out = (H + 2·padding − KH) // stride + 1` (same for width).
- `out[n, f, i, j] = b[f] + Σ_{c,p,q} x_pad[n, c, i·stride + p, j·stride + q] · w[f, c, p, q]`.
- Channel mismatch or kernel larger than the padded input → `ValueError`.

### `conv2d_backward(dout, cache) -> (dx, dw, db)`
Exact gradients w.r.t. `x` (un-padded shape), `w` and `b`.

Must be **vectorized** (no Python loops over `N`, `H_out`, `W_out` simultaneously): a test runs a
`(8, 3, 32, 32)` input with 16 filters `3×3` forward + backward within 3 s.
