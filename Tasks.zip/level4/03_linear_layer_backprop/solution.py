import numpy as np


class Linear:
    """Fully connected layer."""

    def __init__(self, in_features, out_features, seed=0):
        rng = np.random.default_rng(seed)
        k = 1.0 / np.sqrt(in_features)
        self.W = rng.uniform(-k, k, size=(in_features, out_features))
        self.b = np.zeros(out_features)
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        return self.x @ self.W + self.b

    def backward(self, dout):
        self.dW[...] = self.x.T @ dout
        self.db[...] = dout.sum(0)
        return dout @ self.W.T

    def params(self):
        return [self.W, self.b]

    def grads(self):
        return [self.dW, self.db]


class ReLU:
    """ReLU layer."""

    def forward(self, x):
        self.mask = x > 0
        return x * self.mask

    def backward(self, dout):
        return dout * self.mask

    def params(self):
        return []

    def grads(self):
        return []


class Sequential:
    """Chain of layers."""

    def __init__(self, *layers):
        self.layers = list(layers)

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def backward(self, dout):
        for layer in reversed(self.layers):
            dout = layer.backward(dout)
        return dout

    def params(self):
        return [p for layer in self.layers for p in layer.params()]

    def grads(self):
        return [g for layer in self.layers for g in layer.grads()]


class MSELoss:
    """Mean squared error."""

    def forward(self, pred, target):
        self.diff = np.asarray(pred, dtype=float) - np.asarray(target, dtype=float)
        return float(np.mean(self.diff ** 2))

    def backward(self):
        return 2 * self.diff / self.diff.size


def train_regressor(model, X, y, lr=0.05, epochs=500):
    """Full-batch SGD training loop."""
    loss_fn = MSELoss()
    losses = []
    for _ in range(epochs):
        losses.append(loss_fn.forward(model.forward(X), y))
        model.backward(loss_fn.backward())
        for p, g in zip(model.params(), model.grads()):
            p -= lr * g
    return losses
