"""Offline test runner for the task suite (no pytest required).

Each task folder contains starter.py (the candidate's file), solution.py (the reference solution)
and test_solution.py. Tests import from `starter`; with --solution, solution.py is loaded in its place.

Examples
--------
python run_tests.py                           # every task, testing starter.py (candidate work)
python run_tests.py level2                    # one level
python run_tests.py level3/05_knn             # one task
python run_tests.py level1 -v                 # show each failing test's traceback
python run_tests.py --solution                # test the reference solution.py files instead
"""
import argparse
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent

BOOT = r"""
import importlib, importlib.util, json, os, sys, time, traceback
task, impl_file = sys.argv[1], sys.argv[2]
sys.path.insert(0, task)
os.chdir(task)
out = {"results": []}
try:
    spec = importlib.util.spec_from_file_location("starter", os.path.join(task, impl_file))
    mod = importlib.util.module_from_spec(spec)
    sys.modules["starter"] = mod
    spec.loader.exec_module(mod)
    tests = importlib.import_module("test_solution")
except BaseException:
    out["import_error"] = traceback.format_exc()
    print("@@RESULT@@" + json.dumps(out)); sys.exit(0)
fns = [f for n, f in vars(tests).items() if n.startswith("test_") and callable(f)]
fns.sort(key=lambda f: f.__code__.co_firstlineno)
for f in fns:
    try:
        f()
        out["results"].append({"name": f.__name__, "ok": True})
    except BaseException:
        out["results"].append({"name": f.__name__, "ok": False, "tb": traceback.format_exc(limit=-3)})
print("@@RESULT@@" + json.dumps(out))
"""


def find_tasks(targets):
    tasks = []
    for t in targets or ["."]:
        p = (ROOT / t).resolve()
        if (p / "test_solution.py").exists():
            tasks.append(p)
        else:
            tasks.extend(sorted(q.parent for q in p.glob("level*/*/test_solution.py")) or
                         sorted(q.parent for q in p.glob("*/test_solution.py")))
    return tasks


def run_task(task, impl_file, timeout):
    if not (task / impl_file).exists():
        return {"import_error": f"{impl_file} not found", "results": []}
    try:
        proc = subprocess.run([sys.executable, "-c", BOOT, str(task), impl_file],
                              capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"timeout": True, "results": []}
    marker = proc.stdout.rfind("@@RESULT@@")
    if marker < 0:
        return {"import_error": proc.stderr[-2000:] or "no result", "results": []}
    return json.loads(proc.stdout[marker + len("@@RESULT@@"):])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("targets", nargs="*")
    ap.add_argument("--solution", "--reference", dest="solution", action="store_true",
                    help="test solution.py instead of starter.py")
    ap.add_argument("-v", "--verbose", action="store_true")
    ap.add_argument("--timeout", type=int, default=120)
    args = ap.parse_args()
    impl_file = "solution.py" if args.solution else "starter.py"

    total_ok = total = 0
    for task in find_tasks(args.targets):
        res = run_task(task, impl_file, args.timeout)
        rel = task.relative_to(ROOT).as_posix()
        if res.get("timeout"):
            print(f"TIME  {rel}  (>{args.timeout}s)")
            continue
        if "import_error" in res:
            print(f"ERR   {rel}  (could not import {impl_file} or tests)")
            if args.verbose:
                print(res["import_error"])
            continue
        ok = sum(r["ok"] for r in res["results"])
        n = len(res["results"])
        total_ok += ok
        total += n
        print(f"{'PASS' if ok == n else 'FAIL'}  {rel}  {ok}/{n}")
        if args.verbose:
            for r in res["results"]:
                if not r["ok"]:
                    print(f"  - {r['name']}\n" + "\n".join("      " + l for l in r["tb"].splitlines()))
    print(f"\nTotal: {total_ok}/{total} tests passed ({impl_file})")


if __name__ == "__main__":
    main()
