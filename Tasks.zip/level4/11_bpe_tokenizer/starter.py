# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

from collections import Counter

class BPETokenizer:
    """Byte-level byte-pair-encoding tokenizer."""

    def __init__(self):
        raise NotImplementedError('TODO')

    def train(self, text, vocab_size):
        """Learn merges from text."""
        raise NotImplementedError('TODO')

    def encode(self, text):
        """Text -> token ids."""
        raise NotImplementedError('TODO')

    def decode(self, ids):
        """Token ids -> text."""
        raise NotImplementedError('TODO')
