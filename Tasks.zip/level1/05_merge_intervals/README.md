# L1-05 · Merge Intervals

**Level:** 1 · **Topics:** sorting, greedy · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
Implement:

### `merge_intervals(intervals) -> list[tuple]`
`intervals` is an iterable of `(start, end)` pairs (numbers, `start <= end`).
Merge intervals that overlap **or touch** (`(1, 3)` and `(3, 5)` → `(1, 5)`).
Return a list of tuples sorted by start. Input must not be mutated.

### `total_covered(intervals) -> number`
Total length covered by the union of the intervals (`sum(end - start)` after merging).

## Errors
- any pair with `start > end` → `ValueError`

## Example
```python
merge_intervals([(8, 10), (1, 3), (2, 6), (15, 18)])  # [(1, 6), (8, 10), (15, 18)]
total_covered([(1, 3), (2, 6)])                        # 5
```
