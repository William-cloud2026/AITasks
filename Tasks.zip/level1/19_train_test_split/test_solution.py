import random

from starter import train_test_split


def test_sizes_float_and_int():
    tr, te = train_test_split(list(range(10)), test_size=0.25, seed=0)
    assert len(te) == 3 and len(tr) == 7
    tr, te = train_test_split(list(range(10)), test_size=4, seed=0)
    assert len(te) == 4


def test_partition():
    data = list(range(100))
    tr, te = train_test_split(data, 0.3, seed=42)
    assert sorted(tr + te) == data
    assert not set(tr) & set(te)


def test_reproducible_and_seed_dependent():
    data = list(range(50))
    assert train_test_split(data, seed=1) == train_test_split(data, seed=1)
    assert any(train_test_split(data, seed=1)[1] != train_test_split(data, seed=s)[1] for s in range(2, 6))


def test_no_global_random_usage():
    random.seed(123)
    before = random.random()
    random.seed(123)
    train_test_split(list(range(20)), seed=5)
    assert random.random() == before


def test_no_shuffle():
    tr, te = train_test_split("abcdef", test_size=2, shuffle=False)
    assert tr == ["a", "b", "c", "d"] and te == ["e", "f"]


def test_stratify():
    data = list(range(100))
    labels = [0] * 80 + [1] * 20
    tr, te = train_test_split(data, 0.25, seed=3, stratify=labels)
    te_labels = [labels[i] for i in te]
    assert te_labels.count(0) == 20 and te_labels.count(1) == 5
    assert sorted(tr + te) == data


def test_invalid():
    for args in [([1], 0.5), ([1, 2, 3], 0.0), ([1, 2, 3], 1.0), ([1, 2, 3], 3), ([1, 2, 3], 0), ([1, 2], "x")]:
        try:
            train_test_split(*args)
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {args}")
