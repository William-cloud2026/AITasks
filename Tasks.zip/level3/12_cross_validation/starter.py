# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class KFold:
    """Contiguous k-fold splitter."""

    def __init__(self, n_splits=5, shuffle=False, seed=None):
        raise NotImplementedError('TODO')

    def split(self, n_samples):
        """Yield sorted (train, test) index arrays."""
        raise NotImplementedError('TODO')

class StratifiedKFold:
    """Class-balanced k-fold splitter."""

    def __init__(self, n_splits=5, shuffle=False, seed=None):
        raise NotImplementedError('TODO')

    def split(self, y):
        """Yield sorted (train, test) index arrays."""
        raise NotImplementedError('TODO')

def cross_val_score(make_model, X, y, cv, scoring):
    """Score a fresh model on each fold."""
    raise NotImplementedError('TODO')
