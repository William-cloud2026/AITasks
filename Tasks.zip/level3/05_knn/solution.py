import numpy as np


class _KNNBase:
    def __init__(self, k=5, metric="euclidean", weights="uniform"):
        if k < 1:
            raise ValueError("k must be >= 1")
        if metric not in ("euclidean", "manhattan"):
            raise ValueError("unknown metric")
        if weights not in ("uniform", "distance"):
            raise ValueError("unknown weights")
        self.k, self.metric, self.weights = k, metric, weights

    def _fit(self, X, y):
        self._X = np.asarray(X, dtype=float)
        self._y = np.asarray(y)

    def kneighbors(self, X):
        """Distances and indices of the k nearest training points."""
        Q = np.asarray(X, dtype=float)
        if self.metric == "euclidean":
            sq = (Q ** 2).sum(1)[:, None] + (self._X ** 2).sum(1)[None, :] - 2 * Q @ self._X.T
            D = np.sqrt(np.maximum(sq, 0.0))
        else:
            D = np.abs(Q[:, None, :] - self._X[None, :, :]).sum(-1)
        k = min(self.k, len(self._X))
        idx = np.argsort(D, axis=1, kind="stable")[:, :k]
        return np.take_along_axis(D, idx, axis=1), idx

    def _weights(self, dist):
        w = np.ones_like(dist) if self.weights == "uniform" else 1.0 / np.where(dist == 0, 1.0, dist)
        zero = dist == 0
        has_zero = zero.any(axis=1)
        w[has_zero] = zero[has_zero].astype(float)
        return w


class KNNClassifier(_KNNBase):
    """k-NN classifier."""

    def fit(self, X, y):
        """Store training data."""
        self._fit(X, y)
        self.classes_ = np.unique(self._y)
        return self

    def predict_proba(self, X):
        """Class probability estimates."""
        dist, idx = self.kneighbors(X)
        w = self._weights(dist)
        labels = np.searchsorted(self.classes_, self._y[idx])
        P = np.zeros((len(idx), len(self.classes_)))
        for j in range(idx.shape[1]):
            np.add.at(P, (np.arange(len(idx)), labels[:, j]), w[:, j])
        return P / P.sum(axis=1, keepdims=True)

    def predict(self, X):
        """Predicted labels."""
        return self.classes_[np.argmax(self.predict_proba(X), axis=1)]


class KNNRegressor(_KNNBase):
    """k-NN regressor."""

    def fit(self, X, y):
        """Store training data."""
        self._fit(X, np.asarray(y, dtype=float))
        return self

    def predict(self, X):
        """Weighted mean of neighbor targets."""
        dist, idx = self.kneighbors(X)
        w = self._weights(dist)
        return (w * self._y[idx]).sum(1) / w.sum(1)
