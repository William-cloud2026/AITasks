# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import functools
import time

def retry(max_attempts=3, exceptions=(Exception,), backoff=0.0, factor=2.0, sleep=time.sleep, on_retry=None):
    """Create a retry decorator."""
    raise NotImplementedError('TODO')
