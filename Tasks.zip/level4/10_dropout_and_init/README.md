# L4-10 · Dropout & Weight Initialization

**Level:** 4 · **Topics:** regularization, variance preservation, reproducible randomness · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `class Dropout(p=0.5, seed=0)`
- `0 <= p < 1` else `ValueError`. Uses `rng = np.random.default_rng(seed)` created once.
- `training` attribute (default `True`), `train()` / `eval()`.
- training: `mask = rng.random(x.shape) >= p`; `out = x * mask / (1 − p)` (inverted dropout). eval or `p == 0`:
  identity (no random numbers drawn).
- `backward(dout)` uses the last mask (identity in eval).

### Fan computation — `compute_fans(shape) -> (fan_in, fan_out)`
- 2-D weight `(in_features, out_features)` (our `x @ W` convention) → `(shape[0], shape[1])`.
- 4-D conv weight `(out_channels, in_channels, kh, kw)` → `(in_channels·kh·kw, out_channels·kh·kw)`.
- other ranks → `ValueError`.

### Initializers (all take `shape`, `rng` — a `np.random.Generator` — and return a new array)
| Function | Distribution |
|---|---|
| `xavier_uniform(shape, rng, gain=1.0)` | `U(−a, a)`, `a = gain·sqrt(6 / (fan_in + fan_out))` |
| `xavier_normal(shape, rng, gain=1.0)` | `N(0, std²)`, `std = gain·sqrt(2 / (fan_in + fan_out))` |
| `kaiming_uniform(shape, rng, mode="fan_in", nonlinearity="relu")` | `U(−a, a)`, `a = gain·sqrt(3 / fan)` |
| `kaiming_normal(shape, rng, mode="fan_in", nonlinearity="relu")` | `N(0, std²)`, `std = gain / sqrt(fan)` |

`gain` is `sqrt(2)` for `"relu"` and `1` for `"linear"`; `fan` = `fan_in` or `fan_out` per `mode`.
Use `rng.uniform` / `rng.normal`.
