# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import heapq

class CycleError(ValueError):
    """Raised when the dependency graph has a cycle."""

def topo_order(deps):
    """Lexicographically smallest topological order."""
    raise NotImplementedError('TODO')

def stages(deps):
    """Parallel execution stages."""
    raise NotImplementedError('TODO')

def find_cycle(deps):
    """Return a cycle [s0, ..., sk] or None."""
    raise NotImplementedError('TODO')
