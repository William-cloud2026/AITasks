import math

from starter import accuracy, confusion_matrix, f1_score, fbeta_score, precision, recall

Y_TRUE = [1, 0, 1, 1, 0, 0, 1, 0]
Y_PRED = [1, 0, 0, 1, 1, 0, 1, 0]


def test_confusion():
    assert confusion_matrix(Y_TRUE, Y_PRED) == {"tp": 3, "fp": 1, "tn": 3, "fn": 1}


def test_scores():
    assert math.isclose(accuracy(Y_TRUE, Y_PRED), 0.75)
    assert math.isclose(precision(Y_TRUE, Y_PRED), 0.75)
    assert math.isclose(recall(Y_TRUE, Y_PRED), 0.75)
    assert math.isclose(f1_score(Y_TRUE, Y_PRED), 0.75)


def test_fbeta():
    yt, yp = [1, 1, 1, 0], [1, 0, 0, 0]
    p, r = 1.0, 1 / 3
    assert math.isclose(fbeta_score(yt, yp, 2), 5 * p * r / (4 * p + r))
    assert math.isclose(fbeta_score(yt, yp, 0.5), 1.25 * p * r / (0.25 * p + r))


def test_zero_division():
    assert precision([1, 1], [0, 0]) == 0.0
    assert recall([0, 0], [1, 0]) == 0.0
    assert f1_score([0, 0], [0, 0]) == 0.0


def test_bools():
    assert confusion_matrix([True, False], [True, True]) == {"tp": 1, "fp": 1, "tn": 0, "fn": 0}


def test_errors():
    for fn in (lambda: accuracy([], []), lambda: accuracy([1], [1, 0]), lambda: accuracy([2], [1]),
               lambda: fbeta_score([1], [1], 0)):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
