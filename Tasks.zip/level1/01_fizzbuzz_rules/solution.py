def fizzbuzz(n, rules=None):
    """Return FizzBuzz strings for 1..n using (divisor, word) rules."""
    if rules is None:
        rules = [(3, "Fizz"), (5, "Buzz")]
    if n < 0:
        raise ValueError("n must be >= 0")
    for d, _ in rules:
        if d <= 0:
            raise ValueError("divisors must be positive")
    out = []
    for i in range(1, n + 1):
        s = "".join(w for d, w in rules if i % d == 0)
        out.append(s or str(i))
    return out
