# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import csv
import io
import re

def convert(value):
    """Convert one raw string field using the README rules."""
    raise NotImplementedError('TODO')

def parse_csv(text, delimiter=','):
    """Parse CSV text into a list of typed dicts."""
    raise NotImplementedError('TODO')
