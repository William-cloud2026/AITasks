import numpy as np


def sinusoidal_encoding(T, d):
    """Transformer sinusoidal positional encodings."""
    if d % 2:
        raise ValueError("d must be even")
    pos = np.arange(T)[:, None]
    freq = 10000.0 ** (-np.arange(0, d, 2) / d)
    pe = np.zeros((T, d))
    pe[:, 0::2] = np.sin(pos * freq)
    pe[:, 1::2] = np.cos(pos * freq)
    return pe


def apply_rope(x, positions=None, base=10000.0):
    """Rotary position embedding (half-split convention)."""
    x = np.asarray(x, dtype=float)
    T, d = x.shape[-2], x.shape[-1]
    if d % 2:
        raise ValueError("d must be even")
    pos = np.arange(T) if positions is None else np.asarray(positions, dtype=float)
    inv_freq = base ** (-np.arange(0, d // 2) * 2.0 / d)
    ang = pos[:, None] * inv_freq[None, :]
    cos, sin = np.cos(ang), np.sin(ang)
    x1, x2 = x[..., : d // 2], x[..., d // 2:]
    return np.concatenate([x1 * cos - x2 * sin, x1 * sin + x2 * cos], axis=-1)


def alibi_slopes(n_heads):
    """Per-head ALiBi slopes."""
    if n_heads < 1 or n_heads & (n_heads - 1):
        raise ValueError("n_heads must be a power of two")
    return 2.0 ** (-8.0 * np.arange(1, n_heads + 1) / n_heads)


def alibi_bias(n_heads, T):
    """ALiBi bias tensor (n_heads, T, T)."""
    rel = np.arange(T)[None, :] - np.arange(T)[:, None]
    return alibi_slopes(n_heads)[:, None, None] * rel[None]
