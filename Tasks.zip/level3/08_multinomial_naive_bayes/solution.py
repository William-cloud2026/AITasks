import re

import numpy as np


def count_vectorize(docs, vocabulary=None):
    """Bag-of-words count matrix."""
    tokenized = [re.findall(r"\w+", d.lower()) for d in docs]
    if vocabulary is None:
        vocabulary = {t: i for i, t in enumerate(sorted({t for toks in tokenized for t in toks}))}
    X = np.zeros((len(tokenized), len(vocabulary)), dtype=int)
    for i, toks in enumerate(tokenized):
        for t in toks:
            j = vocabulary.get(t)
            if j is not None:
                X[i, j] += 1
    return X, vocabulary


class MultinomialNB:
    """Multinomial naive Bayes with additive smoothing."""

    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def fit(self, X, y):
        """Estimate class priors and feature likelihoods."""
        X = np.asarray(X, dtype=float)
        if (X < 0).any():
            raise ValueError("counts must be non-negative")
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        self.class_count_ = np.array([np.sum(y == c) for c in self.classes_], dtype=float)
        self.feature_count_ = np.array([X[y == c].sum(0) for c in self.classes_])
        self.class_log_prior_ = np.log(self.class_count_ / len(y))
        sm = self.feature_count_ + self.alpha
        self.feature_log_prob_ = np.log(sm / sm.sum(1, keepdims=True))
        return self

    def _jll(self, X):
        return np.asarray(X, dtype=float) @ self.feature_log_prob_.T + self.class_log_prior_

    def predict_log_proba(self, X):
        """Normalized log posteriors."""
        j = self._jll(X)
        m = j.max(1, keepdims=True)
        return j - m - np.log(np.exp(j - m).sum(1, keepdims=True))

    def predict_proba(self, X):
        """Posterior probabilities."""
        return np.exp(self.predict_log_proba(X))

    def predict(self, X):
        """Most probable class."""
        return self.classes_[np.argmax(self._jll(X), axis=1)]
