import numpy as np


def softmax(Z, axis=-1):
    """Stable softmax."""
    Z = np.asarray(Z, dtype=float)
    E = np.exp(Z - Z.max(axis=axis, keepdims=True))
    return E / E.sum(axis=axis, keepdims=True)


def _log_softmax(Z):
    m = Z.max(axis=1, keepdims=True)
    return Z - m - np.log(np.exp(Z - m).sum(axis=1, keepdims=True))


def cross_entropy_and_grad(X, Y, W, b, l2=0.0):
    """Mean cross-entropy with L2 and gradients."""
    n = len(X)
    Z = X @ W + b
    logP = _log_softmax(Z)
    loss = float(-(Y * logP).sum() / n + 0.5 * l2 * (W * W).sum())
    G = (np.exp(logP) - Y) / n
    return loss, X.T @ G + l2 * W, G.sum(0)


class SoftmaxRegression:
    """Multiclass logistic regression."""

    def __init__(self, lr=0.1, epochs=500, l2=0.0):
        self.lr, self.epochs, self.l2 = lr, epochs, l2

    def fit(self, X, y):
        """Fit by full-batch gradient descent."""
        X = np.asarray(X, dtype=float)
        self.classes_, yi = np.unique(np.asarray(y), return_inverse=True)
        Y = np.eye(len(self.classes_))[yi]
        W = np.zeros((X.shape[1], len(self.classes_)))
        b = np.zeros(len(self.classes_))
        self.loss_history_ = []
        for _ in range(self.epochs):
            loss, gW, gb = cross_entropy_and_grad(X, Y, W, b, self.l2)
            self.loss_history_.append(loss)
            W, b = W - self.lr * gW, b - self.lr * gb
        self.W_, self.b_ = W, b
        return self

    def predict_proba(self, X):
        """Class probabilities."""
        return softmax(np.asarray(X, dtype=float) @ self.W_ + self.b_)

    def predict(self, X):
        """Most likely labels."""
        return self.classes_[np.argmax(self.predict_proba(X), axis=1)]
