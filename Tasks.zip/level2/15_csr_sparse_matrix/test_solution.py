import random

from starter import CSRMatrix

DENSE = [[0, 2, 0, 0], [1, 0, 0, 3], [0, 0, 0, 0], [0, 4, 5, 0]]


def test_from_dense_layout():
    m = CSRMatrix.from_dense(DENSE)
    assert m.data == [2, 1, 3, 4, 5]
    assert m.indices == [1, 0, 3, 1, 2]
    assert m.indptr == [0, 1, 3, 3, 5]
    assert m.shape == (4, 4) and m.nnz == 5
    assert m.to_dense() == DENSE


def test_matvec_and_get():
    m = CSRMatrix.from_dense(DENSE)
    assert m.matvec([1, 2, 3, 4]) == [4, 13, 0, 23]
    assert m @ [1, 1, 1, 1] == [2, 4, 0, 9]
    assert m.get(1, 3) == 3 and m.get(2, 2) == 0
    try:
        m.matvec([1, 2])
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


def test_transpose():
    m = CSRMatrix.from_dense(DENSE)
    t = m.transpose()
    assert t.shape == (4, 4)
    assert t.to_dense() == [list(r) for r in zip(*DENSE)]
    assert t.indptr == [0, 1, 3, 4, 5]
    rect = CSRMatrix.from_dense([[1, 0, 2]])
    assert rect.transpose().to_dense() == [[1], [0], [2]]


def test_from_coo():
    m = CSRMatrix.from_coo([1, 0, 1, 1, 2], [2, 1, 0, 2, 2], [5, 7, 1, -5, 9], (3, 3))
    assert m.to_dense() == [[0, 7, 0], [1, 0, 0], [0, 0, 9]]
    assert m.indptr == [0, 1, 2, 3] and m.indices == [1, 0, 2]
    try:
        CSRMatrix.from_coo([3], [0], [1], (3, 3))
    except IndexError:
        pass
    else:
        raise AssertionError("expected IndexError")


def test_random_against_dense():
    rng = random.Random(0)
    for _ in range(20):
        n, mcols = rng.randint(1, 8), rng.randint(1, 8)
        dense = [[rng.choice([0, 0, 0, rng.randint(-5, 5)]) for _ in range(mcols)] for _ in range(n)]
        m = CSRMatrix.from_dense(dense)
        x = [rng.randint(-3, 3) for _ in range(mcols)]
        assert m.matvec(x) == [sum(a * b for a, b in zip(r, x)) for r in dense]
        assert m.transpose().transpose().to_dense() == m.to_dense()
