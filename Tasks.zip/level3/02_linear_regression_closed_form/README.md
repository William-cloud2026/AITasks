# L3-02 · Linear & Ridge Regression (Closed Form)

**Level:** 3 · **Topics:** linear algebra, normal equations, regularization · **Time:** ~35 min · **Allowed:** Python stdlib + numpy

## Task
### `r2_score(y_true, y_pred) -> float`
`1 - SS_res / SS_tot`. If `SS_tot == 0`, return `1.0` if `SS_res == 0` else `0.0`.

### `class LinearRegression(fit_intercept=True, alpha=0.0)`
- `fit(X, y)` (X 2-D, y 1-D; mismatched lengths → `ValueError`), returns `self`, sets `coef_` (shape `(d,)`) and
  `intercept_` (float, `0.0` if `fit_intercept=False`).
- With `fit_intercept`, center `X` and `y` first; the intercept is **not** regularized:
  `intercept_ = mean(y) - mean(X) @ coef_`.
- `alpha == 0`: ordinary least squares; must work for rank-deficient `X` and return the **minimum-norm** solution
  (hint: `np.linalg.lstsq` or `pinv`).
- `alpha > 0`: ridge, `coef_ = (XᵀX + αI)⁻¹ Xᵀy` on the (centered) data. Use `np.linalg.solve`, not an explicit inverse.
- `predict(X)`, `score(X, y)` (R²). `alpha < 0` → `ValueError`.

You may **not** use scikit-learn (it is not available anyway).
