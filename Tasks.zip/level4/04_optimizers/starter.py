# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class SGD:
    """Stochastic gradient descent with optional momentum."""

    def __init__(self, params, lr, momentum=0.0, weight_decay=0.0, nesterov=False):
        raise NotImplementedError('TODO')

    def step(self, grads):
        """Apply one update."""
        raise NotImplementedError('TODO')

class RMSProp:
    """RMSProp."""

    def __init__(self, params, lr=0.01, alpha=0.99, eps=1e-08):
        raise NotImplementedError('TODO')

    def step(self, grads):
        """Apply one update."""
        raise NotImplementedError('TODO')

class Adam:
    """Adam with coupled (L2) weight decay."""

    def __init__(self, params, lr=0.001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.0):
        raise NotImplementedError('TODO')

    def step(self, grads):
        """Apply one update."""
        raise NotImplementedError('TODO')

class AdamW(Adam):
    """Adam with decoupled weight decay."""

    def __init__(self, params, lr=0.001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01):
        raise NotImplementedError('TODO')
