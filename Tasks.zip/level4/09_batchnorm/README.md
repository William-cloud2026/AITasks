# L4-09 · Batch Normalization

**Level:** 4 · **Topics:** normalization layers, train/eval modes, running statistics, backprop · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class BatchNorm1d(num_features, eps=1e-5, momentum=0.1)` for inputs `(N, D)` (PyTorch semantics).

- Parameters `gamma` (ones) and `beta` (zeros); buffers `running_mean` (zeros), `running_var` (ones).
- `training` attribute (default `True`); `train()` / `eval()` set it.
- `forward(x)`:
  - training: normalize with the **batch** mean and **biased** batch variance;
    update `running_mean = (1 − momentum)·running_mean + momentum·batch_mean` and
    `running_var = (1 − momentum)·running_var + momentum·unbiased_batch_var` (`N/(N−1)` correction).
    `N < 2` in training → `ValueError`.
  - eval: normalize with the running statistics.
  - `y = gamma · x_hat + beta`.
- `backward(dout)` (after a training-mode forward) → returns `dx`; sets `dgamma`, `dbeta`.
