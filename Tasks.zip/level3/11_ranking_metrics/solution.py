import numpy as np


def _check(y_true, scores):
    y = np.asarray(y_true).astype(int)
    s = np.asarray(scores, dtype=float)
    if y.shape != s.shape:
        raise ValueError("shape mismatch")
    return y, s


def roc_auc_score(y_true, scores):
    """Area under the ROC curve (Mann-Whitney U)."""
    y, s = _check(y_true, scores)
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        raise ValueError("both classes required")
    uniq, inv, counts = np.unique(s, return_inverse=True, return_counts=True)
    starts = np.cumsum(counts) - counts
    avg_rank = starts + (counts + 1) / 2.0
    ranks = avg_rank[inv]
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def _cum_counts(y, s):
    order = np.argsort(-s, kind="stable")
    ys, ss = y[order], s[order]
    tp = np.cumsum(ys)
    fp = np.cumsum(1 - ys)
    last = np.r_[np.flatnonzero(ss[1:] != ss[:-1]), len(ss) - 1]
    return tp[last], fp[last], ss[last]


def roc_curve(y_true, scores):
    """(fpr, tpr, thresholds)."""
    y, s = _check(y_true, scores)
    tp, fp, thr = _cum_counts(y, s)
    P, N = y.sum(), len(y) - y.sum()
    tpr = np.r_[0.0, tp / P] if P else np.r_[0.0, np.zeros_like(tp, dtype=float)]
    fpr = np.r_[0.0, fp / N] if N else np.r_[0.0, np.zeros_like(fp, dtype=float)]
    return fpr, tpr, np.r_[np.inf, thr]


def average_precision_score(y_true, scores):
    """Step-wise average precision."""
    y, s = _check(y_true, scores)
    P = y.sum()
    if P == 0:
        raise ValueError("no positive samples")
    tp, fp, _ = _cum_counts(y, s)
    precision = tp / (tp + fp)
    recall = tp / P
    return float(np.sum(np.diff(np.r_[0.0, recall]) * precision))


def log_loss(y_true, probs, eps=1e-15):
    """Mean binary cross-entropy."""
    y, p = _check(y_true, probs)
    p = np.clip(p, eps, 1 - eps)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def brier_score(y_true, probs):
    """Mean squared error of probabilities."""
    y, p = _check(y_true, probs)
    return float(np.mean((p - y) ** 2))
