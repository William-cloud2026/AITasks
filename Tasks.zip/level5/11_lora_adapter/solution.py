import numpy as np


class LoRALinear:
    """Linear layer with a low-rank trainable adapter."""

    def __init__(self, W, b, r=4, alpha=8.0, seed=0):
        self.W = np.array(W, dtype=float)
        self.b = np.array(b, dtype=float)
        n_in, n_out = self.W.shape
        if r < 1 or r > min(n_in, n_out):
            raise ValueError("invalid rank")
        rng = np.random.default_rng(seed)
        self.A = rng.normal(0, 0.02, size=(n_in, r))
        self.B = np.zeros((r, n_out))
        self.r, self.alpha, self.scaling = r, alpha, alpha / r
        self.merged = False

    def delta_weight(self):
        """scaling * A @ B."""
        return self.scaling * self.A @ self.B

    def forward(self, x):
        """Base output plus low-rank update."""
        self.x = np.asarray(x, dtype=float)
        out = self.x @ self.W + self.b
        if not self.merged:
            self.xa = self.x @ self.A
            out = out + self.scaling * self.xa @ self.B
        return out

    def backward(self, dout):
        """Gradients for A and B; returns dx."""
        if self.merged:
            raise RuntimeError("cannot train a merged adapter")
        self.dB = self.scaling * self.xa.T @ dout
        dxa = self.scaling * dout @ self.B.T
        self.dA = self.x.T @ dxa
        return dout @ self.W.T + dxa @ self.A.T

    def merge(self):
        """Fold the adapter into W."""
        if self.merged:
            raise RuntimeError("already merged")
        self.W += self.delta_weight()
        self.merged = True

    def unmerge(self):
        """Remove the adapter from W."""
        if not self.merged:
            raise RuntimeError("not merged")
        self.W -= self.delta_weight()
        self.merged = False

    def trainable_parameters(self):
        """Number of trainable scalars."""
        return self.A.size + self.B.size
