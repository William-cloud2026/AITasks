from starter import OutOfBlocksError, PagedKVCache


def expect(fn, exc):
    try:
        fn()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except exc:
        return
    raise AssertionError(f"expected {exc.__name__}")


def test_allocation_and_slots():
    c = PagedKVCache(num_blocks=8, block_size=4)
    c.add_sequence("a")
    assert c.append_tokens("a", 6) == 6
    assert c.block_table("a") == [0, 1] and c.num_free_blocks == 6
    c.add_sequence("b")
    c.append_tokens("b", 1)
    assert c.block_table("b") == [2]
    assert c.append_tokens("a", 2) == 8 and c.block_table("a") == [0, 1]
    assert c.append_tokens("a") == 9 and c.block_table("a") == [0, 1, 3]
    assert c.slot("a", 0) == 0 and c.slot("a", 5) == 5 and c.slot("a", 8) == 12
    expect(lambda: c.slot("a", 9), IndexError)
    expect(lambda: c.add_sequence("a"), ValueError)
    expect(lambda: c.append_tokens("zzz"), KeyError)


def test_free_reuses_lowest_blocks():
    c = PagedKVCache(6, 2)
    for s in "abc":
        c.add_sequence(s)
        c.append_tokens(s, 3)
    assert c.block_table("b") == [2, 3] and c.num_free_blocks == 0
    c.free_sequence("a")
    assert c.num_free_blocks == 2
    c.add_sequence("d")
    c.append_tokens("d", 1)
    assert c.block_table("d") == [0]
    expect(lambda: c.length("a"), KeyError)


def test_out_of_blocks_is_atomic():
    c = PagedKVCache(3, 4)
    c.add_sequence("a")
    c.append_tokens("a", 10)
    c.add_sequence("b")
    expect(lambda: c.append_tokens("b", 5), OutOfBlocksError)
    assert c.length("b") == 0 and c.block_table("b") == [] and c.num_free_blocks == 0
    expect(lambda: c.append_tokens("a", 3), OutOfBlocksError)
    assert c.length("a") == 10
    c.append_tokens("a", 2)
    assert c.length("a") == 12


def test_fork_and_copy_on_write():
    c = PagedKVCache(10, 4)
    c.add_sequence("p")
    c.append_tokens("p", 6)
    c.fork("p", "beam1")
    assert c.block_table("beam1") == [0, 1] and c.refcount(0) == 2 and c.refcount(1) == 2
    assert c.num_free_blocks == 8
    c.append_tokens("beam1", 1)
    assert c.cow_copies == [(1, 2)]
    assert c.block_table("beam1") == [0, 2] and c.refcount(1) == 1 and c.refcount(2) == 1
    c.append_tokens("p", 1)
    assert c.cow_copies == [(1, 2)] and c.block_table("p") == [0, 1]
    c.free_sequence("p")
    assert c.refcount(0) == 1 and c.refcount(1) == 0 and c.num_free_blocks == 8


def test_fork_full_block_no_copy():
    c = PagedKVCache(6, 2)
    c.add_sequence("x")
    c.append_tokens("x", 4)
    c.fork("x", "y")
    c.append_tokens("y", 1)
    assert c.cow_copies == [] and c.block_table("y") == [0, 1, 2]
    c.free_sequence("x")
    c.free_sequence("y")
    assert c.num_free_blocks == 6
