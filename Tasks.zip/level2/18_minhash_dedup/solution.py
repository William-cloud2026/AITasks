import hashlib
import random
from collections import defaultdict
from itertools import combinations

_P = (1 << 61) - 1


def shingles(text, k=5):
    """Character k-gram shingles of normalized text."""
    norm = " ".join(text.lower().split())
    if not norm:
        return set()
    if len(norm) < k:
        return {norm}
    return {norm[i:i + k] for i in range(len(norm) - k + 1)}


def jaccard(a, b):
    """Exact Jaccard similarity."""
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b)


class MinHasher:
    """MinHash signatures with universal hashing."""

    def __init__(self, num_perm=128, seed=0):
        self.num_perm = num_perm
        rng = random.Random(seed)
        self._params = []
        for _ in range(num_perm):
            a = rng.randint(1, _P - 1)
            b = rng.randint(0, _P - 1)
            self._params.append((a, b))

    def signature(self, shingle_set):
        """MinHash signature of a shingle set."""
        if not shingle_set:
            raise ValueError("empty shingle set")
        hs = [int.from_bytes(hashlib.md5(s.encode("utf-8")).digest()[:8], "little") for s in shingle_set]
        return [min((a * h + b) % _P for h in hs) for a, b in self._params]


def estimate_jaccard(sig1, sig2):
    """Fraction of equal signature positions."""
    if len(sig1) != len(sig2):
        raise ValueError("signature length mismatch")
    return sum(x == y for x, y in zip(sig1, sig2)) / len(sig1)


def find_near_duplicates(docs, threshold=0.8, num_perm=128, bands=32, k=5, seed=0):
    """LSH-based near-duplicate pairs."""
    if num_perm % bands:
        raise ValueError("num_perm must be divisible by bands")
    r = num_perm // bands
    mh = MinHasher(num_perm, seed)
    sigs = {}
    for doc_id, text in docs.items():
        sh = shingles(text, k)
        if sh:
            sigs[doc_id] = mh.signature(sh)
    buckets = defaultdict(list)
    for doc_id, sig in sigs.items():
        for b in range(bands):
            buckets[(b, tuple(sig[b * r:(b + 1) * r]))].append(doc_id)
    candidates = set()
    for ids in buckets.values():
        for x, y in combinations(sorted(ids), 2):
            candidates.add((x, y))
    return sorted(p for p in candidates if estimate_jaccard(sigs[p[0]], sigs[p[1]]) >= threshold)
