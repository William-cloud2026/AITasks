# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def hinge_loss(X, y, w, b, lam):
    """Regularized mean hinge loss."""
    raise NotImplementedError('TODO')

class LinearSVM:
    """Linear SVM trained with Pegasos."""

    def __init__(self, lam=0.01, epochs=20, seed=0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Run Pegasos SGD."""
        raise NotImplementedError('TODO')

    def decision_function(self, X):
        """Signed distance-like score."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predicted labels."""
        raise NotImplementedError('TODO')
