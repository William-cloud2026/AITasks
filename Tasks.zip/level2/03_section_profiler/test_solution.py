from starter import Profiler


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_nested_sections():
    clk = FakeClock()
    p = Profiler(clock=clk)
    for _ in range(2):
        with p.section("epoch"):
            clk.t += 1
            with p.section("forward"):
                clk.t += 2
            with p.section("backward"):
                clk.t += 3
    r = p.report()
    assert r["epoch/forward"] == {"calls": 2, "total": 4.0, "mean": 2.0}
    assert r["epoch/backward"]["total"] == 6.0
    assert r["epoch"] == {"calls": 2, "total": 12.0, "mean": 6.0}
    assert set(r) == {"epoch", "epoch/forward", "epoch/backward"}


def test_exception_recorded_and_propagates():
    clk = FakeClock()
    p = Profiler(clock=clk)
    try:
        with p.section("bad"):
            clk.t += 5
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    else:
        raise AssertionError("exception must propagate")
    assert p.report()["bad"]["total"] == 5.0
    with p.section("after"):
        pass
    assert "after" in p.report()


def test_timed_decorator_nests():
    clk = FakeClock()
    p = Profiler(clock=clk)

    @p.timed("step")
    def step(x):
        clk.t += 0.5
        return x + 1

    with p.section("train"):
        assert step(1) == 2
        step(2)
    assert p.report()["train/step"]["calls"] == 2
    assert step.__name__ == "step"


def test_clock_called_twice_per_section():
    calls = []

    def clock():
        calls.append(1)
        return float(len(calls))

    p = Profiler(clock=clock)
    with p.section("a"):
        pass
    assert len(calls) == 2


def test_reset_and_invalid():
    p = Profiler(clock=FakeClock())
    with p.section("x"):
        pass
    p.reset()
    assert p.report() == {}
    for bad in ["", "a/b"]:
        try:
            with p.section(bad):
                pass
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
