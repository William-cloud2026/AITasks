# L2-20 · Prompt Template Engine

**Level:** 2 · **Topics:** parsing, recursion, LLM prompt construction · **Time:** ~60 min · **Allowed:** Python stdlib (no `jinja2`/`string.Template`)

## Task
### `render(template, context) -> str`
A small Jinja-like engine for building LLM prompts. Raise `TemplateError` (subclass of `Exception`) for any problem.

**Variables** – `{{ path | filter | filter:arg }}` (whitespace inside braces optional).
- `path` = `name(.name)*`; each step looks up a dict key (if the object is a dict) or else an attribute.
- Output is `str(value)`, except `None` renders as `""`.
- If the path cannot be resolved the value is *missing*. The `default:"x"` filter replaces a missing value (or
  `None`) with `"x"`. Any other filter applied to a missing value, or a missing value reaching the output → `TemplateError`.

**Filters**: `upper`, `lower`, `title`, `strip`, `length`, `default:"text"`, `truncate:N` (if `len(str(v)) > N`
keep the first `N` characters and append `"..."`), `join:"sep"` (join `str(item)` of a list).
Arguments are either a double-quoted string (no escapes) or an integer. Unknown filter → `TemplateError`.

**Blocks** (may be nested):
- `{% for x in path %}...{% endfor %}` — inside the body `x` and `loop.index` (1-based), `loop.first`,
  `loop.last` are available; loop variables shadow outer context.
- `{% if path %}...{% else %}...{% endif %}` (`else` optional) — truthiness of the value; a missing path is falsy.
- Unknown tag, unclosed or unexpected block → `TemplateError`.

No whitespace control: text outside tags is emitted verbatim.

### `format_chat(messages, add_generation_prompt=True) -> str`
`messages`: list of `{"role", "content"}`. Roles: `system`, `user`, `assistant`; a `system` message is allowed
only at index 0. Output is the concatenation of `"<|{role}|>\n{content}<|end|>\n"` plus `"<|assistant|>\n"` if
`add_generation_prompt`. Empty list, bad role or misplaced system → `ValueError`.

## Example
```python
render("Docs:\n{% for d in docs %}[{{ loop.index }}] {{ d.title | upper }}\n{% endfor %}Q: {{ q }}",
       {"docs": [{"title": "a"}, {"title": "b"}], "q": "why?"})
# 'Docs:\n[1] A\n[2] B\nQ: why?'
```
