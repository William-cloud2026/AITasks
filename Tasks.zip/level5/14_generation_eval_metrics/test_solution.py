import math

from starter import corpus_bleu, exact_match, normalize_answer, rouge_l, token_f1


def test_normalize_and_em():
    assert normalize_answer("  The  Eiffel-Tower!! ") == "eiffeltower"
    assert normalize_answer("An apple a day") == "apple day"
    assert exact_match("the Paris.", "Paris") == 1.0
    assert exact_match("London", ["Paris", "london!"]) == 1.0
    assert exact_match("Rome", "Paris") == 0.0


def test_token_f1():
    # normalized: "cat sat on mat" vs "cat on mat" -> P = 3/4, R = 1
    assert math.isclose(token_f1("the cat sat on the mat", "a cat on a mat"), 2 * 0.75 * 1.0 / 1.75)
    assert token_f1("", "") == 1.0 and token_f1("the", "cat") == 0.0
    assert math.isclose(token_f1("paris france", ["berlin", "paris"]), 2 / 3)


def test_bleu_examples():
    assert math.isclose(corpus_bleu(["the cat sat on the mat"], [["the cat sat on the mat"]]), 1.0)
    cand, ref = ["the cat is on the mat"], [["the cat sat on the mat"]]
    assert math.isclose(corpus_bleu(cand, ref, max_n=2), math.sqrt(5 / 6 * 3 / 5))
    assert corpus_bleu(cand, ref) == 0.0
    smooth = math.exp((math.log(5 / 6) + math.log(4 / 6) + math.log(2 / 5) + math.log(1 / 4)) / 4)
    assert math.isclose(corpus_bleu(cand, ref, smooth=True), smooth)


def test_bleu_brevity_and_multi_ref():
    assert math.isclose(corpus_bleu(["the cat"], [["the cat sat on the mat"]], max_n=2), math.exp(-2))
    v = corpus_bleu(["the cat"], [["the cat sat on the mat", "the cat"]], max_n=2)
    assert math.isclose(v, 1.0)
    clipped = corpus_bleu(["the the the the"], [["the cat"]], max_n=1)
    assert math.isclose(clipped, 0.25)


def test_bleu_corpus_level_aggregation():
    c = ["a b c d", "e f"]
    r = [["a b c d"], ["e g"]]
    p1, p2 = 5 / 6, 3 / 4
    assert math.isclose(corpus_bleu(c, r, max_n=2), math.sqrt(p1 * p2))
    assert corpus_bleu([""], [["a"]]) == 0.0


def test_rouge_l():
    assert math.isclose(rouge_l("the cat sat on mat", "The cat is on the mat"), 2 * 0.8 * (4 / 6) / (0.8 + 4 / 6))
    assert rouge_l("a b c", "a b c") == 1.0
    assert rouge_l("x y", "a b") == 0.0 and rouge_l("", "a") == 0.0
