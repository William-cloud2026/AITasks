# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def fizzbuzz(n, rules=None):
    """Return FizzBuzz strings for 1..n using (divisor, word) rules."""
    raise NotImplementedError('TODO')
