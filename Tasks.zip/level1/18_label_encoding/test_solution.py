from starter import LabelEncoder, one_hot


def _raises(fn, exc):
    try:
        fn()
    except exc:
        return True
    return False


def test_fit_transform():
    enc = LabelEncoder()
    assert enc.fit(["dog", "cat", "dog", "bird"]) is enc
    assert enc.classes_ == ["bird", "cat", "dog"]
    assert enc.transform(["cat", "dog", "bird"]) == [1, 2, 0]


def test_inverse():
    enc = LabelEncoder()
    ids = enc.fit_transform([3, 1, 2, 3])
    assert ids == [2, 0, 1, 2]
    assert enc.inverse_transform(ids) == [3, 1, 2, 3]


def test_errors():
    enc = LabelEncoder()
    assert _raises(lambda: enc.transform(["a"]), RuntimeError)
    assert _raises(lambda: enc.inverse_transform([0]), RuntimeError)
    enc.fit(["a", "b"])
    assert _raises(lambda: enc.transform(["z"]), ValueError)
    assert _raises(lambda: enc.inverse_transform([2]), ValueError)
    assert _raises(lambda: enc.inverse_transform([-1]), ValueError)


def test_fit_transform_generator():
    enc = LabelEncoder()
    assert enc.fit_transform(x for x in "bab") == [1, 0, 1]


def test_one_hot():
    assert one_hot([1, 0], 3) == [[0, 1, 0], [1, 0, 0]]
    assert one_hot([], 2) == []
    assert _raises(lambda: one_hot([3], 3), ValueError)
