import math
from collections import Counter

import numpy as np


class NGramLM:
    """Add-k smoothed n-gram language model."""

    def __init__(self, n=2, k=1.0):
        if n < 1 or k <= 0:
            raise ValueError("n must be >= 1 and k > 0")
        self.n, self.k = n, k

    def fit(self, sentences):
        """Count n-grams."""
        self.vocab = {"</s>", "<unk>"}
        self.ngrams, self.contexts = Counter(), Counter()
        for s in sentences:
            self.vocab.update(s)
        for s in sentences:
            toks = ["<s>"] * (self.n - 1) + list(s) + ["</s>"]
            for i in range(self.n - 1, len(toks)):
                ctx = tuple(toks[i - self.n + 1:i])
                self.ngrams[ctx + (toks[i],)] += 1
                self.contexts[ctx] += 1
        self._sorted_vocab = sorted(self.vocab)
        return self

    def _map(self, w):
        return w if w in self.vocab or w == "<s>" else "<unk>"

    def _ctx(self, context):
        ctx = [self._map(w) for w in context][-(self.n - 1):] if self.n > 1 else []
        return tuple(["<s>"] * (self.n - 1 - len(ctx)) + ctx)

    def prob(self, word, context=()):
        """Smoothed conditional probability."""
        ctx = self._ctx(list(context))
        w = self._map(word)
        return (self.ngrams[ctx + (w,)] + self.k) / (self.contexts[ctx] + self.k * len(self.vocab))

    def sentence_logprob(self, sentence):
        """Log probability including </s>."""
        toks = list(sentence) + ["</s>"]
        return sum(math.log(self.prob(w, toks[:i])) for i, w in enumerate(toks))

    def perplexity(self, sentences):
        """Corpus perplexity."""
        total_lp = sum(self.sentence_logprob(s) for s in sentences)
        total_n = sum(len(s) + 1 for s in sentences)
        return math.exp(-total_lp / total_n)

    def generate(self, max_len=20, seed=None):
        """Sample a sentence."""
        rng = np.random.default_rng(seed)
        out = []
        while len(out) < max_len:
            p = np.array([self.prob(w, out) for w in self._sorted_vocab])
            w = self._sorted_vocab[rng.choice(len(p), p=p / p.sum())]
            if w == "</s>":
                break
            out.append(w)
        return out
