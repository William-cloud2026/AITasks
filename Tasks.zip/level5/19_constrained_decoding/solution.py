import numpy as np


class ConstrainedDecoder:
    """Restrict generation to a fixed set of strings."""

    def __init__(self, vocab, allowed, eos_id):
        if not allowed or any(not s for s in allowed):
            raise ValueError("allowed must be non-empty strings")
        self.vocab, self.eos_id = list(vocab), eos_id
        self.allowed = set(allowed)
        self._trie = {}
        for s in allowed:
            node = self._trie
            for ch in s:
                node = node.setdefault(ch, {})

    def _walk(self, node, text):
        for ch in text:
            node = node.get(ch)
            if node is None:
                return None
        return node

    def allowed_mask(self, prefix):
        """Boolean mask of tokens that keep the output on a valid path."""
        mask = np.zeros(len(self.vocab), dtype=bool)
        start = self._walk(self._trie, prefix)
        if start is None:
            return mask
        for t, tok in enumerate(self.vocab):
            if t != self.eos_id and tok and self._walk(start, tok) is not None:
                mask[t] = True
        mask[self.eos_id] = prefix in self.allowed
        return mask

    def decode(self, logits_fn, max_steps=64):
        """Greedy constrained decoding."""
        text, ids = "", []
        for _ in range(max_steps):
            mask = self.allowed_mask(text)
            if not mask.any():
                raise RuntimeError("dead end")
            logits = np.asarray(logits_fn(list(ids)), dtype=float)
            tok = int(np.argmax(np.where(mask, logits, -np.inf)))
            if tok == self.eos_id:
                return text, ids
            ids.append(tok)
            text += self.vocab[tok]
        raise RuntimeError("max_steps reached")
