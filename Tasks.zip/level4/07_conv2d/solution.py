import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


def conv2d_forward(x, w, b, stride=1, padding=0):
    """Cross-correlation over NCHW input."""
    x = np.asarray(x, dtype=float)
    w = np.asarray(w, dtype=float)
    N, C, H, W = x.shape
    F, Cw, KH, KW = w.shape
    if C != Cw:
        raise ValueError("channel mismatch")
    if H + 2 * padding < KH or W + 2 * padding < KW:
        raise ValueError("kernel larger than input")
    xp = np.pad(x, ((0, 0), (0, 0), (padding, padding), (padding, padding)))
    win = sliding_window_view(xp, (KH, KW), axis=(2, 3))[:, :, ::stride, ::stride]
    out = np.einsum("nchwpq,fcpq->nfhw", win, w, optimize=True) + np.asarray(b, dtype=float)[None, :, None, None]
    return out, (x.shape, xp, w, stride, padding, win)


def conv2d_backward(dout, cache):
    """Gradients of conv2d_forward."""
    x_shape, xp, w, stride, padding, win = cache
    N, C, H, W = x_shape
    F, _, KH, KW = w.shape
    Ho, Wo = dout.shape[2], dout.shape[3]
    db = dout.sum(axis=(0, 2, 3))
    dw = np.einsum("nchwpq,nfhw->fcpq", win, dout, optimize=True)
    dxp = np.zeros_like(xp)
    for p in range(KH):
        for q in range(KW):
            dxp[:, :, p:p + stride * Ho:stride, q:q + stride * Wo:stride] += np.einsum(
                "nfhw,fc->nchw", dout, w[:, :, p, q], optimize=True)
    dx = dxp[:, :, padding:padding + H, padding:padding + W]
    return dx, dw, db
