import math


def _check(step):
    if step < 0:
        raise ValueError("step must be >= 0")


def step_lr(step, base_lr, step_size, gamma=0.1):
    """Step decay."""
    _check(step)
    return base_lr * gamma ** (step // step_size)


def exponential_lr(step, base_lr, gamma):
    """Exponential decay."""
    _check(step)
    return base_lr * gamma ** step


def warmup_cosine_lr(step, base_lr, total_steps, warmup_steps=0, min_lr=0.0):
    """Linear warm-up then cosine decay."""
    _check(step)
    if step < warmup_steps:
        return base_lr * (step + 1) / warmup_steps
    progress = min(1.0, max(0.0, (step - warmup_steps) / max(1, total_steps - warmup_steps)))
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))


def warmup_linear_lr(step, base_lr, total_steps, warmup_steps=0):
    """Linear warm-up then linear decay to zero."""
    _check(step)
    if step < warmup_steps:
        return base_lr * (step + 1) / warmup_steps
    return base_lr * max(0.0, (total_steps - step) / max(1, total_steps - warmup_steps))


def inverse_sqrt_lr(step, base_lr, warmup_steps):
    """Warm-up then inverse square-root decay."""
    _check(step)
    if step < warmup_steps:
        return base_lr * (step + 1) / warmup_steps
    return base_lr * math.sqrt(warmup_steps / (step + 1))


class LambdaScheduler:
    """Sets optimizer.lr from a function of the step."""

    def __init__(self, optimizer, lr_fn):
        self.optimizer, self.lr_fn = optimizer, lr_fn
        self.last_step = 0
        optimizer.lr = lr_fn(0)

    def step(self):
        """Advance one step."""
        self.last_step += 1
        self.optimizer.lr = self.lr_fn(self.last_step)

    def get_last_lr(self):
        """Current learning rate."""
        return self.optimizer.lr
