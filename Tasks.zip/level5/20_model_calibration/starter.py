# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import numpy as np

def softmax(logits, temperature=1.0):
    """Row-wise softmax with temperature."""
    raise NotImplementedError('TODO')

def nll(logits, labels, temperature=1.0):
    """Mean negative log-likelihood."""
    raise NotImplementedError('TODO')

def reliability_bins(probs, labels, n_bins=15):
    """Per-bin accuracy and confidence."""
    raise NotImplementedError('TODO')

def expected_calibration_error(probs, labels, n_bins=15):
    """ECE with equal-width bins."""
    raise NotImplementedError('TODO')

def fit_temperature(logits, labels, t_min=0.05, t_max=20.0, tol=1e-05):
    """Golden-section search for the NLL-optimal temperature."""
    raise NotImplementedError('TODO')
