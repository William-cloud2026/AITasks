import json
import math

from starter import analyze_logs


def rec(ep, lat, status=200, level="INFO"):
    return json.dumps({"ts": "t", "level": level, "endpoint": ep, "latency_ms": lat, "status": status})


def test_basic():
    lines = [rec("/chat", float(i), 500 if i % 10 == 0 else 200) for i in range(1, 101)]
    lines += [rec("/embed", 5, level="WARN")]
    out = analyze_logs(lines)
    assert out["total"] == 101 and out["malformed"] == 0
    assert out["by_level"] == {"INFO": 100, "WARN": 1}
    chat = out["endpoints"]["/chat"]
    assert chat["count"] == 100
    assert chat["p50"] == 50.0 and chat["p95"] == 95.0
    assert math.isclose(chat["error_rate"], 0.1)
    assert out["endpoints"]["/embed"] == {"count": 1, "p50": 5.0, "p95": 5.0, "error_rate": 0.0}


def test_nearest_rank_small():
    out = analyze_logs([rec("/a", v) for v in [15, 20, 35, 40, 50]])
    assert out["endpoints"]["/a"]["p50"] == 35.0
    assert out["endpoints"]["/a"]["p95"] == 50.0


def test_malformed_and_blank():
    lines = [
        "", "   ", "{not json", "[1, 2]", json.dumps({"level": "INFO"}),
        json.dumps({"level": "I", "endpoint": "/x", "latency_ms": "12", "status": 200}),
        json.dumps({"level": "I", "endpoint": "/x", "latency_ms": True, "status": 200}),
        json.dumps({"level": "I", "endpoint": "/x", "latency_ms": 1, "status": "200"}),
        rec("/ok", 1),
    ]
    out = analyze_logs(lines)
    assert out["malformed"] == 6
    assert out["total"] == 1


def test_generator_input_and_empty():
    out = analyze_logs(iter([]))
    assert out == {"total": 0, "malformed": 0, "by_level": {}, "endpoints": {}}
    out = analyze_logs(rec("/g", i) for i in range(3))
    assert out["total"] == 3
