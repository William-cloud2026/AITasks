# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def cross_entropy(logits, targets, label_smoothing=0.0, ignore_index=-100, reduction='mean'):
    """Cross-entropy loss and its gradient w.r.t. logits."""
    raise NotImplementedError('TODO')
