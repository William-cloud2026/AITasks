# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import re
from collections import Counter

class BM25:
    """Okapi BM25 ranking."""

    def __init__(self, k1=1.5, b=0.75):
        raise NotImplementedError('TODO')

    def fit(self, docs):
        """Index documents."""
        raise NotImplementedError('TODO')

    def idf(self, term):
        """Lucene-style idf."""
        raise NotImplementedError('TODO')

    def score(self, query, doc_index):
        """BM25 score of one document."""
        raise NotImplementedError('TODO')

    def search(self, query, k=10):
        """Top-k (index, score)."""
        raise NotImplementedError('TODO')

def reciprocal_rank_fusion(rankings, k=60, top_n=None):
    """Fuse ranked lists with RRF."""
    raise NotImplementedError('TODO')

def hybrid_search(bm25, dense_scores, query, k=10, rrf_k=60):
    """Fuse BM25 and dense rankings."""
    raise NotImplementedError('TODO')
