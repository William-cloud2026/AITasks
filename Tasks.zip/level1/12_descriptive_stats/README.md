# L1-12 · Descriptive Statistics from Scratch

**Level:** 1 · **Topics:** math, numeric edge cases · **Time:** ~25 min · **Allowed:** Python stdlib **except** the `statistics` module

## Task
Implement (all take a non-empty sequence of numbers; empty → `ValueError`):

| Function | Definition |
|---|---|
| `mean(xs)` | arithmetic mean (float) |
| `median(xs)` | middle value; for even length the mean of the two middle values (float) |
| `mode(xs)` | most frequent value; on ties return the **smallest** |
| `variance(xs, sample=False)` | population variance (divide by `n`) or sample variance (divide by `n-1`; needs `n >= 2`, else `ValueError`) |
| `stdev(xs, sample=False)` | square root of `variance` |
| `zscores(xs)` | list of `(x - mean) / population_stdev`; if stdev is 0 return all `0.0` |

## Example
```python
median([3, 1, 2, 4])            # 2.5
variance([2, 4, 4, 4, 5, 5, 7, 9])  # 4.0
```
