# L3-03 · Linear Regression with (Mini-batch) Gradient Descent

**Level:** 3 · **Topics:** gradients, optimization loops, reproducibility · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `mse_loss_and_grad(X, y, w, b, l2=0.0) -> (loss, grad_w, grad_b)`
`loss = 1/(2n) · Σ (Xw + b − y)² + (l2/2)·‖w‖²`, with its exact gradients (bias not regularized).

### `class LinearRegressionGD(lr=0.01, epochs=1000, l2=0.0, batch_size=None, seed=0, tol=None)`
- `fit(X, y)`: initialize `w = zeros(d)`, `b = 0.0`; create **one** `rng = np.random.default_rng(seed)`.
  - `batch_size=None` → one full-batch gradient step per epoch.
  - otherwise, each epoch: `perm = rng.permutation(n)`; step on consecutive mini-batches `perm[i:i+batch_size]`
    (gradient computed on the batch only).
  - after each epoch append the **full-dataset** loss to `loss_history_`.
  - if `tol` is set and `previous_loss - current_loss < tol` (for epoch ≥ 2), stop early.
- Attributes: `coef_`, `intercept_`, `loss_history_`, `n_epochs_` (epochs actually run).
- `predict(X)`.
