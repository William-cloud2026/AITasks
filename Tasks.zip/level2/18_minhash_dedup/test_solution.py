import hashlib
import random

from starter import MinHasher, estimate_jaccard, find_near_duplicates, jaccard, shingles

BASE = ("Large language models are trained on massive corpora of web text, and deduplicating that text "
        "improves both training efficiency and downstream quality of the resulting model.")


def test_shingles():
    assert shingles("Ab  CD", 3) == {"ab ", "b c", " cd"}
    assert shingles("hi", 5) == {"hi"}
    assert shingles("   ", 5) == set()


def test_jaccard():
    assert jaccard({1, 2, 3}, {2, 3, 4}) == 0.5
    assert jaccard(set(), set()) == 1.0
    assert jaccard({1}, set()) == 0.0


def test_signature_follows_spec():
    s = {"abc", "bcd", "xyz"}
    P = 2 ** 61 - 1
    rng = random.Random(42)
    params = [(rng.randint(1, P - 1), rng.randint(0, P - 1)) for _ in range(4)]
    hs = [int.from_bytes(hashlib.md5(x.encode()).digest()[:8], "little") for x in s]
    expected = [min((a * h + b) % P for h in hs) for a, b in params]
    assert MinHasher(4, seed=42).signature(s) == expected


def test_estimate_close_to_true():
    a = shingles(BASE)
    b = shingles(BASE.replace("massive", "huge").replace("quality", "accuracy"))
    mh = MinHasher(256, seed=1)
    est = estimate_jaccard(mh.signature(a), mh.signature(b))
    assert abs(est - jaccard(a, b)) < 0.1


def test_errors():
    for fn in (lambda: MinHasher(8).signature(set()), lambda: estimate_jaccard([1], [1, 2]),
               lambda: find_near_duplicates({}, num_perm=10, bands=3)):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_find_near_duplicates():
    docs = {
        1: BASE,
        2: BASE + " ",
        3: BASE.replace("efficiency", "efficiency greatly"),
        4: "A completely different document about cooking pasta with tomatoes and basil in summer.",
        5: "Another unrelated text: the stock market fell sharply on Tuesday amid rate fears.",
        6: "",
    }
    pairs = find_near_duplicates(docs, threshold=0.8)
    assert (1, 2) in pairs and (1, 3) in pairs and (2, 3) in pairs
    assert all(4 not in p and 5 not in p and 6 not in p for p in pairs)
