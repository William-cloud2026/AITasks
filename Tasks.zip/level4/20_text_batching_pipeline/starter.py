# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

from collections import Counter
import numpy as np

class Vocab:
    """Token <-> id mapping with special tokens."""

    def __init__(self, itos):
        raise NotImplementedError('TODO')

    @classmethod
    def build(cls, token_lists, min_freq=1, max_size=None, specials=('<pad>', '<unk>')):
        """Build from tokenized texts."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')

    def __getitem__(self, token):
        raise NotImplementedError('TODO')

    @property
    def unk_id(self):
        raise NotImplementedError('TODO')

    @property
    def pad_id(self):
        raise NotImplementedError('TODO')

    def lookup_token(self, idx):
        """Id -> token."""
        raise NotImplementedError('TODO')

    def encode(self, tokens):
        """Tokens -> ids."""
        raise NotImplementedError('TODO')

    def decode(self, ids, skip_specials=False):
        """Ids -> tokens."""
        raise NotImplementedError('TODO')

def collate(sequences, pad_id, max_len=None, padding_side='right', truncation_side='right'):
    """Pad/truncate sequences into (ids, mask) arrays."""
    raise NotImplementedError('TODO')

def bucket_batches(lengths, batch_size, shuffle=False, seed=None):
    """Length-sorted batches of indices."""
    raise NotImplementedError('TODO')
