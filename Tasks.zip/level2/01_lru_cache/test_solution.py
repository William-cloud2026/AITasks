import time

from starter import LRUCache


def test_basic_eviction():
    c = LRUCache(2)
    c.put("a", 1)
    c.put("b", 2)
    assert c.get("a") == 1
    c.put("c", 3)
    assert "b" not in c
    assert c.keys() == ["a", "c"]


def test_update_moves_to_end():
    c = LRUCache(2)
    c.put("a", 1)
    c.put("b", 2)
    c.put("a", 10)
    c.put("c", 3)
    assert c.keys() == ["a", "c"]
    assert c.get("a") == 10


def test_contains_does_not_touch():
    c = LRUCache(2)
    c.put("a", 1)
    c.put("b", 2)
    assert "a" in c
    c.put("c", 3)
    assert "a" not in c


def test_stats_and_default():
    c = LRUCache(1)
    c.put(1, "x")
    assert c.get(1) == "x"
    assert c.get(2, "d") == "d"
    assert (c.hits, c.misses) == (1, 1)
    assert len(c) == 1


def test_on_evict():
    evicted = []
    c = LRUCache(2, on_evict=lambda k, v: evicted.append((k, v)))
    for i in range(4):
        c.put(i, i * i)
    assert evicted == [(0, 0), (1, 1)]


def test_invalid_capacity():
    try:
        LRUCache(0)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_performance():
    c = LRUCache(1000)
    t0 = time.perf_counter()
    for i in range(100_000):
        c.put(i, i)
        c.get(i - 500)
    assert time.perf_counter() - t0 < 3.0
    assert len(c) == 1000
