from collections import deque
from itertools import islice


def chunked(iterable, n):
    """Lazily yield lists of n items (last may be shorter)."""
    if n < 1:
        raise ValueError("n must be >= 1")

    def gen():
        it = iter(iterable)
        while True:
            chunk = list(islice(it, n))
            if not chunk:
                return
            yield chunk

    return gen()


def sliding_window(iterable, n):
    """Lazily yield n-tuples of consecutive items."""
    if n < 1:
        raise ValueError("n must be >= 1")

    def gen():
        it = iter(iterable)
        window = deque(islice(it, n), maxlen=n)
        if len(window) < n:
            return
        yield tuple(window)
        for x in it:
            window.append(x)
            yield tuple(window)

    return gen()
