import numpy as np

from starter import MultinomialNB, count_vectorize

DOCS = ["Free money now!!", "free free offer", "Meeting at noon", "project meeting notes", "win money free"]
LABELS = ["spam", "spam", "ham", "ham", "spam"]


def test_count_vectorize():
    X, vocab = count_vectorize(["b a b", "c"])
    assert vocab == {"a": 0, "b": 1, "c": 2}
    np.testing.assert_array_equal(X, [[1, 2, 0], [0, 0, 1]])
    X2, _ = count_vectorize(["a z z"], vocab)
    np.testing.assert_array_equal(X2, [[1, 0, 0]])


def test_parameters():
    X, vocab = count_vectorize(DOCS)
    m = MultinomialNB(alpha=1.0).fit(X, LABELS)
    assert list(m.classes_) == ["ham", "spam"]
    np.testing.assert_allclose(np.exp(m.class_log_prior_), [0.4, 0.6])
    V = len(vocab)
    spam_counts = X[[0, 1, 4]].sum(0)
    expected = np.log((spam_counts + 1) / (spam_counts.sum() + V))
    np.testing.assert_allclose(m.feature_log_prob_[1], expected)


def test_predict():
    X, vocab = count_vectorize(DOCS)
    m = MultinomialNB().fit(X, LABELS)
    Q, _ = count_vectorize(["free money offer", "notes from the meeting"], vocab)
    assert list(m.predict(Q)) == ["spam", "ham"]
    P = m.predict_proba(Q)
    np.testing.assert_allclose(P.sum(1), 1.0)
    assert P[0, 1] > 0.9


def test_long_document_stable():
    X, vocab = count_vectorize(DOCS)
    m = MultinomialNB().fit(X, LABELS)
    Q = np.zeros((1, len(vocab)))
    Q[0, vocab["free"]] = 5000
    lp = m.predict_log_proba(Q)
    assert np.all(np.isfinite(lp)) and np.isclose(np.exp(lp).sum(), 1.0)


def test_alpha_effect_and_negative():
    X, _ = count_vectorize(DOCS)
    a = MultinomialNB(alpha=0.01).fit(X, LABELS)
    b = MultinomialNB(alpha=10).fit(X, LABELS)
    assert np.ptp(b.feature_log_prob_[1]) < np.ptp(a.feature_log_prob_[1])
    try:
        MultinomialNB().fit(-X, LABELS)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
