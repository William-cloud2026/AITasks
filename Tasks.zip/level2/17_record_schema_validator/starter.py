# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re

def validate(record, schema):
    """Return a list of '<path>: <message>' errors."""
    raise NotImplementedError('TODO')
