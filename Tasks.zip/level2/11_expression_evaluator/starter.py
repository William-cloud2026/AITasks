# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import re

class EvalError(Exception):
    """Raised for any evaluation problem."""

def evaluate(expr, variables=None):
    """Safely evaluate an arithmetic expression."""
    raise NotImplementedError('TODO')
