# L3-13 · Softmax (Multinomial Logistic) Regression

**Level:** 3 · **Topics:** multiclass classification, stable softmax, cross-entropy gradients · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
### `softmax(Z, axis=-1)`
Numerically stable (subtract the max). Works for any array shape along `axis`.

### `cross_entropy_and_grad(X, Y, W, b, l2=0.0) -> (loss, grad_W, grad_b)`
`Y` is one-hot `(n, C)`, `W` is `(d, C)`, `b` is `(C,)`. `P = softmax(XW + b)`;
`loss = −mean_i Σ_c Y_ic·log P_ic + (l2/2)·‖W‖²_F`. Compute `log P` stably (log-softmax), not `log(softmax)`.

### `class SoftmaxRegression(lr=0.1, epochs=500, l2=0.0)`
- `fit(X, y)`: `classes_` = sorted unique labels (any hashable type), full-batch GD from zeros;
  stores `W_`, `b_`, `loss_history_` where `loss_history_[i]` is the loss **before** the `i`-th update
  (so `loss_history_[0] == ln(C)`).
- `predict_proba(X)` `(n, C)`; `predict(X)` → labels.
