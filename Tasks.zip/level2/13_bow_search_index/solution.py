import math
import re
from collections import Counter, defaultdict


def _tokens(text):
    return re.findall(r"\w+", text.lower())


class BowIndex:
    """Cosine-similarity keyword search over raw term counts."""

    def __init__(self):
        self._docs = {}
        self._norms = {}
        self._postings = defaultdict(dict)

    def add(self, doc_id, text):
        """Index a document."""
        if doc_id in self._docs:
            raise ValueError(f"duplicate doc_id {doc_id!r}")
        counts = Counter(_tokens(text))
        self._docs[doc_id] = counts
        self._norms[doc_id] = math.sqrt(sum(c * c for c in counts.values()))
        for term, c in counts.items():
            self._postings[term][doc_id] = c

    def remove(self, doc_id):
        """Remove a document."""
        counts = self._docs.pop(doc_id)
        del self._norms[doc_id]
        for term in counts:
            del self._postings[term][doc_id]
            if not self._postings[term]:
                del self._postings[term]

    def search(self, query, k=5):
        """Top-k (doc_id, cosine) pairs with score > 0."""
        q = Counter(_tokens(query))
        if not q:
            return []
        qnorm = math.sqrt(sum(c * c for c in q.values()))
        dots = defaultdict(float)
        for term, qc in q.items():
            for doc_id, dc in self._postings.get(term, {}).items():
                dots[doc_id] += qc * dc
        scored = [(d, s / (qnorm * self._norms[d])) for d, s in dots.items() if s > 0]
        scored.sort(key=lambda x: (-x[1], x[0]))
        return scored[:k]

    def __len__(self):
        return len(self._docs)
