import numpy as np

from starter import PolynomialFeatures


def test_degree2_names_and_values():
    p = PolynomialFeatures(2).fit([[1, 2]])
    assert p.get_feature_names_out(["a", "b"]) == ["1", "a", "b", "a^2", "a b", "b^2"]
    np.testing.assert_allclose(p.transform([[2, 3]]), [[1, 2, 3, 4, 6, 9]])


def test_degree3_three_features():
    p = PolynomialFeatures(3, include_bias=False).fit(np.ones((1, 3)))
    names = p.get_feature_names_out()
    assert len(names) == 3 + 6 + 10
    assert names[:4] == ["x0", "x1", "x2", "x0^2"]
    assert names[-1] == "x2^3" and "x0 x1 x2" in names and names[9] == "x0^3"
    assert names[10] == "x0^2 x1"


def test_interaction_only():
    p = PolynomialFeatures(3, interaction_only=True).fit(np.ones((1, 3)))
    assert p.get_feature_names_out() == ["1", "x0", "x1", "x2", "x0 x1", "x0 x2", "x1 x2", "x0 x1 x2"]
    np.testing.assert_allclose(p.transform([[2, 3, 5]]), [[1, 2, 3, 5, 6, 10, 15, 30]])


def test_powers_matrix():
    p = PolynomialFeatures(2).fit(np.zeros((2, 2)))
    np.testing.assert_array_equal(p.powers_, [[0, 0], [1, 0], [0, 1], [2, 0], [1, 1], [0, 2]])
    assert p.n_features_in_ == 2


def test_errors():
    for fn in (lambda: PolynomialFeatures(0), lambda: PolynomialFeatures(2).fit([[1, 2]]).transform([[1, 2, 3]])):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
