# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class LoRALinear:
    """Linear layer with a low-rank trainable adapter."""

    def __init__(self, W, b, r=4, alpha=8.0, seed=0):
        raise NotImplementedError('TODO')

    def delta_weight(self):
        """scaling * A @ B."""
        raise NotImplementedError('TODO')

    def forward(self, x):
        """Base output plus low-rank update."""
        raise NotImplementedError('TODO')

    def backward(self, dout):
        """Gradients for A and B; returns dx."""
        raise NotImplementedError('TODO')

    def merge(self):
        """Fold the adapter into W."""
        raise NotImplementedError('TODO')

    def unmerge(self):
        """Remove the adapter from W."""
        raise NotImplementedError('TODO')

    def trainable_parameters(self):
        """Number of trainable scalars."""
        raise NotImplementedError('TODO')
