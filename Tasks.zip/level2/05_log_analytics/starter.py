# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import json
import math
from collections import Counter, defaultdict

def percentile(values, p):
    """Nearest-rank percentile."""
    raise NotImplementedError('TODO')

def analyze_logs(lines):
    """Aggregate JSON-lines inference logs."""
    raise NotImplementedError('TODO')
