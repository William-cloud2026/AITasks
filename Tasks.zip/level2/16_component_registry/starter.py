# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import difflib

class Registry:
    """Name -> object registry with config-driven building."""

    def __init__(self, name):
        raise NotImplementedError('TODO')

    def register(self, name=None):
        """Decorator to register an object under a name."""
        raise NotImplementedError('TODO')

    def get(self, name):
        """Look up a registered object."""
        raise NotImplementedError('TODO')

    def build(self, config):
        """Instantiate from a {'type': name, **kwargs} config."""
        raise NotImplementedError('TODO')

    def names(self):
        """Sorted registered names."""
        raise NotImplementedError('TODO')

    def __contains__(self, name):
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')
