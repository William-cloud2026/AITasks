import numpy as np


def sigmoid(z):
    """Numerically stable logistic function."""
    z = np.asarray(z, dtype=float)
    out = np.empty_like(z)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out if out.ndim else float(out)


def bce_loss_and_grad(X, y, w, b, l2=0.0):
    """Stable binary cross-entropy with L2 and its gradients."""
    z = X @ w + b
    loss = float(np.mean(np.logaddexp(0.0, z) - y * z) + 0.5 * l2 * w @ w)
    r = sigmoid(z) - y
    return loss, X.T @ r / len(y) + l2 * w, float(r.mean())


class LogisticRegression:
    """Binary logistic regression trained with full-batch GD."""

    def __init__(self, lr=0.1, epochs=1000, l2=0.0):
        self.lr, self.epochs, self.l2 = lr, epochs, l2

    def fit(self, X, y):
        """Fit weights."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        if len(self.classes_) != 2:
            raise ValueError("exactly two classes required")
        t = (y == self.classes_[1]).astype(float)
        w, b = np.zeros(X.shape[1]), 0.0
        self.loss_history_ = []
        for _ in range(self.epochs):
            _, gw, gb = bce_loss_and_grad(X, t, w, b, self.l2)
            w, b = w - self.lr * gw, b - self.lr * gb
            self.loss_history_.append(bce_loss_and_grad(X, t, w, b, self.l2)[0])
        self.coef_, self.intercept_ = w, b
        return self

    def predict_proba(self, X):
        """P(classes_[1] | x)."""
        return sigmoid(np.asarray(X, dtype=float) @ self.coef_ + self.intercept_)

    def predict(self, X, threshold=0.5):
        """Class labels."""
        return np.where(self.predict_proba(X) >= threshold, self.classes_[1], self.classes_[0])
