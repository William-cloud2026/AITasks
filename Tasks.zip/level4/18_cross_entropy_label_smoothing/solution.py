import numpy as np


def cross_entropy(logits, targets, label_smoothing=0.0, ignore_index=-100, reduction="mean"):
    """Cross-entropy loss and its gradient w.r.t. logits."""
    if reduction not in ("mean", "sum", "none"):
        raise ValueError("invalid reduction")
    logits = np.asarray(logits, dtype=float)
    targets = np.asarray(targets)
    C = logits.shape[-1]
    Z = logits.reshape(-1, C)
    t = targets.reshape(-1)
    valid = t != ignore_index
    if np.any((t[valid] < 0) | (t[valid] >= C)):
        raise ValueError("target out of range")
    m = Z.max(1, keepdims=True)
    logp = Z - m - np.log(np.exp(Z - m).sum(1, keepdims=True))
    q = np.full_like(Z, label_smoothing / C)
    rows = np.flatnonzero(valid)
    q[rows, t[valid]] += 1.0 - label_smoothing
    q[~valid] = 0.0
    per = -(q * logp).sum(1)
    grad = np.exp(logp) * valid[:, None] - q
    count = int(valid.sum())
    if reduction == "mean":
        if count == 0:
            return 0.0, np.zeros_like(logits)
        return float(per.sum() / count), (grad / count).reshape(logits.shape)
    if reduction == "sum":
        return float(per.sum()), grad.reshape(logits.shape)
    return per.reshape(targets.shape), grad.reshape(logits.shape)
