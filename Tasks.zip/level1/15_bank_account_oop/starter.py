# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

class InsufficientFundsError(Exception):
    """Raised when a withdrawal exceeds the balance."""

class BankAccount:
    """A simple bank account with history."""

    def __init__(self, owner, balance=0):
        raise NotImplementedError('TODO')

    @property
    def balance(self):
        """Current balance (read-only)."""
        raise NotImplementedError('TODO')

    @property
    def history(self):
        """Copy of the transaction history."""
        raise NotImplementedError('TODO')

    def deposit(self, amount):
        """Add money; return new balance."""
        raise NotImplementedError('TODO')

    def withdraw(self, amount):
        """Remove money; return new balance."""
        raise NotImplementedError('TODO')

    def transfer_to(self, other, amount):
        """Atomically move money to another account."""
        raise NotImplementedError('TODO')

    def __repr__(self):
        raise NotImplementedError('TODO')
