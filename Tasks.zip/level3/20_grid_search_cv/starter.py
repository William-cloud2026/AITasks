# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import itertools
import numpy as np

def parameter_grid(param_grid):
    """Expand a grid (or list of grids) into parameter dicts."""
    raise NotImplementedError('TODO')

class GridSearchCV:
    """Exhaustive search over a parameter grid."""

    def __init__(self, make_model, param_grid, cv=3, scoring=None):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Evaluate every combination and refit the best."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predict with the refitted best model."""
        raise NotImplementedError('TODO')
