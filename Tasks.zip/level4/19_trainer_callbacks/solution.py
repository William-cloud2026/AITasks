import copy


class Callback:
    """Base callback with no-op hooks."""

    def on_train_begin(self, trainer):
        pass

    def on_epoch_end(self, trainer, epoch, logs):
        pass

    def on_train_end(self, trainer):
        pass


def _better(mode, value, best, min_delta=0.0):
    if best is None:
        return True
    return value < best - min_delta if mode == "min" else value > best + min_delta


class EarlyStopping(Callback):
    """Stop when a monitored metric stops improving."""

    def __init__(self, monitor="val_loss", mode="min", patience=3, min_delta=0.0, restore_best=True):
        if mode not in ("min", "max"):
            raise ValueError("mode must be 'min' or 'max'")
        self.monitor, self.mode, self.patience = monitor, mode, patience
        self.min_delta, self.restore_best = min_delta, restore_best

    def on_train_begin(self, trainer):
        self.best, self.best_epoch, self.wait = None, None, 0
        self.best_state, self.stopped_epoch = None, None

    def on_epoch_end(self, trainer, epoch, logs):
        value = logs[self.monitor]
        if _better(self.mode, value, self.best, self.min_delta):
            self.best, self.best_epoch, self.wait = value, epoch, 0
            if self.restore_best:
                self.best_state = copy.deepcopy(trainer.get_state())
        else:
            self.wait += 1
            if self.wait >= self.patience:
                trainer.stop_training = True
                self.stopped_epoch = epoch

    def on_train_end(self, trainer):
        if self.restore_best and self.best_state is not None:
            trainer.set_state(self.best_state)


class ModelCheckpoint(Callback):
    """Keep in-memory snapshots of the model state."""

    def __init__(self, monitor="val_loss", mode="min", save_best_only=True):
        if mode not in ("min", "max"):
            raise ValueError("mode must be 'min' or 'max'")
        self.monitor, self.mode, self.save_best_only = monitor, mode, save_best_only
        self.saved = []
        self.best = None

    def on_train_begin(self, trainer):
        self.saved, self.best = [], None

    def on_epoch_end(self, trainer, epoch, logs):
        value = logs[self.monitor]
        improved = _better(self.mode, value, self.best)
        if improved:
            self.best = value
        if improved or not self.save_best_only:
            self.saved.append((epoch, value, copy.deepcopy(trainer.get_state())))


class Trainer:
    """Minimal epoch loop with callbacks."""

    def __init__(self, train_epoch, evaluate=None, get_state=None, set_state=None, callbacks=()):
        self.train_epoch, self.evaluate = train_epoch, evaluate
        self._get_state, self._set_state = get_state, set_state
        self.callbacks = list(callbacks)
        self.stop_training = False

    def get_state(self):
        """User-provided model state."""
        if self._get_state is None:
            raise RuntimeError("get_state not provided")
        return self._get_state()

    def set_state(self, state):
        """Restore model state."""
        if self._set_state is None:
            raise RuntimeError("set_state not provided")
        self._set_state(state)

    def fit(self, epochs):
        """Run the training loop."""
        self.stop_training = False
        history = {}
        for cb in self.callbacks:
            cb.on_train_begin(self)
        for epoch in range(epochs):
            logs = dict(self.train_epoch(epoch))
            if self.evaluate:
                logs.update(self.evaluate(epoch))
            for k, v in logs.items():
                history.setdefault(k, []).append(v)
            for cb in self.callbacks:
                cb.on_epoch_end(self, epoch, logs)
            if self.stop_training:
                break
        for cb in self.callbacks:
            cb.on_train_end(self)
        return history
