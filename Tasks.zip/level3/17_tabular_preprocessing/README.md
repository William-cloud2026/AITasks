# L3-17 · Imputation & One-Hot Encoding

**Level:** 3 · **Topics:** missing data, categorical features, robust APIs · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
### `class SimpleImputer(strategy="mean", fill_value=None)`
For numeric 2-D arrays with `np.nan` marking missing values.
- strategies: `"mean"`, `"median"`, `"most_frequent"` (ties → smallest value), `"constant"` (uses `fill_value`,
  which must not be `None` → `ValueError`). Unknown strategy → `ValueError`.
- `fit(X)` sets `statistics_` (one value per column, computed ignoring NaNs). A column that is entirely NaN with a
  non-constant strategy → `ValueError`.
- `transform(X)` returns a copy with NaNs replaced; `fit_transform(X)`.

### `class OneHotEncoder(handle_unknown="error")`
For 2-D array-likes of categorical values (strings/ints, compared with `==`).
- `fit(X)` → `categories_`: list (one per column) of **sorted** unique values (as numpy arrays).
- `transform(X)` → float array `(n, Σ |categories_j|)`, columns ordered by input column then category.
  Unknown category: `"error"` → `ValueError`; `"ignore"` → all zeros for that column block.
- `get_feature_names_out(input_features=None)` → `"{feature}_{category}"`, default features `x0, x1, ...`.
- `inverse_transform(Z)` → object array of original categories (an all-zero block → `None`).
