# L2-02 · Retry Decorator with Exponential Backoff

**Level:** 2 · **Topics:** decorators, closures, exceptions, dependency injection · **Time:** ~30 min · **Allowed:** Python stdlib

## Task
Implement `retry(max_attempts=3, exceptions=(Exception,), backoff=0.0, factor=2.0, sleep=time.sleep, on_retry=None)`
returning a decorator. Typical use: wrapping flaky calls to a model server.

- The wrapped function is called up to `max_attempts` times.
- Only exceptions that are instances of `exceptions` trigger a retry; others propagate immediately.
- Before retry number `k` (k = 1 for the first retry) call `sleep(backoff * factor ** (k - 1))`.
  Never sleep after the final failed attempt. Do not call `sleep` at all when the delay is `0`.
- `on_retry(attempt, exc)` (if given) is called before each sleep, `attempt` being the 1-based number of the
  attempt that just failed.
- After the last attempt fails, re-raise **that** exception.
- The wrapper must preserve `__name__` and `__doc__` (`functools.wraps`) and expose the number of attempts used
  by the most recent call as `wrapper.last_attempts`.
- `max_attempts < 1` or `backoff < 0` → `ValueError` when `retry(...)` is called.

## Example
```python
@retry(max_attempts=4, exceptions=(ConnectionError,), backoff=0.5)
def call_model(prompt): ...
# sleeps 0.5, 1.0, 2.0 between attempts
```
