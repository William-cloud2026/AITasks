# L3-16 · Linear SVM with Pegasos (SGD on Hinge Loss)

**Level:** 3 · **Topics:** convex optimization, SGD, margins · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `hinge_loss(X, y, w, b, lam)`
`y ∈ {−1, +1}`. Return `(lam/2)·‖w‖² + mean(max(0, 1 − y·(Xw + b)))`.

### `class LinearSVM(lam=0.01, epochs=20, seed=0)`
- `fit(X, y)`: exactly two classes (else `ValueError`); `classes_` sorted; `classes_[1]` → `+1`, `classes_[0]` → `−1`.
- **Bias trick:** append a constant feature `1.0` to every sample, so the bias is the last weight (it is regularized
  like the others). Let `z_i` be the augmented sample.
- Pegasos: start `w = 0` (length `d + 1`), `t = 1`, one `rng = np.random.default_rng(seed)`.
  Each epoch: `for i in rng.permutation(n)`:
  - `eta = 1 / (lam · t)`
  - if `y_i·(w·z_i) < 1`: `w ← (1 − eta·lam)·w + eta·y_i·z_i`
  - else: `w ← (1 − eta·lam)·w`
  - `t ← t + 1`
- Attributes `coef_` (first `d` weights), `intercept_` (last weight); `decision_function(X)`;
  `predict(X)` → labels (`classes_[1]` if decision `>= 0`).
