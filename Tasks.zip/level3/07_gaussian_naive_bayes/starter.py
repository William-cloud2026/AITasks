# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class GaussianNB:
    """Gaussian naive Bayes classifier."""

    def __init__(self, var_smoothing=1e-09):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Estimate per-class Gaussians."""
        raise NotImplementedError('TODO')

    def predict_log_proba(self, X):
        """Normalized log posteriors."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Posterior probabilities."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Most probable class."""
        raise NotImplementedError('TODO')
