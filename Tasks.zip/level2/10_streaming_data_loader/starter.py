# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import json
import random

def read_jsonl(path):
    """Yield objects from a JSON-lines file."""
    raise NotImplementedError('TODO')

def shuffle_buffer(iterable, buffer_size, seed=None):
    """Streaming approximate shuffle."""
    raise NotImplementedError('TODO')

def interleave(*iterables):
    """Round-robin across iterables."""
    raise NotImplementedError('TODO')
