# L2-17 · Record Schema Validator

**Level:** 2 · **Topics:** recursion, data validation, error reporting · **Time:** ~45 min · **Allowed:** Python stdlib

## Task
Implement `validate(record, schema) -> list[str]` for cleaning a training dataset. Return **all** errors
(empty list = valid). Each error string has the form `"<path>: <message>"` (message wording is up to you).

`schema` maps field name → spec. Spec keys:
| Key | Meaning |
|---|---|
| `type` | one of `"str" "int" "float" "bool" "list" "dict"` (required). `int` rejects `bool`; `float` accepts `int` but not `bool` |
| `required` | default `True`; missing required field → error at that field's path |
| `nullable` | default `False`; `None` allowed only if `True` (then no further checks) |
| `min` / `max` | numbers: value bounds; `str`/`list`: length bounds (inclusive) |
| `choices` | value must be in this list |
| `pattern` | `str` only: must `re.fullmatch` |
| `items` | `list` only: spec applied to each element, path `field[i]` |
| `fields` | `dict` only: nested schema, path `field.sub` |

Rules:
- Paths: `"age"`, `"tags[1]"`, `"meta.source"`, `"meta.scores[0]"`.
- If the type is wrong, report **only** the type error for that value (skip its other checks).
- Keys present in the record (or nested dict) but absent from the schema → `"<path>: unexpected field"`.
- Order: schema fields in schema order (depth-first), then unexpected fields in record order.
