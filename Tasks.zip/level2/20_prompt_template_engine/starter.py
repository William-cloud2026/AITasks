# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re

class TemplateError(Exception):
    """Raised for any template problem."""

def render(template, context):
    """Render a template with the given context."""
    raise NotImplementedError('TODO')

def format_chat(messages, add_generation_prompt=True):
    """Format chat messages with role markers."""
    raise NotImplementedError('TODO')
