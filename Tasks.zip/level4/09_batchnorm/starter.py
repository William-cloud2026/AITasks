# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class BatchNorm1d:
    """Batch normalization over the batch dimension."""

    def __init__(self, num_features, eps=1e-05, momentum=0.1):
        raise NotImplementedError('TODO')

    def train(self):
        """Switch to training mode."""
        raise NotImplementedError('TODO')

    def eval(self):
        """Switch to evaluation mode."""
        raise NotImplementedError('TODO')

    def forward(self, x):
        """Normalize x."""
        raise NotImplementedError('TODO')

    def backward(self, dout):
        """Gradients for a training-mode forward."""
        raise NotImplementedError('TODO')
