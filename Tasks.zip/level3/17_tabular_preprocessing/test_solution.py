import numpy as np

from starter import OneHotEncoder, SimpleImputer

nan = np.nan
X = np.array([[1.0, nan, 3.0], [nan, 2.0, 3.0], [7.0, 2.0, nan], [4.0, 8.0, 5.0]])


def expect_value_error(fn):
    try:
        fn()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_imputer_strategies():
    np.testing.assert_allclose(SimpleImputer("mean").fit(X).statistics_, [4.0, 4.0, 11 / 3])
    np.testing.assert_allclose(SimpleImputer("median").fit(X).statistics_, [4.0, 2.0, 3.0])
    np.testing.assert_allclose(SimpleImputer("most_frequent").fit(X).statistics_, [1.0, 2.0, 3.0])
    Z = SimpleImputer("constant", fill_value=-1).fit_transform(X)
    assert Z[0, 1] == -1 and Z[2, 2] == -1 and not np.isnan(Z).any()


def test_imputer_transform_copy():
    X0 = X.copy()
    Z = SimpleImputer("median").fit_transform(X)
    np.testing.assert_allclose(Z[1], [4.0, 2.0, 3.0])
    assert np.isnan(X).sum() == 3
    np.testing.assert_array_equal(np.isnan(X), np.isnan(X0))


def test_imputer_errors():
    expect_value_error(lambda: SimpleImputer("mode"))
    expect_value_error(lambda: SimpleImputer("constant"))
    expect_value_error(lambda: SimpleImputer().fit([[nan, 1.0], [nan, 2.0]]))


CAT = [["red", "S"], ["blue", "M"], ["red", "L"], ["green", "M"]]


def test_onehot_basic():
    enc = OneHotEncoder().fit(CAT)
    assert [c.tolist() for c in enc.categories_] == [["blue", "green", "red"], ["L", "M", "S"]]
    Z = enc.transform([["green", "S"]])
    np.testing.assert_array_equal(Z, [[0, 1, 0, 0, 0, 1]])
    assert enc.get_feature_names_out(["color", "size"]) == [
        "color_blue", "color_green", "color_red", "size_L", "size_M", "size_S"]
    assert enc.get_feature_names_out()[0] == "x0_blue"


def test_onehot_unknown():
    expect_value_error(lambda: OneHotEncoder().fit(CAT).transform([["pink", "S"]]))
    Z = OneHotEncoder(handle_unknown="ignore").fit(CAT).transform([["pink", "S"]])
    np.testing.assert_array_equal(Z, [[0, 0, 0, 0, 0, 1]])


def test_onehot_inverse_and_ints():
    enc = OneHotEncoder(handle_unknown="ignore").fit(CAT)
    inv = enc.inverse_transform(enc.transform(CAT + [["pink", "XL"]]))
    assert inv[:4].tolist() == CAT and inv[4].tolist() == [None, None]
    enc = OneHotEncoder().fit([[3], [1], [3]])
    np.testing.assert_array_equal(enc.transform([[1], [3]]), [[1, 0], [0, 1]])
