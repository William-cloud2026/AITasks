# L5-14 · Generation Evaluation Metrics: EM, F1, BLEU, ROUGE-L

**Level:** 5 · **Topics:** LLM evaluation, n-gram statistics, dynamic programming · **Time:** ~60 min · **Allowed:** Python stdlib

## Task
### `normalize_answer(s)` (SQuAD)
lower-case → remove ASCII punctuation (`string.punctuation`) → remove articles (`\b(a|an|the)\b`) → collapse whitespace.

### `exact_match(prediction, golds)` / `token_f1(prediction, golds)`
`golds` is a string or a list of strings; return the **max** over golds (float).
- EM: `1.0` if normalized strings are equal.
- F1 over normalized whitespace tokens (multiset overlap). If either side has no tokens → `float(both empty)`.

### `corpus_bleu(candidates, references, max_n=4, smooth=False)`
`candidates`: list of strings; `references`: list of lists of strings (one or more refs per candidate).
Tokenize by `str.split()` (case-sensitive).
- For each `n ≤ max_n`: `matches_n = Σ_cand Σ_ngram min(count_cand, max over refs of count_ref)`,
  `totals_n = Σ_cand max(len_cand − n + 1, 0)`; `p_n = matches_n / totals_n`.
- `smooth=True`: for `n ≥ 2` use `p_n = (matches_n + 1) / (totals_n + 1)`.
- If `totals_1 == 0` or any `p_n == 0` → return `0.0`.
- Brevity penalty: `c = Σ len_cand`, `r = Σ` (reference length closest to the candidate length; ties → shorter);
  `BP = 1 if c > r else exp(1 − r/c)`.
- `BLEU = BP · exp(mean_n log p_n)`.

### `rouge_l(prediction, reference)`
Lower-cased whitespace tokens; `LCS` = longest common subsequence length; `P = LCS/len(pred)`, `R = LCS/len(ref)`,
return `F1 = 2PR/(P+R)` (`0.0` if LCS is 0 or either side empty).
