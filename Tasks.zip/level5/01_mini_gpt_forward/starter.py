# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def gpt_forward(ids, weights, config):
    """Logits of a GPT-2 style decoder."""
    raise NotImplementedError('TODO')

def count_parameters(config):
    """Number of scalars in the weight dict."""
    raise NotImplementedError('TODO')
