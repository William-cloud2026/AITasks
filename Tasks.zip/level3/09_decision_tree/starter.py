# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class DecisionTreeClassifier:
    """CART classifier with Gini impurity."""

    def __init__(self, max_depth=None, min_samples_split=2, min_samples_leaf=1):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Grow the tree."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Leaf class frequencies."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Majority class of the leaf."""
        raise NotImplementedError('TODO')

    def get_depth(self):
        """Maximum depth (root leaf = 0)."""
        raise NotImplementedError('TODO')

    def get_n_leaves(self):
        """Number of leaves."""
        raise NotImplementedError('TODO')

    def root_split(self):
        """(feature, threshold) of the root or None."""
        raise NotImplementedError('TODO')
