from collections import Counter


def _merge(ids, pair, new_id):
    out, i = [], 0
    while i < len(ids):
        if i + 1 < len(ids) and ids[i] == pair[0] and ids[i + 1] == pair[1]:
            out.append(new_id)
            i += 2
        else:
            out.append(ids[i])
            i += 1
    return out


class BPETokenizer:
    """Byte-level byte-pair-encoding tokenizer."""

    def __init__(self):
        self.merges = {}
        self.vocab = {i: bytes([i]) for i in range(256)}

    def train(self, text, vocab_size):
        """Learn merges from text."""
        if vocab_size < 256:
            raise ValueError("vocab_size must be >= 256")
        self.merges = {}
        self.vocab = {i: bytes([i]) for i in range(256)}
        ids = list(text.encode("utf-8"))
        while len(self.vocab) < vocab_size:
            counts = Counter(zip(ids, ids[1:]))
            if not counts:
                break
            pair, cnt = min(counts.items(), key=lambda kv: (-kv[1], kv[0]))
            if cnt < 2:
                break
            new_id = 256 + len(self.merges)
            ids = _merge(ids, pair, new_id)
            self.merges[pair] = new_id
            self.vocab[new_id] = self.vocab[pair[0]] + self.vocab[pair[1]]
        return self

    def encode(self, text):
        """Text -> token ids."""
        ids = list(text.encode("utf-8"))
        while len(ids) >= 2:
            candidates = [p for p in set(zip(ids, ids[1:])) if p in self.merges]
            if not candidates:
                break
            pair = min(candidates, key=self.merges.get)
            ids = _merge(ids, pair, self.merges[pair])
        return ids

    def decode(self, ids):
        """Token ids -> text."""
        return b"".join(self.vocab[i] for i in ids).decode("utf-8", errors="replace")
