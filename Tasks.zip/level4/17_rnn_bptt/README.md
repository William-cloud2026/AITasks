# L4-17 · Vanilla RNN with Backprop Through Time

**Level:** 4 · **Topics:** recurrent networks, BPTT, gradient clipping · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
### `class RNN(input_size, hidden_size, seed=0)`
- `rng = np.random.default_rng(seed)`; with `k = 1/sqrt(hidden_size)` draw, in this order,
  `Wx (input_size, hidden_size)`, `Wh (hidden_size, hidden_size)`, `b (hidden_size,)` from `rng.uniform(-k, k, ...)`.
- `forward(x, h0=None)`: `x` is **time-major** `(T, N, input_size)`; `h0` defaults to zeros `(N, hidden)`.
  `h_t = tanh(x_t Wx + h_{t−1} Wh + b)`. Returns `hs (T, N, hidden)`.
- `backward(dhs)`: `dhs (T, N, hidden)` is the gradient of the loss w.r.t. **every** hidden state. Returns
  `(dx, dh0)` and sets `dWx`, `dWh`, `db`.

### `clip_grad_norm(grads, max_norm) -> float`
Global L2 norm over all arrays in `grads`. If it exceeds `max_norm`, scale every array **in place** by
`max_norm / total_norm`. Return the norm **before** clipping.
