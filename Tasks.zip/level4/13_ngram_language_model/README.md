# L4-13 · N-gram Language Model with Add-k Smoothing

**Level:** 4 · **Topics:** language modeling, smoothing, perplexity, sampling · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class NGramLM(n=2, k=1.0)` over pre-tokenized sentences (lists of strings). `n < 1` or `k <= 0` → `ValueError`.

- Special tokens: `"<s>"` (padding, never predicted), `"</s>"` (end of sentence), `"<unk>"`.
- `fit(sentences)`: each sentence becomes `["<s>"]*(n−1) + sentence + ["</s>"]`; count every n-gram and its
  `(n−1)`-token context. `vocab` = all training tokens ∪ `{"</s>", "<unk>"}` (**not** `"<s>"`). Returns `self`.
- Out-of-vocabulary tokens are mapped to `"<unk>"` whenever the model is queried.
- `prob(word, context=())`: uses the **last `n−1`** tokens of `context`, left-padded with `"<s>"` if shorter.
  `P = (count(ctx, w) + k) / (count(ctx) + k·V)` with `V = len(vocab)`.
- `sentence_logprob(sentence)`: natural-log probability of the sentence **including** `"</s>"`.
- `perplexity(sentences)`: `exp(−Σ logprob / Σ (len(sentence) + 1))`.
- `generate(max_len=20, seed=None) -> list[str]`: start with `n−1` `"<s>"`; repeatedly sample the next token from the
  distribution over `sorted(vocab)` using `np.random.default_rng(seed).choice(len, p=...)`; stop at `"</s>"` (not
  included) or after `max_len` tokens.
