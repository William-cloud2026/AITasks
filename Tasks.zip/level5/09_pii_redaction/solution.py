import re

_DETECTORS = [
    ("EMAIL", re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("CREDIT_CARD", re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")),
    ("SSN", re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)")),
    ("IPV4", re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")),
    ("PHONE", re.compile(r"(?<!\w)(?:\+\d{1,3}[ .-]?)?(?:\(\d{3}\)|\d{3})[ .-]?\d{3}[ .-]?\d{4}(?!\d)")),
]


def luhn_valid(number):
    """Luhn checksum."""
    digits = [int(c) for c in number if c.isdigit()]
    if len(digits) < 2:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _valid(kind, value):
    if kind == "CREDIT_CARD":
        return luhn_valid(value)
    if kind == "IPV4":
        return all(int(p) <= 255 for p in value.split("."))
    return True


def find_pii(text, types=None):
    """Detect PII spans with overlap resolution."""
    matches = []
    for prio, (kind, rx) in enumerate(_DETECTORS):
        if types is not None and kind not in types:
            continue
        for m in rx.finditer(text):
            if _valid(kind, m.group()):
                matches.append((m.start(), -(m.end() - m.start()), prio, kind, m.end(), m.group()))
    matches.sort()
    out, last_end = [], -1
    for start, _, _, kind, end, value in matches:
        if start >= last_end:
            out.append({"type": kind, "start": start, "end": end, "value": value})
            last_end = end
    return out


def redact(text, types=None):
    """Replace PII with [TYPE] markers."""
    findings = find_pii(text, types)
    parts, pos = [], 0
    for f in findings:
        parts.append(text[pos:f["start"]])
        parts.append(f"[{f['type']}]")
        pos = f["end"]
    parts.append(text[pos:])
    return "".join(parts), findings
