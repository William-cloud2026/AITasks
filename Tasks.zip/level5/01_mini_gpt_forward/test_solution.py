import json
import os

import numpy as np

from starter import count_parameters, gpt_forward

CFG = {"vocab_size": 11, "d_model": 8, "n_heads": 2, "n_layers": 2, "max_seq_len": 6}


def make_weights(cfg, seed=0):
    rng = np.random.default_rng(seed)
    V, d, L, T = cfg["vocab_size"], cfg["d_model"], cfg["n_layers"], cfg["max_seq_len"]
    shapes = {"wte": (V, d), "wpe": (T, d), "lnf.g": (d,), "lnf.b": (d,)}
    for i in range(L):
        shapes.update({f"h{i}.ln1.g": (d,), f"h{i}.ln1.b": (d,), f"h{i}.ln2.g": (d,), f"h{i}.ln2.b": (d,),
                       f"h{i}.attn.w_qkv": (d, 3 * d), f"h{i}.attn.b_qkv": (3 * d,),
                       f"h{i}.attn.w_o": (d, d), f"h{i}.attn.b_o": (d,),
                       f"h{i}.mlp.w1": (d, 4 * d), f"h{i}.mlp.b1": (4 * d,),
                       f"h{i}.mlp.w2": (4 * d, d), f"h{i}.mlp.b2": (d,)})
    w = {}
    for k in sorted(shapes):
        scale = 1.0 if k.endswith(".g") else 0.5
        base = 1.0 if k.endswith(".g") else 0.0
        w[k] = base + scale * rng.normal(size=shapes[k]) * (0.3 if k.endswith(".g") else 1.0)
    return w


W = make_weights(CFG)
IDS = np.array([[3, 1, 4, 1, 5], [9, 2, 6, 5, 3]])


def test_matches_fixture():
    with open(os.path.join(os.path.dirname(__file__), "expected_logits.json")) as f:
        expected = np.array(json.load(f))
    np.testing.assert_allclose(gpt_forward(IDS, W, CFG), expected, rtol=1e-7, atol=1e-9)


def test_shapes_and_single_sequence():
    out = gpt_forward(IDS, W, CFG)
    assert out.shape == (2, 5, 11)
    np.testing.assert_allclose(gpt_forward(IDS[1], W, CFG), out[1], atol=1e-12)


def test_causality():
    a = gpt_forward(np.array([3, 1, 4, 1, 5, 9]), W, CFG)
    b = gpt_forward(np.array([3, 1, 4, 7, 7, 7]), W, CFG)
    np.testing.assert_allclose(a[:3], b[:3], atol=1e-12)
    assert not np.allclose(a[3:], b[3:])


def test_prefix_consistency():
    full = gpt_forward(np.array([3, 1, 4, 1, 5, 9]), W, CFG)
    pre = gpt_forward(np.array([3, 1, 4]), W, CFG)
    np.testing.assert_allclose(full[:3], pre, atol=1e-12)


def test_too_long():
    try:
        gpt_forward(np.zeros(7, dtype=int), W, CFG)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_count_parameters():
    assert count_parameters(CFG) == sum(v.size for v in W.values())
    gpt2 = {"vocab_size": 50257, "d_model": 768, "n_heads": 12, "n_layers": 12, "max_seq_len": 1024}
    assert count_parameters(gpt2) == 124_439_808
