from starter import group_anagrams


def test_example():
    assert group_anagrams(["listen", "Google", "Silent", "enlist", "gogole", "cat"]) == [
        ["listen", "Silent", "enlist"], ["Google", "gogole"], ["cat"]]


def test_ignores_non_letters():
    assert group_anagrams(["Dormitory", "dirty room!!", "a1", "A"]) == [["Dormitory", "dirty room!!"], ["a1", "A"]]


def test_duplicates_and_empty():
    assert group_anagrams(["ab", "ba", "ab"]) == [["ab", "ba", "ab"]]
    assert group_anagrams([]) == []


def test_large():
    words = ["abc", "bca", "cab", "xyz"] * 2500
    out = group_anagrams(words)
    assert len(out) == 2 and len(out[0]) == 7500
