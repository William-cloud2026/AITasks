# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class MLPClassifier:
    """ReLU MLP with softmax output trained by Adam."""

    def __init__(self, hidden_sizes=(64, 64), lr=0.01, epochs=200, batch_size=32, l2=0.0, seed=0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Train with mini-batch Adam."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Class probabilities."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predicted labels."""
        raise NotImplementedError('TODO')
