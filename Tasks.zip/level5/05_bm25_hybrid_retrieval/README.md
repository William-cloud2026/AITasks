# L5-05 · BM25 & Hybrid Retrieval with Reciprocal Rank Fusion

**Level:** 5 · **Topics:** information retrieval, ranking functions, rank fusion · **Time:** ~50 min · **Allowed:** Python stdlib (+ numpy optional)

## Task
### `class BM25(k1=1.5, b=0.75)`
- Tokenizer: `re.findall(r"\w+", text.lower())`.
- `fit(docs)` → `self` (list of strings). `N` docs, `avgdl` = mean doc length in tokens, `df(t)` = #docs containing `t`.
- `idf(t) = ln((N − df + 0.5) / (df + 0.5) + 1)` (unknown term → `ln((N + 0.5)/0.5 + 1)`).
- `score(query, doc_index)` = Σ over **unique** query terms of
  `idf(t) · tf·(k1 + 1) / (tf + k1·(1 − b + b·dl/avgdl))` (terms with `tf = 0` contribute 0).
- `search(query, k=10)` → list of `(doc_index, score)` with `score > 0`, sorted by score desc then index asc.

### `reciprocal_rank_fusion(rankings, k=60, top_n=None) -> list[(doc_id, score)]`
`rankings` is a list of ranked lists of doc ids (best first). `score(d) = Σ_lists 1 / (k + rank)` with 1-based rank
(lists not containing `d` contribute nothing). Sort by score desc; ties → smaller **best rank** (the doc's minimum
rank over all lists), then order of first appearance when scanning the lists in order. Return at most `top_n`.

### `hybrid_search(bm25, dense_scores, query, k=10, rrf_k=60) -> list[(doc_index, score)]`
`dense_scores` is a 1-D array of similarity scores for every document (e.g. from an embedding model). Build the
BM25 ranking (`bm25.search(query, k=N)`) and the dense ranking (all docs sorted by score desc, index asc), fuse with
RRF and return the top `k`.
