import math

from starter import bfs_path, dijkstra, shortest_path

UG = {"A": ["B", "C"], "B": ["D"], "C": ["D", "E"], "D": ["F"], "E": ["F"], "F": []}
WG = {
    "A": {"B": 4, "C": 1},
    "B": {"D": 1},
    "C": {"B": 2, "D": 5},
    "D": {"E": 3},
    "E": {},
    "X": {"A": 1},
}


def test_bfs():
    assert bfs_path(UG, "A", "F") == ["A", "B", "D", "F"]
    assert bfs_path(UG, "C", "F") == ["C", "D", "F"]
    assert bfs_path(UG, "F", "A") is None
    assert bfs_path(UG, "A", "A") == ["A"]


def test_bfs_missing_keys():
    assert bfs_path({"a": ["b"], "b": ["c"]}, "a", "c") == ["a", "b", "c"]
    assert bfs_path({"a": ["b"]}, "a", "z") is None


def test_dijkstra():
    dist, prev = dijkstra(WG, "A")
    assert dist == {"A": 0, "C": 1, "B": 3, "D": 4, "E": 7}
    assert prev == {"C": "A", "B": "C", "D": "B", "E": "D"}


def test_shortest_path():
    assert shortest_path(WG, "A", "E") == (7, ["A", "C", "B", "D", "E"])
    assert shortest_path(WG, "A", "A") == (0, ["A"])
    cost, path = shortest_path(WG, "A", "X")
    assert cost == math.inf and path == []


def test_errors():
    try:
        dijkstra({"a": {"b": -1}, "b": {}}, "a")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")
    try:
        dijkstra(WG, "nope")
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError")


def test_grid_large():
    n = 60
    g = {}
    for r in range(n):
        for c in range(n):
            nb = {}
            if r + 1 < n:
                nb[(r + 1, c)] = 1
            if c + 1 < n:
                nb[(r, c + 1)] = 2
            g[(r, c)] = nb
    cost, path = shortest_path(g, (0, 0), (n - 1, n - 1))
    assert cost == (n - 1) * 3 and len(path) == 2 * n - 1
