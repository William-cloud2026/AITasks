# L2-03 · Section Profiler (Context Managers)

**Level:** 2 · **Topics:** context managers, nesting, injected clocks · **Time:** ~30 min · **Allowed:** Python stdlib

## Task
Implement `class Profiler(clock=time.perf_counter)` to time sections of a training loop.

- `profiler.section(name)` returns a context manager. Sections can be **nested**; the recorded key is the full
  path joined by `/` (e.g. `"epoch/forward"`).
- Each exit adds the elapsed time (`clock()` at exit − `clock()` at entry) to that key and increments its call count.
- Time is recorded even if the block raises; the exception must propagate.
- `profiler.report()` → `{key: {"calls": int, "total": float, "mean": float}}`.
- `profiler.reset()` clears all data.
- `@profiler.timed(name)` decorator: times each call of the function as a section (respects nesting).
- `name` must be a non-empty string without `/` → `ValueError`.

The clock is injectable so tests can use a fake clock. Call `clock()` **exactly once** on enter and **once** on exit.

## Example
```python
p = Profiler()
with p.section("epoch"):
    with p.section("forward"): ...
p.report()  # {'epoch/forward': {...}, 'epoch': {...}}
```
