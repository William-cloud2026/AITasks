# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math

class Value:
    """Scalar with reverse-mode automatic differentiation."""

    def __init__(self, data, _parents=(), _op=''):
        raise NotImplementedError('TODO')

    def __add__(self, other):
        raise NotImplementedError('TODO')

    def __mul__(self, other):
        raise NotImplementedError('TODO')

    def __pow__(self, k):
        raise NotImplementedError('TODO')

    def exp(self):
        """e ** self."""
        raise NotImplementedError('TODO')

    def log(self):
        """Natural log."""
        raise NotImplementedError('TODO')

    def tanh(self):
        """Hyperbolic tangent."""
        raise NotImplementedError('TODO')

    def relu(self):
        """max(0, x)."""
        raise NotImplementedError('TODO')

    def sigmoid(self):
        """Logistic function."""
        raise NotImplementedError('TODO')

    def __neg__(self):
        raise NotImplementedError('TODO')

    def __radd__(self, other):
        raise NotImplementedError('TODO')

    def __sub__(self, other):
        raise NotImplementedError('TODO')

    def __rsub__(self, other):
        raise NotImplementedError('TODO')

    def __rmul__(self, other):
        raise NotImplementedError('TODO')

    def __truediv__(self, other):
        raise NotImplementedError('TODO')

    def __rtruediv__(self, other):
        raise NotImplementedError('TODO')

    def backward(self):
        """Back-propagate from this node."""
        raise NotImplementedError('TODO')

    def __repr__(self):
        raise NotImplementedError('TODO')
