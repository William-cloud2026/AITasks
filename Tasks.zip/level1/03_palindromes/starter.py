# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def is_palindrome(s):
    """Alphanumeric-only, case-insensitive palindrome check."""
    raise NotImplementedError('TODO')

def longest_palindrome(s):
    """Longest contiguous palindromic substring (leftmost on ties)."""
    raise NotImplementedError('TODO')
