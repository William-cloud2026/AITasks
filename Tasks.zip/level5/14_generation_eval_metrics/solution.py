import math
import re
import string
from collections import Counter


def normalize_answer(s):
    """SQuAD-style normalization."""
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def _golds(golds):
    return [golds] if isinstance(golds, str) else list(golds)


def exact_match(prediction, golds):
    """Max exact match over gold answers."""
    p = normalize_answer(prediction)
    return max(float(p == normalize_answer(g)) for g in _golds(golds))


def _f1(pred, gold):
    pt, gt = normalize_answer(pred).split(), normalize_answer(gold).split()
    if not pt or not gt:
        return float(pt == gt)
    same = sum((Counter(pt) & Counter(gt)).values())
    if same == 0:
        return 0.0
    p, r = same / len(pt), same / len(gt)
    return 2 * p * r / (p + r)


def token_f1(prediction, golds):
    """Max token-level F1 over gold answers."""
    return max(_f1(prediction, g) for g in _golds(golds))


def _ngrams(toks, n):
    return Counter(tuple(toks[i:i + n]) for i in range(len(toks) - n + 1))


def corpus_bleu(candidates, references, max_n=4, smooth=False):
    """Corpus-level BLEU with brevity penalty."""
    matches = [0] * max_n
    totals = [0] * max_n
    c_len = r_len = 0
    for cand, refs in zip(candidates, references):
        ct = cand.split()
        rts = [r.split() for r in refs]
        c_len += len(ct)
        r_len += min((abs(len(r) - len(ct)), len(r)) for r in rts)[1]
        for n in range(1, max_n + 1):
            cc = _ngrams(ct, n)
            maxref = Counter()
            for r in rts:
                for g, k in _ngrams(r, n).items():
                    maxref[g] = max(maxref[g], k)
            matches[n - 1] += sum(min(k, maxref[g]) for g, k in cc.items())
            totals[n - 1] += max(len(ct) - n + 1, 0)
    if totals[0] == 0:
        return 0.0
    logs = []
    for n in range(max_n):
        if smooth and n >= 1:
            p = (matches[n] + 1) / (totals[n] + 1)
        else:
            p = matches[n] / totals[n] if totals[n] else 0.0
        if p == 0:
            return 0.0
        logs.append(math.log(p))
    bp = 1.0 if c_len > r_len else math.exp(1 - r_len / c_len)
    return bp * math.exp(sum(logs) / max_n)


def rouge_l(prediction, reference):
    """ROUGE-L F1 via LCS."""
    a, b = prediction.lower().split(), reference.lower().split()
    if not a or not b:
        return 0.0
    prev = [0] * (len(b) + 1)
    for x in a:
        cur = [0]
        for j, y in enumerate(b, 1):
            cur.append(prev[j - 1] + 1 if x == y else max(prev[j], cur[j - 1]))
        prev = cur
    lcs = prev[-1]
    if lcs == 0:
        return 0.0
    p, r = lcs / len(a), lcs / len(b)
    return 2 * p * r / (p + r)
