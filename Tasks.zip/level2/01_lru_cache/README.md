# L2-01 · LRU Cache

**Level:** 2 · **Topics:** hash map + ordering, O(1) operations · **Time:** ~30 min · **Allowed:** Python stdlib (`functools.lru_cache` is **not** allowed)

## Task
Implement `class LRUCache(capacity)` (`capacity < 1` → `ValueError`).

| Member | Behaviour |
|---|---|
| `get(key, default=None)` | return value and mark key as most-recently used; missing → `default` |
| `put(key, value)` | insert/update and mark as most-recently used; evict the least-recently used key if over capacity |
| `__len__`, `__contains__` | `in` must **not** change recency |
| `keys()` | list of keys from **least** to **most** recently used |
| `hits`, `misses` | counters updated by `get` only |
| `on_evict` | optional constructor kwarg `on_evict(key, value)` called for every eviction |

`get` and `put` must be O(1) average (a test runs 200k operations).
