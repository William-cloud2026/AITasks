import numpy as np


def skipgram_pairs(ids, window):
    """(center, context) pairs."""
    n = len(ids)
    return [(ids[i], ids[j]) for i in range(n) for j in range(max(0, i - window), min(n, i + window + 1)) if j != i]


def noise_distribution(counts, power=0.75):
    """Smoothed unigram distribution."""
    p = np.asarray(counts, dtype=float) ** power
    return p / p.sum()


def _sigmoid(x):
    return np.exp(-np.logaddexp(0.0, -x))


def sgns_loss_and_grads(v_c, u_o, U_neg):
    """Negative-sampling loss and gradients."""
    s_pos = u_o @ v_c
    s_neg = U_neg @ v_c
    loss = float(np.logaddexp(0.0, -s_pos) + np.logaddexp(0.0, s_neg).sum())
    g_pos = _sigmoid(s_pos) - 1.0
    g_neg = _sigmoid(s_neg)
    d_vc = g_pos * u_o + g_neg @ U_neg
    d_uo = g_pos * v_c
    d_Uneg = g_neg[:, None] * v_c[None, :]
    return loss, d_vc, d_uo, d_Uneg


class SkipGramNS:
    """Skip-gram with negative sampling."""

    def __init__(self, vocab_size, dim=16, seed=0):
        self.vocab_size, self.dim = vocab_size, dim
        self.rng = np.random.default_rng(seed)
        self.W_in = self.rng.uniform(-0.5 / dim, 0.5 / dim, size=(vocab_size, dim))
        self.W_out = np.zeros((vocab_size, dim))

    def train(self, pairs, noise_probs, epochs=5, lr=0.05, k=5):
        """SGD over (center, context) pairs."""
        history = []
        for _ in range(epochs):
            total = 0.0
            for idx in self.rng.permutation(len(pairs)):
                c, o = pairs[idx]
                neg = self.rng.choice(self.vocab_size, size=k, p=noise_probs)
                loss, d_vc, d_uo, d_neg = sgns_loss_and_grads(self.W_in[c], self.W_out[o], self.W_out[neg])
                total += loss
                self.W_in[c] -= lr * d_vc
                self.W_out[o] -= lr * d_uo
                np.add.at(self.W_out, neg, -lr * d_neg)
            history.append(total / max(1, len(pairs)))
        return history

    def most_similar(self, word_id, topn=5):
        """Nearest words by cosine similarity."""
        W = self.W_in / np.maximum(np.linalg.norm(self.W_in, axis=1, keepdims=True), 1e-12)
        sims = W @ W[word_id]
        order = [i for i in np.argsort(-sims, kind="stable") if i != word_id][:topn]
        return [(int(i), float(sims[i])) for i in order]
