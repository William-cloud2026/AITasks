import math

import numpy as np

from starter import speculative_decode

V = 12
rng = np.random.default_rng(0)
T1 = rng.normal(size=(V, V)) * 3
T2 = rng.normal(size=(V, V)) * 3


def target_next(seq):
    return T1[seq[-1]] + 0.5 * T2[seq[-2] if len(seq) > 1 else 0]


def target_logits(seq):
    calls["target"] += 1
    return np.array([target_next(seq[:i + 1]) for i in range(len(seq))])


calls = {"target": 0}


def greedy(prompt, n, eos=None):
    seq = list(prompt)
    for _ in range(n):
        t = int(np.argmax(target_next(seq)))
        seq.append(t)
        if t == eos:
            break
    return seq


def test_perfect_draft():
    calls["target"] = 0
    out, stats = speculative_decode(target_logits, target_next, [1, 2], 20, k=4)
    assert out == greedy([1, 2], 20)
    assert stats["target_calls"] == math.ceil(20 / 5) == calls["target"]
    assert stats["accepted"] == stats["proposed"]


def test_bad_draft_still_exact():
    bad = lambda seq: T2[seq[-1]]
    for k in (1, 2, 3, 6):
        out, stats = speculative_decode(target_logits, bad, [3], 25, k=k)
        assert out == greedy([3], 25)
        assert len(out) == 26
        assert stats["accepted"] <= stats["proposed"] and stats["draft_calls"] >= stats["proposed"]
        assert stats["target_calls"] <= 25


def test_partially_good_draft_saves_calls():
    noisy = lambda seq: target_next(seq) + (rng.normal(size=V) * 0.5 if len(seq) % 3 == 0 else 0)
    out, stats = speculative_decode(target_logits, noisy, [0], 30, k=4)
    assert out == greedy([0], 30)
    assert stats["target_calls"] < 30


def test_eos_and_budget():
    ref = greedy([1, 2], 40)
    eos = ref[6]
    out, _ = speculative_decode(target_logits, target_next, [1, 2], 40, k=3, eos_id=eos)
    assert out == greedy([1, 2], 40, eos=eos) and out[-1] == eos
    out, _ = speculative_decode(target_logits, target_next, [1, 2], 3, k=8)
    assert out == greedy([1, 2], 3)
