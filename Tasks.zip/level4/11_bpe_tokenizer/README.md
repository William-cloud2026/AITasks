# L4-11 · Byte-Level BPE Tokenizer

**Level:** 4 · **Topics:** tokenization, greedy merges, UTF-8 bytes · **Time:** ~60 min · **Allowed:** Python stdlib

## Task
Implement `class BPETokenizer` (GPT-2-style byte-level BPE, without regex pre-splitting).

- Base vocabulary: the 256 byte values (`id = byte`).
- `train(text, vocab_size)`:
  - `vocab_size < 256` → `ValueError`. Start from `list(text.encode("utf-8"))`.
  - Repeat while the vocabulary is smaller than `vocab_size`: count all **adjacent** pairs; pick the most frequent;
    ties → the **smallest pair** `(a, b)` compared as tuples. **Stop** if the best count is `< 2`.
    The new id is `256 + number_of_merges_so_far`. Replace occurrences **left-to-right, non-overlapping**.
  - Stores `merges` (dict `(a, b) -> new_id`, insertion order = training order) and `vocab` (dict `id -> bytes`).
- `encode(text) -> list[int]`: start from bytes; repeatedly find, among adjacent pairs present, the one with the
  **lowest merge id** and merge all of its occurrences left-to-right; stop when no pair is mergeable.
- `decode(ids) -> str`: concatenate bytes and decode UTF-8 with `errors="replace"`.
- Encoding then decoding must round-trip any string (emoji, CJK, newlines...).

## Example
```python
tok = BPETokenizer(); tok.train("aaabdaaabac", 300)
list(tok.merges.items())   # [((97, 97), 256), ((97, 98), 257), ((256, 257), 258)]
```
