import numpy as np

from starter import cross_entropy

rng = np.random.default_rng(0)


def log_softmax(z):
    z = z - z.max(-1, keepdims=True)
    return z - np.log(np.exp(z).sum(-1, keepdims=True))


def numeric(logits, targets, **kw):
    eps = 1e-6
    num = np.zeros_like(logits)
    for idx in np.ndindex(logits.shape):
        p, m = logits.copy(), logits.copy()
        p[idx] += eps
        m[idx] -= eps
        lp, lm = cross_entropy(p, targets, **kw)[0], cross_entropy(m, targets, **kw)[0]
        num[idx] = (np.sum(lp) - np.sum(lm)) / (2 * eps)
    return num


def test_plain_value():
    logits = rng.normal(size=(5, 4))
    t = np.array([0, 3, 1, 1, 2])
    loss, _ = cross_entropy(logits, t)
    assert np.isclose(loss, -np.mean(log_softmax(logits)[np.arange(5), t]))
    loss, _ = cross_entropy(np.zeros((3, 4)), np.array([0, 1, 2]), label_smoothing=0.3)
    assert np.isclose(loss, np.log(4))


def test_label_smoothing_value_and_grad():
    logits = rng.normal(size=(4, 5))
    t = np.array([1, 0, 4, 2])
    loss, grad = cross_entropy(logits, t, label_smoothing=0.1)
    q = np.full((4, 5), 0.02)
    q[np.arange(4), t] += 0.9
    assert np.isclose(loss, -np.mean((q * log_softmax(logits)).sum(1)))
    np.testing.assert_allclose(grad, numeric(logits, t, label_smoothing=0.1), rtol=1e-5, atol=1e-8)


def test_ignore_index_and_3d():
    logits = rng.normal(size=(2, 3, 6))
    t = np.array([[1, -100, 5], [0, 2, -100]])
    loss, grad = cross_entropy(logits, t, label_smoothing=0.2)
    assert grad.shape == logits.shape
    np.testing.assert_array_equal(grad[0, 1], 0)
    np.testing.assert_array_equal(grad[1, 2], 0)
    np.testing.assert_allclose(grad, numeric(logits, t, label_smoothing=0.2), rtol=1e-5, atol=1e-8)
    valid = t != -100
    ref = -(log_softmax(logits)[valid] * (np.eye(6)[t[valid]] * 0.8 + 0.2 / 6)).sum(1).mean()
    assert np.isclose(loss, ref)


def test_reductions():
    logits = rng.normal(size=(4, 3))
    t = np.array([0, 1, 2, 7])
    per, grad = cross_entropy(logits, t, reduction="none", ignore_index=7)
    assert per.shape == (4,) and per[3] == 0
    total, gsum = cross_entropy(logits, t, reduction="sum", ignore_index=7)
    assert np.isclose(total, per.sum())
    np.testing.assert_allclose(grad, gsum)
    mean, gmean = cross_entropy(logits, t, ignore_index=7)
    assert np.isclose(mean, total / 3)
    np.testing.assert_allclose(gmean, gsum / 3)


def test_all_ignored_and_errors():
    loss, grad = cross_entropy(rng.normal(size=(2, 3)), np.array([-100, -100]))
    assert loss == 0.0 and np.all(grad == 0)
    for kw in ({"targets": np.array([3, 0])}, {"targets": np.array([0, 0]), "reduction": "avg"}):
        try:
            cross_entropy(np.zeros((2, 3)), **kw)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_extreme_logits():
    loss, grad = cross_entropy(np.array([[1e4, -1e4]]), np.array([1]))
    assert np.isclose(loss, 2e4) and np.all(np.isfinite(grad))
