import numpy as np

from starter import GELU, ReLU, LeakyReLU, Sigmoid, SiLU, Softplus, Tanh

rng = np.random.default_rng(0)
X = rng.normal(size=(4, 5)) * 2
X[X == 0] = 0.1
X[np.abs(X) < 1e-3] += 0.01


def numgrad(layer, x, g, eps=1e-6):
    out = np.zeros_like(x)
    for idx in np.ndindex(x.shape):
        xp, xm = x.copy(), x.copy()
        xp[idx] += eps
        xm[idx] -= eps
        out[idx] = ((layer.forward(xp) - layer.forward(xm)) * g).sum() / (2 * eps)
    return out


def check(layer):
    g = rng.normal(size=X.shape)
    layer.forward(X)
    analytic = layer.backward(g)
    numeric = numgrad(type(layer)() if not isinstance(layer, LeakyReLU) else LeakyReLU(layer.alpha), X, g)
    np.testing.assert_allclose(analytic, numeric, rtol=1e-5, atol=1e-7)


def test_forward_values():
    x = np.array([-2.0, 0.0, 1.5])
    np.testing.assert_allclose(ReLU().forward(x), [0, 0, 1.5])
    np.testing.assert_allclose(LeakyReLU(0.1).forward(x), [-0.2, 0, 1.5])
    np.testing.assert_allclose(Sigmoid().forward(x), 1 / (1 + np.exp(-x)))
    np.testing.assert_allclose(Tanh().forward(x), np.tanh(x))
    c = np.sqrt(2 / np.pi)
    np.testing.assert_allclose(GELU().forward(x), 0.5 * x * (1 + np.tanh(c * (x + 0.044715 * x ** 3))))
    np.testing.assert_allclose(Softplus().forward(x), np.log1p(np.exp(x)))
    np.testing.assert_allclose(SiLU().forward(x), x / (1 + np.exp(-x)))


def test_gradients():
    for layer in (ReLU(), LeakyReLU(0.2), Sigmoid(), Tanh(), GELU(), Softplus(), SiLU()):
        check(layer)


def test_relu_zero_derivative():
    r = ReLU()
    r.forward(np.array([0.0, 1.0]))
    np.testing.assert_allclose(r.backward(np.ones(2)), [0.0, 1.0])


def test_extreme_inputs():
    x = np.array([-1000.0, 1000.0])
    with np.errstate(over="raise", invalid="raise"):
        for layer in (Sigmoid(), Softplus(), SiLU(), GELU(), Tanh()):
            y = layer.forward(x)
            assert np.all(np.isfinite(y))
            assert np.all(np.isfinite(layer.backward(np.ones(2))))
    np.testing.assert_allclose(Softplus().forward(x), [0.0, 1000.0])


def test_any_shape():
    x = rng.normal(size=(2, 3, 4))
    for layer in (ReLU(), GELU(), SiLU()):
        assert layer.forward(x).shape == x.shape
        assert layer.backward(np.ones_like(x)).shape == x.shape
