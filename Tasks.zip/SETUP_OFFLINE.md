# Offline Environment Setup (Windows)

This guide prepares a Windows machine **without internet access** to run all 100 tasks.
Everything you need is already in this folder.

| File | What it is |
|---|---|
| `python-3.11.0-amd64.exe` | Official Python 3.11.0 installer for 64-bit Windows (includes `pip`) |
| `numpy-1.26.4-cp311-cp311-win_amd64.whl` | Official NumPy 1.26.4 package for Python 3.11, 64-bit Windows |

Nothing else is required. NumPy has no further dependencies, and `pytest` is optional (`run_tests.py` replaces it).

> Requirements: Windows 10/11, **64-bit**. About 200 MB of free disk space.

---

## 1. Copy the folder

Copy the whole `Tasks` folder (USB drive, network share, ...) to the offline machine, e.g. `C:\Tasks`.

Optional — check the files were copied intact (PowerShell, inside the folder):
```powershell
Get-FileHash numpy-1.26.4-cp311-cp311-win_amd64.whl, python-3.11.0-amd64.exe -Algorithm SHA256
```
Expected:
```
CD25BCECC4974D09257FFCD1F098EE778F7834C3AD767FE5DB785BE9A4AA9CB2  numpy-1.26.4-cp311-cp311-win_amd64.whl
B5884FA3F05F88BBB617D08584930770C00BBCF675F2865A9161C2358829B605  python-3.11.0-amd64.exe
```

## 2. Install Python 3.11

**Option A — with the installer window**
1. Double-click `python-3.11.0-amd64.exe`.
2. On the first screen, **tick "Add python.exe to PATH"** (bottom of the window). This is important.
3. Click **Install Now** and wait until it finishes, then click **Close**.

**Option B — silent install** (Command Prompt opened in the folder):
```bat
python-3.11.0-amd64.exe /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
```

Then **close and reopen** the Command Prompt (so the new PATH is picked up) and check:
```bat
python --version
```
Expected: `Python 3.11.0`

## 3. Install NumPy (offline)

In a Command Prompt opened in the `Tasks` folder:
```bat
python -m pip install --no-index numpy-1.26.4-cp311-cp311-win_amd64.whl
```
`--no-index` tells pip not to try the internet. Expected last line:
`Successfully installed numpy-1.26.4`

Check:
```bat
python -c "import numpy; print(numpy.__version__)"
```
Expected: `1.26.4`

## 4. Verify the whole environment

Still in the `Tasks` folder:
```bat
python run_tests.py --solution
```
This runs all tests against every task's `solution.py` (about 30 seconds). The last line must be:
```
Total: 567/567 tests passed (solution.py)
```
If it is, the machine is ready.

## 5. Prepare the machine for candidates

Every task folder contains `solution.py` (the answer). Candidates must **not** receive it.

1. Run step 4 **before** this step — it needs the `solution.py` files.
2. Create a clean copy without any solutions (choose any folder outside `Tasks`, e.g. `C:\Exam`):
   ```bat
   python tools\make_candidate_package.py C:\Exam
   ```
   To include only some levels: `python tools\make_candidate_package.py C:\Exam level3 level4`.
   The copy contains no `solution.py` files and no `tools` folder. Give candidates `C:\Exam` and remove or restrict
   access to the original `Tasks` folder.
3. Quick check that candidate mode works:
   ```bat
   cd C:\Exam
   python run_tests.py level1/01_fizzbuzz_rules
   ```
   It should print `FAIL ... 0/6` — expected, because `starter.py` is not implemented yet.

Candidates work as described in `README.md`: edit `starter.py` in a task folder and run
`python run_tests.py <level>/<task>`.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized ...` | PATH was not set. Reopen the Command Prompt. If it still fails, re-run the installer → **Modify** → Next → tick **"Add Python to environment variables"** → Install. Or use the launcher: replace `python` with `py -3.11` in every command. |
| `python` opens the Microsoft Store | Windows "App execution aliases" are intercepting it. Settings → Apps → Advanced app settings → App execution aliases → turn **off** `python.exe` and `python3.exe`. Or use `py -3.11`. |
| `... is not a supported wheel on this platform` | The Python in use is not 64-bit 3.11. Check with `python -c "import sys, platform; print(sys.version, platform.architecture()[0])"`; it must show `3.11.x` and `64bit`. If several Pythons are installed, use `py -3.11 -m pip install --no-index numpy-1.26.4-cp311-cp311-win_amd64.whl`. |
| pip tries to connect to the internet / hangs | You forgot `--no-index`, or you typed `numpy` instead of the full `.whl` file name. |
| `Permission denied` / `Access is denied` during pip install | Add `--user`: `python -m pip install --user --no-index numpy-1.26.4-cp311-cp311-win_amd64.whl` |
| `No module named numpy` but install succeeded | NumPy was installed into a different Python. Use the same command prefix for both (`python -m pip ...` and `python ...`, or `py -3.11 -m pip ...` and `py -3.11 ...`). |
| A test reports `TIME` or fails a time limit | Very slow machine. Close other programs and re-run; run a single level with `python run_tests.py level4`. |
| Only some tests fail in step 4 | Make sure the folder was copied completely (including `level5/01_mini_gpt_forward/expected_logits.json`) and re-run with `-v` to see details: `python run_tests.py --solution -v` |

## Optional: pytest

Not needed. If you want it offline, download on an internet machine with
`pip download pytest -d wheels` (Python 3.11, Windows 64-bit), copy the `wheels` folder over and run
`python -m pip install --no-index --find-links wheels pytest`.
