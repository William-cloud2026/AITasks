import numpy as np


def r2_score(y_true, y_pred):
    """Coefficient of determination."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    if ss_tot == 0:
        return 1.0 if ss_res == 0 else 0.0
    return 1.0 - ss_res / ss_tot


class LinearRegression:
    """OLS / ridge regression via closed form."""

    def __init__(self, fit_intercept=True, alpha=0.0):
        if alpha < 0:
            raise ValueError("alpha must be >= 0")
        self.fit_intercept = fit_intercept
        self.alpha = alpha

    def fit(self, X, y):
        """Fit coefficients."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        if X.ndim != 2 or y.ndim != 1 or len(X) != len(y):
            raise ValueError("bad shapes")
        if self.fit_intercept:
            xm, ym = X.mean(0), y.mean()
        else:
            xm, ym = np.zeros(X.shape[1]), 0.0
        Xc, yc = X - xm, y - ym
        if self.alpha == 0:
            self.coef_ = np.linalg.lstsq(Xc, yc, rcond=None)[0]
        else:
            A = Xc.T @ Xc + self.alpha * np.eye(X.shape[1])
            self.coef_ = np.linalg.solve(A, Xc.T @ yc)
        self.intercept_ = float(ym - xm @ self.coef_) if self.fit_intercept else 0.0
        return self

    def predict(self, X):
        """Predict targets."""
        return np.asarray(X, dtype=float) @ self.coef_ + self.intercept_

    def score(self, X, y):
        """R^2 of predictions."""
        return r2_score(y, self.predict(X))
