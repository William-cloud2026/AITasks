# L3-01 · Feature Scalers

**Level:** 3 · **Topics:** numpy broadcasting, fit/transform API · **Time:** ~30 min · **Allowed:** Python stdlib + numpy

## Task
Inputs are 2-D array-likes `(n_samples, n_features)`; 1-D input → `ValueError`. Never mutate inputs.
`transform`/`inverse_transform` before `fit` → `RuntimeError`; feature-count mismatch → `ValueError`.

### `StandardScaler(with_mean=True, with_std=True)`
- `fit(X)` → sets `mean_`, `var_` (population, `ddof=0`), `scale_ = sqrt(var_)` with zeros replaced by `1.0`; returns `self`.
- `transform(X)` = `(X - mean_) / scale_` (skip centering if `with_mean=False`, skip scaling if `with_std=False`).
- `inverse_transform(X)`, `fit_transform(X)`.

### `MinMaxScaler(feature_range=(0, 1))`
- `feature_range[0] >= feature_range[1]` → `ValueError` in the constructor.
- `fit(X)` → `data_min_`, `data_max_`, `scale_ = (hi - lo) / data_range` (a zero range is treated as `1`),
  `min_ = lo - data_min_ * scale_`.
- `transform(X) = X * scale_ + min_` (constant columns therefore map to `lo`), `inverse_transform`, `fit_transform`.
