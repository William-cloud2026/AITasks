# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def roc_auc_score(y_true, scores):
    """Area under the ROC curve (Mann-Whitney U)."""
    raise NotImplementedError('TODO')

def roc_curve(y_true, scores):
    """(fpr, tpr, thresholds)."""
    raise NotImplementedError('TODO')

def average_precision_score(y_true, scores):
    """Step-wise average precision."""
    raise NotImplementedError('TODO')

def log_loss(y_true, probs, eps=1e-15):
    """Mean binary cross-entropy."""
    raise NotImplementedError('TODO')

def brier_score(y_true, probs):
    """Mean squared error of probabilities."""
    raise NotImplementedError('TODO')
