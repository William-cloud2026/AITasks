# L4-03 · Linear Layers, Sequential & Backprop

**Level:** 4 · **Topics:** matrix calculus, modular backprop, API design · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Build a tiny modular NN library.

### `class Linear(in_features, out_features, seed=0)`
- `W`: `(in_features, out_features)` initialised `rng.uniform(-k, k)` with `k = 1/sqrt(in_features)`,
  `rng = np.random.default_rng(seed)`; `b`: zeros `(out_features,)`.
- `forward(x)`: `x` `(N, in)` → `x @ W + b`. `backward(dout)` → returns `dx`; sets `dW`, `db` (overwritten each call).
- `params()` → `[W, b]`, `grads()` → `[dW, db]` (the **same array objects** used for updates).

### `class ReLU` — `forward`, `backward`, `params()`/`grads()` return `[]`.

### `class Sequential(*layers)`
`forward` chains layers, `backward` runs them in reverse and returns `dx`; `params()`/`grads()` concatenate in layer order.

### `class MSELoss`
`forward(pred, target)` → mean of squared error over **all** elements (float); `backward()` → `dpred`.

### `train_regressor(model, X, y, lr=0.05, epochs=500)`
Full-batch SGD: forward, loss, backward, `p -= lr * g` **in place** for every param. Returns the list of losses
(computed before each update).
