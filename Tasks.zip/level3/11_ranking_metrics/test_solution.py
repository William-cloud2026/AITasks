import itertools
import time

import numpy as np

from starter import average_precision_score, brier_score, log_loss, roc_auc_score, roc_curve


def brute_auc(y, s):
    pos = [b for a, b in zip(y, s) if a == 1]
    neg = [b for a, b in zip(y, s) if a == 0]
    tot = sum(1.0 if p > n else 0.5 if p == n else 0.0 for p, n in itertools.product(pos, neg))
    return tot / (len(pos) * len(neg))


def test_auc_examples():
    assert np.isclose(roc_auc_score([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8]), 0.75)
    assert np.isclose(roc_auc_score([0, 1, 0, 1], [0.5, 0.5, 0.2, 0.9]), 0.875)
    assert np.isclose(roc_auc_score([1, 0], [0.0, 1.0]), 0.0)


def test_auc_random_vs_brute():
    rng = np.random.default_rng(0)
    for _ in range(20):
        y = rng.integers(0, 2, 40)
        if y.min() == y.max():
            continue
        s = rng.integers(0, 6, 40) / 5
        assert np.isclose(roc_auc_score(y, s), brute_auc(y, s))


def test_auc_speed_and_error():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 2, 200_000)
    s = y + rng.normal(size=200_000)
    t0 = time.perf_counter()
    auc = roc_auc_score(y, s)
    assert time.perf_counter() - t0 < 3 and 0.7 < auc < 0.8
    try:
        roc_auc_score([1, 1], [0.2, 0.3])
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


def test_roc_curve():
    fpr, tpr, thr = roc_curve([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8])
    np.testing.assert_allclose(thr, [np.inf, 0.8, 0.4, 0.35, 0.1])
    np.testing.assert_allclose(tpr, [0, 0.5, 0.5, 1, 1])
    np.testing.assert_allclose(fpr, [0, 0, 0.5, 0.5, 1])
    fpr, tpr, thr = roc_curve([0, 1, 1], [0.5, 0.5, 0.9])
    np.testing.assert_allclose(thr, [np.inf, 0.9, 0.5])
    np.testing.assert_allclose(tpr, [0, 0.5, 1])
    np.testing.assert_allclose(fpr, [0, 0, 1])
    trapezoid = np.sum(np.diff(fpr) * (tpr[1:] + tpr[:-1]) / 2)
    assert np.isclose(trapezoid, roc_auc_score([0, 1, 1], [0.5, 0.5, 0.9]))


def test_average_precision():
    assert np.isclose(average_precision_score([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8]), 5 / 6)
    assert np.isclose(average_precision_score([1, 0, 1], [0.5, 0.5, 0.1]), 0.5 * 0.5 + 0.5 * (2 / 3))
    assert average_precision_score([1, 1, 0], [3, 2, 1]) == 1.0


def test_log_loss_and_brier():
    assert np.isclose(log_loss([1, 0], [0.8, 0.3]), -(np.log(0.8) + np.log(0.7)) / 2)
    assert np.isfinite(log_loss([1, 0], [0.0, 1.0]))
    assert np.isclose(log_loss([1], [0.0]), -np.log(1e-15))
    assert np.isclose(brier_score([1, 0, 1], [0.9, 0.2, 0.5]), (0.01 + 0.04 + 0.25) / 3)
