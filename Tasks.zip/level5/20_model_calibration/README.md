# L5-20 · Model Calibration: ECE, Reliability Bins, Temperature Scaling

**Level:** 5 · **Topics:** uncertainty, evaluation, 1-D optimization · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
### `softmax(logits, temperature=1.0)` and `nll(logits, labels, temperature=1.0)`
Row-wise stable softmax of `logits / temperature`; `nll` = mean negative log-likelihood of the integer labels
(computed with log-softmax).

### `reliability_bins(probs, labels, n_bins=15) -> list[dict]`
- `probs (N, C)`: confidence = max prob, prediction = argmax. `probs (N,)` (binary, P(y=1)): prediction
  `p >= 0.5`, confidence `max(p, 1 − p)`.
- Equal-width bins over `(0, 1]`: bin `i` holds confidences in `(i/n, (i+1)/n]`; a confidence of exactly `0` goes to
  bin 0. (Use `min(max(ceil(conf·n) − 1, 0), n − 1)`.)
- Return one dict per **non-empty** bin, in bin order: `{"bin", "lower", "upper", "count", "accuracy", "confidence"}`
  (`accuracy` / `confidence` are means within the bin).

### `expected_calibration_error(probs, labels, n_bins=15)`
`Σ_bins (count / N) · |accuracy − confidence|`.

### `fit_temperature(logits, labels, t_min=0.05, t_max=20.0, tol=1e-5) -> float`
Return the temperature `T ∈ [t_min, t_max]` minimizing `nll(logits, labels, T)` (it is unimodal in `log T`; e.g.
golden-section search on `log T` until the bracket is narrower than `tol`).
