# L5-04 · Sentence-Aware Text Chunker for RAG

**Level:** 5 · **Topics:** retrieval-augmented generation, text segmentation, offset bookkeeping · **Time:** ~60 min · **Allowed:** Python stdlib

## Task
Implement `chunk_text(text, max_tokens, overlap=0) -> list[dict]`.

**Tokens** are the matches of `re.finditer(r"\S+", text)` (with their character spans). A token **ends a sentence**
if its last character is one of `.`, `!`, `?` (the last token of the text also ends a sentence).

**Algorithm** (token indices, `n` = number of tokens):
```
i = 0
while i < n:
    j = i
    # extend j to the end of the next sentence (exclusive index) while the chunk stays <= max_tokens
    while j < n and (sentence_end_after(j) - i) <= max_tokens:
        j = sentence_end_after(j)
    if j == i:                        # a single sentence is longer than max_tokens
        j = min(i + max_tokens, n)
    emit tokens[i:j]
    if j == n: break
    i = j - overlap if j - overlap > i else j
```
where `sentence_end_after(j)` = 1 + index of the first sentence-ending token at index `>= j`.

Each chunk is `{"text": text[start:end], "start": start, "end": end, "n_tokens": j - i}` where `start` is the start
offset of token `i` and `end` the end offset of token `j−1` (so whitespace inside the chunk is preserved exactly).

Errors: `max_tokens < 1`, `overlap < 0` or `overlap >= max_tokens` → `ValueError`. Empty / whitespace-only text → `[]`.
