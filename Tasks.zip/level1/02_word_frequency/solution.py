import re
from collections import Counter


def word_frequency(text, top_k=None):
    """Count words; return (word, count) sorted by count desc, word asc."""
    if top_k is not None and top_k < 0:
        raise ValueError("top_k must be >= 0")
    tokens = (t.strip("'") for t in re.findall(r"[a-z0-9']+", text.lower()))
    counts = Counter(t for t in tokens if t)
    items = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return items if top_k is None else items[:top_k]
