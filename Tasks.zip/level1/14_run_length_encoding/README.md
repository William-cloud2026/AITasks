# L1-14 · Run-Length Encoding

**Level:** 1 · **Topics:** string scanning, parsing, validation · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
### `rle_encode(s) -> str`
Encode runs as `<count><char>`, e.g. `"aaabcc"` → `"3a1b2c"`. Counts may be any size (`"a"*12` → `"12a"`).
Input containing any decimal digit → `ValueError`.

### `rle_decode(s) -> str`
Inverse operation. Malformed input → `ValueError` (char without count like `"a3"`, trailing count like `"3"`,
zero count like `"0a"`). Empty string ↔ empty string.

## Example
```python
rle_encode("WWWWWWWWWWWWBWWW")  # '12W1B3W'
rle_decode("2 3x")              # '  xxx'
```
