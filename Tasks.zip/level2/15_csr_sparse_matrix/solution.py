class CSRMatrix:
    """Compressed sparse row matrix."""

    def __init__(self, data, indices, indptr, shape):
        self.data = list(data)
        self.indices = list(indices)
        self.indptr = list(indptr)
        self.shape = tuple(shape)

    @classmethod
    def from_dense(cls, rows):
        """Build from a list of lists."""
        data, indices, indptr = [], [], [0]
        ncols = len(rows[0]) if rows else 0
        for r in rows:
            for j, v in enumerate(r):
                if v != 0:
                    data.append(v)
                    indices.append(j)
            indptr.append(len(data))
        return cls(data, indices, indptr, (len(rows), ncols))

    @classmethod
    def from_coo(cls, row_idx, col_idx, values, shape):
        """Build from coordinate triples, summing duplicates."""
        n, m = shape
        acc = {}
        for i, j, v in zip(row_idx, col_idx, values):
            if not (0 <= i < n and 0 <= j < m):
                raise IndexError(f"index ({i}, {j}) out of range")
            acc[(i, j)] = acc.get((i, j), 0) + v
        data, indices, indptr = [], [], [0]
        by_row = [[] for _ in range(n)]
        for (i, j), v in acc.items():
            if v != 0:
                by_row[i].append((j, v))
        for row in by_row:
            for j, v in sorted(row):
                indices.append(j)
                data.append(v)
            indptr.append(len(data))
        return cls(data, indices, indptr, shape)

    @property
    def nnz(self):
        """Number of stored values."""
        return len(self.data)

    def to_dense(self):
        """Dense list of lists."""
        n, m = self.shape
        out = [[0] * m for _ in range(n)]
        for i in range(n):
            for k in range(self.indptr[i], self.indptr[i + 1]):
                out[i][self.indices[k]] = self.data[k]
        return out

    def get(self, i, j):
        """Element (i, j)."""
        for k in range(self.indptr[i], self.indptr[i + 1]):
            if self.indices[k] == j:
                return self.data[k]
        return 0

    def matvec(self, x):
        """Matrix-vector product."""
        if len(x) != self.shape[1]:
            raise ValueError("dimension mismatch")
        return [sum(self.data[k] * x[self.indices[k]] for k in range(self.indptr[i], self.indptr[i + 1]))
                for i in range(self.shape[0])]

    def __matmul__(self, x):
        return self.matvec(x)

    def transpose(self):
        """Transposed CSR matrix."""
        n, m = self.shape
        counts = [0] * (m + 1)
        for j in self.indices:
            counts[j + 1] += 1
        for j in range(m):
            counts[j + 1] += counts[j]
        indptr = counts[:]
        pos = counts[:-1]
        data = [0] * self.nnz
        indices = [0] * self.nnz
        for i in range(n):
            for k in range(self.indptr[i], self.indptr[i + 1]):
                j = self.indices[k]
                data[pos[j]] = self.data[k]
                indices[pos[j]] = i
                pos[j] += 1
        return CSRMatrix(data, indices, indptr, (m, n))
