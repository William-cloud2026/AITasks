# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def shape(m):
    """Validate and return (rows, cols)."""
    raise NotImplementedError('TODO')

def transpose(m):
    """Return the transpose."""
    raise NotImplementedError('TODO')

def matmul(a, b):
    """Matrix product a @ b."""
    raise NotImplementedError('TODO')

def identity(n):
    """n x n identity matrix."""
    raise NotImplementedError('TODO')

def scale(m, k):
    """Multiply every element by k."""
    raise NotImplementedError('TODO')
