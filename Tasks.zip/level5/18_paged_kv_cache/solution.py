import heapq


class OutOfBlocksError(Exception):
    """Raised when not enough free blocks are available."""


class PagedKVCache:
    """Block allocator with reference counting and copy-on-write."""

    def __init__(self, num_blocks, block_size):
        self.block_size = block_size
        self._free = list(range(num_blocks))
        heapq.heapify(self._free)
        self._ref = [0] * num_blocks
        self._tables = {}
        self._lens = {}
        self.cow_copies = []

    @property
    def num_free_blocks(self):
        return len(self._free)

    def refcount(self, block):
        """Reference count of a physical block."""
        return self._ref[block]

    def _alloc(self):
        b = heapq.heappop(self._free)
        self._ref[b] = 1
        return b

    def _release(self, b):
        self._ref[b] -= 1
        if self._ref[b] == 0:
            heapq.heappush(self._free, b)

    def add_sequence(self, seq_id):
        """Register an empty sequence."""
        if seq_id in self._tables:
            raise ValueError(f"sequence {seq_id!r} exists")
        self._tables[seq_id] = []
        self._lens[seq_id] = 0

    def append_tokens(self, seq_id, n=1):
        """Grow a sequence by n tokens."""
        table, length = self._tables[seq_id], self._lens[seq_id]
        bs = self.block_size
        need_cow = bool(table) and length % bs != 0 and self._ref[table[-1]] > 1
        new_blocks = -(-(length + n) // bs) - len(table)
        if need_cow + max(new_blocks, 0) > len(self._free):
            raise OutOfBlocksError("not enough free blocks")
        if need_cow:
            old = table[-1]
            new = self._alloc()
            self._ref[old] -= 1
            table[-1] = new
            self.cow_copies.append((old, new))
        for _ in range(max(new_blocks, 0)):
            table.append(self._alloc())
        self._lens[seq_id] = length + n
        return length + n

    def fork(self, src_id, dst_id):
        """Share src's blocks with a new sequence dst."""
        if dst_id in self._tables:
            raise ValueError(f"sequence {dst_id!r} exists")
        table = self._tables[src_id]
        for b in table:
            self._ref[b] += 1
        self._tables[dst_id] = list(table)
        self._lens[dst_id] = self._lens[src_id]

    def free_sequence(self, seq_id):
        """Release a sequence's blocks."""
        for b in self._tables.pop(seq_id):
            self._release(b)
        del self._lens[seq_id]

    def block_table(self, seq_id):
        """Copy of the block table."""
        return list(self._tables[seq_id])

    def length(self, seq_id):
        """Number of tokens."""
        return self._lens[seq_id]

    def slot(self, seq_id, pos):
        """Physical slot of a token position."""
        if not 0 <= pos < self._lens[seq_id]:
            raise IndexError("position out of range")
        return self._tables[seq_id][pos // self.block_size] * self.block_size + pos % self.block_size
