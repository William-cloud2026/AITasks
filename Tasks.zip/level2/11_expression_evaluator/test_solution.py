import math

from starter import EvalError, evaluate

CASES = [
    "1 + 2 * 3", "(1 + 2) * 3", "-2 ** 2", "2 ** -1", "2 ** 3 ** 2", "--3", "-+-4",
    "7 // 2", "-7 // 2", "7 % 3", "-7 % 3", "10 / 4", "1.5e2 + .5", "2. * 3",
    "((2))", "1 - 2 - 3", "2 * 3 % 4", "100 / 10 / 5",
]


def test_matches_python():
    for e in CASES:
        got = evaluate(e)
        want = eval(e)  # the test may use eval; your solution may not
        assert got == want and type(got) is type(want), (e, got, want)


def test_variables_and_functions():
    assert evaluate("2 * (3 + x) ** 2", {"x": 1}) == 32
    assert evaluate("max(1, 2 * 3) // 4") == 1
    assert evaluate("abs(-3) + min(4, 5, -1)") == 2
    assert math.isclose(evaluate("sqrt(x_1) * 2", {"x_1": 2.25}), 3.0)
    assert evaluate("round(2.567, 2)") == 2.57


def test_errors():
    bad = ["", "   ", "1 +", "(1", "1)", "2 3", "1 / 0", "5 % 0", "y + 1", "foo(1)", "1 $ 2",
           "*3", "sqrt(-1)", "max()", "0 ** -1", "3 // 0"]
    for e in bad:
        try:
            evaluate(e)
        except EvalError:
            continue
        raise AssertionError(f"expected EvalError for {e!r}")
    assert issubclass(EvalError, Exception) and not issubclass(EvalError, (ValueError, ZeroDivisionError))


def test_no_eval_used():
    import inspect
    import starter
    src = inspect.getsource(starter)
    import re
    for banned in (r"(?<![\w.])eval\(", r"(?<![\w.])exec\(", r"(?<![\w.])compile\(", r"import ast"):
        assert not re.search(banned, src), banned
