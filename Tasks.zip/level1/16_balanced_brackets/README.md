# L1-16 · Balanced Brackets

**Level:** 1 · **Topics:** stacks · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
Brackets are `()`, `[]`, `{}`; every other character is ignored.

### `first_error_index(s) -> int`
Scan left to right with a stack.
- A closing bracket that does not match the top of the stack (or arrives with an empty stack) → return its index.
- If the scan finishes with unclosed openers → return the index of the **earliest** unclosed opener.
- If balanced → return `-1`.

### `is_balanced(s) -> bool`
`True` iff `first_error_index(s) == -1`.

## Example
```python
first_error_index("f(a[1]) + {x")   # 10
first_error_index("(]")             # 1
```
