import numpy as np

from starter import FlatIndex, IVFIndex

rng = np.random.default_rng(0)
CENTERS = rng.normal(size=(20, 16)) * 5
DATA = np.vstack([c + rng.normal(size=(100, 16)) for c in CENTERS])
QUERIES = DATA[rng.choice(len(DATA), 50, replace=False)] + rng.normal(scale=0.1, size=(50, 16))


def brute(Q, X, k, metric):
    if metric == "l2":
        S = ((Q[:, None] - X[None]) ** 2).sum(-1)
        idx = np.argsort(S, axis=1, kind="stable")[:, :k]
    else:
        if metric == "cosine":
            Q = Q / np.linalg.norm(Q, axis=1, keepdims=True)
            X = X / np.linalg.norm(X, axis=1, keepdims=True)
        S = Q @ X.T
        idx = np.argsort(-S, axis=1, kind="stable")[:, :k]
    return np.take_along_axis(S, idx, 1), idx


def test_flat_all_metrics():
    for metric in ("cosine", "ip", "l2"):
        idx = FlatIndex(16, metric)
        idx.add(DATA[:1000])
        idx.add(DATA[1000:])
        s, i = idx.search(QUERIES, 5)
        bs, bi = brute(QUERIES, DATA, 5, metric)
        np.testing.assert_array_equal(i, bi)
        np.testing.assert_allclose(s, bs, rtol=1e-7, atol=1e-7)
        assert len(idx) == 2000


def test_flat_custom_ids_padding_errors():
    idx = FlatIndex(3, "ip")
    idx.add(np.eye(3), ids=[10, 20, 30])
    s, i = idx.search([[0.0, 1.0, 0.5]], 5)
    assert i.tolist() == [[20, 30, 10, -1, -1]] and s[0, -1] == -np.inf
    l2 = FlatIndex(3, "l2")
    l2.add(np.eye(3))
    s, i = l2.search([[1.0, 0, 0]], 4)
    assert i[0, 0] == 0 and s[0, 0] == 0.0 and s[0, 3] == np.inf and i[0, 3] == -1
    for fn in (lambda: FlatIndex(3, "hamming"), lambda: idx.add(np.ones((1, 4)))):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def recall(found, truth):
    return np.mean([len(set(f) & set(t)) / len(t) for f, t in zip(found, truth)])


def test_ivf_exact_when_probing_all():
    ivf = IVFIndex(16, n_lists=20, metric="l2", n_probe=20, seed=0)
    ivf.train(DATA)
    ivf.add(DATA)
    s, i = ivf.search(QUERIES, 10)
    bs, bi = brute(QUERIES, DATA, 10, "l2")
    np.testing.assert_array_equal(i, bi)
    np.testing.assert_allclose(s, bs, atol=1e-7)


def test_ivf_recall_tradeoff():
    ivf = IVFIndex(16, n_lists=20, metric="l2", n_probe=1, seed=0)
    ivf.train(DATA)
    ivf.add(DATA)
    _, truth = brute(QUERIES, DATA, 10, "l2")
    r1 = recall(ivf.search(QUERIES, 10)[1], truth)
    ivf.n_probe = 3
    r3 = recall(ivf.search(QUERIES, 10)[1], truth)
    assert r1 >= 0.8 and r3 >= r1 and r3 >= 0.95


def test_ivf_requires_training():
    ivf = IVFIndex(4, n_lists=2)
    assert not ivf.is_trained
    try:
        ivf.add(np.ones((2, 4)))
    except NotImplementedError:
        raise AssertionError("not implemented")
    except RuntimeError:
        return
    raise AssertionError("expected RuntimeError")


def test_ivf_cosine_and_ids():
    ivf = IVFIndex(16, n_lists=5, metric="cosine", n_probe=5, seed=1)
    ivf.train(DATA)
    ivf.add(DATA, ids=np.arange(2000) + 1000)
    _, i = ivf.search(QUERIES[:5], 3)
    _, bi = brute(QUERIES[:5], DATA, 3, "cosine")
    np.testing.assert_array_equal(i, bi + 1000)
