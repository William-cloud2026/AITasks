# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import asyncio
import inspect

class DynamicBatcher:
    """Collects concurrent requests into model batches."""

    def __init__(self, model_fn, max_batch_size=8, max_wait_ms=5.0):
        raise NotImplementedError('TODO')

    async def start(self):
        """Start the background worker."""
        raise NotImplementedError('TODO')

    async def stop(self):
        """Drain the queue and stop the worker."""
        raise NotImplementedError('TODO')

    async def __aenter__(self):
        raise NotImplementedError('TODO')

    async def __aexit__(self, *exc):
        raise NotImplementedError('TODO')

    async def submit(self, item):
        """Submit one request and wait for its result."""
        raise NotImplementedError('TODO')
