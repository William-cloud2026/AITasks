import numpy as np


class CachedSelfAttention:
    """Causal multi-head self-attention with a KV cache."""

    def __init__(self, Wq, Wk, Wv, Wo, n_heads, window=None):
        self.Wq, self.Wk, self.Wv, self.Wo = (np.asarray(w, dtype=float) for w in (Wq, Wk, Wv, Wo))
        self.H = n_heads
        self.d = self.Wq.shape[0]
        self.dh = self.d // n_heads
        self.window = window
        self.reset()

    def reset(self):
        """Clear the cache."""
        self.K = np.zeros((0, self.d))
        self.V = np.zeros((0, self.d))

    @property
    def cache_len(self):
        return len(self.K)

    def _heads(self, x):
        return x.reshape(x.shape[0], self.H, self.dh).transpose(1, 0, 2)

    def _attend(self, q, k, v, mask):
        qh, kh, vh = self._heads(q), self._heads(k), self._heads(v)
        s = qh @ kh.transpose(0, 2, 1) / np.sqrt(self.dh)
        s = np.where(mask, s, -np.inf)
        s = np.exp(s - s.max(-1, keepdims=True))
        s /= s.sum(-1, keepdims=True)
        out = (s @ vh).transpose(1, 0, 2).reshape(q.shape[0], self.d)
        return out @ self.Wo

    def _mask(self, Tq, Tk, offset):
        i = np.arange(Tq)[:, None] + offset
        j = np.arange(Tk)[None, :]
        m = j <= i
        if self.window is not None:
            m &= j > i - self.window
        return m

    def forward_full(self, x):
        """Causal (optionally windowed) attention over a full sequence."""
        x = np.asarray(x, dtype=float)
        T = len(x)
        return self._attend(x @ self.Wq, x @ self.Wk, x @ self.Wv, self._mask(T, T, 0))

    def prefill(self, x):
        """Process several tokens at once, filling the cache."""
        x = np.asarray(x, dtype=float)
        k_all = np.vstack([self.K, x @ self.Wk])
        v_all = np.vstack([self.V, x @ self.Wv])
        past = len(self.K)
        mask = self._mask(len(x), len(k_all), past)
        out = self._attend(x @ self.Wq, k_all, v_all, mask)
        if self.window is not None:
            k_all, v_all = k_all[-self.window:], v_all[-self.window:]
        self.K, self.V = k_all, v_all
        return out

    def step(self, x_t):
        """Process one token."""
        return self.prefill(np.asarray(x_t, dtype=float)[None])[0]
