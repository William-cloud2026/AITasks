# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

from collections import OrderedDict

class LRUCache:
    """Least-recently-used cache with O(1) get/put."""

    def __init__(self, capacity, on_evict=None):
        raise NotImplementedError('TODO')

    def get(self, key, default=None):
        """Return value for key (marking it recent) or default."""
        raise NotImplementedError('TODO')

    def put(self, key, value):
        """Insert or update key, evicting LRU entries if needed."""
        raise NotImplementedError('TODO')

    def keys(self):
        """Keys from least to most recently used."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')

    def __contains__(self, key):
        raise NotImplementedError('TODO')
