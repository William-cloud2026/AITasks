import numpy as np


class _Node:
    __slots__ = ("feature", "threshold", "left", "right", "counts")

    def __init__(self, counts):
        self.counts = counts
        self.feature = self.threshold = self.left = self.right = None


class DecisionTreeClassifier:
    """CART classifier with Gini impurity."""

    def __init__(self, max_depth=None, min_samples_split=2, min_samples_leaf=1):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf

    def _best_split(self, X, yi):
        n, d = X.shape
        C = len(self.classes_)
        parent = np.bincount(yi, minlength=C).astype(float)
        parent_gini = 1.0 - ((parent / n) ** 2).sum()
        best_gain, best = 1e-12, None
        nl = np.arange(1, n, dtype=float)
        nr = n - nl
        for j in range(d):
            order = np.argsort(X[:, j], kind="stable")
            xs, ys = X[order, j], yi[order]
            left = np.cumsum(np.eye(C)[ys], axis=0)[:-1]
            right = parent - left
            gl = 1.0 - ((left / nl[:, None]) ** 2).sum(1)
            gr = 1.0 - ((right / nr[:, None]) ** 2).sum(1)
            gain = parent_gini - (nl * gl + nr * gr) / n
            valid = (xs[:-1] < xs[1:]) & (nl >= self.min_samples_leaf) & (nr >= self.min_samples_leaf)
            if not valid.any():
                continue
            gain = np.where(valid, gain, -np.inf)
            top = gain.max()
            i = int(np.flatnonzero(gain >= top - 1e-12)[0])
            if gain[i] > best_gain + (1e-12 if best is not None else 0.0):
                best_gain, best = gain[i], (j, (xs[i] + xs[i + 1]) / 2.0)
        return best

    def _build(self, X, yi, depth):
        node = _Node(np.bincount(yi, minlength=len(self.classes_)))
        if (np.count_nonzero(node.counts) <= 1 or (self.max_depth is not None and depth >= self.max_depth)
                or len(yi) < self.min_samples_split):
            return node
        split = self._best_split(X, yi)
        if split is None:
            return node
        node.feature, node.threshold = split
        mask = X[:, node.feature] <= node.threshold
        node.left = self._build(X[mask], yi[mask], depth + 1)
        node.right = self._build(X[~mask], yi[~mask], depth + 1)
        return node

    def fit(self, X, y):
        """Grow the tree."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_, yi = np.unique(y, return_inverse=True)
        self.root_ = self._build(X, yi, 0)
        return self

    def _leaf(self, x):
        node = self.root_
        while node.feature is not None:
            node = node.left if x[node.feature] <= node.threshold else node.right
        return node

    def predict_proba(self, X):
        """Leaf class frequencies."""
        X = np.asarray(X, dtype=float)
        out = np.array([self._leaf(x).counts for x in X], dtype=float)
        return out / out.sum(1, keepdims=True)

    def predict(self, X):
        """Majority class of the leaf."""
        return self.classes_[np.argmax(self.predict_proba(X), axis=1)]

    def get_depth(self):
        """Maximum depth (root leaf = 0)."""
        def depth(n):
            return 0 if n.feature is None else 1 + max(depth(n.left), depth(n.right))
        return depth(self.root_)

    def get_n_leaves(self):
        """Number of leaves."""
        def leaves(n):
            return 1 if n.feature is None else leaves(n.left) + leaves(n.right)
        return leaves(self.root_)

    def root_split(self):
        """(feature, threshold) of the root or None."""
        if self.root_.feature is None:
            return None
        return int(self.root_.feature), float(self.root_.threshold)
