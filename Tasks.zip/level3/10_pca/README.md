# L3-10 · Principal Component Analysis

**Level:** 3 · **Topics:** SVD, variance, dimensionality reduction · **Time:** ~35 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class PCA(n_components=None, whiten=False)` using SVD of the centered data.

- `fit(X)` → `self`. Sets `mean_`, `components_` `(k, d)`, `explained_variance_` (`S² / (n − 1)`),
  `explained_variance_ratio_` (relative to the **total** variance of all components), `n_components_`.
- `n_components`:
  - `None` → `min(n, d)`; `int` in `[1, min(n, d)]`; otherwise `ValueError`.
  - `float` in `(0, 1)` → smallest `k` whose cumulative explained-variance ratio is `>= n_components`.
- **Sign convention:** flip each component so that its entry with the largest absolute value is positive.
- `transform(X)` = `(X − mean_) @ components_.T`, divided by `sqrt(explained_variance_)` if `whiten`.
- `inverse_transform(Z)` undoes `transform`. `fit_transform(X)`.
