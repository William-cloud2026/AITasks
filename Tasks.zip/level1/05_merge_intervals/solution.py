def merge_intervals(intervals):
    """Merge overlapping/touching intervals; return sorted list of tuples."""
    items = [tuple(p) for p in intervals]
    for s, e in items:
        if s > e:
            raise ValueError(f"invalid interval ({s}, {e})")
    items.sort()
    merged = []
    for s, e in items:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


def total_covered(intervals):
    """Total length of the union of intervals."""
    return sum(e - s for s, e in merge_intervals(intervals))
