# L5-18 · Paged KV-Cache Block Manager (vLLM-style)

**Level:** 5 · **Topics:** memory management, reference counting, copy-on-write, LLM serving · **Time:** ~75 min · **Allowed:** Python stdlib

## Task
Physical KV memory is split into `num_blocks` blocks of `block_size` token slots. Each sequence has a **block table**
mapping its logical blocks to physical ones. Implement `class PagedKVCache(num_blocks, block_size)` and
`class OutOfBlocksError(Exception)`.

| Member | Behaviour |
|---|---|
| `add_sequence(seq_id)` | new empty sequence (no blocks). Duplicate id → `ValueError` |
| `append_tokens(seq_id, n=1) -> int` | grow the sequence by `n` tokens, allocating blocks as needed; returns the new length. Allocation always takes the **lowest-numbered free block**. If there are not enough free blocks → `OutOfBlocksError` and **nothing changes** |
| copy-on-write | if the sequence's last block is **shared** (refcount > 1) and **partially filled**, appending first copies it: allocate a new block, record `(old_block, new_block)` in `cow_copies` (list), decrement the old block's refcount, and replace it in this sequence's table |
| `fork(src_id, dst_id) -> None` | `dst` shares all of `src`'s blocks (refcounts +1) and has the same length |
| `free_sequence(seq_id)` | decrement refcounts of its blocks; blocks reaching 0 become free; the sequence is removed |
| `block_table(seq_id)` | list copy; `length(seq_id)` → number of tokens |
| `slot(seq_id, pos)` | physical slot index `table[pos // block_size] * block_size + pos % block_size`; `pos` outside `[0, length)` → `IndexError` |
| `num_free_blocks`, `refcount(block)` | property / method |

Unknown `seq_id` anywhere → `KeyError`.
