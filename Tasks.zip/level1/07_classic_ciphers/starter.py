# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def caesar(text, shift):
    """Shift ASCII letters by `shift`, preserving case."""
    raise NotImplementedError('TODO')

def vigenere_encrypt(text, key):
    """Vigenere-encrypt text with an alphabetic key."""
    raise NotImplementedError('TODO')

def vigenere_decrypt(text, key):
    """Inverse of vigenere_encrypt."""
    raise NotImplementedError('TODO')
