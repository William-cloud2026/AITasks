import numpy as np


class RNN:
    """Elman RNN with tanh activation."""

    def __init__(self, input_size, hidden_size, seed=0):
        rng = np.random.default_rng(seed)
        k = 1.0 / np.sqrt(hidden_size)
        self.Wx = rng.uniform(-k, k, size=(input_size, hidden_size))
        self.Wh = rng.uniform(-k, k, size=(hidden_size, hidden_size))
        self.b = rng.uniform(-k, k, size=hidden_size)

    def forward(self, x, h0=None):
        """Run the recurrence over time."""
        x = np.asarray(x, dtype=float)
        T, N, _ = x.shape
        h = np.zeros((N, self.Wh.shape[0])) if h0 is None else np.asarray(h0, dtype=float)
        self.x, self.h0 = x, h
        hs = []
        for t in range(T):
            h = np.tanh(x[t] @ self.Wx + h @ self.Wh + self.b)
            hs.append(h)
        self.hs = np.stack(hs)
        return self.hs

    def backward(self, dhs):
        """Backprop through time."""
        T = len(dhs)
        self.dWx = np.zeros_like(self.Wx)
        self.dWh = np.zeros_like(self.Wh)
        self.db = np.zeros_like(self.b)
        dx = np.zeros_like(self.x)
        dh_next = np.zeros_like(self.h0)
        for t in range(T - 1, -1, -1):
            dh = dhs[t] + dh_next
            dz = dh * (1 - self.hs[t] ** 2)
            h_prev = self.hs[t - 1] if t else self.h0
            self.dWx += self.x[t].T @ dz
            self.dWh += h_prev.T @ dz
            self.db += dz.sum(0)
            dx[t] = dz @ self.Wx.T
            dh_next = dz @ self.Wh.T
        return dx, dh_next


def clip_grad_norm(grads, max_norm):
    """Clip gradients in place by global norm."""
    total = float(np.sqrt(sum(float((g ** 2).sum()) for g in grads)))
    if total > max_norm:
        for g in grads:
            g *= max_norm / total
    return total
