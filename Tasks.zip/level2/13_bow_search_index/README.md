# L2-13 · Bag-of-Words Search Index

**Level:** 2 · **Topics:** inverted index, cosine similarity, ranking · **Time:** ~40 min · **Allowed:** Python stdlib

## Task
Implement `class BowIndex` — a tiny keyword search engine (a baseline retriever before embeddings).

- Tokenization: `re.findall(r"\w+", text.lower())`.
- Each document is represented by its **raw term counts**.
- `add(doc_id, text)`: duplicate id → `ValueError`.
- `remove(doc_id)`: unknown id → `KeyError`.
- `search(query, k=5) -> list[tuple[doc_id, float]]`: cosine similarity between the query's term-count vector and
  each document; return only documents with score `> 0`, sorted by score **desc** then `doc_id` **asc**, at most `k`.
  Empty query (no tokens) → `[]`.
- `len(index)` → number of documents.
- Must use an **inverted index**: a test searches 5 000 documents 300 times with a time limit.
