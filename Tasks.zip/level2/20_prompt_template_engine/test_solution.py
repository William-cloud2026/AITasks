from starter import TemplateError, format_chat, render


def bad(template, ctx=None):
    try:
        render(template, ctx or {})
    except TemplateError:
        return True
    return False


def test_variables_and_filters():
    assert render("Hi {{name}}!", {"name": "Ada"}) == "Hi Ada!"
    assert render("{{ name | upper }} {{name|lower}}", {"name": "Ada"}) == "ADA ada"
    assert render("{{ s | strip | title }}", {"s": "  hello world "}) == "Hello World"
    assert render("{{ xs | length }}", {"xs": [1, 2, 3]}) == "3"
    assert render('{{ xs | join:", " }}', {"xs": [1, "a"]}) == "1, a"
    assert render("{{ t | truncate:5 }}|{{ u | truncate:5 }}", {"t": "abcdefgh", "u": "abc"}) == "abcde...|abc"
    assert render("{{ n }}", {"n": None}) == ""


def test_paths_and_attributes():
    class User:
        name = "Grace"

    assert render("{{ u.name }} / {{ d.a.b }}", {"u": User(), "d": {"a": {"b": 1}}}) == "Grace / 1"


def test_default():
    assert render('{{ missing | default:"n/a" }}', {}) == "n/a"
    assert render('{{ x | default:"n/a" | upper }}', {"x": None}) == "N/A"
    assert render('{{ x | default:"n/a" }}', {"x": 0}) == "0"
    assert bad("{{ missing }}")
    assert bad("{{ missing | upper }}")
    assert bad("{{ x | nope }}", {"x": 1})


def test_for_loop():
    tpl = "Docs:\n{% for d in docs %}[{{ loop.index }}] {{ d.title | upper }}\n{% endfor %}Q: {{ q }}"
    ctx = {"docs": [{"title": "a"}, {"title": "b"}], "q": "why?"}
    assert render(tpl, ctx) == "Docs:\n[1] A\n[2] B\nQ: why?"
    tpl = "{% for x in xs %}{{ x }}{% if loop.last %}.{% else %}, {% endif %}{% endfor %}"
    assert render(tpl, {"xs": [1, 2, 3]}) == "1, 2, 3."
    assert render("{% for x in xs %}{{ x }}{% endfor %}", {"xs": []}) == ""


def test_nested_and_shadowing():
    tpl = "{% for row in rows %}{% for x in row %}{{ x }}{% endfor %};{% endfor %}{{ x }}"
    assert render(tpl, {"rows": [[1, 2], [3]], "x": "outer"}) == "12;3;outer"


def test_if():
    tpl = "{% if user %}Hello {{ user }}{% else %}Hello stranger{% endif %}"
    assert render(tpl, {"user": "Ada"}) == "Hello Ada"
    assert render(tpl, {"user": ""}) == "Hello stranger"
    assert render(tpl, {}) == "Hello stranger"
    assert render("{% if a.b %}yes{% endif %}", {"a": {}}) == ""


def test_block_errors():
    assert bad("{% for x in xs %}{{ x }}", {"xs": [1]})
    assert bad("{% endfor %}")
    assert bad("{% if a %}x{% endfor %}", {"a": 1})
    assert bad("{% while x %}{% endwhile %}")
    assert bad("{% for x in missing %}{% endfor %}")
    assert issubclass(TemplateError, Exception)


def test_format_chat():
    msgs = [{"role": "system", "content": "Be brief."}, {"role": "user", "content": "Hi"}]
    assert format_chat(msgs) == "<|system|>\nBe brief.<|end|>\n<|user|>\nHi<|end|>\n<|assistant|>\n"
    assert format_chat(msgs[1:], add_generation_prompt=False) == "<|user|>\nHi<|end|>\n"
    for m in ([], [{"role": "user", "content": "a"}, {"role": "system", "content": "b"}],
              [{"role": "bot", "content": "x"}]):
        try:
            format_chat(m)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
