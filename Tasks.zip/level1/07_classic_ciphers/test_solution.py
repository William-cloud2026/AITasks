from starter import caesar, vigenere_decrypt, vigenere_encrypt


def test_caesar_basic():
    assert caesar("Hello, World!", 3) == "Khoor, Zruog!"
    assert caesar("xyz XYZ", 3) == "abc ABC"


def test_caesar_large_and_negative():
    assert caesar("abc", 29) == "def"
    assert caesar("abc", -1) == "zab"
    assert caesar(caesar("Round trip 123", 1000), -1000) == "Round trip 123"


def test_caesar_non_ascii_untouched():
    assert caesar("café ñ", 1) == "dbgé ñ"


def test_vigenere_known():
    assert vigenere_encrypt("ATTACK AT DAWN", "lemon") == "LXFOPV EF RNHR"
    assert vigenere_encrypt("attack at dawn", "LEMON") == "lxfopv ef rnhr"


def test_vigenere_round_trip():
    msg = "The quick brown fox, jumps over 13 lazy dogs!"
    assert vigenere_decrypt(vigenere_encrypt(msg, "Secret"), "sEcReT") == msg


def test_vigenere_key_validation():
    for key in ["", "abc1", "key word"]:
        try:
            vigenere_encrypt("hi", key)
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for key {key!r}")
