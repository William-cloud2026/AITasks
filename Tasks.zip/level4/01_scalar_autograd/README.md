# L4-01 · Scalar Autograd Engine

**Level:** 4 · **Topics:** computational graphs, reverse-mode autodiff, operator overloading · **Time:** ~60 min · **Allowed:** Python stdlib (+ numpy optional)

## Task
Implement `class Value` — a scalar that records the operations producing it and can back-propagate gradients
(a "micrograd").

| Feature | Notes |
|---|---|
| `Value(data)` | `.data` (float), `.grad` (float, initially `0.0`) |
| `+ - * /` with `Value` or numbers, both sides (`2 * v`, `1 - v`, `3 / v`) | |
| `-v`, `v ** k` | `k` is an `int`/`float` constant (a `Value` exponent → `TypeError`) |
| `v.exp()`, `v.log()`, `v.tanh()`, `v.relu()`, `v.sigmoid()` | `relu'(0) = 0` |
| `v.backward()` | sets `v.grad = 1` and propagates to every node of the graph in reverse topological order. Gradients **accumulate** with `+=` (a node used twice gets both contributions) |

`backward()` must be **iterative** (no recursion): a test builds a chain of 5 000 operations.

## Example
```python
x, y = Value(2.0), Value(-3.0)
z = (x * y + x ** 2).tanh()
z.backward()
x.grad, y.grad
```
