import re

_TYPES = {"str": (str,), "int": (int,), "float": (int, float), "bool": (bool,), "list": (list,), "dict": (dict,)}


def _type_ok(value, tname):
    if tname not in ("bool",) and isinstance(value, bool):
        return False
    return isinstance(value, _TYPES[tname])


def _check(value, spec, path, errors):
    if value is None:
        if not spec.get("nullable", False):
            errors.append(f"{path}: must not be null")
        return
    t = spec["type"]
    if not _type_ok(value, t):
        errors.append(f"{path}: expected {t}, got {type(value).__name__}")
        return
    measure = len(value) if t in ("str", "list") else value
    if "min" in spec and t in ("str", "list", "int", "float") and measure < spec["min"]:
        errors.append(f"{path}: below minimum {spec['min']}")
    if "max" in spec and t in ("str", "list", "int", "float") and measure > spec["max"]:
        errors.append(f"{path}: above maximum {spec['max']}")
    if "choices" in spec and value not in spec["choices"]:
        errors.append(f"{path}: not one of {spec['choices']}")
    if "pattern" in spec and t == "str" and not re.fullmatch(spec["pattern"], value):
        errors.append(f"{path}: does not match pattern")
    if t == "list" and "items" in spec:
        for i, item in enumerate(value):
            _check(item, spec["items"], f"{path}[{i}]", errors)
    if t == "dict" and "fields" in spec:
        _check_record(value, spec["fields"], path + ".", errors)


def _check_record(record, schema, prefix, errors):
    for name, spec in schema.items():
        path = prefix + name
        if name not in record:
            if spec.get("required", True):
                errors.append(f"{path}: required field missing")
            continue
        _check(record[name], spec, path, errors)
    for name in record:
        if name not in schema:
            errors.append(f"{prefix}{name}: unexpected field")


def validate(record, schema):
    """Return a list of '<path>: <message>' errors."""
    errors = []
    if not isinstance(record, dict):
        return [f"<root>: expected dict, got {type(record).__name__}"]
    _check_record(record, schema, "", errors)
    return errors
