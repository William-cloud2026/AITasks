# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import re
from collections import Counter, defaultdict

class BowIndex:
    """Cosine-similarity keyword search over raw term counts."""

    def __init__(self):
        raise NotImplementedError('TODO')

    def add(self, doc_id, text):
        """Index a document."""
        raise NotImplementedError('TODO')

    def remove(self, doc_id):
        """Remove a document."""
        raise NotImplementedError('TODO')

    def search(self, query, k=5):
        """Top-k (doc_id, cosine) pairs with score > 0."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')
