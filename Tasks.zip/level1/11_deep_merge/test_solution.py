from starter import deep_merge


def test_example():
    base = {"model": {"lr": 0.1, "layers": [64]}}
    over = {"model": {"layers": [128]}, "seed": 1}
    assert deep_merge(base, over) == {"model": {"lr": 0.1, "layers": [128]}, "seed": 1}


def test_concat():
    assert deep_merge({"a": [1], "b": {"c": [2]}}, {"a": [3], "b": {"c": [4]}}, "concat") == \
        {"a": [1, 3], "b": {"c": [2, 4]}}


def test_type_conflict_override_wins():
    assert deep_merge({"a": {"x": 1}}, {"a": 5}) == {"a": 5}
    assert deep_merge({"a": 5}, {"a": {"x": 1}}) == {"a": {"x": 1}}


def test_three_levels():
    a = {"l1": {"l2": {"l3": 1, "keep": True}}}
    b = {"l1": {"l2": {"l3": 2}}}
    assert deep_merge(a, b) == {"l1": {"l2": {"l3": 2, "keep": True}}}


def test_no_mutation_no_sharing():
    base = {"a": {"b": [1]}, "x": [1]}
    over = {"a": {"c": {"d": 1}}, "y": [2]}
    res = deep_merge(base, over)
    res["a"]["b"].append(99)
    res["a"]["c"]["d"] = 42
    res["y"].append(3)
    res["x"].append(5)
    assert base == {"a": {"b": [1]}, "x": [1]}
    assert over == {"a": {"c": {"d": 1}}, "y": [2]}


def test_bad_strategy():
    try:
        deep_merge({}, {}, "zip")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
