import numpy as np


class SGD:
    """Stochastic gradient descent with optional momentum."""

    def __init__(self, params, lr, momentum=0.0, weight_decay=0.0, nesterov=False):
        if lr < 0 or momentum < 0 or weight_decay < 0 or (nesterov and momentum <= 0):
            raise ValueError("invalid hyper-parameters")
        self.params, self.lr, self.momentum = list(params), lr, momentum
        self.weight_decay, self.nesterov = weight_decay, nesterov
        self.bufs = [None] * len(self.params)

    def step(self, grads):
        """Apply one update."""
        for i, (p, grad) in enumerate(zip(self.params, grads)):
            g = grad + self.weight_decay * p
            if self.momentum:
                self.bufs[i] = g.copy() if self.bufs[i] is None else self.momentum * self.bufs[i] + g
                g = g + self.momentum * self.bufs[i] if self.nesterov else self.bufs[i]
            p -= self.lr * g


class RMSProp:
    """RMSProp."""

    def __init__(self, params, lr=0.01, alpha=0.99, eps=1e-8):
        if lr < 0 or not 0 <= alpha < 1:
            raise ValueError("invalid hyper-parameters")
        self.params, self.lr, self.alpha, self.eps = list(params), lr, alpha, eps
        self.v = [np.zeros_like(p) for p in self.params]

    def step(self, grads):
        """Apply one update."""
        for p, g, v in zip(self.params, grads, self.v):
            v *= self.alpha
            v += (1 - self.alpha) * g * g
            p -= self.lr * g / (np.sqrt(v) + self.eps)


class Adam:
    """Adam with coupled (L2) weight decay."""

    _decoupled = False

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.0):
        b1, b2 = betas
        if lr < 0 or not (0 <= b1 < 1 and 0 <= b2 < 1) or weight_decay < 0:
            raise ValueError("invalid hyper-parameters")
        self.params, self.lr, self.betas, self.eps = list(params), lr, betas, eps
        self.weight_decay = weight_decay
        self.m = [np.zeros_like(p) for p in self.params]
        self.v = [np.zeros_like(p) for p in self.params]
        self.t = 0

    def step(self, grads):
        """Apply one update."""
        self.t += 1
        b1, b2 = self.betas
        for p, grad, m, v in zip(self.params, grads, self.m, self.v):
            if self._decoupled:
                p *= 1 - self.lr * self.weight_decay
                g = grad
            else:
                g = grad + self.weight_decay * p
            m *= b1
            m += (1 - b1) * g
            v *= b2
            v += (1 - b2) * g * g
            m_hat = m / (1 - b1 ** self.t)
            v_hat = v / (1 - b2 ** self.t)
            p -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


class AdamW(Adam):
    """Adam with decoupled weight decay."""

    _decoupled = True

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01):
        super().__init__(params, lr, betas, eps, weight_decay)
