# L5-19 · Grammar-Constrained Decoding with a Trie

**Level:** 5 · **Topics:** structured generation, logit masking, prefix trees · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Force an LLM to output exactly one of a set of allowed strings (e.g. class labels, enum values, tool names)
regardless of what it "wants" to say.

### `class ConstrainedDecoder(vocab, allowed, eos_id)`
- `vocab`: list of token strings (`vocab[eos_id]` is the EOS token; its string is ignored). Empty-string tokens are never allowed.
- `allowed`: list of non-empty target strings (empty list or empty string → `ValueError`).
- `allowed_mask(prefix) -> np.ndarray[bool] (V,)`: token `t != eos_id` is allowed iff `prefix + vocab[t]` is a
  prefix of at least one allowed string; `eos_id` is allowed iff `prefix` is itself one of the allowed strings.
  Use a **character trie** so this is fast (a test uses 3 000 allowed strings and a 2 000-token vocab).
- `decode(logits_fn, max_steps=64) -> (text, token_ids)`: greedy decoding where at every step logits of disallowed
  tokens are ignored (argmax over allowed ones, ties → lowest id). Stop when EOS is chosen (EOS id **not** included
  in `token_ids`). If no token is allowed (can't happen with a correct trie) or `max_steps` is reached → `RuntimeError`.
  `logits_fn(token_ids_so_far) -> (V,)`.
