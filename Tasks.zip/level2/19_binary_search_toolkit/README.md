# L2-19 · Binary Search Toolkit

**Level:** 2 · **Topics:** binary search invariants, predicates, complexity · **Time:** ~40 min · **Allowed:** Python stdlib (**not** the `bisect` module)

## Task
| Function | Behaviour |
|---|---|
| `bisect_left(a, x, key=None)` | first index `i` such that `key(a[i]) >= x` (identity key if `None`); `a` sorted by key |
| `bisect_right(a, x, key=None)` | first index `i` such that `key(a[i]) > x` |
| `search_rotated(a, target)` | `a` is an ascending list of **distinct** values rotated at an unknown pivot; return index of `target` or `-1`. O(log n) |
| `first_true(lo, hi, pred)` | `pred` is monotone over `[lo, hi)` (False…False True…True). Return the smallest `i` with `pred(i)`, or `hi` if none. At most `ceil(log2(hi - lo)) + 1` calls to `pred` |
| `max_batch_size(fits, limit)` | `fits(b)` is True for small batch sizes and False above some threshold (e.g. GPU OOM probing). Return the largest `b` in `[1, limit]` with `fits(b)`, or `0` if `fits(1)` is False. At most `ceil(log2(limit)) + 2` calls |
