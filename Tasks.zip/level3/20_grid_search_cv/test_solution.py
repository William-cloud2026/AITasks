import numpy as np

from starter import GridSearchCV, parameter_grid


def test_parameter_grid_order():
    g = parameter_grid({"lr": [0.1, 0.01], "depth": [1, 2, 3]})
    assert g == [{"depth": 1, "lr": 0.1}, {"depth": 1, "lr": 0.01}, {"depth": 2, "lr": 0.1},
                 {"depth": 2, "lr": 0.01}, {"depth": 3, "lr": 0.1}, {"depth": 3, "lr": 0.01}]
    assert parameter_grid({}) == [{}]
    assert parameter_grid([{"a": [1]}, {"b": [2, 3]}]) == [{"a": 1}, {"b": 2}, {"b": 3}]


class ThresholdModel:
    log = []

    def __init__(self, threshold=0.0, flip=False):
        self.threshold, self.flip = threshold, flip

    def fit(self, X, y):
        ThresholdModel.log.append(len(X))
        return self

    def predict(self, X):
        p = (np.asarray(X)[:, 0] > self.threshold).astype(int)
        return 1 - p if self.flip else p


X = np.linspace(-1, 1, 10).reshape(-1, 1)
y = (X[:, 0] > 0.3).astype(int)


def test_grid_search():
    ThresholdModel.log = []
    gs = GridSearchCV(ThresholdModel, {"threshold": [-0.5, 0.0, 0.3, 0.5], "flip": [False, True]}, cv=3).fit(X, y)
    assert len(gs.results_) == 8
    assert gs.best_params_ == {"flip": False, "threshold": 0.3}
    assert gs.best_score_ == 1.0
    assert ThresholdModel.log == [6, 7, 7] * 8 + [10]
    np.testing.assert_array_equal(gs.predict(X), y)
    r = gs.results_[gs.best_index_]
    assert r["scores"] == [1.0, 1.0, 1.0] and r["std_score"] == 0.0


def test_first_best_wins_and_custom_scoring():
    gs = GridSearchCV(ThresholdModel, {"threshold": [0.25, 0.3, 0.2]}, cv=2,
                      scoring=lambda t, p: -float(np.sum(t != p))).fit(X, y)
    assert gs.best_params_ == {"threshold": 0.25}
    assert all(res["mean_score"] == 0.0 for res in gs.results_)


def test_std_and_folds():
    gs = GridSearchCV(ThresholdModel, {"threshold": [0.0]}, cv=4).fit(X, y)
    scores = gs.results_[0]["scores"]
    assert len(scores) == 4
    assert np.isclose(gs.results_[0]["std_score"], np.std(scores))
    assert np.isclose(gs.results_[0]["mean_score"], np.mean(scores))
