# L1-15 · Bank Account (OOP & Exceptions)

**Level:** 1 · **Topics:** classes, properties, custom exceptions · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
Implement `class BankAccount` and `class InsufficientFundsError(Exception)`.

| Member | Behaviour |
|---|---|
| `BankAccount(owner, balance=0)` | negative initial balance → `ValueError` |
| `.owner` | owner name |
| `.balance` | **read-only** property (assigning raises `AttributeError`) |
| `.deposit(amount)` | `amount <= 0` → `ValueError`; returns new balance |
| `.withdraw(amount)` | `amount <= 0` → `ValueError`; `amount > balance` → `InsufficientFundsError` (balance unchanged); returns new balance |
| `.transfer_to(other, amount)` | withdraw from self and deposit into `other`; **atomic** — on any error neither account changes |
| `.history` | list of `(kind, amount, balance_after)` tuples, kinds: `"deposit"`, `"withdraw"`, `"transfer_out"`, `"transfer_in"`. Returns a **copy** |
| `repr(acc)` | `BankAccount(owner='Ada', balance=100)` |

Failed operations are **not** recorded in history.
