# L2-04 · Trie Autocomplete

**Level:** 2 · **Topics:** trees, recursion, ranking · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
Implement `class Trie` for query autocompletion.

| Method | Behaviour |
|---|---|
| `insert(word, weight=1)` | add word; inserting an existing word **adds** to its weight. Empty word or `weight <= 0` → `ValueError` |
| `contains(word)` / `word in trie` | exact membership |
| `weight(word)` | stored weight, `0` if absent |
| `count_prefix(prefix)` | number of distinct words starting with `prefix` (`""` → all words) |
| `complete(prefix, k=5)` | up to `k` words starting with `prefix`, sorted by weight **desc**, then word **asc** |
| `delete(word)` | remove word, return `True` if it existed; prune empty nodes |
| `len(trie)` | number of distinct words |
