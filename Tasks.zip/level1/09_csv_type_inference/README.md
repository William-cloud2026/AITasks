# L1-09 · CSV Parsing with Type Inference

**Level:** 1 · **Topics:** parsing, regex, csv module · **Time:** ~30 min · **Allowed:** Python stdlib (`csv` allowed)

## Task
Implement `parse_csv(text, delimiter=",") -> list[dict]`.

- The first non-blank line is the header. Header names are stripped of whitespace.
  Duplicate or empty header names → `ValueError`.
- Blank lines (only whitespace) are skipped.
- Standard CSV quoting (`"a,b"`) must be supported.
- Every value is stripped, then converted, checking in this order:
  1. `""` → `None`
  2. `"true"` / `"false"` (any case) → `bool`
  3. matches `[+-]?\d+` → `int`
  4. matches `[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?` → `float`
  5. otherwise → the stripped `str`
- A data row whose field count differs from the header → `ValueError` whose message contains
  `line N` where `N` is the 1-based line number in `text`.

## Example
```python
parse_csv("name, age ,score\nAda, 36, 9.5\nBob,,TRUE\n")
# [{'name': 'Ada', 'age': 36, 'score': 9.5}, {'name': 'Bob', 'age': None, 'score': True}]
```
