# L5-03 · Decoding Strategies: Greedy, Top-k/Top-p Sampling, Beam Search

**Level:** 5 · **Topics:** LLM text generation, probability filtering, search · **Time:** ~75 min · **Allowed:** Python stdlib + numpy

A "model" is a function `next_logits(tokens: list[int]) -> np.ndarray (V,)` (unnormalized logits for the next token).

### `filter_logits(logits, top_k=None, top_p=None) -> np.ndarray`
Returns a copy where removed tokens are `-inf`.
1. `top_k`: keep the `k` highest logits (ties at the boundary resolved by lower token id, i.e. order by
   `np.argsort(-logits, kind="stable")`).
2. then `top_p` (nucleus): sort remaining tokens by probability (same stable order), keep the **smallest prefix**
   whose cumulative probability (softmax over the remaining tokens) is `>= top_p`. Always keep at least one token.

### `greedy_decode(next_logits, prompt, max_new_tokens, eos_id=None) -> list[int]`
Append `argmax` (lowest id on ties) until `max_new_tokens` or `eos_id` is produced (eos **included**). Returns the
full sequence (prompt + generated).

### `sample_decode(next_logits, prompt, max_new_tokens, temperature=1.0, top_k=None, top_p=None, seed=None, eos_id=None)`
Divide logits by `temperature` (`temperature == 0` → greedy), then `filter_logits`, softmax, and sample with
`rng.choice(V, p=probs)` where `rng = np.random.default_rng(seed)`. `temperature < 0` → `ValueError`.

### `beam_search(next_logprobs, prompt, beam_width, max_new_tokens, eos_id=None, length_penalty=1.0) -> (tokens, score)`
`next_logprobs(tokens)` returns log-probabilities `(V,)`.
- Start with one beam `(prompt, 0.0)`. At each step expand **every alive beam** with **every** token; rank all
  candidates by cumulative log-prob (desc; ties: earlier beam, then lower token id) and keep the top `beam_width`.
  Candidates ending in `eos_id` move to the finished list; the others stay alive. Stop when no beam is alive or after
  `max_new_tokens` steps; remaining alive beams are then finished.
- Final score of a finished beam = `cum_logprob / (n_generated ** length_penalty)` (`n_generated` includes eos).
  Return the finished beam with the highest score (ties → the one finished first) and that score.
