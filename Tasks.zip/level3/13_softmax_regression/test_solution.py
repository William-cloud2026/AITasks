import numpy as np

from starter import SoftmaxRegression, cross_entropy_and_grad, softmax

rng = np.random.default_rng(4)
CENTERS = np.array([[0, 3], [3, -2], [-3, -2]])
X = np.vstack([c + rng.normal(size=(60, 2)) for c in CENTERS])
y = np.repeat(["red", "green", "blue"], 60)


def test_softmax_stable():
    with np.errstate(over="raise", invalid="raise"):
        P = softmax(np.array([[1000.0, 1000.0, -1000.0], [1.0, 2.0, 3.0]]))
    np.testing.assert_allclose(P[0], [0.5, 0.5, 0.0], atol=1e-12)
    e = np.exp([1.0, 2.0, 3.0])
    np.testing.assert_allclose(P[1], e / e.sum())
    np.testing.assert_allclose(softmax(np.ones((2, 3)), axis=0), 0.5)


def test_loss_and_grad():
    Y = np.eye(3)[rng.integers(0, 3, 20)]
    Xs = rng.normal(size=(20, 4))
    W, b = rng.normal(size=(4, 3)), rng.normal(size=3)
    loss, gW, gb = cross_entropy_and_grad(Xs, Y, W, b, l2=0.3)
    P = softmax(Xs @ W + b)
    assert np.isclose(loss, -np.mean(np.sum(Y * np.log(P), 1)) + 0.15 * np.sum(W ** 2))
    eps = 1e-6
    num = np.zeros_like(W)
    for i in range(4):
        for j in range(3):
            E = np.zeros_like(W)
            E[i, j] = eps
            num[i, j] = (cross_entropy_and_grad(Xs, Y, W + E, b, 0.3)[0] -
                         cross_entropy_and_grad(Xs, Y, W - E, b, 0.3)[0]) / (2 * eps)
    np.testing.assert_allclose(gW, num, rtol=1e-5, atol=1e-8)
    numb = np.array([(cross_entropy_and_grad(Xs, Y, W, b + e, 0.3)[0] -
                      cross_entropy_and_grad(Xs, Y, W, b - e, 0.3)[0]) / (2 * eps) for e in np.eye(3) * eps])
    np.testing.assert_allclose(gb, numb, rtol=1e-5, atol=1e-8)


def test_extreme_logits_finite():
    X1 = np.array([[1.0]])
    loss, gW, gb = cross_entropy_and_grad(X1, np.array([[0.0, 1.0]]), np.array([[2000.0, -2000.0]]), np.zeros(2))
    assert np.isclose(loss, 4000.0) and np.all(np.isfinite(gW))


def test_fit():
    m = SoftmaxRegression(lr=0.2, epochs=300).fit(X, y)
    assert list(m.classes_) == ["blue", "green", "red"]
    assert np.mean(m.predict(X) == y) > 0.95
    P = m.predict_proba(X)
    assert P.shape == (180, 3) and np.allclose(P.sum(1), 1)
    h = m.loss_history_
    assert len(h) == 300 and h[-1] < h[0]
    assert np.isclose(h[0], np.log(3))
