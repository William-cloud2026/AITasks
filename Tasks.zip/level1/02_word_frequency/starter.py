# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re
from collections import Counter

def word_frequency(text, top_k=None):
    """Count words; return (word, count) sorted by count desc, word asc."""
    raise NotImplementedError('TODO')
