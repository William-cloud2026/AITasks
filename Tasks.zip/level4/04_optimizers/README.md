# L4-04 · Optimizers: SGD (Momentum/Nesterov), RMSProp, Adam, AdamW

**Level:** 4 · **Topics:** optimization algorithms, in-place updates, state management · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Every optimizer takes `params` (a list of numpy float arrays) and keyword hyper-parameters; `step(grads)` updates
each param **in place** (same array objects) using the matching gradient. `lr` must be a public, mutable attribute.
State is kept per parameter. Formulas follow PyTorch.

### `SGD(params, lr, momentum=0.0, weight_decay=0.0, nesterov=False)`
```
g = grad + weight_decay * p
if momentum: buf = g on the first step, else buf = momentum * buf + g
             g = g + momentum * buf if nesterov else buf
p -= lr * g
```
### `RMSProp(params, lr=0.01, alpha=0.99, eps=1e-8)`
`v = alpha·v + (1 − alpha)·g²`, `p -= lr · g / (sqrt(v) + eps)` (v starts at 0).

### `Adam(params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.0)`
```
g = grad + weight_decay * p             # L2-style decay (coupled)
m = b1*m + (1-b1)*g ;  v = b2*v + (1-b2)*g²     (m, v start at 0; t starts at 1)
m_hat = m / (1 - b1**t) ;  v_hat = v / (1 - b2**t)
p -= lr * m_hat / (sqrt(v_hat) + eps)
```
### `AdamW(params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0.01)`
Decoupled decay: first `p *= (1 − lr·weight_decay)`, then the Adam update **without** adding decay to the gradient.

Invalid hyper-parameters (`lr < 0`, `momentum < 0`, betas outside `[0, 1)`, `nesterov` without momentum) → `ValueError`.
