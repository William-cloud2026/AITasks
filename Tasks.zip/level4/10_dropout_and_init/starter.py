# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class Dropout:
    """Inverted dropout."""

    def __init__(self, p=0.5, seed=0):
        raise NotImplementedError('TODO')

    def train(self):
        raise NotImplementedError('TODO')

    def eval(self):
        raise NotImplementedError('TODO')

    def forward(self, x):
        """Apply dropout."""
        raise NotImplementedError('TODO')

    def backward(self, dout):
        """Gradient through the last mask."""
        raise NotImplementedError('TODO')

def compute_fans(shape):
    """(fan_in, fan_out) for 2-D or 4-D weights."""
    raise NotImplementedError('TODO')

def xavier_uniform(shape, rng, gain=1.0):
    """Glorot uniform."""
    raise NotImplementedError('TODO')

def xavier_normal(shape, rng, gain=1.0):
    """Glorot normal."""
    raise NotImplementedError('TODO')

def kaiming_uniform(shape, rng, mode='fan_in', nonlinearity='relu'):
    """He uniform."""
    raise NotImplementedError('TODO')

def kaiming_normal(shape, rng, mode='fan_in', nonlinearity='relu'):
    """He normal."""
    raise NotImplementedError('TODO')
