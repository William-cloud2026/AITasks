# L1-20 · Binary Classification Metrics

**Level:** 1 · **Topics:** ML evaluation, edge cases · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
`y_true` and `y_pred` are equal-length, non-empty sequences of `0`/`1` (bools allowed). Otherwise → `ValueError`.

| Function | Returns |
|---|---|
| `confusion_matrix(y_true, y_pred)` | `{"tp": int, "fp": int, "tn": int, "fn": int}` |
| `accuracy(y_true, y_pred)` | `(tp + tn) / n` |
| `precision(y_true, y_pred)` | `tp / (tp + fp)`; `0.0` if denominator is 0 |
| `recall(y_true, y_pred)` | `tp / (tp + fn)`; `0.0` if denominator is 0 |
| `f1_score(y_true, y_pred)` | harmonic mean of precision and recall; `0.0` if both are 0 |
| `fbeta_score(y_true, y_pred, beta)` | `(1+β²)·P·R / (β²·P + R)`; `0.0` if denominator is 0; `beta <= 0` → `ValueError` |
