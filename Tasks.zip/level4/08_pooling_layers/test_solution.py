import numpy as np

from starter import (avgpool2d_backward, avgpool2d_forward, global_avg_pool, global_avg_pool_backward,
                      maxpool2d_backward, maxpool2d_forward)

rng = np.random.default_rng(0)


def naive_pool(x, k, s, fn):
    N, C, H, W = x.shape
    Ho, Wo = (H - k) // s + 1, (W - k) // s + 1
    out = np.zeros((N, C, Ho, Wo))
    for i in range(Ho):
        for j in range(Wo):
            out[:, :, i, j] = fn(x[:, :, i * s:i * s + k, j * s:j * s + k], axis=(2, 3))
    return out


def numeric(f, x, g, eps=1e-6):
    num = np.zeros_like(x)
    for idx in np.ndindex(x.shape):
        xp, xm = x.copy(), x.copy()
        xp[idx] += eps
        xm[idx] -= eps
        num[idx] = ((f(xp) - f(xm)) * g).sum() / (2 * eps)
    return num


def test_forward():
    x = rng.normal(size=(2, 3, 7, 6))
    for k, s in [(2, None), (3, 2), (2, 1), (3, 3)]:
        out, _ = maxpool2d_forward(x, k, s)
        np.testing.assert_allclose(out, naive_pool(x, k, s or k, np.max))
        out, _ = avgpool2d_forward(x, k, s)
        np.testing.assert_allclose(out, naive_pool(x, k, s or k, np.mean))


def test_max_backward_numeric_overlapping():
    x = rng.normal(size=(2, 2, 5, 5))
    for k, s in [(2, None), (3, 1), (2, 1)]:
        out, cache = maxpool2d_forward(x, k, s)
        g = rng.normal(size=out.shape)
        np.testing.assert_allclose(maxpool2d_backward(g, cache), numeric(lambda z: maxpool2d_forward(z, k, s)[0], x, g),
                                   atol=1e-6)


def test_max_tie_first_element():
    x = np.ones((1, 1, 2, 2))
    out, cache = maxpool2d_forward(x, 2)
    dx = maxpool2d_backward(np.array([[[[5.0]]]]), cache)
    np.testing.assert_array_equal(dx, [[[[5.0, 0.0], [0.0, 0.0]]]])


def test_avg_backward_numeric():
    x = rng.normal(size=(1, 2, 6, 5))
    for k, s in [(2, None), (3, 1)]:
        out, cache = avgpool2d_forward(x, k, s)
        g = rng.normal(size=out.shape)
        np.testing.assert_allclose(avgpool2d_backward(g, cache), numeric(lambda z: avgpool2d_forward(z, k, s)[0], x, g),
                                   atol=1e-7)


def test_global_avg_pool():
    x = rng.normal(size=(3, 4, 5, 6))
    np.testing.assert_allclose(global_avg_pool(x), x.mean(axis=(2, 3)))
    g = rng.normal(size=(3, 4))
    dx = global_avg_pool_backward(g, x.shape)
    np.testing.assert_allclose(dx, numeric(global_avg_pool, x, g), atol=1e-7)


def test_kernel_too_large():
    try:
        maxpool2d_forward(np.zeros((1, 1, 2, 2)), 3)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
