from starter import rle_decode, rle_encode


def test_encode():
    assert rle_encode("aaabcc") == "3a1b2c"
    assert rle_encode("WWWWWWWWWWWWBWWW") == "12W1B3W"
    assert rle_encode("") == ""


def test_decode():
    assert rle_decode("3a1b2c") == "aaabcc"
    assert rle_decode("2 3x") == "  xxx"
    assert rle_decode("") == ""


def test_round_trip():
    for s in ["hello  world!!", "a" * 1000 + "b", "\n\n\t", "xyz"]:
        assert rle_decode(rle_encode(s)) == s


def test_errors():
    for fn in (lambda: rle_encode("abc1"), lambda: rle_decode("a3"), lambda: rle_decode("3"),
               lambda: rle_decode("0a"), lambda: rle_decode("2a3")):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
