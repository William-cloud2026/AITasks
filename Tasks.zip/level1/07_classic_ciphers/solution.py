def _shift_char(c, k):
    if "a" <= c <= "z":
        return chr((ord(c) - 97 + k) % 26 + 97)
    if "A" <= c <= "Z":
        return chr((ord(c) - 65 + k) % 26 + 65)
    return c


def caesar(text, shift):
    """Shift ASCII letters by `shift`, preserving case."""
    return "".join(_shift_char(c, shift) for c in text)


def _key_shifts(key):
    if not key or not all(("a" <= c <= "z") or ("A" <= c <= "Z") for c in key):
        raise ValueError("key must be non-empty ASCII letters")
    return [ord(c.lower()) - 97 for c in key]


def _vigenere(text, key, sign):
    shifts = _key_shifts(key)
    out, i = [], 0
    for c in text:
        if c.isascii() and c.isalpha():
            out.append(_shift_char(c, sign * shifts[i % len(shifts)]))
            i += 1
        else:
            out.append(c)
    return "".join(out)


def vigenere_encrypt(text, key):
    """Vigenere-encrypt text with an alphabetic key."""
    return _vigenere(text, key, 1)


def vigenere_decrypt(text, key):
    """Inverse of vigenere_encrypt."""
    return _vigenere(text, key, -1)
