# L3-19 · Matrix Factorization Recommender (ALS)

**Level:** 3 · **Topics:** collaborative filtering, alternating least squares, masking · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class ALSRecommender(n_factors=5, reg=0.1, n_iters=20, seed=0)`.

- `fit(R)`: `R` is a `(n_users, n_items)` float matrix with `np.nan` for unobserved ratings.
  - Initialize `U (n_users, k)` and `V (n_items, k)` with `rng.normal(scale=0.1, size=...)` from
    `rng = np.random.default_rng(seed)` (draw `U` first, then `V`).
  - Each iteration: update **every user** row: `U[u] = solve(V_oᵀV_o + reg·I, V_oᵀ r_o)` using only the items
    user `u` rated (rows with no ratings become zero); then update **every item** analogously with the new `U`.
  - After each iteration append the objective `Σ_observed (r − U[u]·V[i])² + reg·(‖U‖² + ‖V‖²)` to `loss_history_`.
- Attributes `user_factors_` (`U`), `item_factors_` (`V`).
- `predict(u, i)` → float; `predict_all()` → `U Vᵀ`.
- `rmse(R)` → RMSE over the non-NaN entries of `R`.
- `recommend(u, n=5, exclude_seen=True)` → list of item indices sorted by predicted score descending (ties → lower
  index); seen = items observed for `u` in the training matrix.
