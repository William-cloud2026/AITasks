# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def bisect_left(a, x, key=None):
    """First i with key(a[i]) >= x."""
    raise NotImplementedError('TODO')

def bisect_right(a, x, key=None):
    """First i with key(a[i]) > x."""
    raise NotImplementedError('TODO')

def search_rotated(a, target):
    """Index of target in a rotated sorted list, or -1."""
    raise NotImplementedError('TODO')

def first_true(lo, hi, pred):
    """Smallest i in [lo, hi) with pred(i), else hi."""
    raise NotImplementedError('TODO')

def max_batch_size(fits, limit):
    """Largest b in [1, limit] with fits(b), or 0."""
    raise NotImplementedError('TODO')
