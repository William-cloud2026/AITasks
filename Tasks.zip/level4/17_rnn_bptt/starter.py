# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class RNN:
    """Elman RNN with tanh activation."""

    def __init__(self, input_size, hidden_size, seed=0):
        raise NotImplementedError('TODO')

    def forward(self, x, h0=None):
        """Run the recurrence over time."""
        raise NotImplementedError('TODO')

    def backward(self, dhs):
        """Backprop through time."""
        raise NotImplementedError('TODO')

def clip_grad_norm(grads, max_norm):
    """Clip gradients in place by global norm."""
    raise NotImplementedError('TODO')
