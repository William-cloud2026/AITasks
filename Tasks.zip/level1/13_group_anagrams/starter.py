# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def group_anagrams(words):
    """Group words whose letters are anagrams, preserving input order."""
    raise NotImplementedError('TODO')
