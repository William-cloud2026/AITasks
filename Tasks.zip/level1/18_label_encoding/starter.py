# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

class LabelEncoder:
    """Map labels to integer ids in sorted order."""

    def __init__(self):
        raise NotImplementedError('TODO')

    def fit(self, labels):
        """Learn sorted unique classes."""
        raise NotImplementedError('TODO')

    def transform(self, labels):
        """Labels -> ids."""
        raise NotImplementedError('TODO')

    def inverse_transform(self, ids):
        """Ids -> labels."""
        raise NotImplementedError('TODO')

    def fit_transform(self, labels):
        """Fit then transform."""
        raise NotImplementedError('TODO')

def one_hot(ids, num_classes):
    """One-hot encode integer ids."""
    raise NotImplementedError('TODO')
