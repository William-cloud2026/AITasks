import numpy as np

from starter import expected_calibration_error, fit_temperature, nll, reliability_bins, softmax

rng = np.random.default_rng(0)


def test_softmax_and_nll():
    z = np.array([[1.0, 2.0, 3.0], [1000.0, 0.0, -1000.0]])
    P = softmax(z)
    np.testing.assert_allclose(P.sum(1), 1)
    np.testing.assert_allclose(P[1], [1, 0, 0], atol=1e-12)
    np.testing.assert_allclose(softmax(z, temperature=2.0)[0], np.exp([0.5, 1, 1.5]) / np.exp([0.5, 1, 1.5]).sum())
    assert np.isclose(nll(z, [2, 0]), -np.log(P[0, 2]) / 2)
    assert np.isfinite(nll(z, [2, 2]))


def test_reliability_bins_multiclass():
    probs = np.array([[0.95, 0.05], [0.9, 0.1], [0.28, 0.72], [0.45, 0.55], [0.5, 0.5]])
    labels = np.array([0, 1, 1, 0, 0])
    bins = reliability_bins(probs, labels, n_bins=10)
    assert [b["bin"] for b in bins] == [4, 5, 7, 8, 9]
    b9 = bins[-1]
    assert b9["count"] == 1 and b9["accuracy"] == 1.0 and np.isclose(b9["confidence"], 0.95)
    b8 = bins[3]
    assert np.isclose(b8["lower"], 0.8) and np.isclose(b8["upper"], 0.9) and b8["accuracy"] == 0.0
    ece = expected_calibration_error(probs, labels, n_bins=10)
    expected = (abs(1 - 0.5) + abs(0 - 0.55) + abs(1 - 0.72) + abs(0 - 0.9) + abs(1 - 0.95)) / 5
    assert np.isclose(ece, expected)


def test_binary_probs():
    p = np.array([0.1, 0.8, 0.6, 0.0])
    y = np.array([0, 1, 0, 0])
    bins = reliability_bins(p, y, n_bins=5)
    assert [b["bin"] for b in bins] == [2, 3, 4]
    assert bins[-1]["count"] == 2 and bins[-1]["accuracy"] == 1.0
    assert np.isclose(expected_calibration_error(p, y, 5), (abs(0 - 0.6) + abs(1 - 0.8) + 2 * abs(1 - 0.95)) / 4)


def test_perfectly_calibrated_low_ece():
    n = 20000
    conf = rng.uniform(0.5, 1.0, size=n)
    labels = (rng.random(n) < conf).astype(int)
    probs = np.column_stack([1 - conf, conf])
    assert expected_calibration_error(probs, labels) < 0.02


def test_temperature_scaling_recovers_overconfidence():
    n, C = 5000, 5
    true_logits = rng.normal(size=(n, C)) * 1.5
    p = softmax(true_logits)
    labels = np.array([rng.choice(C, p=row) for row in p])
    over = true_logits * 3.0
    T = fit_temperature(over, labels)
    assert 2.6 < T < 3.4
    assert nll(over, labels, T) <= nll(over, labels, T * 1.05) and nll(over, labels, T) <= nll(over, labels, T / 1.05)
    assert expected_calibration_error(softmax(over, T), labels) < expected_calibration_error(softmax(over), labels)
    assert t_bounds_ok(fit_temperature(over[:, :1] * 0, labels * 0, 0.5, 2.0))


def t_bounds_ok(t):
    return 0.5 <= t <= 2.0
