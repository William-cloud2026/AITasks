import re


def chunk_text(text, max_tokens, overlap=0):
    """Split text into sentence-aligned, token-bounded chunks."""
    if max_tokens < 1 or overlap < 0 or overlap >= max_tokens:
        raise ValueError("invalid max_tokens/overlap")
    toks = [(m.start(), m.end()) for m in re.finditer(r"\S+", text)]
    n = len(toks)
    ends = [text[e - 1] in ".!?" or k == n - 1 for k, (_, e) in enumerate(toks)]
    next_end = [0] * n
    nxt = n
    for k in range(n - 1, -1, -1):
        if ends[k]:
            nxt = k + 1
        next_end[k] = nxt
    chunks = []
    i = 0
    while i < n:
        j = i
        while j < n and next_end[j] - i <= max_tokens:
            j = next_end[j]
        if j == i:
            j = min(i + max_tokens, n)
        start, end = toks[i][0], toks[j - 1][1]
        chunks.append({"text": text[start:end], "start": start, "end": end, "n_tokens": j - i})
        if j == n:
            break
        i = j - overlap if j - overlap > i else j
    return chunks
