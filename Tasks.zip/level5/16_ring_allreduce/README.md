# L5-16 · Ring All-Reduce & Data-Parallel Gradients

**Level:** 5 · **Topics:** distributed training, collective communication, simulation · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Simulate the bandwidth-optimal ring all-reduce used by data-parallel training (NCCL/Horovod) on a single machine.

### `ring_allreduce(arrays) -> (results, schedule)`
`arrays`: one array per worker (`W` workers, identical shapes; otherwise `ValueError`).
1. Each worker splits its flattened (float) array into `W` chunks with `np.array_split`.
2. **Reduce-scatter**, steps `s = 0..W−2`: every worker `r` sends chunk `(r − s) mod W` to worker `(r + 1) mod W`,
   which **adds** it to its own copy of that chunk. All sends of a step happen simultaneously (use the values from
   before the step).
3. **All-gather**, steps `s = 0..W−2`: every worker `r` sends chunk `(r + 1 − s) mod W` to `(r + 1) mod W`, which
   **overwrites** its copy.
4. `results[r]` is worker `r`'s reassembled array (original shape) — all equal to the element-wise sum.
   `schedule` is the list of `2(W−1)` steps, each a list of `(src, dst, chunk)` tuples ordered by `src`.
   `W == 1` → `([copy], [])`. Input arrays must not be modified.

### `data_parallel_gradient(grad_fn, params, X, y, n_workers) -> np.ndarray`
Shard the batch with `np.array_split` (rows), let each worker compute `grad_fn(params, X_shard, y_shard)` — the
**sum** of per-example gradients over its shard — all-reduce with `ring_allreduce`, and return the **mean** gradient
over the whole batch (identical to a single-worker full-batch mean gradient).
