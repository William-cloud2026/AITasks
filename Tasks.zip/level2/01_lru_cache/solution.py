from collections import OrderedDict


class LRUCache:
    """Least-recently-used cache with O(1) get/put."""

    def __init__(self, capacity, on_evict=None):
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        self.capacity = capacity
        self.on_evict = on_evict
        self._data = OrderedDict()
        self.hits = 0
        self.misses = 0

    def get(self, key, default=None):
        """Return value for key (marking it recent) or default."""
        if key in self._data:
            self._data.move_to_end(key)
            self.hits += 1
            return self._data[key]
        self.misses += 1
        return default

    def put(self, key, value):
        """Insert or update key, evicting LRU entries if needed."""
        self._data[key] = value
        self._data.move_to_end(key)
        while len(self._data) > self.capacity:
            k, v = self._data.popitem(last=False)
            if self.on_evict:
                self.on_evict(k, v)

    def keys(self):
        """Keys from least to most recently used."""
        return list(self._data)

    def __len__(self):
        return len(self._data)

    def __contains__(self, key):
        return key in self._data
