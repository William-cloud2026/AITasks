import numpy as np


class Dropout:
    """Inverted dropout."""

    def __init__(self, p=0.5, seed=0):
        if not 0 <= p < 1:
            raise ValueError("p must be in [0, 1)")
        self.p = p
        self.rng = np.random.default_rng(seed)
        self.training = True
        self.mask = None

    def train(self):
        self.training = True
        return self

    def eval(self):
        self.training = False
        return self

    def forward(self, x):
        """Apply dropout."""
        x = np.asarray(x, dtype=float)
        if not self.training or self.p == 0:
            self.mask = None
            return x
        self.mask = self.rng.random(x.shape) >= self.p
        return x * self.mask / (1 - self.p)

    def backward(self, dout):
        """Gradient through the last mask."""
        if self.mask is None:
            return dout
        return dout * self.mask / (1 - self.p)


def compute_fans(shape):
    """(fan_in, fan_out) for 2-D or 4-D weights."""
    if len(shape) == 2:
        return shape[0], shape[1]
    if len(shape) == 4:
        rf = shape[2] * shape[3]
        return shape[1] * rf, shape[0] * rf
    raise ValueError("unsupported weight rank")


def _gain(nonlinearity):
    if nonlinearity == "relu":
        return np.sqrt(2.0)
    if nonlinearity == "linear":
        return 1.0
    raise ValueError("unknown nonlinearity")


def xavier_uniform(shape, rng, gain=1.0):
    """Glorot uniform."""
    fi, fo = compute_fans(shape)
    a = gain * np.sqrt(6.0 / (fi + fo))
    return rng.uniform(-a, a, size=shape)


def xavier_normal(shape, rng, gain=1.0):
    """Glorot normal."""
    fi, fo = compute_fans(shape)
    return rng.normal(0.0, gain * np.sqrt(2.0 / (fi + fo)), size=shape)


def kaiming_uniform(shape, rng, mode="fan_in", nonlinearity="relu"):
    """He uniform."""
    fi, fo = compute_fans(shape)
    fan = fi if mode == "fan_in" else fo
    a = _gain(nonlinearity) * np.sqrt(3.0 / fan)
    return rng.uniform(-a, a, size=shape)


def kaiming_normal(shape, rng, mode="fan_in", nonlinearity="relu"):
    """He normal."""
    fi, fo = compute_fans(shape)
    fan = fi if mode == "fan_in" else fo
    return rng.normal(0.0, _gain(nonlinearity) / np.sqrt(fan), size=shape)
