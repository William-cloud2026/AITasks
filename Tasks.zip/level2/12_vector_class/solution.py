import math
import numbers


class Vector:
    """Immutable numeric vector."""

    __slots__ = ("_c",)

    def __init__(self, components):
        comps = tuple(components)
        if not comps:
            raise ValueError("vector must have at least one component")
        for c in comps:
            if isinstance(c, bool) or not isinstance(c, (int, float)):
                raise TypeError("components must be int or float")
        object.__setattr__(self, "_c", comps)

    def __setattr__(self, name, value):
        raise AttributeError("Vector is immutable")

    def __delattr__(self, name):
        raise AttributeError("Vector is immutable")

    def __len__(self):
        return len(self._c)

    def __iter__(self):
        return iter(self._c)

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            return Vector(self._c[idx])
        return self._c[idx]

    def _check(self, other):
        if len(other) != len(self):
            raise ValueError("dimension mismatch")

    def __add__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        self._check(other)
        return Vector(a + b for a, b in zip(self, other))

    def __sub__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        self._check(other)
        return Vector(a - b for a, b in zip(self, other))

    def __mul__(self, k):
        if isinstance(k, bool) or not isinstance(k, numbers.Real):
            return NotImplemented
        return Vector(a * k for a in self)

    __rmul__ = __mul__

    def __truediv__(self, k):
        if isinstance(k, bool) or not isinstance(k, numbers.Real):
            return NotImplemented
        if k == 0:
            raise ZeroDivisionError("division by zero")
        return Vector(a / k for a in self)

    def __matmul__(self, other):
        if not isinstance(other, Vector):
            return NotImplemented
        self._check(other)
        return sum(a * b for a, b in zip(self, other))

    def __neg__(self):
        return Vector(-a for a in self)

    def __abs__(self):
        return math.sqrt(sum(a * a for a in self))

    def __eq__(self, other):
        return isinstance(other, Vector) and self._c == other._c

    def __hash__(self):
        return hash(self._c)

    def normalized(self):
        """Unit-length copy."""
        n = abs(self)
        if n == 0:
            raise ValueError("cannot normalize zero vector")
        return self / n

    def cosine(self, other):
        """Cosine similarity."""
        n = abs(self) * abs(other)
        if n == 0:
            raise ValueError("cosine undefined for zero vector")
        return (self @ other) / n

    def __repr__(self):
        return f"Vector({list(self._c)!r})"
