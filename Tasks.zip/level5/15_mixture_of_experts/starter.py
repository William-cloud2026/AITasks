# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import numpy as np

class MoELayer:
    """Top-k routed mixture of feed-forward experts."""

    def __init__(self, d_model, d_hidden, n_experts, top_k=2, capacity_factor=None, seed=0):
        raise NotImplementedError('TODO')

    def expert(self, e, x):
        """Apply expert e to rows of x."""
        raise NotImplementedError('TODO')

    def forward(self, x):
        """Route tokens to experts and combine outputs."""
        raise NotImplementedError('TODO')
