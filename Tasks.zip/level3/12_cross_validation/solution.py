import numpy as np


class KFold:
    """Contiguous k-fold splitter."""

    def __init__(self, n_splits=5, shuffle=False, seed=None):
        if n_splits < 2:
            raise ValueError("n_splits must be >= 2")
        self.n_splits, self.shuffle, self.seed = n_splits, shuffle, seed

    def split(self, n_samples):
        """Yield sorted (train, test) index arrays."""
        if self.n_splits > n_samples:
            raise ValueError("n_splits > n_samples")
        order = np.random.default_rng(self.seed).permutation(n_samples) if self.shuffle else np.arange(n_samples)
        sizes = np.full(self.n_splits, n_samples // self.n_splits)
        sizes[: n_samples % self.n_splits] += 1
        start = 0
        for size in sizes:
            test = np.sort(order[start:start + size])
            train = np.sort(np.r_[order[:start], order[start + size:]]).astype(int)
            yield train, test
            start += size


class StratifiedKFold:
    """Class-balanced k-fold splitter."""

    def __init__(self, n_splits=5, shuffle=False, seed=None):
        if n_splits < 2:
            raise ValueError("n_splits must be >= 2")
        self.n_splits, self.shuffle, self.seed = n_splits, shuffle, seed

    def split(self, y):
        """Yield sorted (train, test) index arrays."""
        y = np.asarray(y)
        if self.n_splits > len(y):
            raise ValueError("n_splits > n_samples")
        rng = np.random.default_rng(self.seed)
        fold = np.empty(len(y), dtype=int)
        offset = 0
        for c in np.unique(y):
            idx = np.flatnonzero(y == c)
            if self.shuffle:
                idx = rng.permutation(idx)
            fold[idx] = (offset + np.arange(len(idx))) % self.n_splits
            offset += len(idx)
        for f in range(self.n_splits):
            yield np.flatnonzero(fold != f), np.flatnonzero(fold == f)


def cross_val_score(make_model, X, y, cv, scoring):
    """Score a fresh model on each fold."""
    X, y = np.asarray(X), np.asarray(y)
    splits = cv.split(y) if isinstance(cv, StratifiedKFold) else cv.split(len(X))
    scores = []
    for tr, te in splits:
        model = make_model()
        model.fit(X[tr], y[tr])
        scores.append(scoring(y[te], model.predict(X[te])))
    return np.array(scores)
