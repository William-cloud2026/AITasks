# L1-06 · Roman Numerals

**Level:** 1 · **Topics:** mapping tables, validation · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
### `to_roman(n: int) -> str`
Convert an integer in `1..3999` to its canonical Roman numeral (subtractive notation: `IV`, `IX`, `XL`, `XC`,
`CD`, `CM`). Anything else (including `bool` and non-int) → `ValueError`.

### `from_roman(s: str) -> int`
Parse a **canonical, upper-case** Roman numeral. Reject anything that is not exactly what
`to_roman` would produce for some value (e.g. `"IIII"`, `"VX"`, `"IC"`, `"MMMM"`, `"iv"`, `""`) with `ValueError`.

## Example
```python
to_roman(1994)       # 'MCMXCIV'
from_roman("MMXXV")  # 2025
```
