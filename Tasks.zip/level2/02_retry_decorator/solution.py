import functools
import time


def retry(max_attempts=3, exceptions=(Exception,), backoff=0.0, factor=2.0, sleep=time.sleep, on_retry=None):
    """Create a retry decorator."""
    if max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")
    if backoff < 0:
        raise ValueError("backoff must be >= 0")

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                wrapper.last_attempts = attempt
                try:
                    return fn(*args, **kwargs)
                except exceptions as exc:
                    if attempt == max_attempts:
                        raise
                    if on_retry:
                        on_retry(attempt, exc)
                    delay = backoff * factor ** (attempt - 1)
                    if delay > 0:
                        sleep(delay)

        wrapper.last_attempts = 0
        return wrapper

    return decorator
