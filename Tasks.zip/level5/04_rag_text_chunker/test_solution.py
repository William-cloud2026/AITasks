from starter import chunk_text

TEXT = "One two three. Four five!  Six seven eight nine ten eleven. Twelve?\nThirteen fourteen"


def texts(chunks):
    return [c["text"] for c in chunks]


def test_sentence_packing():
    ch = chunk_text(TEXT, 6)
    assert texts(ch) == ["One two three. Four five!", "Six seven eight nine ten eleven.", "Twelve?\nThirteen fourteen"]
    assert [c["n_tokens"] for c in ch] == [5, 6, 3]


def test_offsets_exact():
    for c in chunk_text(TEXT, 4, overlap=1):
        assert TEXT[c["start"]:c["end"]] == c["text"]
        assert c["n_tokens"] == len(c["text"].split())


def test_long_sentence_split():
    ch = chunk_text(TEXT, 3)
    assert texts(ch) == ["One two three.", "Four five!", "Six seven eight", "nine ten eleven.",
                         "Twelve?\nThirteen fourteen"]


def test_overlap():
    ch = chunk_text(TEXT, 4, overlap=2)
    assert texts(ch)[:4] == ["One two three.", "two three. Four five!", "Four five!", "Six seven eight nine"]
    assert all(c["n_tokens"] <= 4 for c in ch)
    assert ch[-1]["end"] == len(TEXT)


def test_no_infinite_loop_with_overlap():
    words = " ".join(f"w{i}" for i in range(50))
    ch = chunk_text(words, 5, overlap=4)
    assert ch[-1]["text"].endswith("w49") and len(ch) == 46


def test_edge_cases():
    assert chunk_text("", 5) == [] and chunk_text("   \n ", 5) == []
    assert texts(chunk_text("single", 1)) == ["single"]
    for args in ((TEXT, 0), (TEXT, 3, 3), (TEXT, 3, -1)):
        try:
            chunk_text(*args)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
