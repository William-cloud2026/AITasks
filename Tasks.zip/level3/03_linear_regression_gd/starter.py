# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def mse_loss_and_grad(X, y, w, b, l2=0.0):
    """Half-MSE loss with L2 and its gradients."""
    raise NotImplementedError('TODO')

class LinearRegressionGD:
    """Linear regression trained with gradient descent."""

    def __init__(self, lr=0.01, epochs=1000, l2=0.0, batch_size=None, seed=0, tol=None):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Run gradient descent."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predict targets."""
        raise NotImplementedError('TODO')
