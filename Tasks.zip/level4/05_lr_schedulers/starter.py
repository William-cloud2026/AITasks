# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math

def step_lr(step, base_lr, step_size, gamma=0.1):
    """Step decay."""
    raise NotImplementedError('TODO')

def exponential_lr(step, base_lr, gamma):
    """Exponential decay."""
    raise NotImplementedError('TODO')

def warmup_cosine_lr(step, base_lr, total_steps, warmup_steps=0, min_lr=0.0):
    """Linear warm-up then cosine decay."""
    raise NotImplementedError('TODO')

def warmup_linear_lr(step, base_lr, total_steps, warmup_steps=0):
    """Linear warm-up then linear decay to zero."""
    raise NotImplementedError('TODO')

def inverse_sqrt_lr(step, base_lr, warmup_steps):
    """Warm-up then inverse square-root decay."""
    raise NotImplementedError('TODO')

class LambdaScheduler:
    """Sets optimizer.lr from a function of the step."""

    def __init__(self, optimizer, lr_fn):
        raise NotImplementedError('TODO')

    def step(self):
        """Advance one step."""
        raise NotImplementedError('TODO')

    def get_last_lr(self):
        """Current learning rate."""
        raise NotImplementedError('TODO')
