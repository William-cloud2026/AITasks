# L3-09 · Decision Tree Classifier (CART / Gini)

**Level:** 3 · **Topics:** recursion, greedy search, efficient split finding · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class DecisionTreeClassifier(max_depth=None, min_samples_split=2, min_samples_leaf=1)`.

**Splits.** For every feature `j` (ascending) consider thresholds at the midpoints between consecutive **distinct**
sorted values; a sample goes left if `x[j] <= threshold`. Both children must have at least `min_samples_leaf`
samples. Gain = `gini(parent) − (n_L·gini(L) + n_R·gini(R)) / n` with `gini = 1 − Σ p_c²`.

**Choosing.** A split is accepted only if its gain is `> 1e-12`. Among candidates, pick the largest gain; a
candidate only beats the current best if its gain is larger by more than `1e-12` (so ties go to the **lowest feature
index**, then the **lowest threshold**).

**Stopping.** A node becomes a leaf if it is pure, `depth == max_depth`, it has fewer than `min_samples_split`
samples, or no split is accepted.

**API**
- `fit(X, y)` → `self`; `classes_` = sorted unique labels.
- `predict_proba(X)` → leaf class frequencies, columns follow `classes_`.
- `predict(X)` → most frequent class in the leaf (ties → first in `classes_`).
- `get_depth()` (a single-leaf tree has depth 0), `get_n_leaves()`.
- `root_split()` → `(feature, threshold)` of the root, or `None` if the root is a leaf.

Training on 400 samples × 5 features with unlimited depth must take well under 10 s (sort each feature once per
node and use cumulative class counts rather than re-scanning for every threshold).
