# L1-03 · Palindromes

**Level:** 1 · **Topics:** strings, two pointers, expand-around-center · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
Implement two functions:

### `is_palindrome(s) -> bool`
Consider only alphanumeric characters (`str.isalnum()`), ignore case. Empty input (or input with no
alphanumerics) is a palindrome.

### `longest_palindrome(s) -> str`
Return the longest **contiguous** palindromic substring of `s`, comparing characters **exactly**
(case-sensitive, all characters count). If several have the same max length, return the **leftmost**.
Empty input → `""`. Aim for O(n²) or better.

## Example
```python
is_palindrome("A man, a plan, a canal: Panama")  # True
longest_palindrome("babad")                      # 'bab'
```
