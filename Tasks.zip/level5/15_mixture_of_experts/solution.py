import math

import numpy as np


class MoELayer:
    """Top-k routed mixture of feed-forward experts."""

    def __init__(self, d_model, d_hidden, n_experts, top_k=2, capacity_factor=None, seed=0):
        if top_k > n_experts or top_k < 1:
            raise ValueError("invalid top_k")
        self.E, self.k, self.capacity_factor = n_experts, top_k, capacity_factor
        rng = np.random.default_rng(seed)
        self.W_gate = rng.normal(0, 0.1, (d_model, n_experts))
        W1, W2 = [], []
        for _ in range(n_experts):
            W1.append(rng.normal(0, 0.1, (d_model, d_hidden)))
            W2.append(rng.normal(0, 0.1, (d_hidden, d_model)))
        self.W1, self.W2 = np.array(W1), np.array(W2)
        self.b1 = np.zeros((n_experts, d_hidden))
        self.b2 = np.zeros((n_experts, d_model))

    def expert(self, e, x):
        """Apply expert e to rows of x."""
        return np.maximum(x @ self.W1[e] + self.b1[e], 0) @ self.W2[e] + self.b2[e]

    def forward(self, x):
        """Route tokens to experts and combine outputs."""
        x = np.asarray(x, dtype=float)
        N = len(x)
        z = x @ self.W_gate
        p = np.exp(z - z.max(1, keepdims=True))
        p /= p.sum(1, keepdims=True)
        chosen = np.argsort(-p, axis=1, kind="stable")[:, :self.k]
        gates = np.take_along_axis(p, chosen, 1)
        gates /= gates.sum(1, keepdims=True)
        accepted = np.ones_like(chosen, dtype=bool)
        if self.capacity_factor is not None:
            cap = math.ceil(self.capacity_factor * N * self.k / self.E)
            load = np.zeros(self.E, dtype=int)
            for r in range(self.k):
                for e in range(self.E):
                    rows = np.flatnonzero(chosen[:, r] == e)
                    room = max(cap - load[e], 0)
                    accepted[rows[room:], r] = False
                    load[e] += min(room, len(rows))
        y = np.zeros_like(x)
        counts = np.zeros(self.E, dtype=int)
        for e in range(self.E):
            rows, ranks = np.nonzero((chosen == e) & accepted)
            if len(rows):
                y[rows] += gates[rows, ranks][:, None] * self.expert(e, x[rows])
                counts[e] = len(rows)
        self.router_probs, self.topk_indices = p, chosen
        self.expert_counts, self.dropped = counts, int((~accepted).sum())
        f = np.bincount(chosen[:, 0], minlength=self.E) / N
        self.aux_loss = float(self.E * np.sum(f * p.mean(0)))
        return y
