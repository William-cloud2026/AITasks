# L1-08 · Pure-Python Matrix Basics

**Level:** 1 · **Topics:** nested lists, comprehensions, validation · **Time:** ~25 min · **Allowed:** Python stdlib (no numpy)

## Task
Matrices are lists of lists of numbers. A **valid** matrix is non-empty, every row is non-empty and all rows
have the same length. All functions return new lists (never mutate input).

| Function | Description |
|---|---|
| `shape(m) -> (rows, cols)` | validates `m` |
| `transpose(m)` | transposed matrix |
| `matmul(a, b)` | matrix product; `ValueError` if inner dimensions differ |
| `identity(n)` | `n x n` identity using ints (`n >= 1`, else `ValueError`) |
| `scale(m, k)` | multiply every element by `k` |

Any invalid matrix argument → `ValueError`.

## Example
```python
matmul([[1, 2], [3, 4]], [[5], [6]])   # [[17], [39]]
transpose([[1, 2, 3]])                 # [[1], [2], [3]]
```
