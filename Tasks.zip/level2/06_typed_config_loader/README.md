# L2-06 · Typed Config Loader (dataclasses + type hints)

**Level:** 2 · **Topics:** dataclasses, `typing` introspection, recursion, error paths · **Time:** ~45 min · **Allowed:** Python stdlib

## Task
Implement `from_dict(cls, data)` that builds a (possibly nested) **dataclass** instance from a plain dict
(e.g. parsed YAML/JSON training config), validating types. Raise `ConfigError` (subclass of `ValueError`)
on any problem.

Supported field annotations:
| Annotation | Accepts |
|---|---|
| `int` | `int` (but **not** `bool`) |
| `float` | `int` or `float` (not `bool`); always stored as `float` |
| `str`, `bool` | exactly that type |
| `list[T]` | a `list`, each element converted as `T` |
| `dict[str, T]` | a `dict` with `str` keys, values converted as `T` |
| `Optional[T]` / `T \| None` | `None` or `T` |
| another dataclass | a `dict`, converted recursively |

Rules:
- Missing field with a default (or `default_factory`) → use the default. Missing without default → error.
- Unknown keys → error.
- Error messages must start with the **path** of the offending value then `": "`, e.g.
  `"model.layers[1]: expected int, got str"`, `"optim: unknown key 'betas2'"` (path of the dict holding the key),
  `"seed: missing required field"`. Top-level path is the field name; use `.` for fields, `[i]` for list
  indexes and `[key]` (without quotes) for dict keys.

## Example
```python
@dataclass
class Model:
    layers: list[int]
    dropout: float = 0.1

@dataclass
class Config:
    model: Model
    name: Optional[str] = None

from_dict(Config, {"model": {"layers": [64, 32], "dropout": 0}})
# Config(model=Model(layers=[64, 32], dropout=0.0), name=None)
```
