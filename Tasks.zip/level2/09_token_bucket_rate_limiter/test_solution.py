import math

from starter import MultiKeyLimiter, TokenBucket


class Clock:
    def __init__(self):
        self.t = 100.0

    def __call__(self):
        return self.t


def test_starts_full_and_drains():
    clk = Clock()
    b = TokenBucket(rate=2, capacity=5, clock=clk)
    assert b.try_acquire(5)
    assert not b.try_acquire(1)
    assert math.isclose(b.available(), 0.0)


def test_refill_and_cap():
    clk = Clock()
    b = TokenBucket(rate=2, capacity=5, clock=clk)
    b.try_acquire(5)
    clk.t += 1.5
    assert math.isclose(b.available(), 3.0)
    clk.t += 100
    assert math.isclose(b.available(), 5.0)


def test_failed_acquire_consumes_nothing():
    clk = Clock()
    b = TokenBucket(rate=1, capacity=3, clock=clk)
    b.try_acquire(2)
    assert not b.try_acquire(2)
    assert math.isclose(b.available(), 1.0)


def test_wait_time():
    clk = Clock()
    b = TokenBucket(rate=4, capacity=10, clock=clk)
    assert b.wait_time(10) == 0.0
    b.try_acquire(10)
    assert math.isclose(b.wait_time(2), 0.5)
    clk.t += 0.5
    assert b.try_acquire(2)


def test_validation():
    clk = Clock()
    for fn in (lambda: TokenBucket(0, 1, clk), lambda: TokenBucket(1, 0, clk),
               lambda: TokenBucket(1, 2, clk).try_acquire(3), lambda: TokenBucket(1, 2, clk).try_acquire(0)):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_multi_key():
    clk = Clock()
    lim = MultiKeyLimiter(rate=1, capacity=2, clock=clk)
    assert lim.try_acquire("alice", 2)
    assert not lim.try_acquire("alice")
    assert lim.try_acquire("bob", 2)
    clk.t += 1
    assert lim.try_acquire("alice")
    assert not lim.try_acquire("alice")
