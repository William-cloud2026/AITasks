# L1-01 · FizzBuzz with Custom Rules

**Level:** 1 · **Topics:** loops, conditionals, input validation · **Time:** ~15 min · **Allowed:** Python stdlib

## Task
Implement `fizzbuzz(n, rules=None)` in `starter.py`.

- Return a list of strings for the numbers `1..n` (inclusive).
- `rules` is a list of `(divisor, word)` pairs. Default: `[(3, "Fizz"), (5, "Buzz")]`.
- For each number, concatenate the words of **every** rule whose divisor divides it, **in rule order**.
  If no rule matches, use `str(number)`.
- `n == 0` returns `[]`.

## Errors
- `n < 0` → `ValueError`
- any divisor `<= 0` → `ValueError`

## Example
```python
fizzbuzz(5)                                   # ['1', '2', 'Fizz', '4', 'Buzz']
fizzbuzz(6, [(2, "Foo"), (3, "Bar")])         # ['1', 'Foo', 'Bar', 'Foo', '5', 'FooBar']
```
