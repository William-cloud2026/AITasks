import numpy as np


def _sigmoid(x):
    out = np.empty_like(x, dtype=float)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    e = np.exp(x[~pos])
    out[~pos] = e / (1.0 + e)
    return out


class ReLU:
    """Rectified linear unit."""

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        return np.maximum(self.x, 0.0)

    def backward(self, grad_out):
        return grad_out * (self.x > 0)


class LeakyReLU:
    """Leaky ReLU."""

    def __init__(self, alpha=0.01):
        self.alpha = alpha

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        return np.where(self.x > 0, self.x, self.alpha * self.x)

    def backward(self, grad_out):
        return grad_out * np.where(self.x > 0, 1.0, self.alpha)


class Sigmoid:
    """Logistic sigmoid."""

    def forward(self, x):
        self.y = _sigmoid(np.asarray(x, dtype=float))
        return self.y

    def backward(self, grad_out):
        return grad_out * self.y * (1 - self.y)


class Tanh:
    """Hyperbolic tangent."""

    def forward(self, x):
        self.y = np.tanh(np.asarray(x, dtype=float))
        return self.y

    def backward(self, grad_out):
        return grad_out * (1 - self.y ** 2)


class GELU:
    """GELU (tanh approximation)."""

    _C = np.sqrt(2 / np.pi)

    def forward(self, x):
        self.x = x = np.asarray(x, dtype=float)
        self.t = np.tanh(self._C * (x + 0.044715 * x ** 3))
        return 0.5 * x * (1 + self.t)

    def backward(self, grad_out):
        x, t = self.x, self.t
        dt = (1 - t ** 2) * self._C * (1 + 3 * 0.044715 * x ** 2)
        return grad_out * (0.5 * (1 + t) + 0.5 * x * dt)


class Softplus:
    """log(1 + exp(x))."""

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        return np.logaddexp(0.0, self.x)

    def backward(self, grad_out):
        return grad_out * _sigmoid(self.x)


class SiLU:
    """x * sigmoid(x)."""

    def forward(self, x):
        self.x = np.asarray(x, dtype=float)
        self.s = _sigmoid(self.x)
        return self.x * self.s

    def backward(self, grad_out):
        return grad_out * (self.s + self.x * self.s * (1 - self.s))
