import numpy as np


def _softmax(z):
    z = z - np.max(z[np.isfinite(z)])
    e = np.where(np.isfinite(z), np.exp(z), 0.0)
    return e / e.sum()


def filter_logits(logits, top_k=None, top_p=None):
    """Top-k then top-p filtering."""
    out = np.asarray(logits, dtype=float).copy()
    order = np.argsort(-out, kind="stable")
    if top_k is not None and top_k < len(out):
        out[order[top_k:]] = -np.inf
    if top_p is not None:
        order = np.argsort(-out, kind="stable")
        probs = _softmax(out)[order]
        cum = np.cumsum(probs)
        keep = int(np.searchsorted(cum, top_p - 1e-12) + 1)
        out[order[max(1, keep):]] = -np.inf
    return out


def greedy_decode(next_logits, prompt, max_new_tokens, eos_id=None):
    """Argmax decoding."""
    seq = list(prompt)
    for _ in range(max_new_tokens):
        tok = int(np.argmax(next_logits(seq)))
        seq.append(tok)
        if tok == eos_id:
            break
    return seq


def sample_decode(next_logits, prompt, max_new_tokens, temperature=1.0, top_k=None, top_p=None, seed=None,
                  eos_id=None):
    """Temperature / top-k / top-p sampling."""
    if temperature < 0:
        raise ValueError("temperature must be >= 0")
    if temperature == 0:
        return greedy_decode(next_logits, prompt, max_new_tokens, eos_id)
    rng = np.random.default_rng(seed)
    seq = list(prompt)
    for _ in range(max_new_tokens):
        logits = filter_logits(np.asarray(next_logits(seq), dtype=float) / temperature, top_k, top_p)
        p = _softmax(logits)
        tok = int(rng.choice(len(p), p=p))
        seq.append(tok)
        if tok == eos_id:
            break
    return seq


def beam_search(next_logprobs, prompt, beam_width, max_new_tokens, eos_id=None, length_penalty=1.0):
    """Beam search with length-normalized final scoring."""
    alive = [(list(prompt), 0.0)]
    finished = []
    n0 = len(prompt)
    for _ in range(max_new_tokens):
        cands = []
        for b, (seq, score) in enumerate(alive):
            lp = np.asarray(next_logprobs(seq), dtype=float)
            for tok in range(len(lp)):
                cands.append((-(score + lp[tok]), b, tok, seq + [tok], score + lp[tok]))
        cands.sort(key=lambda c: (c[0], c[1], c[2]))
        alive = []
        for _, _, tok, seq, score in cands[:beam_width]:
            if eos_id is not None and tok == eos_id:
                finished.append((seq, score))
            else:
                alive.append((seq, score))
        if not alive:
            break
    finished.extend(alive)
    best, best_score = None, -np.inf
    for seq, score in finished:
        norm = score / ((len(seq) - n0) ** length_penalty)
        if norm > best_score:
            best, best_score = seq, norm
    return best, float(best_score)
