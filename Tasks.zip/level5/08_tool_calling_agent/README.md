# L5-08 · Tool-Calling Agent Loop

**Level:** 5 · **Topics:** LLM agents, tool schemas, robust parsing, conversation state · **Time:** ~75 min · **Allowed:** Python stdlib

The LLM is injected as a plain function, so everything runs offline with scripted fake models.

### `class ToolError(Exception)`

### `class ToolRegistry`
- `register(name, fn, schema, description="")`: `schema = {param: {"type": T, "required": bool}}` with
  `T ∈ {"string", "number", "integer", "boolean"}` (`required` defaults to `True`). Duplicate name → `ValueError`.
- `call(name, arguments)`: raise `ToolError` for: unknown tool, `arguments` not a dict, missing required argument,
  unexpected argument, wrong type (`number` = int/float, `integer` = int; `bool` is never a number/integer). Otherwise
  return `fn(**arguments)`; any exception raised by `fn` is re-raised as `ToolError(str(exc))`.
- `describe()`: one line per tool, sorted by name: `- name(p1: type, p2?: type): description` (params in schema
  order, optional ones marked with `?`). Tools with no params: `- name(): description`.

### `parse_action(text) -> tuple`
- If `text` contains `"FINAL:"` → `("final", <text after the first "FINAL:", stripped>)`.
- Else take the content of the first fenced block ```` ```json ... ``` ```` (or a plain ```` ``` ... ``` ```` block); if
  there is none and the stripped text starts with `{`, use the whole text. Parse it as JSON; it must be an object with a
  string `"tool"` and (optional, default `{}`) `"arguments"` object → `("tool", name, arguments)`.
- Anything else → `("invalid", reason)`.

### `class Agent(llm, registry, max_steps=5, system_prompt=None)`
`run(task) -> dict` with keys `answer`, `stopped` (`"final"` or `"max_steps"`), `steps`, `messages`.
1. `messages = [{"role": "system", "content": system_prompt or default}, {"role": "user", "content": task}]`; the
   default system prompt must contain `registry.describe()`.
2. Up to `max_steps` times: `reply = llm(messages)`; append `{"role": "assistant", "content": reply}`; then by action:
   - final → set `answer`, `stopped = "final"`, return.
   - tool → call it; append `{"role": "tool", "content": json.dumps({"tool": name, "result": result})}` and step
     `{"tool": name, "arguments": args, "result": result}`; on `ToolError` use key `"error"` (with `str(exc)`) instead
     of `"result"` in both.
   - invalid → append `{"role": "user", "content": f"Invalid action: {reason}. Reply with a JSON tool call or FINAL: <answer>."}`
     and step `{"tool": None, "arguments": None, "error": reason}`.
3. If no final answer: `answer = None`, `stopped = "max_steps"`.
