# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class SimpleImputer:
    """Fill NaNs column-wise."""

    def __init__(self, strategy='mean', fill_value=None):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Compute per-column fill values."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Replace NaNs."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')

class OneHotEncoder:
    """One-hot encode categorical columns."""

    def __init__(self, handle_unknown='error'):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Learn sorted categories per column."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Encode X."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')

    def get_feature_names_out(self, input_features=None):
        """Output column names."""
        raise NotImplementedError('TODO')

    def inverse_transform(self, Z):
        """Decode one-hot blocks."""
        raise NotImplementedError('TODO')
