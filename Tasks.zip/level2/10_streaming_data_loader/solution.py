import json
import random


def read_jsonl(path):
    """Yield objects from a JSON-lines file."""
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"line {i}: invalid JSON ({e.msg})") from None


def shuffle_buffer(iterable, buffer_size, seed=None):
    """Streaming approximate shuffle."""
    if buffer_size < 1:
        raise ValueError("buffer_size must be >= 1")

    def gen():
        rng = random.Random(seed)
        it = iter(iterable)
        buf = []
        for x in it:
            buf.append(x)
            if len(buf) == buffer_size:
                break
        for x in it:
            j = rng.randrange(len(buf))
            yield buf[j]
            buf[j] = x
        rng.shuffle(buf)
        yield from buf

    return gen()


def interleave(*iterables):
    """Round-robin across iterables."""
    its = [iter(x) for x in iterables]
    while its:
        alive = []
        for it in its:
            try:
                yield next(it)
            except StopIteration:
                continue
            alive.append(it)
        its = alive
