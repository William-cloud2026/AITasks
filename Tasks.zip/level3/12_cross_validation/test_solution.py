import numpy as np

from starter import KFold, StratifiedKFold, cross_val_score


def test_kfold_sizes_and_order():
    folds = list(KFold(3).split(10))
    assert [len(te) for _, te in folds] == [4, 3, 3]
    np.testing.assert_array_equal(folds[0][1], [0, 1, 2, 3])
    np.testing.assert_array_equal(folds[1][0], [0, 1, 2, 3, 7, 8, 9])


def test_kfold_shuffle_exact():
    folds = list(KFold(4, shuffle=True, seed=11).split(9))
    perm = np.random.default_rng(11).permutation(9)
    np.testing.assert_array_equal(folds[0][1], np.sort(perm[:3]))
    np.testing.assert_array_equal(folds[3][1], np.sort(perm[7:]))
    allte = np.concatenate([te for _, te in folds])
    np.testing.assert_array_equal(np.sort(allte), np.arange(9))
    for tr, te in folds:
        assert not set(tr) & set(te) and len(tr) + len(te) == 9
        assert np.all(np.diff(tr) > 0) and np.all(np.diff(te) > 0)


def test_stratified():
    y = np.array([0] * 12 + [1] * 6 + [2] * 3)
    folds = list(StratifiedKFold(3).split(y))
    for tr, te in folds:
        counts = np.bincount(y[te], minlength=3)
        assert counts.tolist() == [4, 2, 1]
    folds = list(StratifiedKFold(2).split(np.array([1, 0, 1, 0, 0])))
    np.testing.assert_array_equal(folds[0][1], [1, 2, 4])
    np.testing.assert_array_equal(folds[1][1], [0, 3])


def test_stratified_shuffle_reproducible():
    y = np.array([0, 1] * 10 + [2] * 5)
    a = [te.tolist() for _, te in StratifiedKFold(5, shuffle=True, seed=1).split(y)]
    b = [te.tolist() for _, te in StratifiedKFold(5, shuffle=True, seed=1).split(y)]
    assert a == b
    assert sorted(sum(a, [])) == list(range(25))


def test_errors():
    for fn in (lambda: KFold(1), lambda: list(KFold(5).split(3)), lambda: list(StratifiedKFold(4).split([0, 1]))):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


class MajorityModel:
    instances = 0

    def __init__(self):
        MajorityModel.instances += 1

    def fit(self, X, y):
        vals, counts = np.unique(y, return_counts=True)
        self.label = vals[np.argmax(counts)]
        return self

    def predict(self, X):
        return np.full(len(X), self.label)


def test_cross_val_score():
    X = np.arange(20).reshape(10, 2)
    y = np.array([0] * 7 + [1] * 3)
    MajorityModel.instances = 0
    scores = cross_val_score(MajorityModel, X, y, KFold(5), lambda t, p: float(np.mean(t == p)))
    np.testing.assert_allclose(scores, [1, 1, 1, 0.5, 0])
    assert MajorityModel.instances == 5
    scores = cross_val_score(MajorityModel, X, y, StratifiedKFold(2), lambda t, p: float(np.mean(t == p)))
    assert scores.shape == (2,)
