from starter import from_roman, to_roman


def test_to_roman_known():
    cases = {1: "I", 4: "IV", 9: "IX", 14: "XIV", 40: "XL", 90: "XC", 400: "CD",
             1994: "MCMXCIV", 2025: "MMXXV", 3999: "MMMCMXCIX"}
    for n, r in cases.items():
        assert to_roman(n) == r


def test_round_trip_all():
    for n in range(1, 4000):
        assert from_roman(to_roman(n)) == n


def test_to_roman_invalid():
    for bad in [0, 4000, -5, 3.0, True, "10"]:
        try:
            to_roman(bad)
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {bad!r}")


def test_from_roman_invalid():
    for bad in ["", "IIII", "VX", "IC", "MMMM", "iv", "IIV", "XM", "VV", "ABC", "MCMC"]:
        try:
            from_roman(bad)
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {bad!r}")
