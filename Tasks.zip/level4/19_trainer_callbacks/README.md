# L4-19 · Training Loop with Callbacks (Early Stopping & Checkpointing)

**Level:** 4 · **Topics:** framework design, hooks, state management · **Time:** ~50 min · **Allowed:** Python stdlib (+ numpy optional)

## Task
### `class Callback` — base class with no-op hooks
`on_train_begin(trainer)`, `on_epoch_end(trainer, epoch, logs)`, `on_train_end(trainer)`.

### `class Trainer(train_epoch, evaluate=None, get_state=None, set_state=None, callbacks=())`
- `fit(epochs) -> dict[str, list]` (the history).
- For `epoch` in `0..epochs−1`: `logs = dict(train_epoch(epoch))`; if `evaluate`: `logs.update(evaluate(epoch))`;
  append every log value to the history; call `on_epoch_end` of each callback **in order**; then stop if
  `trainer.stop_training` is `True`.
- `on_train_begin` is called before the first epoch (it resets `stop_training = False`), `on_train_end` after the last.
- `get_state()` / `set_state(state)` are user-provided (e.g. a dict of weights). Expose `trainer.get_state()` /
  `trainer.set_state(state)` methods that call them (`RuntimeError` if not provided).

### `class EarlyStopping(Callback)(monitor="val_loss", mode="min", patience=3, min_delta=0.0, restore_best=True)`
- Improvement: `value < best − min_delta` (min) or `value > best + min_delta` (max). The first epoch always improves.
- On improvement: record `best`, `best_epoch`, reset the wait counter, and if `restore_best` store a
  `copy.deepcopy(trainer.get_state())`. Otherwise increment wait; when `wait >= patience` set
  `trainer.stop_training = True` and `stopped_epoch = epoch`.
- `on_train_end`: if `restore_best` and a state was stored → `trainer.set_state(best_state)`.
- Missing monitor key in logs → `KeyError`. Invalid `mode` → `ValueError`.

### `class ModelCheckpoint(Callback)(monitor="val_loss", mode="min", save_best_only=True)`
Keeps `saved`: list of `(epoch, value, deep-copied state)`; appends when the value improves (strictly) or always
if `save_best_only=False`.
