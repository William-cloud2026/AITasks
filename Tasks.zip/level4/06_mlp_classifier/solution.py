import numpy as np


class MLPClassifier:
    """ReLU MLP with softmax output trained by Adam."""

    def __init__(self, hidden_sizes=(64, 64), lr=0.01, epochs=200, batch_size=32, l2=0.0, seed=0):
        self.hidden_sizes, self.lr, self.epochs = tuple(hidden_sizes), lr, epochs
        self.batch_size, self.l2, self.seed = batch_size, l2, seed

    def _forward(self, X):
        acts = [X]
        h = X
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = h @ W + b
            h = np.maximum(z, 0) if i < len(self.W) - 1 else z
            acts.append(h)
        return acts

    @staticmethod
    def _softmax(Z):
        E = np.exp(Z - Z.max(1, keepdims=True))
        return E / E.sum(1, keepdims=True)

    def fit(self, X, y):
        """Train with mini-batch Adam."""
        X = np.asarray(X, dtype=float)
        self.classes_, yi = np.unique(np.asarray(y), return_inverse=True)
        rng = np.random.default_rng(self.seed)
        sizes = [X.shape[1], *self.hidden_sizes, len(self.classes_)]
        self.W = [rng.normal(0, np.sqrt(2 / a), size=(a, b)) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b) for b in sizes[1:]]
        params = self.W + self.b
        m = [np.zeros_like(p) for p in params]
        v = [np.zeros_like(p) for p in params]
        t = 0
        self.loss_history_ = []
        n = len(X)
        for _ in range(self.epochs):
            perm = rng.permutation(n)
            losses = []
            for s in range(0, n, self.batch_size):
                idx = perm[s:s + self.batch_size]
                xb, yb = X[idx], yi[idx]
                acts = self._forward(xb)
                P = self._softmax(acts[-1])
                losses.append(-np.mean(np.log(P[np.arange(len(idx)), yb] + 1e-12)))
                d = P
                d[np.arange(len(idx)), yb] -= 1
                d /= len(idx)
                gW, gb = [None] * len(self.W), [None] * len(self.W)
                for i in range(len(self.W) - 1, -1, -1):
                    gW[i] = acts[i].T @ d + self.l2 * self.W[i]
                    gb[i] = d.sum(0)
                    if i:
                        d = (d @ self.W[i].T) * (acts[i] > 0)
                t += 1
                for p, g, mi, vi in zip(params, gW + gb, m, v):
                    mi *= 0.9
                    mi += 0.1 * g
                    vi *= 0.999
                    vi += 0.001 * g * g
                    p -= self.lr * (mi / (1 - 0.9 ** t)) / (np.sqrt(vi / (1 - 0.999 ** t)) + 1e-8)
            self.loss_history_.append(float(np.mean(losses)))
        return self

    def predict_proba(self, X):
        """Class probabilities."""
        return self._softmax(self._forward(np.asarray(X, dtype=float))[-1])

    def predict(self, X):
        """Predicted labels."""
        return self.classes_[np.argmax(self.predict_proba(X), axis=1)]
