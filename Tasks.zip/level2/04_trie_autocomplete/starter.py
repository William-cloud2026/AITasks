# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import heapq

class Trie:
    """Prefix tree with weighted completions."""

    def __init__(self):
        raise NotImplementedError('TODO')

    def insert(self, word, weight=1):
        """Insert word (weights accumulate)."""
        raise NotImplementedError('TODO')

    def contains(self, word):
        """Exact membership."""
        raise NotImplementedError('TODO')
    __contains__ = contains

    def weight(self, word):
        """Stored weight or 0."""
        raise NotImplementedError('TODO')

    def count_prefix(self, prefix):
        """Number of words with this prefix."""
        raise NotImplementedError('TODO')

    def complete(self, prefix, k=5):
        """Top-k completions by weight desc, word asc."""
        raise NotImplementedError('TODO')

    def delete(self, word):
        """Remove word; return True if it existed."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')
