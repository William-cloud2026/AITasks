# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def sigmoid(z):
    """Numerically stable logistic function."""
    raise NotImplementedError('TODO')

def bce_loss_and_grad(X, y, w, b, l2=0.0):
    """Stable binary cross-entropy with L2 and its gradients."""
    raise NotImplementedError('TODO')

class LogisticRegression:
    """Binary logistic regression trained with full-batch GD."""

    def __init__(self, lr=0.1, epochs=1000, l2=0.0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Fit weights."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """P(classes_[1] | x)."""
        raise NotImplementedError('TODO')

    def predict(self, X, threshold=0.5):
        """Class labels."""
        raise NotImplementedError('TODO')
