# L3-15 · Numerical Gradient Checking

**Level:** 3 · **Topics:** finite differences, debugging backprop · **Time:** ~30 min · **Allowed:** Python stdlib + numpy

## Task
| Function | Behaviour |
|---|---|
| `numerical_gradient(f, x, eps=1e-6)` | `f` maps an array of any shape to a scalar. Return an array shaped like `x` using **central differences**. `x` must be left unchanged afterwards (even if you perturb it in place) |
| `relative_error(a, b)` | `max(|a − b| / max(1e-8, |a| + |b|))` element-wise, as a float |
| `check_gradient(f, grad_f, x, tol=1e-5, eps=1e-6)` | returns `(ok, err)` comparing `grad_f(x)` with `numerical_gradient`; `ok = err < tol` |
| `jacobian(f, x, eps=1e-6)` | `f: R^n → R^m` (1-D in, 1-D out); return `(m, n)` matrix by central differences |

Inputs may be integer arrays — compute in `float64`.
