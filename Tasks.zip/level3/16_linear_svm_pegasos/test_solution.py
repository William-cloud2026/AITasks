import numpy as np

from starter import LinearSVM, hinge_loss

rng = np.random.default_rng(6)
X = np.vstack([rng.normal([-2, -2], 0.8, size=(100, 2)), rng.normal([2, 2], 0.8, size=(100, 2))])
y = np.array([0] * 100 + [1] * 100)


def test_hinge_loss_value():
    Xs = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
    ys = np.array([1, -1, 1])
    w, b = np.array([0.5, 0.5]), 0.0
    # margins: 0.5, -0.5, 1.0 -> hinge 0.5, 1.5, 0.0
    assert np.isclose(hinge_loss(Xs, ys, w, b, lam=0.1), 0.05 * 0.5 + 2.0 / 3)


def test_fit_accuracy():
    m = LinearSVM(lam=0.01, epochs=10).fit(X, y)
    assert np.mean(m.predict(X) == y) > 0.97
    assert m.coef_.shape == (2,) and np.all(m.coef_ > 0)


def test_exact_first_steps():
    Xs = np.array([[1.0, 2.0], [-1.0, -1.0], [2.0, 0.5]])
    ys = np.array(["b", "a", "b"])
    m = LinearSVM(lam=0.5, epochs=1, seed=42).fit(Xs, ys)
    s = np.array([1.0, -1.0, 1.0])
    Z = np.column_stack([Xs, np.ones(3)])
    w, t = np.zeros(3), 1
    for i in np.random.default_rng(42).permutation(3):
        eta = 1 / (0.5 * t)
        if s[i] * (Z[i] @ w) < 1:
            w = (1 - eta * 0.5) * w + eta * s[i] * Z[i]
        else:
            w = (1 - eta * 0.5) * w
        t += 1
    np.testing.assert_allclose(m.coef_, w[:2])
    assert np.isclose(m.intercept_, w[2])
    assert list(m.classes_) == ["a", "b"]


def test_reproducible_and_loss_reasonable():
    a = LinearSVM(seed=1).fit(X, y)
    b = LinearSVM(seed=1).fit(X, y)
    np.testing.assert_array_equal(a.coef_, b.coef_)
    s = np.where(y == 1, 1, -1)
    assert hinge_loss(X, s, a.coef_, a.intercept_, 0.01) < 0.2


def test_decision_function_sign():
    m = LinearSVM().fit(X, y)
    d = m.decision_function([[3, 3], [-3, -3]])
    assert d[0] > 0 > d[1]


def test_bad_classes():
    try:
        LinearSVM().fit(X, np.arange(200) % 3)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
