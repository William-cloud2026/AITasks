# L1-17 · Text Normalization for NLP

**Level:** 1 · **Topics:** unicode, `unicodedata`, preprocessing · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
### `normalize_text(text, lowercase=True, strip_accents=True, remove_punctuation=True) -> str`
Apply in this order:
1. `strip_accents`: Unicode-normalize with **NFKD** and remove all combining marks
   (`unicodedata.combining(ch) != 0`).
2. `lowercase`: `str.lower()`.
3. `remove_punctuation`: replace every character whose Unicode category starts with `"P"` with a space.
4. **Always**: collapse any run of whitespace to a single space and strip both ends.

### `tokenize(text) -> list[str]`
`normalize_text(text)` with defaults, split on spaces. Empty text → `[]`.

### `vocabulary(texts, min_count=1) -> dict[str, int]`
Build `token -> id` over all texts. Keep tokens with frequency `>= min_count`. Sort by frequency descending,
then token ascending; ids are `0..n-1` in that order.

## Example
```python
normalize_text("  Café   déjà-vu!! ")   # 'cafe deja vu'
```
