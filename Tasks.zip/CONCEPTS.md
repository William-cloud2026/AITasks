# Concepts Guide — Python & AI Engineering

A study companion for the 100 tasks in this folder. For every concept you get **what it is**, **why it matters /
how it is used in real AI systems**, the **key idea or formula**, and **which tasks practise it**
(`L3-05` = `level3/05_*`).

The guide explains ideas, not task solutions — each task's `README.md` remains the exact specification.

## Contents
- [Part A — Python engineering foundations](#part-a--python-engineering-foundations)
- [Part B — Machine learning fundamentals](#part-b--machine-learning-fundamentals)
- [Part C — Evaluation metrics](#part-c--evaluation-metrics)
- [Part D — Deep learning](#part-d--deep-learning)
- [Part E — NLP and language models](#part-e--nlp-and-language-models)
- [Part F — Transformers](#part-f--transformers)
- [Part G — LLM inference and serving](#part-g--llm-inference-and-serving)
- [Part H — Building LLM applications (RAG, agents, guardrails)](#part-h--building-llm-applications)
- [Part I — Adapting and scaling models](#part-i--adapting-and-scaling-models)
- [Glossary](#glossary)
- [Concept → task map](#concept--task-map)

### How the levels build on each other
```
Level 1  Python basics ─────────┐
Level 2  Python engineering ────┼──► Level 3  classical ML (numpy)
                                │          │
                                │          ▼
                                │    Level 4  neural nets, NLP building blocks
                                │          │
                                └──────────▼
                                     Level 5  transformers, LLM serving, RAG, agents
```

---

## Part A — Python engineering foundations

### A1. Iterators, generators and laziness
**What.** An *iterator* produces items one at a time (`next()`); a *generator* is a function with `yield` that
creates one. Nothing is computed until someone asks for the next item.

**Why it matters in AI.** Training data is often far larger than RAM (terabytes of text). Data loaders stream records
from disk, transform them, shuffle them in a buffer and batch them — all lazily. The same pattern streams tokens out
of an LLM.

**Key ideas.**
- `itertools.islice`, `deque(maxlen=n)` for windows, `chain`, `groupby`.
- A generator function's body does not run at call time — validate arguments *before* creating the generator if
  errors must be raised immediately.
- Laziness lets you work with infinite streams (`itertools.count()`).

**Tasks:** L1-10, L2-10, L4-20.

### A2. Decorators and closures
**What.** A decorator is a function that takes a function and returns a new one (`@retry(...)`). A closure is an inner
function that remembers variables from the enclosing scope.

**Why it matters in AI.** Retrying flaky model APIs, timing/profiling, caching, registering components
(`@MODELS.register("bert")`), tracing tool calls in agents. Always use `functools.wraps` so the wrapper keeps the
original name and docstring.

**Tasks:** L2-02, L2-03, L2-16.

### A3. Context managers
**What.** Objects used with `with` that run setup and guaranteed cleanup (`__enter__/__exit__` or
`@contextlib.contextmanager`).

**Why it matters in AI.** Timing sections of a training step, temporarily switching a model to eval mode, opening files,
locks, GPU memory scopes, `torch.no_grad()`.

**Key idea.** Cleanup must happen even if the block raises — use `try/finally`.

**Tasks:** L2-03, L5-12 (`async with`).

### A4. Dependency injection and testable code
**What.** Pass collaborators (clock, random generator, LLM function, sleep function) in as parameters instead of
hard-coding them.

**Why it matters in AI.** LLM-based systems call slow, costly, non-deterministic services. Injecting `llm(prompt)` or
`clock()` lets you test logic deterministically and offline with fakes — exactly how the Level 5 tasks work.

**Tasks:** L2-02, L2-03, L2-09, L5-07, L5-08, L5-12, L5-13.

### A5. Core data structures and complexity
| Structure | Typical operations | AI usage |
|---|---|---|
| Hash map (`dict`) | O(1) lookup | vocabularies, caches, counting n-grams |
| Ordered dict / linked list | O(1) move-to-end | LRU caches (KV caches, response caches) |
| Heap (`heapq`) | O(log n) push/pop min | top-k results, schedulers, block allocators |
| Trie (prefix tree) | O(len) prefix search | autocomplete, constrained decoding, tokenizers |
| Graph + BFS/Dijkstra | shortest paths | knowledge graphs, routing |
| DAG + topological sort | dependency order | ML pipelines, build systems, workflow engines |
| Sparse matrix (CSR) | store only non-zeros | bag-of-words, TF-IDF, recommender data |

**Big-O.** Tests in several tasks contain time limits: the intended solution must use the right data structure
(e.g. an inverted index instead of scanning every document, a heap instead of sorting everything).

**Tasks:** L2-01, L2-04, L2-07, L2-08, L2-13, L2-15, L2-19, L5-18, L5-19.

### A6. Parsing
**What.** Turning text into structure: *tokenize* (split into meaningful pieces), then *parse* (apply grammar rules).
A **recursive-descent parser** has one function per grammar rule; operator precedence comes from which rule calls which.

**Why it matters in AI.** Prompt templates, parsing LLM output (JSON tool calls), safe calculators for agents (never
`eval()` model output!), config files, log analysis.

**Tasks:** L1-09, L1-14, L2-05, L2-11, L2-20, L5-08.

### A7. Typed configuration and validation
**What.** Dataclasses + type hints describe what a config or record should look like; a validator checks real data
against it and reports precise error paths (`model.layers[1]: expected int`).

**Why it matters in AI.** Training runs are driven by large nested configs; datasets contain malformed records.
Failing early with a clear message saves hours of GPU time. (Libraries like pydantic do this in production.)

**Tasks:** L1-11, L2-06, L2-16, L2-17.

### A8. Randomness and reproducibility
**What.** Pseudo-random generators produce the same sequence from the same **seed**.

**Why it matters in AI.** Reproducible experiments, fair model comparisons, debugging. Prefer a *local* generator
(`random.Random(seed)`, `np.random.default_rng(seed)`) over global state so components don't interfere.

**Tasks:** L1-19, L2-10, L3-03, L3-06, L4-06, L4-10, L5-03.

### A9. Unicode and text normalization
**What.** The same visible text can have different byte/code-point representations (`é` = one code point or `e` +
combining accent). **NFKD** decomposes characters; removing combining marks strips accents.

**Why it matters in AI.** Tokenizers, search and deduplication all compare strings — inconsistent normalization means
"café" ≠ "café". Text is stored as **UTF-8 bytes**, which byte-level tokenizers operate on directly.

**Tasks:** L1-02, L1-17, L4-11.

### A10. Asynchronous programming
**What.** `asyncio` runs many waiting tasks concurrently on one thread (`async def`, `await`, queues, futures).

**Why it matters in AI.** Inference servers handle thousands of concurrent requests; agent frameworks call many tools
and APIs in parallel. Async code lets a server collect requests into batches while others wait.

**Tasks:** L5-12.

### A11. Rate limiting and retries
**What.** A **token bucket** refills at a fixed rate up to a capacity; each request spends tokens. **Exponential
backoff** waits `base · factor^k` between retries.

**Why it matters in AI.** LLM APIs enforce requests-per-minute and tokens-per-minute quotas and occasionally fail;
production clients combine both techniques.

**Tasks:** L2-02, L2-09.

### A12. Floating-point pitfalls
- `0.1 + 0.2 != 0.3`; compare with tolerances (`math.isclose`, `np.allclose`).
- `exp(1000)` overflows → use log-space (`np.logaddexp`, log-sum-exp).
- Rounding `x.5` in numpy is "half to even".
- Values on bin edges (e.g. `0.7 * 10` = `7.000000000000001`) can land in unexpected buckets.

**Tasks:** L1-12, L3-04, L3-13, L5-10, L5-20.

---

## Part B — Machine learning fundamentals

### B1. What is machine learning?
A model is a function `f(x; θ)` with parameters `θ`. **Training** chooses `θ` to minimize a **loss** on training data;
we hope it **generalizes** to new data.

| Type | Data | Examples in this folder |
|---|---|---|
| Supervised | inputs + labels | regression, logistic regression, kNN, trees, NB, SVM, MLP |
| Unsupervised | inputs only | k-means, PCA, anomaly detection |
| Self-supervised | labels derived from data itself | language modelling (predict next token), word2vec |

### B2. The ML workflow and data splits
```
raw data → clean/validate → split → preprocess (fit on TRAIN only) → train → tune on VALIDATION → final TEST
```
- **Train / validation / test**: tune hyper-parameters on validation; touch the test set once.
- **Data leakage**: any information from the test set reaching training (e.g. fitting a scaler on all data,
  duplicates across splits) gives over-optimistic results.
- **Stratification** keeps class proportions equal across splits — important for imbalanced data.

**Tasks:** L1-19, L3-12, L3-20, L2-18 (dedup prevents train/test contamination).

### B3. Cross-validation and hyper-parameter search
**k-fold CV** splits data into k folds; each fold is the validation set once; average the scores. **Grid search**
tries every combination of hyper-parameters, scores each with CV, and refits the best on all data.

**Why.** More reliable estimates than one split; principled model selection.

**Tasks:** L3-12, L3-20.

### B4. Feature preprocessing
| Technique | Idea | When |
|---|---|---|
| Standardization | `(x − mean) / std` | gradient-based models, distance-based models, PCA |
| Min-max scaling | map to `[0, 1]` | bounded inputs, neural nets |
| Imputation | fill missing values (mean/median/mode/constant) | real tabular data |
| One-hot encoding | category → binary vector | categorical features for linear models |
| Label encoding | class name → integer id | targets for classifiers |
| Polynomial features | add `x²`, `x·y`, ... | let linear models fit curves |

Always **fit** the transformer on training data and **apply** it to validation/test data.

**Tasks:** L1-18, L3-01, L3-14, L3-17.

### B5. Overfitting, underfitting and regularization
- **Underfitting** (high bias): model too simple. **Overfitting** (high variance): model memorizes noise.
- **Regularization** limits complexity: L2 / *weight decay* (`λ‖w‖²`), L1, early stopping, dropout, tree depth limits,
  minimum leaf size, data augmentation.

**Tasks:** L3-02 (ridge), L3-03, L3-09, L4-04 (weight decay), L4-10 (dropout), L4-19 (early stopping).

### B6. Linear regression
`ŷ = Xw + b`, minimize mean squared error.
- **Closed form (normal equations):** `w = (XᵀX + λI)⁻¹ Xᵀy` — solve the linear system rather than invert.
  `λ > 0` is **ridge regression**. Rank-deficient `X` → use least squares / pseudo-inverse (minimum-norm solution).
- **R²** measures explained variance: `1 − SS_res / SS_tot`.

**Tasks:** L3-02, L3-03.

### B7. Gradient descent
Repeatedly step against the gradient: `θ ← θ − η ∇L(θ)` (`η` = learning rate).
- **Full-batch**: exact gradient, slow per step. **Stochastic / mini-batch (SGD)**: noisy but cheap; the standard for
  deep learning. One **epoch** = one pass over the data.
- Too large `η` diverges; too small is slow. Feature scaling makes optimization much easier.

**Tasks:** L3-03, L3-04, L3-13, L3-16, L4-04.

### B8. Logistic regression, softmax and cross-entropy
- **Binary:** `p = σ(z) = 1/(1 + e^{−z})`, loss = binary cross-entropy `−[y log p + (1−y) log(1−p)]`.
- **Multiclass:** `p = softmax(z)_c = e^{z_c} / Σ_j e^{z_j}`, loss = `−log p_true`.
- Beautiful gradient: `∂L/∂z = p − y` (probabilities minus one-hot target).
- These are exactly the output layer + loss of every classifier and of every language model (next-token prediction is
  softmax over the vocabulary).

**Tasks:** L3-04, L3-13, L4-06, L4-18.

### B9. Numerical stability
- **Stable sigmoid:** use `e^{z}/(1+e^{z})` for negative `z`.
- **Log-sum-exp:** `log Σ e^{z_i} = m + log Σ e^{z_i − m}` with `m = max z`. Used for softmax, log-softmax,
  naive Bayes posteriors, and attention.
- Compute `log softmax` directly instead of `log(softmax(z))` to avoid `log(0)`.
- Masked positions in attention use `−∞` scores, but a row that is *entirely* masked must be handled to avoid NaNs.

**Tasks:** L3-04, L3-07, L3-08, L3-13, L4-02, L4-14, L4-18.

### B10. Gradient checking
Compare analytic gradients with **central finite differences** `(f(x+ε) − f(x−ε)) / 2ε`. Relative error ≲ 1e-5 means
your backprop is right. The standard way to debug hand-written backward passes.

**Tasks:** L3-15 (and used inside most Level 4 tests).

### B11. k-Nearest Neighbours
Predict from the labels of the k closest training points (Euclidean/Manhattan/cosine distance). No training, slow
prediction. Vectorize distances with `‖a−b‖² = ‖a‖² + ‖b‖² − 2a·b`. The same "find nearest vectors" problem powers
**vector search** in RAG (H4).

**Tasks:** L3-05, L5-06.

### B12. k-Means clustering
Alternate: assign each point to the nearest centroid; move each centroid to the mean of its points. **k-means++**
initialization picks spread-out starting centroids (probability ∝ squared distance). Minimizes **inertia** (sum of
squared distances). Used for data exploration, vector quantization and **IVF vector indexes**.

**Tasks:** L3-06, L5-06.

### B13. Naive Bayes
Bayes' rule with the "naive" assumption that features are independent given the class:
`log P(c|x) ∝ log P(c) + Σ_j log P(x_j|c)`.
- **Gaussian NB** for continuous features; **Multinomial NB** for word counts (classic spam filter).
- **Laplace / additive smoothing** (`+α`) avoids zero probabilities for unseen words.

**Tasks:** L3-07, L3-08.

### B14. Decision trees
Recursively split data on the feature/threshold that most reduces impurity (**Gini** `1 − Σ p_c²` or entropy).
Interpretable; prone to overfitting → limit depth / leaf size. Ensembles of trees (random forests, gradient boosting)
dominate tabular ML.

**Tasks:** L3-09.

### B15. Support vector machines
Find the separating hyperplane with the largest **margin**; **hinge loss** `max(0, 1 − y·f(x))` + L2 penalty.
**Pegasos** is a simple SGD solver with step size `1/(λt)`.

**Tasks:** L3-16.

### B16. Principal Component Analysis
Find orthogonal directions of maximum variance via **SVD** of centered data; project onto the top k to reduce
dimensionality. `explained_variance_ratio` tells how much information is kept. Used for visualization, compression,
denoising, analysing embeddings.

**Tasks:** L3-10.

### B17. Anomaly detection
Flag data that is unlikely under a model of "normal": z-scores, IQR (Tukey fences), or multivariate Gaussian with
**Mahalanobis distance** `sqrt((x−μ)ᵀ Σ⁻¹ (x−μ))` (accounts for correlations). Used for fraud, monitoring, data
quality, detecting out-of-distribution inputs.

**Tasks:** L3-18.

### B18. Recommender systems and matrix factorization
Approximate the sparse user×item rating matrix as `U Vᵀ` (low-rank). **ALS** alternates exact least-squares solves
for users and items. The learned vectors are **embeddings** — the same idea as word embeddings.

**Tasks:** L3-19.

---

## Part C — Evaluation metrics

### C1. Classification metrics
```
                 predicted 1   predicted 0
actual 1             TP            FN
actual 0             FP            TN
```
- **Accuracy** `(TP+TN)/N` — misleading on imbalanced data.
- **Precision** `TP/(TP+FP)`: of what we flagged, how much was right. **Recall** `TP/(TP+FN)`: of what exists, how
  much we found. **F1** = harmonic mean; **Fβ** weights recall β times as much as precision.

**Tasks:** L1-20.

### C2. Ranking and probabilistic metrics
- **ROC-AUC**: probability a random positive scores above a random negative (threshold-independent).
- **Average precision (PR-AUC)**: better than ROC-AUC when positives are rare.
- **Log loss** (cross-entropy) and **Brier score** judge the probabilities themselves.

**Tasks:** L3-11.

### C3. Calibration
A model is **calibrated** if, among predictions with confidence 0.8, about 80 % are correct. Modern neural networks
are often **over-confident**.
- **Reliability diagram / ECE** (expected calibration error) measure it with confidence bins.
- **Temperature scaling** divides logits by a single learned `T > 1` to soften probabilities without changing
  predictions. Also, the *sampling temperature* in LLM generation is the same knob (G2).

**Tasks:** L5-20.

### C4. Metrics for generated text
| Metric | Measures | Typical use |
|---|---|---|
| Exact match (EM) | normalized string equality | extractive QA |
| Token F1 | word overlap | QA (SQuAD) |
| BLEU | n-gram precision + brevity penalty | machine translation |
| ROUGE-L | longest common subsequence | summarization |
| Perplexity | how surprised a LM is (lower = better) | language modelling |

Overlap metrics miss paraphrases; modern LLM evaluation adds human ratings and **LLM-as-a-judge**, but these
classical metrics remain cheap, deterministic baselines.

**Tasks:** L5-14, L4-13 (perplexity).

---

## Part D — Deep learning

### D1. Neural networks
Layers of `linear transform → non-linear activation`. An **MLP** (multi-layer perceptron) with enough hidden units can
approximate very complex functions (e.g. separating intertwined spirals).

**Tasks:** L4-03, L4-06.

### D2. Backpropagation and automatic differentiation
The chain rule applied backwards through the computation graph. Each operation knows its local derivative; gradients
flow from the loss to every parameter. **Reverse-mode autodiff** (what PyTorch/JAX do) computes all gradients in one
backward pass. Nodes used several times **accumulate** gradients.

Matrix rules you will use constantly — for `Y = XW + b`:
`dX = dY Wᵀ`, `dW = Xᵀ dY`, `db = Σ_rows dY`.

**Tasks:** L4-01, L4-03, and every Level 4 backward pass.

### D3. Activation functions
| Activation | Formula | Notes |
|---|---|---|
| ReLU | `max(0, x)` | default for MLPs/CNNs |
| Leaky ReLU | `x` or `αx` | avoids "dead" units |
| Sigmoid / Tanh | squash to (0,1) / (−1,1) | gates, RNNs; saturate |
| GELU | `x·Φ(x)` (tanh approx.) | transformers (BERT, GPT) |
| SiLU / Swish | `x·σ(x)` | LLaMA-style feed-forward layers |
| Softplus | `log(1+eˣ)` | smooth ReLU, positive outputs |

**Tasks:** L4-02.

### D4. Weight initialization
Keep activation variance stable across layers so signals neither explode nor vanish.
**Xavier/Glorot** (tanh/linear): `Var = 2/(fan_in+fan_out)`; **He/Kaiming** (ReLU): `Var = 2/fan_in`.

**Tasks:** L4-10, L4-06.

### D5. Optimizers
| Optimizer | Idea |
|---|---|
| SGD + momentum | accumulate a velocity to smooth noisy gradients |
| Nesterov | look-ahead momentum |
| RMSProp | divide by running RMS of gradients (per-parameter step size) |
| Adam | momentum + RMSProp + bias correction — default for transformers |
| AdamW | Adam with **decoupled** weight decay — standard for LLM training |

**Tasks:** L4-04, L4-06.

### D6. Learning-rate schedules
**Warm-up** (small LR first, avoids early instability) followed by decay (**cosine**, linear, inverse-sqrt). Nearly all
transformer training uses warm-up + cosine or linear decay.

**Tasks:** L4-05.

### D7. Regularization in deep learning
- **Dropout**: randomly zero activations during training (scale by `1/(1−p)` — "inverted dropout"); identity at eval.
- **Weight decay** (D5), **early stopping** (D11), **label smoothing** (D10), data augmentation.

**Tasks:** L4-10, L4-18, L4-19.

### D8. Normalization layers
| Layer | Normalizes over | Used in |
|---|---|---|
| BatchNorm | the batch, per feature (running stats for eval) | CNNs |
| LayerNorm | the features of each token | transformers (GPT, BERT) |
| RMSNorm | features, no mean subtraction | LLaMA, Mistral and most modern LLMs |

Normalization stabilizes and speeds up training. BatchNorm behaves differently in train vs eval mode — a classic bug.

**Tasks:** L4-09, L4-16.

### D9. Convolutional and recurrent networks
- **Convolution** slides small learned filters over an image (weight sharing, translation equivariance);
  **pooling** downsamples. Efficient implementations reshape patches into a matrix (**im2col**) and use one matmul.
- **RNNs** process sequences step by step with a hidden state; trained with **backprop through time (BPTT)**; suffer
  vanishing/exploding gradients → **gradient clipping**, LSTMs/GRUs, and ultimately transformers.

**Tasks:** L4-07, L4-08, L4-17.

### D10. Loss functions for classification and language models
**Cross-entropy** over classes (or over the vocabulary for LMs).
- **Label smoothing**: target `(1−ε)·onehot + ε/C`; reduces over-confidence.
- **ignore_index**: skip padding tokens (or prompt tokens during instruction tuning) when averaging the loss.

**Tasks:** L4-18.

### D11. The training loop and callbacks
`for epoch: for batch: forward → loss → backward → optimizer step`, then evaluate. **Callbacks/hooks** add behaviour
without changing the loop: logging, **early stopping** (stop when validation stops improving, restore the best
weights), **checkpointing**.

**Tasks:** L4-19, L4-06.

---

## Part E — NLP and language models

### E1. Text representation: from words to numbers
| Representation | Idea | Limitation |
|---|---|---|
| One-hot / bag of words | count words | no meaning, huge sparse vectors |
| TF-IDF | down-weight common words: `tf · idf`, `idf = log(N/df)` (smoothed) | still no semantics |
| Word embeddings | dense vectors where similar words are close | one vector per word, no context |
| Contextual embeddings | transformer outputs | compute-heavy |

**Cosine similarity** `a·b / (‖a‖‖b‖)` compares vectors regardless of length.

**Tasks:** L2-13, L2-14, L3-08, L4-12.

### E2. Tokenization
LLMs read **tokens**, not characters or words.
- **BPE (byte-pair encoding)**: start from bytes; repeatedly merge the most frequent adjacent pair into a new token.
  Byte-level BPE (GPT-2 onward) can encode *any* text, including emoji and every language.
- Token count drives **cost, latency and context-window limits** of every LLM call.
- Vocabularies include **special tokens** (`<pad>`, `<unk>`, `<eos>`, chat role markers).

**Tasks:** L4-11, L4-20, L1-17.

### E3. Batching text: padding and attention masks
Sequences have different lengths; to batch them, **pad** to a common length and pass an **attention mask** (1 = real
token, 0 = pad) so the model ignores padding. Decoder LLMs usually **left-pad** for generation. **Length bucketing**
groups similar lengths to waste less compute on padding.

**Tasks:** L4-20.

### E4. Word embeddings (word2vec)
**Skip-gram**: predict context words from a center word. **Negative sampling** turns the expensive softmax over the
vocabulary into a few binary classifications (real pair vs random "noise" words drawn ∝ `count^0.75`). Words in
similar contexts get similar vectors ("you shall know a word by the company it keeps").

**Tasks:** L4-12.

### E5. Language models and perplexity
A language model assigns probabilities to sequences: `P(w₁..wₙ) = Π P(wᵢ | w₁..wᵢ₋₁)`.
- **n-gram LMs** condition on the previous `n−1` words; **smoothing** handles unseen n-grams.
- **Neural LMs / LLMs** condition on thousands of previous tokens using transformers.
- **Perplexity** = `exp(average negative log-likelihood)` — "how many choices the model is confused between".

**Tasks:** L4-13, L5-01.

### E6. Prompts and chat templates
Chat models are trained on conversations serialized with special role markers (system / user / assistant). The
inference code must reproduce **exactly** the template used in training; a **generation prompt** (`<|assistant|>`)
tells the model it is its turn. Prompt templates insert variables, retrieved documents and examples (few-shot).

**Tasks:** L2-20, L5-07.

### E7. Data quality: deduplication
Web-scale training corpora contain many near-duplicates, which waste compute, cause memorization and leak test data
into training. **Shingling** + **MinHash** estimates Jaccard similarity cheaply; **LSH banding** finds candidate pairs
without comparing every pair.

**Tasks:** L2-18.

---

## Part F — Transformers

### F1. Attention
Each token builds a **query**; every token offers a **key** and a **value**. Output = weighted average of values,
weights = softmax of query·key similarity:
```
Attention(Q, K, V) = softmax(Q Kᵀ / √d) · V
```
- `√d` scaling keeps softmax from saturating.
- **Masks**: *causal* (a token may not look at the future — required for generation) and *padding* masks.
- **Self-attention** (Q, K, V from the same sequence) vs **cross-attention** (Q from one, K/V from another, e.g.
  encoder–decoder translation).

**Tasks:** L4-14, L5-02.

### F2. Multi-head attention
Split the model dimension into `H` heads that attend independently (each can track different relationships), then
concatenate and project. Variants that share K/V across heads (**multi-query / grouped-query attention**) shrink the
KV cache in modern LLMs.

**Tasks:** L4-14, L5-01, L5-02.

### F3. Positional information
Attention alone ignores order, so position is injected:
| Method | Idea | Used in |
|---|---|---|
| Sinusoidal | fixed sin/cos waves added to embeddings | original Transformer |
| Learned absolute | a trained vector per position | GPT-2, BERT |
| **RoPE** (rotary) | rotate query/key pairs by an angle ∝ position, so `q·k` depends on relative distance | LLaMA, Mistral, most modern LLMs |
| ALiBi | add a distance-proportional penalty to attention scores | BLOOM, MPT |

**Tasks:** L4-15, L5-01.

### F4. The transformer block and GPT
```
x = token_embedding + position_embedding
repeat N times:
    x = x + Attention(LayerNorm(x))       # residual connection
    x = x + MLP(LayerNorm(x))             # MLP: expand 4×, GELU/SiLU, project back
logits = LayerNorm(x) @ Embeddingᵀ         # weight tying
```
**Decoder-only** models (GPT, LLaMA) predict the next token; **encoder-only** (BERT) produce representations for
classification/embeddings; **encoder-decoder** (T5) map input text to output text. Pre-LN (normalize before each
sub-layer) trains more stably. Parameter count ≈ `12·L·d²` plus embeddings.

**Tasks:** L5-01.

### F5. Mixture of Experts (MoE)
Replace the single MLP with `E` expert MLPs and a **router** that sends each token to its top-k experts. Total
parameters grow, but compute per token stays ~constant ("sparse" models such as Mixtral). Engineering issues:
**load balancing** (auxiliary loss), **expert capacity** (tokens beyond capacity are dropped), efficient
gather/scatter.

**Tasks:** L5-15.

---

## Part G — LLM inference and serving

### G1. Autoregressive generation
Generate one token at a time: run the model, pick a token, append, repeat until an end-of-sequence token or a length
limit. The **prefill** phase processes the whole prompt in parallel; the **decode** phase produces one token per step
and is memory-bandwidth bound.

**Tasks:** L5-01, L5-02, L5-03.

### G2. Decoding strategies
| Strategy | Behaviour |
|---|---|
| Greedy | always the most likely token — deterministic, can be repetitive |
| Temperature | divide logits by `T`: `T < 1` sharper/safer, `T > 1` more random, `T → 0` = greedy |
| Top-k | sample only among the k most likely tokens |
| Top-p (nucleus) | sample among the smallest set whose probability mass ≥ p |
| Beam search | keep the `B` best partial sequences; good for translation/ASR; length penalty avoids favouring short outputs |

**Tasks:** L5-03.

### G3. KV cache
In decoding, the keys and values of previous tokens never change — store them instead of recomputing, turning each
step from O(n²) into O(n) work. The cache dominates GPU memory for long contexts and many users. **Sliding-window
attention** bounds it by keeping only the last `W` tokens.

**Tasks:** L5-02.

### G4. Paged attention (vLLM)
Allocate the KV cache in fixed-size **blocks** like virtual-memory pages instead of one contiguous buffer per request.
Removes fragmentation, enables **sharing** blocks between sequences (common prompt prefixes, beam search, parallel
samples) with **reference counting** and **copy-on-write**. This is a key idea behind high-throughput servers.

**Tasks:** L5-18.

### G5. Batching and throughput
GPUs are efficient on large batches. **Dynamic batching** groups requests that arrive within a short window (trading
a little latency for much higher throughput). **Continuous batching** (in LLM servers) adds/removes sequences from the
running batch at every decode step.

**Tasks:** L5-12.

### G6. Speculative decoding
A small **draft** model proposes several tokens; the large **target** model verifies them all in a single forward
pass and accepts the longest correct prefix. Output is **identical** to the target model's (for greedy decoding;
a rejection-sampling variant preserves the distribution when sampling) — just faster.

**Tasks:** L5-17.

### G7. Quantization
Store weights (and sometimes activations) in fewer bits: `q = round(x / scale) (+ zero_point)`.
- **Symmetric** (zero point 0) vs **asymmetric/affine** (range not centered at 0).
- **Per-channel** scales are far more accurate than one scale per tensor.
- Integer matmul accumulates in **int32**, then rescales.
- INT8 halves memory vs FP16; INT4 (GPTQ/AWQ-style methods) lets large models run on consumer GPUs and laptops.

**Tasks:** L5-10.

### G8. Structured / constrained generation
Mask the logits of tokens that would break a required format, so the model can only produce valid output (one of a
set of labels, valid JSON, a grammar). A **trie** over allowed strings tells which tokens can continue the current
prefix. Used for reliable classification, function calling and JSON mode.

**Tasks:** L5-19.

### G9. Caching LLM responses
**Exact caches** key on the prompt string. **Semantic caches** embed the query and reuse an answer if a previous query
is similar enough (cosine ≥ threshold), saving cost and latency. Need eviction (**LRU**, **TTL**) and careful
thresholds to avoid wrong answers.

**Tasks:** L5-13, L2-01.

---

## Part H — Building LLM applications

### H1. What is RAG (Retrieval-Augmented Generation)?
LLMs only know what was in their training data (which has a cutoff date) and they can **hallucinate**. RAG
fixes this by **retrieving** relevant documents at question time and putting them in the prompt, so the model answers
*from provided evidence*.

```
                 ┌──────────── offline (indexing) ────────────┐
documents ──► clean ──► chunk ──► embed / index ──► vector + keyword index
                                                        │
question ──► (rewrite) ──► retrieve top-k ◄─────────────┘
                              │
                              ▼
                 rerank / fuse ──► pack into prompt (token budget) ──► LLM ──► answer + citations
                                                                                  │
                                                                     validate citations, guardrails
```

**Why companies use it.** Answers grounded in private/up-to-date data (internal docs, tickets, manuals, law, medicine)
without retraining the model; sources can be cited and checked; access control can be applied at retrieval time.

**RAG vs fine-tuning.** RAG adds *knowledge*; fine-tuning changes *behaviour/style/format*. They are often combined.

**Tasks:** L5-04, L5-05, L5-06, L5-07 (and L2-13, L2-14 as simple retrievers).

### H2. Chunking
Documents are split into chunks small enough to embed and to fit several into the prompt, but large enough to keep
meaning. Respect sentence/paragraph boundaries; use **overlap** so facts crossing a boundary are not lost; keep
**offsets/metadata** (source, page) for citations.

**Tasks:** L5-04.

### H3. Lexical retrieval: BM25
The classic search-engine ranking function: rewards query terms that are frequent in the document (with
**saturation** `k1`) and rare in the collection (**idf**), normalized for document length (`b`). Excellent for exact
terms: product codes, names, error messages.

**Tasks:** L5-05, L2-13, L2-14.

### H4. Dense retrieval and vector indexes
An **embedding model** maps text to vectors so that semantically similar texts are close (works for paraphrases and
across wording). Search = nearest neighbours.
- **Flat (exact)** search compares with every vector — accurate, O(N).
- **Approximate nearest neighbour (ANN)** indexes trade a little recall for big speed-ups: **IVF** (cluster with
  k-means, search only the `nprobe` closest clusters), HNSW graphs, product quantization. Libraries: FAISS; vector
  databases build on the same ideas.
- Measure quality with **recall@k** against exact search.

**Tasks:** L5-06, L3-05, L3-06.

### H5. Hybrid search and rank fusion
Combine lexical and dense results. **Reciprocal Rank Fusion**: `score(d) = Σ 1/(k + rank(d))` — simple, needs no
score calibration, robust. Often followed by a **reranker** model.

**Tasks:** L5-05.

### H6. Context packing, prompting and citations
Fit the best chunks into the model's **context window** under a token budget; number them; instruct the model to
answer only from context and cite `[n]`; then **validate** citations (do the cited numbers exist?) and fall back to
"I don't know" when nothing relevant is retrieved.

**Tasks:** L5-07, L2-20.

### H7. Agents and tool calling
An **agent** is an LLM in a loop that can call **tools** (search, calculator, database, APIs):
```
messages → LLM → (tool call?) ── yes ──► validate args against schema ──► run tool ──► append result ──┐
                     │                                                                                 │
                     └── final answer                         ◄──────────────────────── loop ◄─────────┘
```
Engineering essentials: tool **schemas** (names, argument types), robust **parsing** of model output, feeding
**errors back** so the model can recover, a **step limit**, never executing model-generated code with `eval`, logging
every step for debugging.

**Tasks:** L5-08, L2-11, L2-16.

### H8. Guardrails and privacy
Checks around the model: input filters (prompt-injection, PII), output validation (format, policy, citations).
**PII redaction** detects emails, phone numbers, card numbers (validated with the **Luhn** checksum), IDs and IP
addresses before logging or sending text to third parties.

**Tasks:** L5-09.

### H9. Observability for AI systems
Log structured events (latency, status, token counts, model version), compute percentiles (p50/p95 — averages hide tail
latency), track error rates per endpoint, profile training steps.

**Tasks:** L2-05, L2-03.

---

## Part I — Adapting and scaling models

### I1. Fine-tuning and parameter-efficient fine-tuning (PEFT)
**Fine-tuning** continues training a pre-trained model on task data. Updating all billions of weights is expensive, so
**PEFT** trains a tiny number of extra parameters.
**LoRA** freezes `W` and learns a low-rank update `ΔW = (α/r)·A·B` (`A: d×r`, `B: r×d`, `r` ≪ `d`). `B` starts at
zero so training starts from the original model. After training, the update can be **merged** into `W` (no inference
overhead) or kept separate to swap adapters per task/customer.

**Tasks:** L5-11.

### I2. Distributed training
- **Data parallelism**: every GPU holds a model copy, processes a different slice of the batch, then gradients are
  **averaged** with an **all-reduce** so all copies stay identical.
- **Ring all-reduce** (reduce-scatter + all-gather): each worker sends ≈ `2·(W−1)/W` × the data size regardless of
  worker count — bandwidth-optimal. Used by NCCL/Horovod/PyTorch DDP.
- Larger models also need tensor, pipeline and sharded (ZeRO/FSDP) parallelism.

**Tasks:** L5-16.

### I3. Efficient scaling ideas in this folder
| Idea | Saves | Task |
|---|---|---|
| Mixture of experts | compute per token | L5-15 |
| Quantization | memory, bandwidth | L5-10 |
| LoRA | trainable parameters, storage | L5-11 |
| KV cache / paged attention | recomputation, memory waste | L5-02, L5-18 |
| Speculative decoding | latency | L5-17 |
| Dynamic batching | GPU idle time | L5-12 |
| Semantic cache | repeated LLM calls | L5-13 |

---

## Glossary
| Term | Meaning |
|---|---|
| Logits | raw, unnormalized scores before softmax |
| Embedding | dense vector representing a token, word, document, user or item |
| Epoch / batch / step | full data pass / group of examples / one parameter update |
| Hyper-parameter | setting chosen by you, not learned (learning rate, k, depth) |
| Inference | using a trained model to make predictions |
| Context window | maximum number of tokens a model can attend to at once |
| Hallucination | fluent but unsupported or false model output |
| Grounding | tying answers to provided sources (RAG) |
| Prefill / decode | processing the prompt / generating tokens one by one |
| Throughput / latency | requests (tokens) per second / time per request |
| Recall@k | fraction of the true top-k neighbours (or relevant docs) found |
| Sparse vs dense | mostly-zero vectors (BoW) vs compact real-valued vectors (embeddings) |
| Fan-in / fan-out | number of inputs / outputs of a layer |
| Residual connection | `x + f(x)` — eases training of deep networks |
| Weight tying | sharing the input embedding matrix with the output projection |
| Zero-shot / few-shot | prompting without / with examples |
| Instruction tuning | fine-tuning on (instruction, response) pairs |
| Data leakage | test information influencing training |

---

## Concept → task map

| Concept | Level 1 | Level 2 | Level 3 | Level 4 | Level 5 |
|---|---|---|---|---|---|
| Generators & streaming | 10 | 10 | | 20 | |
| Decorators / context managers | | 02, 03, 16 | | | 12 |
| Data structures & algorithms | 03, 05, 13, 16 | 01, 04, 07, 08, 15, 19 | | | 18, 19 |
| Parsing & validation | 06, 09, 14 | 05, 06, 11, 17, 20 | | | 08 |
| Text processing / NLP features | 02, 17 | 13, 14, 18, 20 | 08 | 11, 12, 13, 20 | 04, 05 |
| Data splitting & preprocessing | 18, 19 | | 01, 12, 14, 17 | | |
| Classical models | | | 02–09, 16, 18, 19 | | |
| Metrics & evaluation | 12, 20 | | 11, 20 | 13 | 14, 20 |
| Optimization & training | | | 03, 04, 13, 15 | 04, 05, 06, 19 | |
| Neural network layers | | | | 01–03, 07–10, 16, 17 | |
| Attention & transformers | | | | 14, 15 | 01, 02, 15 |
| LLM decoding & serving | | 09 | | | 03, 10, 12, 13, 17, 18, 19 |
| RAG & retrieval | | 13, 14 | 05, 06 | | 04, 05, 06, 07 |
| Agents & guardrails | | 11, 16 | | | 08, 09 |
| Fine-tuning & distributed | | | | | 11, 16 |
