# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class ALSRecommender:
    """Explicit-feedback matrix factorization via ALS."""

    def __init__(self, n_factors=5, reg=0.1, n_iters=20, seed=0):
        raise NotImplementedError('TODO')

    def fit(self, R):
        """Alternate user/item least-squares updates."""
        raise NotImplementedError('TODO')

    def predict(self, u, i):
        """Predicted rating."""
        raise NotImplementedError('TODO')

    def predict_all(self):
        """Full predicted matrix."""
        raise NotImplementedError('TODO')

    def rmse(self, R):
        """RMSE over observed entries of R."""
        raise NotImplementedError('TODO')

    def recommend(self, u, n=5, exclude_seen=True):
        """Top-n item indices for user u."""
        raise NotImplementedError('TODO')
