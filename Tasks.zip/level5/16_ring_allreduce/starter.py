# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def ring_allreduce(arrays):
    """Simulated ring all-reduce (sum)."""
    raise NotImplementedError('TODO')

def data_parallel_gradient(grad_fn, params, X, y, n_workers):
    """Mean gradient computed by simulated data-parallel workers."""
    raise NotImplementedError('TODO')
