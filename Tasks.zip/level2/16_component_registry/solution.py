import difflib


class Registry:
    """Name -> object registry with config-driven building."""

    def __init__(self, name):
        self.name = name
        self._items = {}

    def register(self, name=None):
        """Decorator to register an object under a name."""
        if callable(name):
            obj = name
            self._add(obj.__name__, obj)
            return obj

        def decorator(obj):
            self._add(name or obj.__name__, obj)
            return obj

        return decorator

    def _add(self, name, obj):
        if name in self._items:
            raise KeyError(f"{name!r} already registered in {self.name}")
        self._items[name] = obj

    def get(self, name):
        """Look up a registered object."""
        if name not in self._items:
            close = difflib.get_close_matches(name, list(self._items), n=1)
            hint = f"; did you mean '{close[0]}'?" if close else ""
            raise KeyError(f"{name!r} not found in {self.name}{hint}")
        return self._items[name]

    def _resolve(self, value):
        if isinstance(value, dict) and "type" in value:
            return self.build(value)
        if isinstance(value, list):
            return [self._resolve(v) for v in value]
        return value

    def build(self, config):
        """Instantiate from a {'type': name, **kwargs} config."""
        if not isinstance(config, dict) or "type" not in config:
            raise ValueError("config must be a dict with a 'type' key")
        kwargs = {k: self._resolve(v) for k, v in config.items() if k != "type"}
        return self.get(config["type"])(**kwargs)

    def names(self):
        """Sorted registered names."""
        return sorted(self._items)

    def __contains__(self, name):
        return name in self._items

    def __len__(self):
        return len(self._items)
