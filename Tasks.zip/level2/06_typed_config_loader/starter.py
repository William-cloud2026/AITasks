# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import dataclasses
import types
import typing

class ConfigError(ValueError):
    """Raised for any config validation problem."""

def from_dict(cls, data):
    """Build dataclass `cls` from a dict, validating types."""
    raise NotImplementedError('TODO')
