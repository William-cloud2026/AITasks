def is_palindrome(s):
    """Alphanumeric-only, case-insensitive palindrome check."""
    chars = [c.lower() for c in s if c.isalnum()]
    return chars == chars[::-1]


def longest_palindrome(s):
    """Longest contiguous palindromic substring (leftmost on ties)."""
    best_lo, best_len = 0, 0
    n = len(s)
    for center in range(2 * n - 1):
        lo = center // 2
        hi = lo + center % 2
        while lo >= 0 and hi < n and s[lo] == s[hi]:
            lo -= 1
            hi += 1
        length = hi - lo - 1
        start = lo + 1
        if length > best_len or (length == best_len and start < best_lo):
            best_lo, best_len = start, length
    return s[best_lo:best_lo + best_len]
