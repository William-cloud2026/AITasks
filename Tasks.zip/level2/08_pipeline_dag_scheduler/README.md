# L2-08 · ML Pipeline DAG Scheduler

**Level:** 2 · **Topics:** topological sort, cycle detection, heaps · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
A pipeline is described by `deps: dict[str, list[str]]` mapping each step to the steps it depends on.
Steps that only appear as dependencies are valid steps with no dependencies.

### `topo_order(deps) -> list[str]`
Return an order where every step comes after all of its dependencies. When several steps are ready, pick the
**alphabetically smallest** first (the result is therefore unique).

### `stages(deps) -> list[list[str]]`
Group steps into parallel stages: stage 0 = steps with no deps; stage k = steps whose deps are all in stages
`< k` and at least one in stage `k-1`. Each stage sorted alphabetically.

### `find_cycle(deps) -> list[str] | None`
Return one cycle as a list of steps `[s0, s1, ..., sk]` where each `s(i)` depends on `s(i+1)` and `sk` depends
on `s0` (no repeated element), or `None` if acyclic.

### Errors
`topo_order` and `stages` raise `CycleError` (subclass of `ValueError`) if the graph has a cycle.
A step depending on itself is a cycle.
