# L2-11 · Safe Arithmetic Expression Evaluator

**Level:** 2 · **Topics:** tokenizing, recursive-descent parsing, precedence · **Time:** ~50 min · **Allowed:** Python stdlib (**no** `eval`, `exec`, `compile`, `ast`)

## Task
Implement `evaluate(expr, variables=None)` — useful e.g. as a safe "calculator tool" for an LLM agent.

Grammar (lowest → highest precedence), matching Python semantics:
```
expr   := term (('+' | '-') term)*
term   := unary (('*' | '/' | '//' | '%') unary)*
unary  := ('+' | '-') unary | power
power  := atom ('**' unary)?          # right-associative, so -2**2 == -4 and 2**-1 == 0.5
atom   := NUMBER | NAME | NAME '(' args ')' | '(' expr ')'
```
- `NUMBER`: integer (`42`) → `int`, or decimal (`3.14`, `.5`, `2.`, `1e-3`) → `float`.
- `NAME`: `[A-Za-z_][A-Za-z0-9_]*`, looked up in `variables` (a dict).
- Function calls: only `abs`, `min`, `max`, `round`, `sqrt` (`math.sqrt`) with comma-separated args.
- Whitespace is ignored. Results must equal Python's for the same expression.
- **Every** error (syntax error, unknown name/function, division by zero, trailing tokens, empty input)
  → `EvalError` (subclass of `Exception`).

## Example
```python
evaluate("2 * (3 + x) ** 2", {"x": 1})  # 32
evaluate("max(1, 2 * 3) // 4")          # 1
```
