# L2-12 · Immutable Vector Class

**Level:** 2 · **Topics:** operator overloading, dunder methods, immutability, hashing · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
Implement `class Vector` (an embedding-like immutable numeric vector).

| Feature | Behaviour |
|---|---|
| `Vector(iterable)` | at least 1 component, all `int`/`float` (not `bool`) else `ValueError`/`TypeError` |
| `len`, iteration, `v[i]`, `v[a:b]` | slicing returns a `Vector` |
| `v + w`, `v - w` | element-wise; dimension mismatch → `ValueError`; non-Vector → `TypeError` (return `NotImplemented`) |
| `v * k`, `k * v`, `v / k` | scalar ops; `/ 0` → `ZeroDivisionError` |
| `v @ w` | dot product |
| `abs(v)` | Euclidean norm |
| `-v` | negation |
| `v == w`, `hash(v)` | equal iff same components; equal vectors hash equally |
| `v.normalized()` | unit vector; zero vector → `ValueError` |
| `v.cosine(w)` | cosine similarity; zero vector → `ValueError` |
| `repr(v)` | `Vector([1, 2.5])` |
| immutability | item assignment raises `TypeError`; setting any attribute raises `AttributeError` |
