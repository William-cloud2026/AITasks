import math

import numpy as np

from starter import BM25, hybrid_search, reciprocal_rank_fusion

DOCS = [
    "the quick brown fox jumps over the lazy dog",
    "a quick brown dog outpaces a quick fox",
    "the lazy cat sleeps all day",
    "machine learning models need data",
    "deep learning is a subset of machine learning",
]


def test_idf_and_score():
    bm = BM25().fit(DOCS)
    assert bm.N == 5 and math.isclose(bm.avgdl, (9 + 8 + 6 + 5 + 8) / 5)
    assert math.isclose(bm.idf("quick"), math.log((5 - 2 + 0.5) / (2 + 0.5) + 1))
    tf, dl = 2, 8
    expected = bm.idf("quick") * tf * 2.5 / (tf + 1.5 * (1 - 0.75 + 0.75 * dl / bm.avgdl))
    assert math.isclose(bm.score("quick quick", 1), expected)
    assert bm.score("zebra", 0) == 0.0


def test_search_order():
    bm = BM25().fit(DOCS)
    res = bm.search("quick fox")
    assert [i for i, _ in res] == [1, 0]
    res = bm.search("machine learning")
    assert [i for i, _ in res] == [4, 3]
    assert bm.search("unknownword") == []
    assert len(bm.search("the", k=1)) == 1


def test_rrf():
    fused = reciprocal_rank_fusion([["a", "b", "c"], ["c", "b", "d"]], k=60)
    s = {d: v for d, v in fused}
    assert math.isclose(s["b"], 2 / 62) and math.isclose(s["a"], 1 / 61) and math.isclose(s["c"], 1 / 61 + 1 / 63)
    assert [d for d, _ in fused] == ["c", "b", "a", "d"]
    tie = reciprocal_rank_fusion([["x", "y"], ["y", "x"]])
    assert [d for d, _ in tie] == ["x", "y"]
    assert len(reciprocal_rank_fusion([["a", "b", "c"]], top_n=2)) == 2


def test_hybrid():
    bm = BM25().fit(DOCS)
    dense = np.array([0.1, 0.2, 0.9, 0.3, 0.05])
    res = hybrid_search(bm, dense, "lazy dog", k=3, rrf_k=1)
    lexical = [i for i, _ in bm.search("lazy dog", k=5)]
    assert lexical[0] == 0
    ids = [i for i, _ in res]
    assert len(ids) == 3 and ids[0] in (0, 2)
    assert set(ids) <= set(range(5))
    expected = reciprocal_rank_fusion([lexical, [2, 3, 1, 0, 4]], k=1, top_n=3)
    assert res == expected
