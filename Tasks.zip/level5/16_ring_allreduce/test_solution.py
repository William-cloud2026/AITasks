import numpy as np

from starter import data_parallel_gradient, ring_allreduce

rng = np.random.default_rng(0)


def test_sum_correct_various_sizes():
    for W in (2, 3, 4, 7):
        for shape in ((10,), (3, 5), (2,)):
            arrays = [rng.normal(size=shape) for _ in range(W)]
            copies = [a.copy() for a in arrays]
            results, schedule = ring_allreduce(arrays)
            total = np.sum(arrays, axis=0)
            for r in results:
                assert r.shape == shape
                np.testing.assert_allclose(r, total, atol=1e-12)
            assert len(schedule) == 2 * (W - 1)
            for a, c in zip(arrays, copies):
                np.testing.assert_array_equal(a, c)


def test_schedule_exact():
    _, schedule = ring_allreduce([np.ones(6) * i for i in range(3)])
    assert schedule == [
        [(0, 1, 0), (1, 2, 1), (2, 0, 2)],
        [(0, 1, 2), (1, 2, 0), (2, 0, 1)],
        [(0, 1, 1), (1, 2, 2), (2, 0, 0)],
        [(0, 1, 0), (1, 2, 1), (2, 0, 2)],
    ]


def test_single_worker_and_errors():
    res, sched = ring_allreduce([np.arange(4)])
    np.testing.assert_array_equal(res[0], np.arange(4))
    assert sched == []
    try:
        ring_allreduce([np.zeros(3), np.zeros(4)])
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_data_parallel_matches_full_batch():
    X = rng.normal(size=(103, 5))
    w_true = rng.normal(size=5)
    y = X @ w_true + rng.normal(size=103)
    params = rng.normal(size=5)

    def grad_sum(w, Xs, ys):
        return 2 * Xs.T @ (Xs @ w - ys)

    full = grad_sum(params, X, y) / len(X)
    for workers in (1, 2, 4, 8):
        np.testing.assert_allclose(data_parallel_gradient(grad_sum, params, X, y, workers), full, atol=1e-10)
