import numpy as np


def hinge_loss(X, y, w, b, lam):
    """Regularized mean hinge loss."""
    margins = y * (X @ w + b)
    return float(0.5 * lam * w @ w + np.mean(np.maximum(0.0, 1.0 - margins)))


class LinearSVM:
    """Linear SVM trained with Pegasos."""

    def __init__(self, lam=0.01, epochs=20, seed=0):
        self.lam, self.epochs, self.seed = lam, epochs, seed

    def fit(self, X, y):
        """Run Pegasos SGD."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        if len(self.classes_) != 2:
            raise ValueError("exactly two classes required")
        s = np.where(y == self.classes_[1], 1.0, -1.0)
        Z = np.column_stack([X, np.ones(len(X))])
        w, t = np.zeros(Z.shape[1]), 1
        rng = np.random.default_rng(self.seed)
        for _ in range(self.epochs):
            for i in rng.permutation(len(Z)):
                eta = 1.0 / (self.lam * t)
                if s[i] * (Z[i] @ w) < 1:
                    w = (1 - eta * self.lam) * w + eta * s[i] * Z[i]
                else:
                    w = (1 - eta * self.lam) * w
                t += 1
        self.coef_, self.intercept_ = w[:-1], float(w[-1])
        return self

    def decision_function(self, X):
        """Signed distance-like score."""
        return np.asarray(X, dtype=float) @ self.coef_ + self.intercept_

    def predict(self, X):
        """Predicted labels."""
        return np.where(self.decision_function(X) >= 0, self.classes_[1], self.classes_[0])
