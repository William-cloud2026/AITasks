# L3-07 · Gaussian Naive Bayes

**Level:** 3 · **Topics:** probabilistic models, log-space arithmetic, log-sum-exp · **Time:** ~35 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class GaussianNB(var_smoothing=1e-9)`.

- `fit(X, y)` → `self`. Sets:
  - `classes_` (sorted unique labels), `class_prior_` (empirical class frequencies),
  - `theta_` `(n_classes, n_features)`: per-class feature means,
  - `var_` `(n_classes, n_features)`: per-class population variances **plus** `epsilon_ = var_smoothing * max(np.var(X, axis=0))`.
- Joint log-likelihood for class `c`: `log prior_c + Σ_j [ -½·log(2π·var_cj) - (x_j - θ_cj)² / (2·var_cj) ]`.
- `predict_log_proba(X)`: joint log-likelihood normalized with a **stable log-sum-exp** (must not produce
  `-inf`/`nan` for points far from all classes).
- `predict_proba(X)`, `predict(X)`.
