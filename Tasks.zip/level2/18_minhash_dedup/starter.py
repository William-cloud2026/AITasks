# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import hashlib
import random
from collections import defaultdict
from itertools import combinations

def shingles(text, k=5):
    """Character k-gram shingles of normalized text."""
    raise NotImplementedError('TODO')

def jaccard(a, b):
    """Exact Jaccard similarity."""
    raise NotImplementedError('TODO')

class MinHasher:
    """MinHash signatures with universal hashing."""

    def __init__(self, num_perm=128, seed=0):
        raise NotImplementedError('TODO')

    def signature(self, shingle_set):
        """MinHash signature of a shingle set."""
        raise NotImplementedError('TODO')

def estimate_jaccard(sig1, sig2):
    """Fraction of equal signature positions."""
    raise NotImplementedError('TODO')

def find_near_duplicates(docs, threshold=0.8, num_perm=128, bands=32, k=5, seed=0):
    """LSH-based near-duplicate pairs."""
    raise NotImplementedError('TODO')
