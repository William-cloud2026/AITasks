from starter import validate

SCHEMA = {
    "id": {"type": "int", "min": 1},
    "text": {"type": "str", "min": 1, "max": 20},
    "label": {"type": "str", "choices": ["pos", "neg"]},
    "score": {"type": "float", "min": 0, "max": 1, "required": False},
    "lang": {"type": "str", "pattern": r"[a-z]{2}", "nullable": True, "required": False},
    "tags": {"type": "list", "max": 3, "items": {"type": "str", "min": 1}, "required": False},
    "meta": {"type": "dict", "required": False, "fields": {
        "source": {"type": "str"},
        "scores": {"type": "list", "items": {"type": "float"}, "required": False},
    }},
}


def paths(errors):
    for e in errors:
        assert ": " in e, e
    return [e.split(": ", 1)[0] for e in errors]


def test_valid():
    rec = {"id": 1, "text": "great movie", "label": "pos", "score": 1, "lang": None,
           "tags": ["a"], "meta": {"source": "imdb", "scores": [0.5, 1]}}
    assert validate(rec, SCHEMA) == []
    assert validate({"id": 2, "text": "x", "label": "neg"}, SCHEMA) == []


def test_multiple_errors_in_order():
    rec = {"id": 0, "text": "", "label": "meh", "score": 1.5, "lang": "EN", "extra": 1}
    assert paths(validate(rec, SCHEMA)) == ["id", "text", "label", "score", "lang", "extra"]


def test_missing_required():
    assert paths(validate({"text": "hi"}, SCHEMA)) == ["id", "label"]


def test_type_error_only_once():
    errs = validate({"id": "7", "text": "a", "label": "pos"}, SCHEMA)
    assert paths(errs) == ["id"] and len(errs) == 1
    assert paths(validate({"id": True, "text": "a", "label": "pos"}, SCHEMA)) == ["id"]
    assert paths(validate({"id": 1, "text": "a", "label": "pos", "score": False}, SCHEMA)) == ["score"]


def test_nested_paths():
    rec = {"id": 1, "text": "a", "label": "pos", "tags": ["ok", "", 3, "x"],
           "meta": {"scores": [1.0, "bad"], "who": "me"}}
    assert paths(validate(rec, SCHEMA)) == ["tags", "tags[1]", "tags[2]", "meta.source", "meta.scores[1]", "meta.who"]


def test_null_handling():
    assert paths(validate({"id": None, "text": "a", "label": "pos"}, SCHEMA)) == ["id"]
    assert validate({"id": 1, "text": "a", "label": "pos", "lang": None}, SCHEMA) == []
