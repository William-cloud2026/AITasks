from starter import BPETokenizer

CORPUS = ("the cat sat on the mat. the dog sat on the log. " * 20 +
          "tokenization with byte pair encoding merges frequent pairs. " * 10)


def test_classic_example():
    tok = BPETokenizer()
    tok.train("aaabdaaabac", 300)
    assert list(tok.merges.items()) == [((97, 97), 256), ((97, 98), 257), ((256, 257), 258)]
    assert tok.vocab[258] == b"aaab"
    assert tok.encode("aaab") == [258]
    assert tok.encode("aaabdaaabac") == [258, 100, 258, 97, 99]


def test_vocab_size_limit_and_stop():
    tok = BPETokenizer()
    tok.train(CORPUS, 270)
    assert len(tok.vocab) == 270 and len(tok.merges) == 14
    tok2 = BPETokenizer()
    tok2.train("abcdef", 1000)
    assert tok2.merges == {}


def test_compression_and_roundtrip():
    tok = BPETokenizer()
    tok.train(CORPUS, 400)
    text = "the cat sat on the log."
    ids = tok.encode(text)
    assert len(ids) < len(text.encode()) / 2
    assert tok.decode(ids) == text
    for s in ["", "héllo wörld", "日本語のテキスト", "emoji 🚀🔥 test\n\ttabs", "unseen zebra xylophone"]:
        assert tok.decode(tok.encode(s)) == s


def test_tie_break_smallest_pair():
    tok = BPETokenizer()
    tok.train("abab cdcd", 257)
    assert list(tok.merges) == [(97, 98)]


def test_encode_uses_merge_priority():
    tok = BPETokenizer()
    tok.merges = {(98, 99): 256, (97, 98): 257}
    tok.vocab.update({256: b"bc", 257: b"ab"})
    assert tok.encode("abc") == [97, 256]


def test_decode_invalid_bytes_replaced():
    tok = BPETokenizer()
    assert tok.decode([0xE6]) == "�"


def test_invalid_vocab_size():
    try:
        BPETokenizer().train("abc", 100)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
