from starter import identity, matmul, scale, shape, transpose


def _raises(fn):
    try:
        fn()
    except ValueError:
        return True
    return False


def test_shape():
    assert shape([[1, 2, 3], [4, 5, 6]]) == (2, 3)
    assert _raises(lambda: shape([]))
    assert _raises(lambda: shape([[]]))
    assert _raises(lambda: shape([[1, 2], [3]]))


def test_transpose():
    assert transpose([[1, 2, 3]]) == [[1], [2], [3]]
    assert transpose([[1, 2], [3, 4], [5, 6]]) == [[1, 3, 5], [2, 4, 6]]


def test_matmul():
    assert matmul([[1, 2], [3, 4]], [[5], [6]]) == [[17], [39]]
    a = [[1, 2, 3], [4, 5, 6]]
    assert matmul(a, identity(3)) == a
    assert matmul(identity(2), a) == a
    assert _raises(lambda: matmul([[1, 2]], [[1, 2]]))


def test_identity():
    assert identity(1) == [[1]]
    assert identity(3) == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    assert _raises(lambda: identity(0))


def test_scale_no_mutation():
    m = [[1, 2], [3, 4]]
    assert scale(m, 0.5) == [[0.5, 1.0], [1.5, 2.0]]
    t = transpose(m)
    t[0][0] = 99
    assert m == [[1, 2], [3, 4]]
