import numpy as np

from starter import check_gradient, jacobian, numerical_gradient, relative_error


def test_vector_gradient():
    x = np.array([1.0, -2.0, 0.5])
    g = numerical_gradient(lambda v: np.sum(v ** 3), x)
    np.testing.assert_allclose(g, 3 * x ** 2, rtol=1e-6)


def test_matrix_shape_and_no_mutation():
    W = np.arange(6, dtype=float).reshape(2, 3) / 10
    W0 = W.copy()
    A = np.array([[1.0, 2.0], [3.0, 4.0]])
    g = numerical_gradient(lambda M: np.sum((A @ M) ** 2), W)
    assert g.shape == (2, 3)
    np.testing.assert_allclose(g, 2 * A.T @ (A @ W), rtol=1e-6)
    np.testing.assert_array_equal(W, W0)


def test_integer_input():
    g = numerical_gradient(lambda v: float(v @ v), np.array([1, 2]))
    np.testing.assert_allclose(g, [2.0, 4.0], rtol=1e-6)


def test_relative_error():
    assert relative_error([1.0, 2.0], [1.0, 2.0]) == 0.0
    assert np.isclose(relative_error([1.0], [3.0]), 0.5)
    assert relative_error([0.0], [0.0]) == 0.0


def test_check_gradient():
    f = lambda v: np.sum(np.sin(v) * v)
    good = lambda v: np.cos(v) * v + np.sin(v)
    bad = lambda v: np.cos(v) * v
    x = np.linspace(-2, 2, 7)
    ok, err = check_gradient(f, good, x)
    assert ok and err < 1e-7
    ok, err = check_gradient(f, bad, x)
    assert not ok and err > 1e-2


def test_jacobian():
    A = np.array([[1.0, 2.0, 3.0], [0.0, -1.0, 4.0]])
    np.testing.assert_allclose(jacobian(lambda v: A @ v, np.ones(3)), A, atol=1e-8)
    J = jacobian(lambda v: np.array([v[0] * v[1], np.exp(v[1])]), np.array([2.0, 0.0]))
    np.testing.assert_allclose(J, [[0.0, 2.0], [0.0, 1.0]], atol=1e-6)
