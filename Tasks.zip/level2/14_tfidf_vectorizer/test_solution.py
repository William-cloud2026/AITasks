import math

from starter import TfidfVectorizer

DOCS = ["the cat sat", "the dog sat", "the cat and the dog"]


def close_rows(a, b):
    return all(math.isclose(x, y, abs_tol=1e-9) for ra, rb in zip(a, b) for x, y in zip(ra, rb))


def test_vocab_and_idf():
    v = TfidfVectorizer().fit(DOCS)
    assert v.get_feature_names_out() == ["and", "cat", "dog", "sat", "the"]
    assert v.vocabulary_ == {"and": 0, "cat": 1, "dog": 2, "sat": 3, "the": 4}
    assert math.isclose(v.idf_[4], 1.0)
    assert math.isclose(v.idf_[0], math.log(4 / 2) + 1)
    assert math.isclose(v.idf_[1], math.log(4 / 3) + 1)


def test_transform_values():
    v = TfidfVectorizer()
    x = v.fit_transform(DOCS)
    i_cat = math.log(4 / 3) + 1
    raw = [0, i_cat, 0, i_cat, 1.0]
    n = math.sqrt(sum(r * r for r in raw))
    assert close_rows([x[0]], [[r / n for r in raw]])
    for row in x:
        assert math.isclose(sum(r * r for r in row), 1.0)


def test_raw_counts_and_sublinear():
    i_and = math.log(2) + 1
    i_cat = i_dog = math.log(4 / 3) + 1
    for sub, tf_the in ((False, 2.0), (True, 1 + math.log(2))):
        row = TfidfVectorizer(sublinear_tf=sub).fit(DOCS).transform(["the cat and the dog"])[0]
        raw = [i_and, i_cat, i_dog, 0.0, tf_the]
        n = math.sqrt(sum(r * r for r in raw))
        assert close_rows([row], [[r / n for r in raw]])


def test_unknown_terms_and_zero_rows():
    v = TfidfVectorizer().fit(DOCS)
    assert v.transform(["zebra unicorn"]) == [[0.0] * 5]


def test_min_df_and_max_features():
    v = TfidfVectorizer(min_df=2).fit(DOCS)
    assert v.get_feature_names_out() == ["cat", "dog", "sat", "the"]
    v = TfidfVectorizer(max_features=2).fit(DOCS)
    assert v.get_feature_names_out() == ["cat", "the"]


def test_not_fitted():
    try:
        TfidfVectorizer().transform(["x"])
    except NotImplementedError:
        raise AssertionError("not implemented")
    except RuntimeError:
        return
    raise AssertionError("expected RuntimeError")
