def flatten(nested, depth=None):
    """Flatten lists/tuples up to `depth` levels (None = fully)."""
    if not isinstance(nested, (list, tuple)):
        raise TypeError("nested must be a list or tuple")
    if depth is not None and depth < 0:
        raise ValueError("depth must be >= 0")
    out = []
    stack = [(iter(nested), 0)]
    while stack:
        it, level = stack[-1]
        for item in it:
            if isinstance(item, (list, tuple)) and (depth is None or level < depth):
                stack.append((iter(item), level + 1))
                break
            out.append(item)
        else:
            stack.pop()
    return out
