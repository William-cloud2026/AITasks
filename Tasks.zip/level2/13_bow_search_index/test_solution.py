import math
import random
import time

from starter import BowIndex


def build():
    idx = BowIndex()
    idx.add("d1", "The cat sat on the mat")
    idx.add("d2", "Dogs and cats are pets")
    idx.add("d3", "The dog chased the cat")
    idx.add("d4", "Quantum computing")
    return idx


def test_scores():
    idx = build()
    res = idx.search("the cat")
    ids = [d for d, _ in res]
    assert ids == ["d3", "d1"]
    # d1 counts: the2 cat1 sat1 on1 mat1 -> norm sqrt(8); query the1 cat1 -> norm sqrt(2); dot 3
    assert math.isclose(res[1][1], 3 / math.sqrt(16))
    # d3 counts: the2 dog1 chased1 cat1 -> norm sqrt(7)
    assert math.isclose(res[0][1], 3 / math.sqrt(14))
    assert all(0 < s <= 1 + 1e-12 for _, s in res)


def test_tie_break_and_k():
    idx = BowIndex()
    idx.add("b", "apple")
    idx.add("a", "apple")
    idx.add("c", "apple pie")
    assert [d for d, _ in idx.search("apple", k=2)] == ["a", "b"]
    assert idx.search("APPLE!!")[0][1] == 1.0


def test_empty_and_unknown():
    idx = build()
    assert idx.search("") == []
    assert idx.search("zebra") == []


def test_remove_and_errors():
    idx = build()
    idx.remove("d1")
    assert [d for d, _ in idx.search("mat")] == []
    assert len(idx) == 3
    for fn, exc in ((lambda: idx.remove("d1"), KeyError), (lambda: idx.add("d2", "x"), ValueError)):
        try:
            fn()
        except exc:
            continue
        raise AssertionError(f"expected {exc.__name__}")


def test_performance():
    rng = random.Random(0)
    vocab = [f"w{i}" for i in range(3000)]
    idx = BowIndex()
    for i in range(5000):
        idx.add(i, " ".join(rng.choices(vocab, k=30)))
    t0 = time.perf_counter()
    for _ in range(300):
        res = idx.search(" ".join(rng.choices(vocab, k=3)), k=10)
        assert len(res) <= 10
    assert time.perf_counter() - t0 < 3.0
