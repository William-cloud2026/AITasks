# L5-10 · Post-Training Quantization (INT8 / INT4)

**Level:** 5 · **Topics:** model compression, fixed-point arithmetic, per-channel scaling · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Rounding is `np.round` (round half to even) everywhere.

### `quantize_symmetric(x, bits=8, axis=None) -> (q, scale)`
- `qmax = 2^(bits−1) − 1`. `scale = max|x| / qmax` computed over the whole tensor (`axis=None`, scalar float) or
  **per channel** along `axis` (max over all *other* axes, kept with `keepdims=True` so it broadcasts against `x`).
- A zero max gives `scale = 1.0`. `q = clip(round(x / scale), −qmax, qmax)` as `int8`. `bits` must be in `2..8`
  (else `ValueError`).

### `quantize_asymmetric(x, bits=8) -> (q, scale, zero_point)`
- `qmax = 2^bits − 1`; `lo = min(x.min(), 0)`, `hi = max(x.max(), 0)` (range always contains 0);
  `scale = (hi − lo) / qmax` (or `1.0` if `hi == lo`); `zero_point = int(clip(round(−lo / scale), 0, qmax))`;
  `q = clip(round(x / scale) + zero_point, 0, qmax)` as `uint8`.

### `dequantize(q, scale, zero_point=0) -> float array` = `(q − zero_point) · scale` (compute in float).

### `quantized_matmul(xq, x_scale, wq, w_scale) -> float array`
`xq (n, k)` and `wq (k, m)` are `int8`; accumulate in **int32** (`xq.astype(int32) @ wq.astype(int32)`) then
multiply by `x_scale * w_scale` (`w_scale` may be a scalar or per-output-channel `(1, m)`).

### `quantize_linear_layer(W, bits=8) -> (q, scale)`
Per-output-channel symmetric quantization of a weight matrix `W (in, out)` (i.e. `axis=1`).
