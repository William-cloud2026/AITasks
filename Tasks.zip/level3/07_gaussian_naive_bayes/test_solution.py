import numpy as np

from starter import GaussianNB

rng = np.random.default_rng(7)
X = np.vstack([rng.normal([0, 0], [1, 2], size=(60, 2)), rng.normal([4, 1], [0.5, 1], size=(40, 2))])
y = np.array([0] * 60 + [1] * 40)


def test_parameters():
    m = GaussianNB().fit(X, y)
    np.testing.assert_allclose(m.class_prior_, [0.6, 0.4])
    np.testing.assert_allclose(m.theta_[1], X[60:].mean(0))
    eps = 1e-9 * X.var(0).max()
    np.testing.assert_allclose(m.var_[0], X[:60].var(0) + eps)


def test_posterior_matches_formula():
    m = GaussianNB().fit(X, y)
    x = np.array([2.0, 0.5])
    logs = []
    for c in range(2):
        mu, var = m.theta_[c], m.var_[c]
        logs.append(np.log(m.class_prior_[c]) + np.sum(-0.5 * np.log(2 * np.pi * var) - (x - mu) ** 2 / (2 * var)))
    logs = np.array(logs)
    expected = np.exp(logs - logs.max()) / np.exp(logs - logs.max()).sum()
    np.testing.assert_allclose(m.predict_proba([x])[0], expected, rtol=1e-10)


def test_accuracy_and_shapes():
    m = GaussianNB().fit(X, y)
    assert np.mean(m.predict(X) == y) > 0.95
    P = m.predict_proba(X)
    assert P.shape == (100, 2)
    np.testing.assert_allclose(P.sum(1), 1.0)


def test_far_points_stable():
    m = GaussianNB().fit(X, y)
    lp = m.predict_log_proba([[1e4, -1e4], [-500.0, 300.0]])
    assert np.all(np.isfinite(lp))
    np.testing.assert_allclose(np.exp(lp).sum(1), 1.0)


def test_string_labels():
    labels = np.where(y == 0, "cat", "dog")
    m = GaussianNB().fit(X, labels)
    assert list(m.classes_) == ["cat", "dog"]
    assert m.predict([[4.0, 1.0]])[0] == "dog"
