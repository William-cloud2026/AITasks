# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re
from itertools import groupby

def rle_encode(s):
    """Encode runs as <count><char>."""
    raise NotImplementedError('TODO')

def rle_decode(s):
    """Decode <count><char> pairs."""
    raise NotImplementedError('TODO')
