import asyncio
import time

from starter import DynamicBatcher


def double(xs):
    return [x * 2 for x in xs]


def test_batches_concurrent_requests():
    async def main():
        b = DynamicBatcher(double, max_batch_size=8, max_wait_ms=20)
        await b.start()
        res = await asyncio.gather(*(b.submit(i) for i in range(20)))
        await b.stop()
        return res, b.batch_sizes

    res, sizes = asyncio.run(main())
    assert res == [2 * i for i in range(20)]
    assert sizes == [8, 8, 4]


def test_max_wait_single_request():
    async def main():
        async with DynamicBatcher(double, max_batch_size=4, max_wait_ms=50) as b:
            t0 = time.perf_counter()
            r = await b.submit(21)
            return r, time.perf_counter() - t0, b.batch_sizes

    r, dt, sizes = asyncio.run(main())
    assert r == 42 and sizes == [1]
    assert 0.03 <= dt < 1.0


def test_staggered_arrivals():
    async def main():
        b = DynamicBatcher(double, max_batch_size=16, max_wait_ms=30)
        await b.start()
        first = [asyncio.create_task(b.submit(i)) for i in range(3)]
        await asyncio.sleep(0.15)
        second = [asyncio.create_task(b.submit(i)) for i in range(10, 12)]
        res = await asyncio.gather(*first, *second)
        await b.stop()
        return res, b.batch_sizes

    res, sizes = asyncio.run(main())
    assert res == [0, 2, 4, 20, 22] and sizes == [3, 2]


def test_async_model_and_errors():
    calls = []

    async def model(xs):
        calls.append(list(xs))
        await asyncio.sleep(0.01)
        if any(x < 0 for x in xs):
            raise KeyError("negative input")
        if any(x == 99 for x in xs):
            return [0]
        return [x + 1 for x in xs]

    async def main():
        out = {}
        async with DynamicBatcher(model, max_batch_size=2, max_wait_ms=5) as b:
            r = await asyncio.gather(b.submit(-1), b.submit(5), return_exceptions=True)
            out["err"] = r
            r = await asyncio.gather(b.submit(99), b.submit(1), return_exceptions=True)
            out["mismatch"] = r
            out["ok"] = await b.submit(41)
        return out

    out = asyncio.run(main())
    assert all(isinstance(e, KeyError) for e in out["err"])
    assert all(isinstance(e, ValueError) for e in out["mismatch"])
    assert out["ok"] == 42


def test_submit_requires_start_and_drain_on_stop():
    async def main():
        b = DynamicBatcher(double, max_batch_size=4, max_wait_ms=1000)
        try:
            await b.submit(1)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except RuntimeError:
            pass
        else:
            raise AssertionError("expected RuntimeError")
        await b.start()
        tasks = [asyncio.create_task(b.submit(i)) for i in range(3)]
        await asyncio.sleep(0)
        t0 = time.perf_counter()
        await b.stop()
        res = await asyncio.gather(*tasks)
        return res, time.perf_counter() - t0

    res, dt = asyncio.run(main())
    assert res == [0, 2, 4]
    assert dt < 0.5
