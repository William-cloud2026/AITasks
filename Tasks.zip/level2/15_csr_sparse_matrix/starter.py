# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

class CSRMatrix:
    """Compressed sparse row matrix."""

    def __init__(self, data, indices, indptr, shape):
        raise NotImplementedError('TODO')

    @classmethod
    def from_dense(cls, rows):
        """Build from a list of lists."""
        raise NotImplementedError('TODO')

    @classmethod
    def from_coo(cls, row_idx, col_idx, values, shape):
        """Build from coordinate triples, summing duplicates."""
        raise NotImplementedError('TODO')

    @property
    def nnz(self):
        """Number of stored values."""
        raise NotImplementedError('TODO')

    def to_dense(self):
        """Dense list of lists."""
        raise NotImplementedError('TODO')

    def get(self, i, j):
        """Element (i, j)."""
        raise NotImplementedError('TODO')

    def matvec(self, x):
        """Matrix-vector product."""
        raise NotImplementedError('TODO')

    def __matmul__(self, x):
        raise NotImplementedError('TODO')

    def transpose(self):
        """Transposed CSR matrix."""
        raise NotImplementedError('TODO')
