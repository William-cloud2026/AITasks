# L4-12 · Word2Vec: Skip-Gram with Negative Sampling

**Level:** 4 · **Topics:** embeddings, sampling, SGD, numerically stable losses · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
### `skipgram_pairs(ids, window) -> list[tuple[int, int]]`
For each position `i` (ascending) and each `j` in `[i − window, i + window]` ∩ valid indices, `j != i`
(ascending), emit `(ids[i], ids[j])`.

### `noise_distribution(counts, power=0.75) -> np.ndarray`
`p_w ∝ counts_w ** power`, normalized to sum 1.

### `sgns_loss_and_grads(v_c, u_o, U_neg) -> (loss, d_vc, d_uo, d_Uneg)`
`v_c`: center vector `(d,)`, `u_o`: context vector `(d,)`, `U_neg`: `(k, d)` negative context vectors.
`loss = −log σ(u_o·v_c) − Σ_k log σ(−u_k·v_c)`, computed stably (`np.logaddexp`). Return exact gradients.

### `class SkipGramNS(vocab_size, dim=16, seed=0)`
- `rng = np.random.default_rng(seed)`; `W_in = rng.uniform(-0.5/dim, 0.5/dim, (vocab_size, dim))`, `W_out = zeros`.
- `train(pairs, noise_probs, epochs=5, lr=0.05, k=5)`: for each epoch, iterate pairs in a random order
  (`rng.permutation`); draw `k` negatives with `rng.choice(vocab_size, size=k, p=noise_probs)`; SGD step on
  `W_in[c]`, `W_out[o]` and `W_out[negatives]` (accumulate if a negative repeats). Returns list of mean loss per epoch.
- `most_similar(word_id, topn=5)` → list of `(id, cosine)` using `W_in`, excluding the word itself, sorted by
  similarity descending.
