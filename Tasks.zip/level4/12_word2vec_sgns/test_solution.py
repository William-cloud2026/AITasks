import numpy as np

from starter import SkipGramNS, noise_distribution, sgns_loss_and_grads, skipgram_pairs


def test_pairs():
    assert skipgram_pairs([10, 11, 12, 13], 1) == [(10, 11), (11, 10), (11, 12), (12, 11), (12, 13), (13, 12)]
    assert skipgram_pairs([1, 2, 3], 2) == [(1, 2), (1, 3), (2, 1), (2, 3), (3, 1), (3, 2)]
    assert skipgram_pairs([5], 3) == []


def test_noise_distribution():
    p = noise_distribution([16, 1, 0])
    np.testing.assert_allclose(p, [8 / 9, 1 / 9, 0])


def test_loss_and_grads():
    rng = np.random.default_rng(0)
    v, u, U = rng.normal(size=4), rng.normal(size=4), rng.normal(size=(3, 4))
    loss, dv, du, dU = sgns_loss_and_grads(v, u, U)
    sig = lambda x: 1 / (1 + np.exp(-x))
    assert np.isclose(loss, -np.log(sig(u @ v)) - np.sum(np.log(sig(-U @ v))))
    eps = 1e-6
    for arr, grad, which in ((v, dv, 0), (u, du, 1), (U, dU, 2)):
        num = np.zeros_like(arr)
        for idx in np.ndindex(arr.shape):
            p, m = arr.copy(), arr.copy()
            p[idx] += eps
            m[idx] -= eps
            args_p, args_m = [v, u, U], [v, u, U]
            args_p[which], args_m[which] = p, m
            num[idx] = (sgns_loss_and_grads(*args_p)[0] - sgns_loss_and_grads(*args_m)[0]) / (2 * eps)
        np.testing.assert_allclose(grad, num, rtol=1e-5, atol=1e-8)


def test_stable_extremes():
    v = np.array([100.0])
    loss, dv, du, dU = sgns_loss_and_grads(v, np.array([-100.0]), np.array([[100.0]]))
    assert np.isfinite(loss) and np.isclose(loss, 20000.0)
    assert np.all(np.isfinite(dv))


def test_learns_topics():
    rng = np.random.default_rng(0)
    group_a, group_b = list(range(0, 6)), list(range(6, 12))
    corpus = []
    for _ in range(300):
        g = group_a if rng.random() < 0.5 else group_b
        corpus += list(rng.choice(g, size=8))
    pairs = skipgram_pairs(corpus, 2)
    counts = np.bincount(corpus, minlength=12)
    model = SkipGramNS(12, dim=8, seed=1)
    hist = model.train(pairs, noise_distribution(counts), epochs=3, lr=0.05, k=5)
    assert len(hist) == 3 and hist[-1] < hist[0]
    sims = model.most_similar(0, topn=4)
    assert len(sims) == 4 and all(i in group_a for i, _ in sims)
    assert all(sims[i][1] >= sims[i + 1][1] for i in range(3))
    assert all(i != 0 for i, _ in model.most_similar(0, topn=11))
