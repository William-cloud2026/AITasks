import numpy as np


def mse_loss_and_grad(X, y, w, b, l2=0.0):
    """Half-MSE loss with L2 and its gradients."""
    n = len(y)
    r = X @ w + b - y
    loss = float(r @ r / (2 * n) + 0.5 * l2 * w @ w)
    grad_w = X.T @ r / n + l2 * w
    grad_b = float(r.sum() / n)
    return loss, grad_w, grad_b


class LinearRegressionGD:
    """Linear regression trained with gradient descent."""

    def __init__(self, lr=0.01, epochs=1000, l2=0.0, batch_size=None, seed=0, tol=None):
        self.lr, self.epochs, self.l2 = lr, epochs, l2
        self.batch_size, self.seed, self.tol = batch_size, seed, tol

    def fit(self, X, y):
        """Run gradient descent."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        n, d = X.shape
        w, b = np.zeros(d), 0.0
        rng = np.random.default_rng(self.seed)
        self.loss_history_ = []
        self.n_epochs_ = 0
        for _ in range(self.epochs):
            if self.batch_size is None:
                _, gw, gb = mse_loss_and_grad(X, y, w, b, self.l2)
                w, b = w - self.lr * gw, b - self.lr * gb
            else:
                perm = rng.permutation(n)
                for i in range(0, n, self.batch_size):
                    idx = perm[i:i + self.batch_size]
                    _, gw, gb = mse_loss_and_grad(X[idx], y[idx], w, b, self.l2)
                    w, b = w - self.lr * gw, b - self.lr * gb
            loss = mse_loss_and_grad(X, y, w, b, self.l2)[0]
            self.loss_history_.append(loss)
            self.n_epochs_ += 1
            if self.tol is not None and len(self.loss_history_) >= 2 and \
                    self.loss_history_[-2] - loss < self.tol:
                break
        self.coef_, self.intercept_ = w, b
        return self

    def predict(self, X):
        """Predict targets."""
        return np.asarray(X, dtype=float) @ self.coef_ + self.intercept_
