# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

from itertools import combinations, combinations_with_replacement
import numpy as np

class PolynomialFeatures:
    """Polynomial and interaction features."""

    def __init__(self, degree=2, include_bias=True, interaction_only=False):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Compute output powers."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Expand features."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')

    def get_feature_names_out(self, input_features=None):
        """Human-readable output names."""
        raise NotImplementedError('TODO')
