# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class LayerNorm:
    """Layer normalization over the last dimension."""

    def __init__(self, d, eps=1e-05):
        raise NotImplementedError('TODO')

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, dout):
        raise NotImplementedError('TODO')

class RMSNorm:
    """Root-mean-square normalization over the last dimension."""

    def __init__(self, d, eps=1e-06):
        raise NotImplementedError('TODO')

    def forward(self, x):
        raise NotImplementedError('TODO')

    def backward(self, dout):
        raise NotImplementedError('TODO')
