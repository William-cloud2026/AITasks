# L5-13 · Semantic Cache for LLM Responses

**Level:** 5 · **Topics:** embeddings, similarity search, LRU + TTL eviction, cost optimization · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class SemanticCache(embed_fn, threshold=0.9, max_entries=100, ttl=None, clock=time.monotonic)`.
`embed_fn(text) -> 1-D array`. Similarity is **cosine** (a zero vector has similarity 0 with everything).

- `put(query, response)`: store (embedding computed once). If an entry with the **identical query string** exists,
  replace its response and refresh its timestamp and recency. If the cache exceeds `max_entries`, evict the
  **least recently used** entry.
- `get(query)`: first drop expired entries (`clock() − stored_at >= ttl` when `ttl` is set). Compute the query
  embedding once; find the entry with the highest similarity (ties → most recently used). If it is `>= threshold`,
  it is a **hit**: mark it most-recently used, increment `hits`, return its response. Otherwise increment `misses`
  and return `None`.
- `len(cache)` → number of non-expired entries. `hits`, `misses` counters.
- `embed_fn` must be called exactly once per `get`/`put` call.
