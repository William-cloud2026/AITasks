import numpy as np

from starter import ALSRecommender


def make_data(seed=0):
    rng = np.random.default_rng(seed)
    U = rng.normal(size=(40, 3))
    V = rng.normal(size=(30, 3))
    full = U @ V.T
    mask = rng.random(full.shape) < 0.5
    train = np.where(mask, full, np.nan)
    test = np.where(~mask, full, np.nan)
    return full, train, test


def test_fit_quality():
    full, train, test = make_data()
    m = ALSRecommender(n_factors=3, reg=0.01, n_iters=30).fit(train)
    assert m.rmse(train) < 0.05
    assert m.rmse(test) < 0.3
    assert m.user_factors_.shape == (40, 3) and m.item_factors_.shape == (30, 3)


def test_loss_monotone():
    _, train, _ = make_data(1)
    m = ALSRecommender(n_factors=3, reg=0.1, n_iters=15).fit(train)
    h = np.array(m.loss_history_)
    assert len(h) == 15 and np.all(np.diff(h) <= 1e-8 * h[:-1])


def test_first_iteration_exact():
    _, train, _ = make_data(2)
    m = ALSRecommender(n_factors=2, reg=0.5, n_iters=1, seed=9).fit(train)
    rng = np.random.default_rng(9)
    U0 = rng.normal(scale=0.1, size=(40, 2))
    V = rng.normal(scale=0.1, size=(30, 2))
    mask = ~np.isnan(train)
    U = np.zeros((40, 2))
    for r in range(40):
        Vo = V[mask[r]]
        U[r] = np.linalg.solve(Vo.T @ Vo + 0.5 * np.eye(2), Vo.T @ train[r, mask[r]])
    Vn = np.zeros((30, 2))
    for c in range(30):
        Uo = U[mask[:, c]]
        Vn[c] = np.linalg.solve(Uo.T @ Uo + 0.5 * np.eye(2), Uo.T @ train[mask[:, c], c])
    np.testing.assert_allclose(m.user_factors_, U, atol=1e-10)
    np.testing.assert_allclose(m.item_factors_, Vn, atol=1e-10)


def test_predict_and_recommend():
    full, train, _ = make_data(3)
    m = ALSRecommender(n_factors=3, reg=0.01, n_iters=20).fit(train)
    assert np.isclose(m.predict(2, 5), m.predict_all()[2, 5])
    recs = m.recommend(0, n=5)
    seen = set(np.flatnonzero(~np.isnan(train[0])))
    assert len(recs) == 5 and not set(recs) & seen
    scores = m.predict_all()[0]
    assert all(scores[recs[i]] >= scores[recs[i + 1]] for i in range(4))
    all_recs = m.recommend(0, n=30, exclude_seen=False)
    assert len(all_recs) == 30


def test_user_without_ratings():
    _, train, _ = make_data(4)
    train[5, :] = np.nan
    m = ALSRecommender(n_factors=3, n_iters=5).fit(train)
    np.testing.assert_array_equal(m.user_factors_[5], 0)
