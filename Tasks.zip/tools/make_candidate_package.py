"""Create a candidate copy of the task suite WITHOUT the solutions.

Copies everything except every task's solution.py and the tools/ folder.

Usage: python tools/make_candidate_package.py <output_dir> [levelX ...]
Example: python tools/make_candidate_package.py D:\\candidate_tasks level3 level4
"""
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
EXCLUDE_DIRS = {"tools", "__pycache__", ".pytest_cache"}


def main(out_dir, levels):
    out = pathlib.Path(out_dir).resolve()
    if out == ROOT or ROOT in out.parents:
        sys.exit("output directory must be outside the task folder")
    if out.exists() and any(out.iterdir()):
        sys.exit(f"{out} exists and is not empty")
    copied = 0
    for src in ROOT.rglob("*"):
        rel = src.relative_to(ROOT)
        if not src.is_file() or EXCLUDE_DIRS & set(rel.parts):
            continue
        if rel.parts[0].startswith("level"):
            if levels and rel.parts[0] not in levels:
                continue
            if src.name == "solution.py":
                continue
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied += 1
    leaked = list(out.glob("level*/*/solution.py"))
    assert not leaked, leaked
    print(f"copied {copied} files to {out} (no solution.py files included)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], set(sys.argv[2:]))
