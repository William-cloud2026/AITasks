# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def sinusoidal_encoding(T, d):
    """Transformer sinusoidal positional encodings."""
    raise NotImplementedError('TODO')

def apply_rope(x, positions=None, base=10000.0):
    """Rotary position embedding (half-split convention)."""
    raise NotImplementedError('TODO')

def alibi_slopes(n_heads):
    """Per-head ALiBi slopes."""
    raise NotImplementedError('TODO')

def alibi_bias(n_heads, T):
    """ALiBi bias tensor (n_heads, T, T)."""
    raise NotImplementedError('TODO')
