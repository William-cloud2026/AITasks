import numpy as np

from starter import LayerNorm, RMSNorm

rng = np.random.default_rng(0)


def numeric(fn, arr, g, eps=1e-6):
    num = np.zeros_like(arr)
    for idx in np.ndindex(arr.shape):
        old = arr[idx]
        arr[idx] = old + eps
        lp = (fn() * g).sum()
        arr[idx] = old - eps
        lm = (fn() * g).sum()
        arr[idx] = old
        num[idx] = (lp - lm) / (2 * eps)
    return num


def test_layernorm_forward():
    x = rng.normal(2, 3, size=(2, 3, 6))
    ln = LayerNorm(6)
    y = ln.forward(x)
    np.testing.assert_allclose(y.mean(-1), 0, atol=1e-10)
    np.testing.assert_allclose(y, (x - x.mean(-1, keepdims=True)) / np.sqrt(x.var(-1, keepdims=True) + 1e-5))


def test_layernorm_backward():
    x = rng.normal(size=(2, 3, 5))
    ln = LayerNorm(5)
    ln.gamma, ln.beta = rng.normal(size=5), rng.normal(size=5)
    g = rng.normal(size=x.shape)
    ln.forward(x)
    dx = ln.backward(g)
    np.testing.assert_allclose(dx, numeric(lambda: ln.forward(x), x, g), rtol=1e-5, atol=1e-7)
    ln.forward(x)
    ln.backward(g)
    dgamma, dbeta = ln.dgamma.copy(), ln.dbeta.copy()
    np.testing.assert_allclose(dgamma, numeric(lambda: ln.forward(x), ln.gamma, g), rtol=1e-5, atol=1e-7)
    np.testing.assert_allclose(dbeta, numeric(lambda: ln.forward(x), ln.beta, g), rtol=1e-5, atol=1e-7)


def test_rmsnorm_forward():
    x = rng.normal(size=(4, 8))
    rn = RMSNorm(8)
    rn.gamma = np.arange(1, 9, dtype=float)
    np.testing.assert_allclose(rn.forward(x), rn.gamma * x / np.sqrt((x ** 2).mean(-1, keepdims=True) + 1e-6))


def test_rmsnorm_backward():
    x = rng.normal(size=(3, 2, 7))
    rn = RMSNorm(7)
    rn.gamma = rng.normal(size=7)
    g = rng.normal(size=x.shape)
    rn.forward(x)
    dx = rn.backward(g)
    dgamma = rn.dgamma.copy()
    np.testing.assert_allclose(dx, numeric(lambda: rn.forward(x), x, g), rtol=1e-5, atol=1e-7)
    np.testing.assert_allclose(dgamma, numeric(lambda: rn.forward(x), rn.gamma, g), rtol=1e-5, atol=1e-7)


def test_2d_input_shapes():
    ln, rn = LayerNorm(4), RMSNorm(4)
    x = rng.normal(size=(5, 4))
    ln.forward(x)
    rn.forward(x)
    assert ln.backward(np.ones_like(x)).shape == x.shape and ln.dgamma.shape == (4,)
    assert rn.backward(np.ones_like(x)).shape == x.shape and rn.dgamma.shape == (4,)
