def confusion_matrix(y_true, y_pred):
    """Return tp/fp/tn/fn counts."""
    y_true, y_pred = list(y_true), list(y_pred)
    if not y_true or len(y_true) != len(y_pred):
        raise ValueError("inputs must be non-empty and equal length")
    if any(v not in (0, 1) for v in y_true + y_pred):
        raise ValueError("labels must be 0 or 1")
    cm = {"tp": 0, "fp": 0, "tn": 0, "fn": 0}
    for t, p in zip(y_true, y_pred):
        key = ("t" if t == p else "f") + ("p" if p == 1 else "n")
        cm[key] += 1
    return cm


def accuracy(y_true, y_pred):
    """Fraction correct."""
    cm = confusion_matrix(y_true, y_pred)
    return (cm["tp"] + cm["tn"]) / sum(cm.values())


def precision(y_true, y_pred):
    """tp / (tp + fp)."""
    cm = confusion_matrix(y_true, y_pred)
    d = cm["tp"] + cm["fp"]
    return cm["tp"] / d if d else 0.0


def recall(y_true, y_pred):
    """tp / (tp + fn)."""
    cm = confusion_matrix(y_true, y_pred)
    d = cm["tp"] + cm["fn"]
    return cm["tp"] / d if d else 0.0


def fbeta_score(y_true, y_pred, beta):
    """F-beta score."""
    if beta <= 0:
        raise ValueError("beta must be > 0")
    p, r = precision(y_true, y_pred), recall(y_true, y_pred)
    d = beta ** 2 * p + r
    return (1 + beta ** 2) * p * r / d if d else 0.0


def f1_score(y_true, y_pred):
    """F1 score."""
    return fbeta_score(y_true, y_pred, 1.0)
