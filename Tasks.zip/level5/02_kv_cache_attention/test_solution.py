import time

import numpy as np

from starter import CachedSelfAttention

rng = np.random.default_rng(0)
D, H = 16, 4
WS = [rng.normal(0, 0.3, size=(D, D)) for _ in range(4)]
X = rng.normal(size=(12, D))


def ref_attention(x, window=None):
    q, k, v = x @ WS[0], x @ WS[1], x @ WS[2]
    T, dh = len(x), D // H
    out = np.zeros((T, D))
    for h in range(H):
        sl = slice(h * dh, (h + 1) * dh)
        for i in range(T):
            js = [j for j in range(T) if j <= i and (window is None or j > i - window)]
            s = np.array([q[i, sl] @ k[j, sl] / np.sqrt(dh) for j in js])
            p = np.exp(s - s.max())
            p /= p.sum()
            out[i, sl] = p @ v[js, sl]
    return out @ WS[3]


def test_forward_full():
    att = CachedSelfAttention(*WS, n_heads=H)
    np.testing.assert_allclose(att.forward_full(X), ref_attention(X), atol=1e-10)
    att = CachedSelfAttention(*WS, n_heads=H, window=3)
    np.testing.assert_allclose(att.forward_full(X), ref_attention(X, 3), atol=1e-10)
    assert att.cache_len == 0


def test_step_equals_full():
    att = CachedSelfAttention(*WS, n_heads=H)
    outs = np.array([att.step(x) for x in X])
    np.testing.assert_allclose(outs, ref_attention(X), atol=1e-10)
    assert att.cache_len == 12
    att.reset()
    assert att.cache_len == 0


def test_sliding_window_cache_bounded():
    att = CachedSelfAttention(*WS, n_heads=H, window=4)
    outs = []
    for x in X:
        outs.append(att.step(x))
        assert att.cache_len <= 4
    np.testing.assert_allclose(np.array(outs), ref_attention(X, 4), atol=1e-10)


def test_prefill_then_step():
    for window in (None, 5):
        att = CachedSelfAttention(*WS, n_heads=H, window=window)
        first = att.prefill(X[:7])
        rest = [att.step(x) for x in X[7:]]
        np.testing.assert_allclose(np.vstack([first, rest]), ref_attention(X, window), atol=1e-10)


def test_decode_speed():
    d, T = 64, 400
    Ws = [rng.normal(0, 0.1, size=(d, d)) for _ in range(4)]
    att = CachedSelfAttention(*Ws, n_heads=8)
    xs = rng.normal(size=(T, d))
    t0 = time.perf_counter()
    for x in xs:
        att.step(x)
    assert time.perf_counter() - t0 < 5.0
