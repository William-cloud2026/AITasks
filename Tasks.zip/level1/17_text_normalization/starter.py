# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import unicodedata
from collections import Counter

def normalize_text(text, lowercase=True, strip_accents=True, remove_punctuation=True):
    """Normalize text according to the README pipeline."""
    raise NotImplementedError('TODO')

def tokenize(text):
    """Normalize then split on whitespace."""
    raise NotImplementedError('TODO')

def vocabulary(texts, min_count=1):
    """Build a frequency-sorted token->id mapping."""
    raise NotImplementedError('TODO')
