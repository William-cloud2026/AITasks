# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import copy

class Callback:
    """Base callback with no-op hooks."""

    def on_train_begin(self, trainer):
        raise NotImplementedError('TODO')

    def on_epoch_end(self, trainer, epoch, logs):
        raise NotImplementedError('TODO')

    def on_train_end(self, trainer):
        raise NotImplementedError('TODO')

class EarlyStopping(Callback):
    """Stop when a monitored metric stops improving."""

    def __init__(self, monitor='val_loss', mode='min', patience=3, min_delta=0.0, restore_best=True):
        raise NotImplementedError('TODO')

    def on_train_begin(self, trainer):
        raise NotImplementedError('TODO')

    def on_epoch_end(self, trainer, epoch, logs):
        raise NotImplementedError('TODO')

    def on_train_end(self, trainer):
        raise NotImplementedError('TODO')

class ModelCheckpoint(Callback):
    """Keep in-memory snapshots of the model state."""

    def __init__(self, monitor='val_loss', mode='min', save_best_only=True):
        raise NotImplementedError('TODO')

    def on_train_begin(self, trainer):
        raise NotImplementedError('TODO')

    def on_epoch_end(self, trainer, epoch, logs):
        raise NotImplementedError('TODO')

class Trainer:
    """Minimal epoch loop with callbacks."""

    def __init__(self, train_epoch, evaluate=None, get_state=None, set_state=None, callbacks=()):
        raise NotImplementedError('TODO')

    def get_state(self):
        """User-provided model state."""
        raise NotImplementedError('TODO')

    def set_state(self, state):
        """Restore model state."""
        raise NotImplementedError('TODO')

    def fit(self, epochs):
        """Run the training loop."""
        raise NotImplementedError('TODO')
