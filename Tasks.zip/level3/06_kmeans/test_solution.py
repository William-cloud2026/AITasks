import numpy as np

from starter import KMeans

rng = np.random.default_rng(5)
CENTERS = np.array([[0.0, 0.0], [10.0, 0.0], [0.0, 10.0], [10.0, 10.0]])
X = np.vstack([c + rng.normal(scale=0.5, size=(50, 2)) for c in CENTERS])


def match(found):
    return np.array([np.min(np.linalg.norm(found - c, axis=1)) for c in CENTERS])


def test_recovers_centers():
    m = KMeans(4, seed=0).fit(X)
    assert match(m.cluster_centers_).max() < 0.3
    assert m.cluster_centers_.shape == (4, 2) and m.labels_.shape == (200,)
    assert len(set(m.labels_.tolist())) == 4


def test_inertia_consistent():
    m = KMeans(4, seed=1).fit(X)
    manual = sum(np.sum((X[m.labels_ == j] - m.cluster_centers_[j]) ** 2) for j in range(4))
    assert np.isclose(m.inertia_, manual)
    np.testing.assert_array_equal(m.predict(X), m.labels_)
    T = m.transform(X)
    assert T.shape == (200, 4)
    np.testing.assert_allclose(T.min(1) ** 2, np.sum((X - m.cluster_centers_[m.labels_]) ** 2, axis=1), atol=1e-8)


def test_reproducible():
    a = KMeans(4, seed=3, n_init=3).fit(X)
    b = KMeans(4, seed=3, n_init=3).fit(X)
    np.testing.assert_array_equal(a.cluster_centers_, b.cluster_centers_)


def test_random_init_and_single_cluster():
    m = KMeans(4, init="random", n_init=20, seed=0).fit(X)
    assert match(m.cluster_centers_).max() < 0.3
    one = KMeans(1, seed=0).fit(X)
    np.testing.assert_allclose(one.cluster_centers_[0], X.mean(0))


def test_duplicate_points_no_crash():
    Xd = np.array([[0.0, 0.0]] * 5 + [[1.0, 1.0]] * 5)
    m = KMeans(3, seed=0, n_init=2).fit(Xd)
    assert np.isfinite(m.cluster_centers_).all()
    assert np.isclose(m.inertia_, 0.0)


def test_invalid():
    try:
        KMeans(5).fit(X[:3])
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
