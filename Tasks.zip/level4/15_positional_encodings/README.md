# L4-15 · Positional Encodings: Sinusoidal, RoPE, ALiBi

**Level:** 4 · **Topics:** transformers, rotary embeddings, relative position · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
### `sinusoidal_encoding(T, d) -> (T, d)`
`PE[p, 2i] = sin(p / 10000^(2i/d))`, `PE[p, 2i+1] = cos(p / 10000^(2i/d))`. Odd `d` → `ValueError`.

### `apply_rope(x, positions=None, base=10000.0)`
Rotary embedding in the **half-split** ("rotate_half", GPT-NeoX / LLaMA-HF) convention:
- `x` has shape `(..., T, d)` with even `d` (else `ValueError`); `positions` defaults to `arange(T)`.
- `inv_freq[i] = base^(−2i/d)` for `i < d/2`; `angle[p, i] = positions[p] · inv_freq[i]`.
- With `x1 = x[..., :d/2]`, `x2 = x[..., d/2:]`:
  `out = concat(x1·cos − x2·sin, x1·sin + x2·cos)`.

Properties checked: norms preserved; `rope(q, m) · rope(k, n)` depends only on `m − n`.

### `alibi_slopes(n_heads)` and `alibi_bias(n_heads, T)`
- `n_heads` must be a power of two (else `ValueError`); `slope_h = 2^(−8(h+1)/n_heads)` for `h = 0..n_heads−1`.
- `bias[h, i, j] = slope_h · (j − i)` → shape `(n_heads, T, T)` (callers combine it with a causal mask).
