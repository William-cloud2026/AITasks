import contextlib
import functools
import time


class Profiler:
    """Accumulates timings for nested named sections."""

    def __init__(self, clock=time.perf_counter):
        self.clock = clock
        self._stack = []
        self._data = {}

    @contextlib.contextmanager
    def section(self, name):
        """Context manager timing a named (possibly nested) section."""
        if not isinstance(name, str) or not name or "/" in name:
            raise ValueError("invalid section name")
        self._stack.append(name)
        key = "/".join(self._stack)
        start = self.clock()
        try:
            yield
        finally:
            elapsed = self.clock() - start
            self._stack.pop()
            entry = self._data.setdefault(key, [0, 0.0])
            entry[0] += 1
            entry[1] += elapsed

    def timed(self, name):
        """Decorator timing each call as a section."""
        def decorator(fn):
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                with self.section(name):
                    return fn(*args, **kwargs)
            return wrapper
        return decorator

    def report(self):
        """Return {key: {calls, total, mean}}."""
        return {k: {"calls": c, "total": t, "mean": t / c} for k, (c, t) in self._data.items()}

    def reset(self):
        """Clear all recorded data."""
        self._data.clear()
