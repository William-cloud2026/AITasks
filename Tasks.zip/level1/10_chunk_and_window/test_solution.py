import itertools

from starter import chunked, sliding_window


def test_chunked():
    assert list(chunked(range(7), 3)) == [[0, 1, 2], [3, 4, 5], [6]]
    assert list(chunked([], 3)) == []
    assert list(chunked("ab", 5)) == [["a", "b"]]


def test_window():
    assert list(sliding_window("abcd", 2)) == [("a", "b"), ("b", "c"), ("c", "d")]
    assert list(sliding_window([1, 2], 3)) == []
    assert list(sliding_window([1, 2, 3], 3)) == [(1, 2, 3)]


def test_infinite_inputs():
    assert list(itertools.islice(chunked(itertools.count(), 2), 3)) == [[0, 1], [2, 3], [4, 5]]
    assert next(sliding_window(itertools.count(10), 3)) == (10, 11, 12)


def test_laziness():
    it = iter(range(100))
    gen = chunked(it, 4)
    next(gen)
    assert next(it) == 4


def test_returns_generators():
    import types
    assert isinstance(chunked([1], 1), types.GeneratorType) or hasattr(chunked([1], 1), "__next__")


def test_eager_validation():
    for fn in (chunked, sliding_window):
        try:
            fn([1, 2, 3], 0)
        except ValueError:
            continue
        raise AssertionError("ValueError must be raised at call time")
