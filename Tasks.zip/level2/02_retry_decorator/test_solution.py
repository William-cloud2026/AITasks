from starter import retry


def flaky(fail_times, exc=ConnectionError):
    state = {"n": 0}

    def fn(x):
        """doc"""
        state["n"] += 1
        if state["n"] <= fail_times:
            raise exc(f"fail {state['n']}")
        return x * 2

    return fn, state


def test_succeeds_after_retries():
    sleeps = []
    fn, state = flaky(2)
    wrapped = retry(max_attempts=3, backoff=0.5, sleep=sleeps.append)(fn)
    assert wrapped(21) == 42
    assert state["n"] == 3
    assert sleeps == [0.5, 1.0]
    assert wrapped.last_attempts == 3


def test_gives_up_and_reraises_last():
    sleeps = []
    fn, _ = flaky(10)
    wrapped = retry(max_attempts=4, backoff=1, factor=3, sleep=sleeps.append)(fn)
    try:
        wrapped(1)
    except ConnectionError as e:
        assert str(e) == "fail 4"
    else:
        raise AssertionError("expected ConnectionError")
    assert sleeps == [1, 3, 9]


def test_non_matching_exception_propagates():
    fn, state = flaky(5, exc=KeyError)
    wrapped = retry(max_attempts=5, exceptions=(ConnectionError,), sleep=lambda s: None)(fn)
    try:
        wrapped(1)
    except KeyError:
        pass
    assert state["n"] == 1


def test_no_sleep_when_zero_and_on_retry():
    calls = []
    fn, _ = flaky(2)

    def no_sleep(_):
        raise AssertionError("sleep must not be called")

    wrapped = retry(max_attempts=3, sleep=no_sleep, on_retry=lambda a, e: calls.append((a, str(e))))(fn)
    assert wrapped(1) == 2
    assert calls == [(1, "fail 1"), (2, "fail 2")]


def test_metadata():
    fn, _ = flaky(0)
    wrapped = retry()(fn)
    assert wrapped.__name__ == "fn" and wrapped.__doc__ == "doc"
    wrapped(1)
    assert wrapped.last_attempts == 1


def test_validation():
    for kwargs in ({"max_attempts": 0}, {"backoff": -1}):
        try:
            retry(**kwargs)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
