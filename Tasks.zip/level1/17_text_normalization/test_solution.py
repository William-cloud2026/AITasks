from starter import normalize_text, tokenize, vocabulary


def test_example():
    assert normalize_text("  Café   déjà-vu!! ") == "cafe deja vu"


def test_flags():
    assert normalize_text("Café!", lowercase=False) == "Cafe"
    assert normalize_text("Café!", strip_accents=False) == "café"
    assert normalize_text("A,B", remove_punctuation=False) == "a,b"


def test_whitespace_always_collapsed():
    assert normalize_text("a\t\n b", False, False, False) == "a b"


def test_unicode_punct_and_compat():
    assert normalize_text("«Ｈｅｌｌｏ» — world…") == "hello world"


def test_tokenize():
    assert tokenize("Hello, WORLD! Hello?") == ["hello", "world", "hello"]
    assert tokenize("   ") == []


def test_vocabulary():
    v = vocabulary(["b a a", "c b a", "d"], min_count=1)
    assert v == {"a": 0, "b": 1, "c": 2, "d": 3}
    assert vocabulary(["b a a", "c b a", "d"], min_count=2) == {"a": 0, "b": 1}
