from starter import Trie


def build():
    t = Trie()
    for w, wt in [("python", 10), ("pytorch", 8), ("pandas", 8), ("pydantic", 3), ("py", 1), ("numpy", 9)]:
        t.insert(w, wt)
    return t


def test_complete_ranking():
    t = build()
    assert t.complete("p", 3) == ["python", "pandas", "pytorch"]
    assert t.complete("py") == ["python", "pytorch", "pydantic", "py"]
    assert t.complete("x") == []


def test_weights_accumulate():
    t = build()
    t.insert("pydantic", 20)
    assert t.weight("pydantic") == 23
    assert t.complete("py", 1) == ["pydantic"]
    assert len(t) == 6


def test_contains_and_prefix_counts():
    t = build()
    assert "py" in t and t.contains("numpy")
    assert "pyt" not in t
    assert t.count_prefix("py") == 4
    assert t.count_prefix("") == 6
    assert t.count_prefix("z") == 0


def test_delete():
    t = build()
    assert t.delete("py")
    assert not t.delete("py")
    assert "py" not in t and "python" in t
    assert t.count_prefix("py") == 3
    assert t.delete("pydantic")
    assert t.count_prefix("pyd") == 0
    assert len(t) == 4


def test_validation():
    t = Trie()
    for args in [("",), ("a", 0), ("a", -1)]:
        try:
            t.insert(*args)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_large():
    t = Trie()
    for i in range(20000):
        t.insert(f"item{i:05d}", (i * 7919) % 1000 + 1)
    assert t.count_prefix("item1") == 10000
    res = t.complete("item", 3)
    assert len(res) == 3 and all(t.weight(w) == 1000 for w in res)
