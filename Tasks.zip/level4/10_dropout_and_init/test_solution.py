import numpy as np

from starter import (Dropout, compute_fans, kaiming_normal, kaiming_uniform, xavier_normal,
                      xavier_uniform)


def test_dropout_exact_mask():
    x = np.arange(12, dtype=float).reshape(3, 4)
    d = Dropout(p=0.25, seed=7)
    out = d.forward(x)
    mask = np.random.default_rng(7).random((3, 4)) >= 0.25
    np.testing.assert_allclose(out, x * mask / 0.75)
    np.testing.assert_allclose(d.backward(np.ones_like(x)), mask / 0.75)


def test_dropout_expectation_and_eval():
    d = Dropout(p=0.5, seed=0)
    x = np.ones((200, 200))
    assert abs(d.forward(x).mean() - 1.0) < 0.02
    d.eval()
    np.testing.assert_array_equal(d.forward(x), x)
    np.testing.assert_array_equal(d.backward(x), x)
    assert d.train() is d and d.training
    np.testing.assert_array_equal(Dropout(p=0.0).forward(x), x)


def test_dropout_invalid():
    for p in (1.0, -0.1):
        try:
            Dropout(p)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_fans():
    assert compute_fans((128, 64)) == (128, 64)
    assert compute_fans((32, 16, 3, 3)) == (144, 288)
    try:
        compute_fans((5,))
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


def test_xavier():
    w = xavier_uniform((400, 600), np.random.default_rng(0))
    a = np.sqrt(6 / 1000)
    assert w.shape == (400, 600) and np.abs(w).max() <= a
    assert abs(w.std() - a / np.sqrt(3)) < 0.002
    w = xavier_normal((400, 600), np.random.default_rng(0), gain=2.0)
    assert abs(w.std() - 2 * np.sqrt(2 / 1000)) < 0.002
    np.testing.assert_array_equal(xavier_uniform((3, 4), np.random.default_rng(5)),
                                  np.random.default_rng(5).uniform(-np.sqrt(6 / 7), np.sqrt(6 / 7), size=(3, 4)))


def test_kaiming():
    w = kaiming_normal((32, 16, 3, 3), np.random.default_rng(1))
    assert abs(w.std() - np.sqrt(2 / 144)) < 0.005
    w = kaiming_uniform((500, 300), np.random.default_rng(1), mode="fan_out", nonlinearity="linear")
    a = np.sqrt(3 / 300)
    assert np.abs(w).max() <= a and abs(w.std() - a / np.sqrt(3)) < 0.002


def test_variance_preserved_through_relu_stack():
    rng = np.random.default_rng(2)
    h = rng.normal(size=(1000, 256))
    for _ in range(10):
        h = np.maximum(h @ kaiming_normal((256, 256), rng), 0)
    assert 0.3 < np.mean(h ** 2) < 3.0
