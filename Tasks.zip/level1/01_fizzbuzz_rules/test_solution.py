from starter import fizzbuzz


def test_default_rules():
    assert fizzbuzz(15) == ['1', '2', 'Fizz', '4', 'Buzz', 'Fizz', '7', '8', 'Fizz', 'Buzz',
                            '11', 'Fizz', '13', '14', 'FizzBuzz']


def test_zero():
    assert fizzbuzz(0) == []


def test_custom_rules_order_matters():
    assert fizzbuzz(6, [(2, "Foo"), (3, "Bar")])[-1] == "FooBar"
    assert fizzbuzz(6, [(3, "Bar"), (2, "Foo")])[-1] == "BarFoo"


def test_three_rules():
    out = fizzbuzz(105, [(3, "Fizz"), (5, "Buzz"), (7, "Bazz")])
    assert out[104] == "FizzBuzzBazz"
    assert out[6] == "Bazz"
    assert len(out) == 105


def test_empty_rules():
    assert fizzbuzz(3, []) == ['1', '2', '3']


def test_errors():
    for bad in [lambda: fizzbuzz(-1), lambda: fizzbuzz(5, [(0, "X")]), lambda: fizzbuzz(5, [(-2, "X")])]:
        try:
            bad()
        except ValueError:
            pass
        else:
            raise AssertionError("expected ValueError")
