from starter import find_pii, luhn_valid, redact


def test_luhn():
    assert luhn_valid("79927398713")
    assert not luhn_valid("79927398710")
    assert luhn_valid("4111 1111 1111 1111") and luhn_valid("5500-0000-0000-0004")
    assert not luhn_valid("4111 1111 1111 1112")
    assert not luhn_valid("0") and not luhn_valid("")


def test_email_and_phone():
    text = "Mail jane.doe+ai@example.co.uk or call (555) 123-4567 / +1 555.123.4567 today."
    red, f = redact(text)
    assert red == "Mail [EMAIL] or call [PHONE] / [PHONE] today."
    assert [x["value"] for x in f] == ["jane.doe+ai@example.co.uk", "(555) 123-4567", "+1 555.123.4567"]
    assert text[f[0]["start"]:f[0]["end"]] == f[0]["value"]


def test_credit_card_luhn_gate():
    red, f = redact("Card 4111 1111 1111 1111 and fake 4111 1111 1111 1112.")
    assert red == "Card [CREDIT_CARD] and fake 4111 1111 1111 1112."
    assert f == [{"type": "CREDIT_CARD", "start": 5, "end": 24, "value": "4111 1111 1111 1111"}]
    assert redact("pay 5500-0000-0000-0004 now")[0] == "pay [CREDIT_CARD] now"


def test_ssn_and_ip():
    red, f = redact("SSN 123-45-6789, server 192.168.1.20, bad 192.168.1.300, version 1.2.3.4.5")
    assert red == "SSN [SSN], server [IPV4], bad 192.168.1.300, version 1.2.3.4.5"
    assert [x["type"] for x in f] == ["SSN", "IPV4"]


def test_types_filter_and_priority():
    text = "a@b.io 555-123-4567"
    assert [x["type"] for x in find_pii(text, types={"PHONE"})] == ["PHONE"]
    assert redact(text, types={"EMAIL"})[0] == "[EMAIL] 555-123-4567"
    # a 10-digit Luhn-valid number is not long enough for a card (13+ digits) -> phone
    assert [x["type"] for x in find_pii("call 4111111111 now")] == ["PHONE"]


def test_no_pii():
    text = "Nothing to see here: 3.14, 2024-01-01, room 101."
    assert redact(text) == (text, [])
