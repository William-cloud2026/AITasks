# L3-12 · Cross-Validation Splitters

**Level:** 3 · **Topics:** evaluation protocol, index bookkeeping, stratification · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `class KFold(n_splits=5, shuffle=False, seed=None)`
`split(n_samples)` yields `(train_idx, test_idx)` integer numpy arrays, both **sorted ascending**.
- Index order = `arange(n)`, or `np.random.default_rng(seed).permutation(n)` if `shuffle`.
- Folds are consecutive chunks of that order; the first `n % n_splits` folds have size `n // n_splits + 1`, the
  rest `n // n_splits`.
- `n_splits < 2` (constructor) or `n_splits > n_samples` (in `split`) → `ValueError`.

### `class StratifiedKFold(n_splits=5, shuffle=False, seed=None)`
`split(y)` yields `(train_idx, test_idx)` sorted arrays. Algorithm (deterministic):
- one `rng = np.random.default_rng(seed)` per `split` call;
- iterate classes in **sorted** order; take the class's indices in ascending order (or `rng.permutation` of them
  if `shuffle`); assign the `j`-th of them to fold `(offset + j) % n_splits`, where `offset` is the total number of
  samples assigned before this class.
- `n_splits > len(y)` → `ValueError`.

### `cross_val_score(make_model, X, y, cv, scoring) -> np.ndarray`
For each split of `cv` (call `cv.split(len(X))` for `KFold` and `cv.split(y)` for `StratifiedKFold`): build a fresh
model with `make_model()`, `fit(X[train], y[train])`, then `scoring(y[test], model.predict(X[test]))`.
