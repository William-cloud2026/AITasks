from starter import CycleError, find_cycle, stages, topo_order

PIPE = {
    "train": ["features", "split"],
    "features": ["clean"],
    "split": ["clean"],
    "clean": ["load"],
    "evaluate": ["train", "split"],
    "report": ["evaluate"],
    "download_stopwords": [],
}


def valid_order(order, deps):
    pos = {n: i for i, n in enumerate(order)}
    return all(pos[d] < pos[s] for s, ds in deps.items() for d in ds)


def test_topo_order_unique():
    order = topo_order(PIPE)
    assert order == ["download_stopwords", "load", "clean", "features", "split", "train", "evaluate", "report"]
    assert valid_order(order, PIPE)


def test_stages():
    assert stages(PIPE) == [["download_stopwords", "load"], ["clean"], ["features", "split"], ["train"],
                            ["evaluate"], ["report"]]
    assert stages({}) == []


def test_alphabetical_tie_break():
    assert topo_order({"c": [], "b": [], "a": ["c"]}) == ["b", "c", "a"]


def test_cycle_errors():
    for deps in ({"a": ["b"], "b": ["a"]}, {"a": ["a"]}, {"x": ["y"], "y": ["z"], "z": ["x"], "w": []}):
        for fn in (topo_order, stages):
            try:
                fn(deps)
            except CycleError:
                continue
            raise AssertionError("expected CycleError")
    assert issubclass(CycleError, ValueError)


def test_find_cycle():
    assert find_cycle(PIPE) is None
    deps = {"x": ["y"], "y": ["z"], "z": ["x"], "w": ["x"]}
    cyc = find_cycle(deps)
    assert cyc is not None and len(cyc) == 3 and len(set(cyc)) == 3
    for i, s in enumerate(cyc):
        assert cyc[(i + 1) % len(cyc)] in deps[s]
    assert find_cycle({"a": ["a"]}) == ["a"]


def test_large_chain():
    deps = {f"s{i:04d}": [f"s{i - 1:04d}"] for i in range(1, 3000)}
    order = topo_order(deps)
    assert order[0] == "s0000" and order[-1] == "s2999"
