import numpy as np


def _layer_norm(x, g, b, eps=1e-5):
    mu = x.mean(-1, keepdims=True)
    var = x.var(-1, keepdims=True)
    return (x - mu) / np.sqrt(var + eps) * g + b


def _gelu(x):
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))


def _attention(x, w, i, H):
    B, T, d = x.shape
    dh = d // H
    qkv = x @ w[f"h{i}.attn.w_qkv"] + w[f"h{i}.attn.b_qkv"]
    q, k, v = (qkv[..., j * d:(j + 1) * d].reshape(B, T, H, dh).transpose(0, 2, 1, 3) for j in range(3))
    s = q @ k.transpose(0, 1, 3, 2) / np.sqrt(dh)
    s = np.where(np.tril(np.ones((T, T), dtype=bool)), s, -np.inf)
    s = np.exp(s - s.max(-1, keepdims=True))
    s /= s.sum(-1, keepdims=True)
    out = (s @ v).transpose(0, 2, 1, 3).reshape(B, T, d)
    return out @ w[f"h{i}.attn.w_o"] + w[f"h{i}.attn.b_o"]


def gpt_forward(ids, weights, config):
    """Logits of a GPT-2 style decoder."""
    ids = np.asarray(ids)
    single = ids.ndim == 1
    if single:
        ids = ids[None]
    T = ids.shape[1]
    if T > config["max_seq_len"]:
        raise ValueError("sequence too long")
    w = weights
    x = w["wte"][ids] + w["wpe"][:T]
    for i in range(config["n_layers"]):
        x = x + _attention(_layer_norm(x, w[f"h{i}.ln1.g"], w[f"h{i}.ln1.b"]), w, i, config["n_heads"])
        m = _layer_norm(x, w[f"h{i}.ln2.g"], w[f"h{i}.ln2.b"])
        x = x + _gelu(m @ w[f"h{i}.mlp.w1"] + w[f"h{i}.mlp.b1"]) @ w[f"h{i}.mlp.w2"] + w[f"h{i}.mlp.b2"]
    logits = _layer_norm(x, w["lnf.g"], w["lnf.b"]) @ w["wte"].T
    return logits[0] if single else logits


def count_parameters(config):
    """Number of scalars in the weight dict."""
    V, d, L, T = config["vocab_size"], config["d_model"], config["n_layers"], config["max_seq_len"]
    per_layer = 4 * d + (d * 3 * d + 3 * d) + (d * d + d) + (d * 4 * d + 4 * d) + (4 * d * d + d)
    return V * d + T * d + L * per_layer + 2 * d
