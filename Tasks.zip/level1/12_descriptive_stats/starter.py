# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
from collections import Counter

def mean(xs):
    """Arithmetic mean."""
    raise NotImplementedError('TODO')

def median(xs):
    """Median (mean of middle two for even n)."""
    raise NotImplementedError('TODO')

def mode(xs):
    """Most frequent value, smallest on ties."""
    raise NotImplementedError('TODO')

def variance(xs, sample=False):
    """Population (default) or sample variance."""
    raise NotImplementedError('TODO')

def stdev(xs, sample=False):
    """Square root of variance."""
    raise NotImplementedError('TODO')

def zscores(xs):
    """Standardized scores using population stdev."""
    raise NotImplementedError('TODO')
