import numpy as np


def _sq_dists(X, C):
    return np.maximum((X ** 2).sum(1)[:, None] + (C ** 2).sum(1)[None, :] - 2 * X @ C.T, 0.0)


class KMeans:
    """Lloyd's k-means with k-means++ initialization."""

    def __init__(self, n_clusters, init="k-means++", n_init=10, max_iter=300, tol=1e-6, seed=0):
        if init not in ("k-means++", "random"):
            raise ValueError("unknown init")
        self.n_clusters, self.init, self.n_init = n_clusters, init, n_init
        self.max_iter, self.tol, self.seed = max_iter, tol, seed

    def _init_centers(self, X, rng):
        n, k = len(X), self.n_clusters
        if self.init == "random":
            return X[rng.choice(n, size=k, replace=False)].copy()
        centers = [X[rng.integers(n)]]
        d2 = _sq_dists(X, np.array(centers))[:, 0]
        for _ in range(1, k):
            total = d2.sum()
            idx = rng.choice(n, p=d2 / total) if total > 0 else rng.integers(n)
            centers.append(X[idx])
            d2 = np.minimum(d2, _sq_dists(X, X[idx:idx + 1])[:, 0])
        return np.array(centers)

    def _run(self, X, rng):
        C = self._init_centers(X, rng)
        for it in range(1, self.max_iter + 1):
            D = _sq_dists(X, C)
            labels = D.argmin(1)
            newC = C.copy()
            for j in range(self.n_clusters):
                members = X[labels == j]
                if len(members):
                    newC[j] = members.mean(0)
                else:
                    far = D[np.arange(len(X)), labels].argmax()
                    newC[j] = X[far]
            shift = ((newC - C) ** 2).sum()
            C = newC
            if shift <= self.tol:
                break
        D = _sq_dists(X, C)
        labels = D.argmin(1)
        return C, labels, float(D[np.arange(len(X)), labels].sum()), it

    def fit(self, X):
        """Cluster X."""
        X = np.asarray(X, dtype=float)
        if not 1 <= self.n_clusters <= len(X):
            raise ValueError("invalid n_clusters")
        rng = np.random.default_rng(self.seed)
        best = None
        for _ in range(self.n_init):
            res = self._run(X, rng)
            if best is None or res[2] < best[2]:
                best = res
        self.cluster_centers_, self.labels_, self.inertia_, self.n_iter_ = best
        return self

    def predict(self, X):
        """Nearest center index."""
        return _sq_dists(np.asarray(X, dtype=float), self.cluster_centers_).argmin(1)

    def transform(self, X):
        """Distances to centers."""
        return np.sqrt(_sq_dists(np.asarray(X, dtype=float), self.cluster_centers_))
