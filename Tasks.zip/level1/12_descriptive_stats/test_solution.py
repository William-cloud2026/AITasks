import math

from starter import mean, median, mode, stdev, variance, zscores


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-12)


def test_mean_median():
    assert close(mean([1, 2, 3, 4]), 2.5)
    assert close(median([3, 1, 2, 4]), 2.5)
    assert close(median([5, 1, 3]), 3)


def test_mode():
    assert mode([1, 2, 2, 3]) == 2
    assert mode([3, 3, 1, 1, 2]) == 1
    assert mode([7]) == 7


def test_variance():
    data = [2, 4, 4, 4, 5, 5, 7, 9]
    assert close(variance(data), 4.0)
    assert close(stdev(data), 2.0)
    assert close(variance(data, sample=True), 32 / 7)


def test_zscores():
    z = zscores([2, 4, 4, 4, 5, 5, 7, 9])
    assert close(z[0], -1.5) and close(z[-1], 2.0)
    assert zscores([5, 5, 5]) == [0.0, 0.0, 0.0]


def test_generators_accepted():
    assert close(mean(x for x in range(5)), 2.0)


def test_errors():
    for fn in (lambda: mean([]), lambda: median([]), lambda: mode([]),
               lambda: variance([]), lambda: variance([1], sample=True)):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
