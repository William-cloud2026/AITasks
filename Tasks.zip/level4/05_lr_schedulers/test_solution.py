import math

from starter import (LambdaScheduler, exponential_lr, inverse_sqrt_lr, step_lr, warmup_cosine_lr,
                      warmup_linear_lr)


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15)


def test_step_and_exponential():
    assert [step_lr(s, 1.0, 3, 0.5) for s in range(7)] == [1, 1, 1, 0.5, 0.5, 0.5, 0.25]
    assert close(exponential_lr(3, 2.0, 0.9), 2.0 * 0.729)


def test_warmup_cosine():
    vals = [warmup_cosine_lr(s, 1.0, total_steps=10, warmup_steps=2, min_lr=0.1) for s in range(12)]
    assert close(vals[0], 0.5) and close(vals[1], 1.0)
    assert close(vals[2], 1.0)
    assert close(vals[6], 0.1 + 0.45 * (1 + math.cos(math.pi * 0.5)))
    assert close(vals[10], 0.1) and close(vals[11], 0.1)
    assert all(vals[i] >= vals[i + 1] - 1e-15 for i in range(1, 11))


def test_cosine_no_warmup():
    assert close(warmup_cosine_lr(0, 3e-4, 100), 3e-4)
    assert close(warmup_cosine_lr(50, 3e-4, 100), 1.5e-4)


def test_warmup_linear():
    vals = [warmup_linear_lr(s, 1.0, total_steps=10, warmup_steps=4) for s in range(12)]
    assert close(vals[3], 1.0) and close(vals[4], 1.0)
    assert close(vals[7], 0.5) and vals[10] == 0.0 and vals[11] == 0.0


def test_inverse_sqrt():
    assert close(inverse_sqrt_lr(0, 1.0, 4), 0.25)
    assert close(inverse_sqrt_lr(3, 1.0, 4), 1.0)
    assert close(inverse_sqrt_lr(15, 1.0, 4), 0.5)


def test_negative_step():
    for fn in (lambda: step_lr(-1, 1, 1), lambda: warmup_cosine_lr(-1, 1, 10)):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


class Opt:
    lr = 123.0


def test_lambda_scheduler():
    opt = Opt()
    sched = LambdaScheduler(opt, lambda s: warmup_linear_lr(s, 0.1, 4, 2))
    seen = [opt.lr]
    for _ in range(5):
        sched.step()
        seen.append(sched.get_last_lr())
    assert all(close(a, b) for a, b in zip(seen, [0.05, 0.1, 0.1, 0.05, 0.0, 0.0]))
    assert sched.last_step == 5
