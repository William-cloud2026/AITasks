import re


class TemplateError(Exception):
    """Raised for any template problem."""


_MISSING = object()
_TOKEN = re.compile(r"({{.*?}}|{%.*?%})", re.S)
_FILTER = re.compile(r"\s*([A-Za-z_]\w*)\s*(?::\s*(\"[^\"]*\"|-?\d+))?\s*$")


def _parse(tokens, pos, end_tags):
    nodes = []
    while pos < len(tokens):
        tok = tokens[pos]
        if tok.startswith("{%"):
            parts = tok[2:-2].split()
            if not parts:
                raise TemplateError("empty tag")
            tag = parts[0]
            if tag in end_tags:
                return nodes, pos, tag
            if tag == "for":
                if len(parts) != 4 or parts[2] != "in":
                    raise TemplateError("bad for syntax")
                body, pos, end = _parse(tokens, pos + 1, ("endfor",))
                if end != "endfor":
                    raise TemplateError("unclosed for")
                nodes.append(("for", parts[1], parts[3], body))
            elif tag == "if":
                if len(parts) != 2:
                    raise TemplateError("bad if syntax")
                body, pos, end = _parse(tokens, pos + 1, ("else", "endif"))
                other = []
                if end == "else":
                    other, pos, end = _parse(tokens, pos + 1, ("endif",))
                if end != "endif":
                    raise TemplateError("unclosed if")
                nodes.append(("if", parts[1], body, other))
            else:
                raise TemplateError(f"unexpected tag {tag!r}")
        elif tok.startswith("{{"):
            nodes.append(("var", tok[2:-2]))
        else:
            nodes.append(("text", tok))
        pos += 1
    return nodes, pos, None


def _lookup(path, scopes):
    names = path.strip().split(".")
    if not all(re.fullmatch(r"[A-Za-z_]\w*", n) for n in names):
        raise TemplateError(f"bad path {path!r}")
    for scope in reversed(scopes):
        if names[0] in scope:
            obj = scope[names[0]]
            break
    else:
        return _MISSING
    for n in names[1:]:
        if isinstance(obj, dict):
            if n not in obj:
                return _MISSING
            obj = obj[n]
        elif hasattr(obj, n):
            obj = getattr(obj, n)
        else:
            return _MISSING
    return obj


def _apply_filter(value, spec):
    m = _FILTER.match(spec)
    if not m:
        raise TemplateError(f"bad filter {spec!r}")
    name, arg = m.groups()
    if arg is not None:
        arg = arg[1:-1] if arg.startswith('"') else int(arg)
    if name == "default":
        return arg if value is _MISSING or value is None else value
    if value is _MISSING:
        raise TemplateError("missing variable")
    simple = {"upper": str.upper, "lower": str.lower, "title": str.title, "strip": str.strip}
    if name in simple:
        return simple[name](str(value))
    if name == "length":
        return len(value)
    if name == "truncate":
        s = str(value)
        return s if len(s) <= arg else s[:arg] + "..."
    if name == "join":
        return arg.join(str(v) for v in value)
    raise TemplateError(f"unknown filter {name!r}")


def _render(nodes, scopes, out):
    for node in nodes:
        kind = node[0]
        if kind == "text":
            out.append(node[1])
        elif kind == "var":
            path, *filters = node[1].split("|")
            value = _lookup(path, scopes)
            for f in filters:
                value = _apply_filter(value, f)
            if value is _MISSING:
                raise TemplateError(f"missing variable {path.strip()!r}")
            out.append("" if value is None else str(value))
        elif kind == "for":
            _, var, path, body = node
            seq = _lookup(path, scopes)
            if seq is _MISSING:
                raise TemplateError(f"missing variable {path!r}")
            items = list(seq)
            for i, item in enumerate(items):
                loop = {"index": i + 1, "first": i == 0, "last": i == len(items) - 1}
                _render(body, scopes + [{var: item, "loop": loop}], out)
        elif kind == "if":
            _, path, body, other = node
            value = _lookup(path, scopes)
            _render(body if value is not _MISSING and value else other, scopes, out)


def render(template, context):
    """Render a template with the given context."""
    tokens = [t for t in _TOKEN.split(template) if t]
    nodes, pos, end = _parse(tokens, 0, ())
    if end is not None:
        raise TemplateError("unexpected end tag")
    out = []
    _render(nodes, [dict(context)], out)
    return "".join(out)


def format_chat(messages, add_generation_prompt=True):
    """Format chat messages with role markers."""
    if not messages:
        raise ValueError("messages must not be empty")
    out = []
    for i, m in enumerate(messages):
        role = m["role"]
        if role not in ("system", "user", "assistant"):
            raise ValueError(f"bad role {role!r}")
        if role == "system" and i != 0:
            raise ValueError("system message must be first")
        out.append(f"<|{role}|>\n{m['content']}<|end|>\n")
    if add_generation_prompt:
        out.append("<|assistant|>\n")
    return "".join(out)
