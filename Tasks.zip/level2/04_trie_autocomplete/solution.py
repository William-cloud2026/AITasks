import heapq


class _Node:
    __slots__ = ("children", "weight", "count")

    def __init__(self):
        self.children = {}
        self.weight = 0
        self.count = 0


class Trie:
    """Prefix tree with weighted completions."""

    def __init__(self):
        self._root = _Node()

    def _find(self, prefix):
        node = self._root
        for ch in prefix:
            node = node.children.get(ch)
            if node is None:
                return None
        return node

    def insert(self, word, weight=1):
        """Insert word (weights accumulate)."""
        if not word or weight <= 0:
            raise ValueError("word must be non-empty and weight > 0")
        new = not self.contains(word)
        node = self._root
        if new:
            node.count += 1
        for ch in word:
            node = node.children.setdefault(ch, _Node())
            if new:
                node.count += 1
        node.weight += weight

    def contains(self, word):
        """Exact membership."""
        node = self._find(word)
        return node is not None and node.weight > 0

    __contains__ = contains

    def weight(self, word):
        """Stored weight or 0."""
        node = self._find(word)
        return node.weight if node else 0

    def count_prefix(self, prefix):
        """Number of words with this prefix."""
        node = self._find(prefix)
        return node.count if node else 0

    def complete(self, prefix, k=5):
        """Top-k completions by weight desc, word asc."""
        node = self._find(prefix)
        if node is None or k <= 0:
            return []
        items = []
        stack = [(node, prefix)]
        while stack:
            n, w = stack.pop()
            if n.weight > 0:
                items.append((-n.weight, w))
            for ch, child in n.children.items():
                stack.append((child, w + ch))
        return [w for _, w in heapq.nsmallest(k, items)]

    def delete(self, word):
        """Remove word; return True if it existed."""
        if not word or not self.contains(word):
            return False
        path = [self._root]
        for ch in word:
            path.append(path[-1].children[ch])
        path[-1].weight = 0
        for n in path:
            n.count -= 1
        for i in range(len(word), 0, -1):
            if path[i].count == 0:
                del path[i - 1].children[word[i - 1]]
            else:
                break
        return True

    def __len__(self):
        return self._root.count
