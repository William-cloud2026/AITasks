# L5-09 · PII Detection & Redaction Guardrail

**Level:** 5 · **Topics:** LLM guardrails, regex engineering, checksum validation, overlap resolution · **Time:** ~60 min · **Allowed:** Python stdlib

## Task
### `luhn_valid(number) -> bool`
`number` is a string of digits (spaces/dashes are ignored). Standard Luhn checksum. Fewer than 2 digits → `False`.

### `find_pii(text, types=None) -> list[dict]` and `redact(text, types=None) -> (redacted_text, findings)`
Detectors (apply each regex to the whole text):
| Type | Regex / rule |
|---|---|
| `EMAIL` | `[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}` |
| `CREDIT_CARD` | `(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)` **and** `luhn_valid` |
| `SSN` | `(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)` |
| `IPV4` | `(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])` **and** every octet `<= 255` |
| `PHONE` | `(?<!\w)(?:\+\d{1,3}[ .-]?)?(?:\(\d{3}\)\|\d{3})[ .-]?\d{3}[ .-]?\d{4}(?!\d)` |

`types` (optional) restricts which detectors run.

**Overlaps:** collect all matches, sort by `(start, −length, priority)` where priority follows the table order
(EMAIL first), and greedily keep a match if it starts at or after the end of the last kept match.

Each finding: `{"type", "start", "end", "value"}` (sorted by `start`). `redact` replaces each finding with
`[TYPE]` (e.g. `[EMAIL]`) and returns the new text plus the findings (offsets refer to the **original** text).
