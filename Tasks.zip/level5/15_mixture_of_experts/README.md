# L5-15 · Mixture-of-Experts Layer with Top-k Routing & Capacity

**Level:** 5 · **Topics:** sparse models, routing, load balancing, vectorized gather/scatter · **Time:** ~75 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class MoELayer(d_model, d_hidden, n_experts, top_k=2, capacity_factor=None, seed=0)` (forward only).

**Parameters** (`rng = np.random.default_rng(seed)`, drawn in this order):
`W_gate = rng.normal(0, 0.1, (d_model, E))`; then for `e = 0..E−1`: `W1[e] = rng.normal(0, 0.1, (d_model, d_hidden))`,
`W2[e] = rng.normal(0, 0.1, (d_hidden, d_model))`. Store `W1 (E, d, h)`, `W2 (E, h, d)`; biases `b1 (E, h)`,
`b2 (E, d)` zeros. `top_k > n_experts` → `ValueError`.

**Expert** `e`: `relu(x @ W1[e] + b1[e]) @ W2[e] + b2[e]`.

**forward(x)** with `x (N, d)` → `(N, d)`:
1. `probs = softmax(x @ W_gate)`; chosen experts per token = first `top_k` of `argsort(−probs, kind="stable")`.
2. Gate weights = chosen probs renormalized to sum to 1 per token.
3. Capacity (only if `capacity_factor` is set): `C = ceil(capacity_factor · N · top_k / E)`. Assignments are
   granted in **rank-major** order: first every token's rank-0 choice (tokens in index order), then every token's
   rank-1 choice, etc. An expert accepts assignments until it holds `C`; further ones are **dropped** (they
   contribute nothing; gates are *not* renormalized).
4. `y[n] = Σ_accepted gate · expert(e, x[n])`.

**Diagnostics set by forward:** `router_probs (N, E)`, `topk_indices (N, k)`, `expert_counts (E,)` (accepted
assignments), `dropped` (int), and the Switch-Transformer load-balancing loss
`aux_loss = E · Σ_e f_e · P_e` where `f_e` = fraction of tokens whose rank-0 choice is `e` (before capacity) and
`P_e = mean_n probs[n, e]`.

Must run each expert once on its group of tokens (no per-token Python loop): a test uses `N = 4096`.
