import json
import math
from collections import Counter, defaultdict


def percentile(values, p):
    """Nearest-rank percentile."""
    s = sorted(values)
    rank = max(1, math.ceil(p / 100 * len(s)))
    return float(s[rank - 1])


def analyze_logs(lines):
    """Aggregate JSON-lines inference logs."""
    total = malformed = 0
    levels = Counter()
    lat = defaultdict(list)
    errors = Counter()
    for line in lines:
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            malformed += 1
            continue
        if (not isinstance(rec, dict) or any(k not in rec for k in ("level", "endpoint", "latency_ms", "status"))
                or isinstance(rec["latency_ms"], bool) or not isinstance(rec["latency_ms"], (int, float))
                or isinstance(rec["status"], bool) or not isinstance(rec["status"], int)):
            malformed += 1
            continue
        total += 1
        levels[rec["level"]] += 1
        lat[rec["endpoint"]].append(rec["latency_ms"])
        if rec["status"] >= 500:
            errors[rec["endpoint"]] += 1
    endpoints = {
        ep: {"count": len(v), "p50": percentile(v, 50), "p95": percentile(v, 95), "error_rate": errors[ep] / len(v)}
        for ep, v in lat.items()
    }
    return {"total": total, "malformed": malformed, "by_level": dict(levels), "endpoints": endpoints}
