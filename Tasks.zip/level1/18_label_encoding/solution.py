class LabelEncoder:
    """Map labels to integer ids in sorted order."""

    def __init__(self):
        self.classes_ = None
        self._index = None

    def fit(self, labels):
        """Learn sorted unique classes."""
        self.classes_ = sorted(set(labels))
        self._index = {c: i for i, c in enumerate(self.classes_)}
        return self

    def _require_fit(self):
        if self.classes_ is None:
            raise RuntimeError("LabelEncoder is not fitted")

    def transform(self, labels):
        """Labels -> ids."""
        self._require_fit()
        out = []
        for lab in labels:
            if lab not in self._index:
                raise ValueError(f"unknown label: {lab!r}")
            out.append(self._index[lab])
        return out

    def inverse_transform(self, ids):
        """Ids -> labels."""
        self._require_fit()
        out = []
        for i in ids:
            if not isinstance(i, int) or not 0 <= i < len(self.classes_):
                raise ValueError(f"invalid id: {i!r}")
            out.append(self.classes_[i])
        return out

    def fit_transform(self, labels):
        """Fit then transform."""
        labels = list(labels)
        return self.fit(labels).transform(labels)


def one_hot(ids, num_classes):
    """One-hot encode integer ids."""
    out = []
    for i in ids:
        if not 0 <= i < num_classes:
            raise ValueError(f"id {i} out of range")
        row = [0] * num_classes
        row[i] = 1
        out.append(row)
    return out
