import time

import numpy as np

from starter import ConstrainedDecoder

VOCAB = ["<eos>", "pos", "neg", "neu", "itive", "ative", "tral", "p", "o", "s", "i", "t", "v", "e", "!", "positive"]
ALLOWED = ["positive", "negative", "neutral"]


def test_mask():
    d = ConstrainedDecoder(VOCAB, ALLOWED, eos_id=0)
    m = d.allowed_mask("")
    assert [VOCAB[i] for i in np.flatnonzero(m)] == ["pos", "neg", "neu", "p", "positive"]
    m = d.allowed_mask("pos")
    assert [VOCAB[i] for i in np.flatnonzero(m)] == ["itive", "i"]
    m = d.allowed_mask("positive")
    assert [VOCAB[i] for i in np.flatnonzero(m)] == ["<eos>"]
    assert not d.allowed_mask("xyz").any()


def test_decode_forces_valid_output():
    d = ConstrainedDecoder(VOCAB, ALLOWED, eos_id=0)

    def logits_fn(ids):
        text = "".join(VOCAB[i] for i in ids)
        z = np.zeros(len(VOCAB))
        z[VOCAB.index("!")] = 10
        z[VOCAB.index("neg")] = 5 if text == "" else 0
        z[VOCAB.index("ative")] = 3
        z[0] = 1
        return z

    text, ids = d.decode(logits_fn)
    assert text == "negative" and ids == [2, 5]


def test_decode_prefers_model_choice_among_valid():
    d = ConstrainedDecoder(VOCAB, ALLOWED, eos_id=0)

    def logits_fn(ids):
        z = np.zeros(len(VOCAB))
        z[VOCAB.index("p")] = 2
        z[VOCAB.index("o")] = 2
        z[VOCAB.index("s")] = 2
        z[VOCAB.index("itive")] = 1
        z[0] = 0.5
        return z

    text, ids = d.decode(logits_fn)
    assert text == "positive" and [VOCAB[i] for i in ids] == ["p", "o", "s", "itive"]


def test_errors():
    for allowed in ([], ["ok", ""]):
        try:
            ConstrainedDecoder(VOCAB, allowed, 0)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
    d = ConstrainedDecoder(["<eos>", "a"], ["aaaa"], 0)
    try:
        d.decode(lambda ids: np.zeros(2), max_steps=2)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except RuntimeError:
        return
    raise AssertionError("expected RuntimeError")


def test_speed_large():
    rng = np.random.default_rng(0)
    letters = list("abcdefghij")
    allowed = sorted({"".join(rng.choice(letters, size=rng.integers(3, 9))) for _ in range(3000)})
    vocab = ["<eos>"] + sorted({"".join(rng.choice(letters, size=rng.integers(1, 4))) for _ in range(3000)})[:1999]
    d = ConstrainedDecoder(vocab, allowed, 0)
    t0 = time.perf_counter()
    text, ids = d.decode(lambda ids: rng.normal(size=len(vocab)))
    assert time.perf_counter() - t0 < 10
    assert text in set(allowed)
