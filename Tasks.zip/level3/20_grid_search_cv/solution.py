import itertools

import numpy as np


def parameter_grid(param_grid):
    """Expand a grid (or list of grids) into parameter dicts."""
    grids = param_grid if isinstance(param_grid, list) else [param_grid]
    out = []
    for g in grids:
        keys = sorted(g)
        for combo in itertools.product(*(g[k] for k in keys)):
            out.append(dict(zip(keys, combo)))
    return out


def _folds(n, k):
    sizes = np.full(k, n // k)
    sizes[: n % k] += 1
    start = 0
    for s in sizes:
        test = np.arange(start, start + s)
        yield np.r_[np.arange(0, start), np.arange(start + s, n)].astype(int), test
        start += s


class GridSearchCV:
    """Exhaustive search over a parameter grid."""

    def __init__(self, make_model, param_grid, cv=3, scoring=None):
        self.make_model, self.param_grid, self.cv = make_model, param_grid, cv
        self.scoring = scoring or (lambda t, p: float(np.mean(np.asarray(t) == np.asarray(p))))

    def fit(self, X, y):
        """Evaluate every combination and refit the best."""
        X, y = np.asarray(X), np.asarray(y)
        self.results_ = []
        for params in parameter_grid(self.param_grid):
            scores = []
            for tr, te in _folds(len(X), self.cv):
                model = self.make_model(**params)
                model.fit(X[tr], y[tr])
                scores.append(float(self.scoring(y[te], model.predict(X[te]))))
            self.results_.append({"params": params, "scores": scores,
                                  "mean_score": float(np.mean(scores)), "std_score": float(np.std(scores))})
        means = [r["mean_score"] for r in self.results_]
        self.best_index_ = int(np.argmax(means))
        self.best_params_ = self.results_[self.best_index_]["params"]
        self.best_score_ = self.results_[self.best_index_]["mean_score"]
        self.best_model_ = self.make_model(**self.best_params_)
        self.best_model_.fit(X, y)
        return self

    def predict(self, X):
        """Predict with the refitted best model."""
        return self.best_model_.predict(X)
