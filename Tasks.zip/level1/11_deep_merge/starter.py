# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import copy

def deep_merge(base, override, list_strategy='replace'):
    """Recursively merge override into a deep copy of base."""
    raise NotImplementedError('TODO')
