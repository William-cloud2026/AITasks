import numpy as np


def speculative_decode(target_logits_fn, draft_logits_fn, prompt, max_new_tokens, k=4, eos_id=None):
    """Greedy speculative decoding."""
    seq = list(prompt)
    stats = {"target_calls": 0, "draft_calls": 0, "proposed": 0, "accepted": 0}
    generated = 0
    while generated < max_new_tokens:
        remaining = max_new_tokens - generated
        proposals = []
        for _ in range(min(k, remaining)):
            tok = int(np.argmax(draft_logits_fn(seq + proposals)))
            stats["draft_calls"] += 1
            proposals.append(tok)
            if tok == eos_id:
                break
        logits = np.asarray(target_logits_fn(seq + proposals))
        stats["target_calls"] += 1
        start = len(seq) - 1
        preds = [int(np.argmax(logits[start + j])) for j in range(len(proposals) + 1)]
        n = 0
        while n < len(proposals) and proposals[n] == preds[n]:
            n += 1
        new = proposals[:n] + [preds[n]]
        new = new[:remaining]
        if eos_id is not None and eos_id in new:
            new = new[:new.index(eos_id) + 1]
        stats["proposed"] += len(proposals)
        stats["accepted"] += n
        seq += new
        generated += len(new)
        if eos_id is not None and new[-1] == eos_id:
            break
    return seq, stats
