import numpy as np


def zscore_outliers(x, threshold=3.0):
    """Boolean mask of z-score outliers."""
    x = np.asarray(x, dtype=float)
    sd = x.std()
    if sd == 0:
        return np.zeros(x.shape, dtype=bool)
    return np.abs(x - x.mean()) / sd > threshold


def iqr_outliers(x, k=1.5):
    """Boolean mask of IQR (Tukey fence) outliers."""
    x = np.asarray(x, dtype=float)
    q1, q3 = np.percentile(x, [25, 75])
    iqr = q3 - q1
    return (x < q1 - k * iqr) | (x > q3 + k * iqr)


class GaussianAnomalyDetector:
    """Multivariate Gaussian / Mahalanobis anomaly detector."""

    def __init__(self, contamination=0.05, reg=1e-6):
        if not 0 < contamination <= 0.5:
            raise ValueError("contamination must be in (0, 0.5]")
        self.contamination, self.reg = contamination, reg

    def fit(self, X):
        """Estimate mean, covariance and threshold."""
        X = np.asarray(X, dtype=float)
        self.mean_ = X.mean(0)
        self.cov_ = np.cov(X, rowvar=False, bias=True).reshape(X.shape[1], X.shape[1]) + self.reg * np.eye(X.shape[1])
        self.precision_ = np.linalg.inv(self.cov_)
        self.threshold_ = float(np.quantile(self.score_samples(X), 1 - self.contamination))
        return self

    def score_samples(self, X):
        """Mahalanobis distances."""
        D = np.asarray(X, dtype=float) - self.mean_
        return np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", D, self.precision_, D), 0.0))

    def predict(self, X):
        """1 for anomalies, 0 otherwise."""
        return (self.score_samples(X) > self.threshold_).astype(int)
