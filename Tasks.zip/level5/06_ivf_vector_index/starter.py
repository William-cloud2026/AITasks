# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class FlatIndex:
    """Exact nearest-neighbor search."""

    def __init__(self, dim, metric='cosine'):
        raise NotImplementedError('TODO')

    def add(self, vectors, ids=None):
        """Append vectors."""
        raise NotImplementedError('TODO')

    def search(self, queries, k):
        """Top-k scores and ids."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')

class IVFIndex:
    """Inverted-file index with k-means coarse quantizer."""

    def __init__(self, dim, n_lists, metric='l2', n_probe=1, seed=0):
        raise NotImplementedError('TODO')

    @property
    def is_trained(self):
        raise NotImplementedError('TODO')

    def train(self, vectors, n_iter=20):
        """Learn coarse centroids with k-means."""
        raise NotImplementedError('TODO')

    def add(self, vectors, ids=None):
        """Assign vectors to inverted lists."""
        raise NotImplementedError('TODO')

    def search(self, queries, k):
        """Approximate top-k search."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')
