import inspect
import math
import random

import starter
from starter import bisect_left, bisect_right, first_true, max_batch_size, search_rotated


def test_bisect_matches_stdlib_semantics():
    import bisect as ref
    rng = random.Random(0)
    for _ in range(200):
        a = sorted(rng.randint(0, 20) for _ in range(rng.randint(0, 15)))
        x = rng.randint(-1, 21)
        assert bisect_left(a, x) == ref.bisect_left(a, x)
        assert bisect_right(a, x) == ref.bisect_right(a, x)


def test_bisect_key():
    recs = [("a", 1), ("b", 3), ("c", 3), ("d", 7)]
    assert bisect_left(recs, 3, key=lambda r: r[1]) == 1
    assert bisect_right(recs, 3, key=lambda r: r[1]) == 3


def test_search_rotated():
    base = list(range(0, 40, 3))
    for k in range(len(base)):
        a = base[k:] + base[:k]
        for i, v in enumerate(a):
            assert search_rotated(a, v) == i
        assert search_rotated(a, 1) == -1
    assert search_rotated([], 5) == -1


def counting(fn):
    calls = []

    def wrapped(x):
        calls.append(x)
        return fn(x)

    return wrapped, calls


def test_first_true():
    for threshold in [0, 1, 500, 999, 1000, 5000]:
        pred, calls = counting(lambda i, t=threshold: i >= t)
        assert first_true(0, 1000, pred) == min(threshold, 1000)
        assert len(calls) <= math.ceil(math.log2(1000)) + 1
    assert first_true(5, 5, lambda i: True) == 5


def test_max_batch_size():
    for cap in [0, 1, 7, 64, 100, 1000]:
        fits, calls = counting(lambda b, c=cap: b <= c)
        assert max_batch_size(fits, 1000) == min(cap, 1000)
        assert len(calls) <= math.ceil(math.log2(1000)) + 2


def test_no_bisect_module():
    src = inspect.getsource(starter)
    assert "import bisect" not in src and "from bisect" not in src
