# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def quantize_symmetric(x, bits=8, axis=None):
    """Symmetric (zero-point 0) quantization."""
    raise NotImplementedError('TODO')

def quantize_asymmetric(x, bits=8):
    """Affine quantization to unsigned integers."""
    raise NotImplementedError('TODO')

def dequantize(q, scale, zero_point=0):
    """Map integers back to floats."""
    raise NotImplementedError('TODO')

def quantized_matmul(xq, x_scale, wq, w_scale):
    """Integer matmul with int32 accumulation."""
    raise NotImplementedError('TODO')

def quantize_linear_layer(W, bits=8):
    """Per-output-channel symmetric weight quantization."""
    raise NotImplementedError('TODO')
