# L3-04 · Logistic Regression

**Level:** 3 · **Topics:** numerical stability, cross-entropy, gradient descent · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `sigmoid(z)`
Element-wise, works on scalars and arrays, numerically stable: no overflow warnings for `|z|` up to `1e4`
(tests turn numpy warnings into errors).

### `bce_loss_and_grad(X, y, w, b, l2=0.0) -> (loss, grad_w, grad_b)`
`loss = mean(log(1 + e^{z}) − y·z) + (l2/2)·‖w‖²` where `z = Xw + b` (this is the binary cross-entropy written
stably — use `np.logaddexp`). `y ∈ {0, 1}`. Bias not regularized.

### `class LogisticRegression(lr=0.1, epochs=1000, l2=0.0)`
- Full-batch gradient descent from `w = 0, b = 0`; records `loss_history_` (loss after every epoch).
- `classes_` = sorted unique labels; exactly two classes required (else `ValueError`); `classes_[1]` is the positive class.
- `predict_proba(X)` → shape `(n,)`, probability of `classes_[1]`.
- `predict(X, threshold=0.5)` → labels from `classes_` (positive if `p >= threshold`).
- `coef_`, `intercept_`.
