from itertools import combinations, combinations_with_replacement

import numpy as np


class PolynomialFeatures:
    """Polynomial and interaction features."""

    def __init__(self, degree=2, include_bias=True, interaction_only=False):
        if degree < 1:
            raise ValueError("degree must be >= 1")
        self.degree, self.include_bias, self.interaction_only = degree, include_bias, interaction_only

    def fit(self, X):
        """Compute output powers."""
        X = np.asarray(X, dtype=float)
        d = X.shape[1]
        self.n_features_in_ = d
        combos = combinations if self.interaction_only else combinations_with_replacement
        rows = [np.zeros(d, dtype=int)] if self.include_bias else []
        for deg in range(1, self.degree + 1):
            for c in combos(range(d), deg):
                row = np.zeros(d, dtype=int)
                for j in c:
                    row[j] += 1
                rows.append(row)
        self.powers_ = np.array(rows, dtype=int).reshape(-1, d)
        return self

    def transform(self, X):
        """Expand features."""
        X = np.asarray(X, dtype=float)
        if X.shape[1] != self.n_features_in_:
            raise ValueError("feature count mismatch")
        return np.prod(X[:, None, :] ** self.powers_[None, :, :], axis=2)

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)

    def get_feature_names_out(self, input_features=None):
        """Human-readable output names."""
        names = input_features or [f"x{i}" for i in range(self.n_features_in_)]
        out = []
        for row in self.powers_:
            terms = [names[j] if p == 1 else f"{names[j]}^{p}" for j, p in enumerate(row) if p]
            out.append(" ".join(terms) if terms else "1")
        return out
