import warnings

import numpy as np

from starter import MultiHeadAttention, causal_mask, scaled_dot_product_attention

rng = np.random.default_rng(0)


def ref_attention(q, k, v, mask=None):
    out = np.zeros(q.shape[:-1] + (v.shape[-1],))
    W = np.zeros(q.shape[:-1] + (k.shape[-2],))
    for idx in np.ndindex(q.shape[:-2]):
        for i in range(q.shape[-2]):
            s = np.array([q[idx][i] @ k[idx][j] / np.sqrt(q.shape[-1]) for j in range(k.shape[-2])])
            allowed = np.ones_like(s, dtype=bool) if mask is None else np.broadcast_to(mask, q.shape[:-2] + (q.shape[-2], k.shape[-2]))[idx][i]
            if not allowed.any():
                continue
            e = np.where(allowed, np.exp(s - s[allowed].max()), 0)
            W[idx][i] = e / e.sum()
            out[idx][i] = W[idx][i] @ v[idx]
    return out, W


def test_causal_mask():
    np.testing.assert_array_equal(causal_mask(3), [[1, 0, 0], [1, 1, 0], [1, 1, 1]])
    assert causal_mask(3).dtype == bool


def test_sdpa_matches_reference():
    q, k, v = rng.normal(size=(2, 3, 4, 8)), rng.normal(size=(2, 3, 5, 8)), rng.normal(size=(2, 3, 5, 6))
    out, w = scaled_dot_product_attention(q, k, v)
    ro, rw = ref_attention(q, k, v)
    np.testing.assert_allclose(out, ro, atol=1e-10)
    np.testing.assert_allclose(w, rw, atol=1e-12)
    np.testing.assert_allclose(w.sum(-1), 1)


def test_causal_and_padding_masks():
    q = k = v = rng.normal(size=(2, 4, 8))
    out, w = scaled_dot_product_attention(q, k, v, causal_mask(4))
    assert np.all(w[:, np.triu_indices(4, 1)[0], np.triu_indices(4, 1)[1]] == 0)
    np.testing.assert_allclose(out, ref_attention(q, k, v, causal_mask(4))[0], atol=1e-10)
    pad = np.array([[True, True, True, False], [True, True, False, False]])[:, None, :]
    out, w = scaled_dot_product_attention(q, k, v, pad)
    assert np.all(w[1, :, 2:] == 0) and np.all(w[0, :, 3] == 0)


def test_fully_masked_rows():
    q = rng.normal(size=(1, 2, 4))
    mask = np.array([[False, False, False], [True, False, True]])
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        out, w = scaled_dot_product_attention(q, rng.normal(size=(1, 3, 4)), rng.normal(size=(1, 3, 2)), mask)
    assert np.all(np.isfinite(out)) and np.all(out[0, 0] == 0) and np.all(w[0, 0] == 0)
    assert np.isclose(w[0, 1].sum(), 1) and w[0, 1, 1] == 0


def test_large_scores_stable():
    q = np.full((1, 1, 2), 1e4)
    k = np.array([[[1e4, 1e4], [-1e4, -1e4]]])
    v = np.array([[[1.0], [2.0]]])
    with np.errstate(over="raise", invalid="raise"):
        out, w = scaled_dot_product_attention(q, k, v)
    np.testing.assert_allclose(out, [[[1.0]]])


def test_mha_matches_manual():
    mha = MultiHeadAttention(16, 4, seed=1)
    r = np.random.default_rng(1)
    np.testing.assert_allclose(mha.Wq, r.normal(0, 0.02, size=(16, 16)))
    mha.bq = rng.normal(size=16)
    mha.bo = rng.normal(size=16)
    x = rng.normal(size=(2, 5, 16))
    mask = causal_mask(5)
    out = mha.forward(x, mask=mask)
    assert out.shape == (2, 5, 16) and mha.last_attn.shape == (2, 4, 5, 5)
    Q, K, V = x @ mha.Wq + mha.bq, x @ mha.Wk + mha.bk, x @ mha.Wv + mha.bv
    heads = []
    for h in range(4):
        sl = slice(4 * h, 4 * h + 4)
        o, _ = ref_attention(Q[..., sl], K[..., sl], V[..., sl], mask)
        heads.append(o)
    expected = np.concatenate(heads, -1) @ mha.Wo + mha.bo
    np.testing.assert_allclose(out, expected, atol=1e-10)


def test_cross_attention_and_errors():
    mha = MultiHeadAttention(8, 2)
    out = mha.forward(rng.normal(size=(3, 2, 8)), rng.normal(size=(3, 7, 8)))
    assert out.shape == (3, 2, 8) and mha.last_attn.shape == (3, 2, 2, 7)
    try:
        MultiHeadAttention(10, 3)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")
