# L2-14 · TF-IDF Vectorizer

**Level:** 2 · **Topics:** NLP feature extraction, vocabulary building, normalization · **Time:** ~40 min · **Allowed:** Python stdlib

## Task
Implement `class TfidfVectorizer(min_df=1, max_features=None, sublinear_tf=False)` (same math as scikit-learn's
defaults, but simpler tokenization).

- Tokenizer: `re.findall(r"\w+", doc.lower())`.
- `fit(docs)` (returns `self`):
  - `df(t)` = number of documents containing `t`; keep terms with `df >= min_df`.
  - if `max_features` is set, keep the `max_features` terms with highest `df` (ties: term ascending).
  - `vocabulary_`: `{term: index}` where indices follow **alphabetical** term order.
  - `idf_`: list aligned with indices, `idf(t) = ln((1 + N) / (1 + df(t))) + 1` (N = number of docs).
- `transform(docs) -> list[list[float]]`: dense rows of length `len(vocabulary_)`;
  `tf` = raw count (or `1 + ln(count)` if `sublinear_tf`), weight = `tf * idf`, then **L2-normalize** each row
  (all-zero rows stay zero). Unknown terms are ignored. Calling before `fit` → `RuntimeError`.
- `fit_transform(docs)`, `get_feature_names_out() -> list[str]` (terms ordered by index).
