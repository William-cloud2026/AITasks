import numpy as np


class PCA:
    """PCA via SVD."""

    def __init__(self, n_components=None, whiten=False):
        self.n_components = n_components
        self.whiten = whiten

    def fit(self, X):
        """Compute principal components."""
        X = np.asarray(X, dtype=float)
        n, d = X.shape
        self.mean_ = X.mean(0)
        _, S, Vt = np.linalg.svd(X - self.mean_, full_matrices=False)
        var = S ** 2 / (n - 1)
        ratio = var / var.sum()
        m = min(n, d)
        nc = self.n_components
        if nc is None:
            k = m
        elif isinstance(nc, float):
            if not 0 < nc < 1:
                raise ValueError("float n_components must be in (0, 1)")
            k = int(np.searchsorted(np.cumsum(ratio), nc - 1e-12) + 1)
        elif isinstance(nc, (int, np.integer)) and not isinstance(nc, bool) and 1 <= nc <= m:
            k = int(nc)
        else:
            raise ValueError("invalid n_components")
        comps = Vt[:k]
        signs = np.sign(comps[np.arange(k), np.argmax(np.abs(comps), axis=1)])
        signs[signs == 0] = 1
        self.components_ = comps * signs[:, None]
        self.explained_variance_ = var[:k]
        self.explained_variance_ratio_ = ratio[:k]
        self.n_components_ = k
        return self

    def transform(self, X):
        """Project onto components."""
        Z = (np.asarray(X, dtype=float) - self.mean_) @ self.components_.T
        return Z / np.sqrt(self.explained_variance_) if self.whiten else Z

    def inverse_transform(self, Z):
        """Map back to input space."""
        Z = np.asarray(Z, dtype=float)
        if self.whiten:
            Z = Z * np.sqrt(self.explained_variance_)
        return Z @ self.components_ + self.mean_

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)
