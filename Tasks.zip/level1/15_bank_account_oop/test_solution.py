from starter import BankAccount, InsufficientFundsError


def test_basic_flow():
    a = BankAccount("Ada", 100)
    assert a.deposit(50) == 150
    assert a.withdraw(30) == 120
    assert a.balance == 120
    assert a.history == [("deposit", 50, 150), ("withdraw", 30, 120)]


def test_readonly_balance():
    a = BankAccount("Ada")
    try:
        a.balance = 1000
    except AttributeError:
        return
    raise AssertionError("balance must be read-only")


def test_insufficient_funds():
    a = BankAccount("Ada", 10)
    try:
        a.withdraw(11)
    except InsufficientFundsError:
        pass
    else:
        raise AssertionError("expected InsufficientFundsError")
    assert a.balance == 10 and a.history == []
    assert issubclass(InsufficientFundsError, Exception)


def test_invalid_amounts():
    a = BankAccount("Ada", 10)
    for fn in (lambda: a.deposit(0), lambda: a.withdraw(-5), lambda: BankAccount("x", -1)):
        try:
            fn()
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_transfer_atomic():
    a, b = BankAccount("A", 50), BankAccount("B", 0)
    a.transfer_to(b, 20)
    assert (a.balance, b.balance) == (30, 20)
    assert a.history[-1] == ("transfer_out", 20, 30)
    assert b.history[-1] == ("transfer_in", 20, 20)
    try:
        a.transfer_to(b, 1000)
    except InsufficientFundsError:
        pass
    assert (a.balance, b.balance) == (30, 20)


def test_history_is_copy_and_repr():
    a = BankAccount("Ada", 100)
    a.history.append(("hack", 1, 1))
    assert a.history == []
    assert repr(a) == "BankAccount(owner='Ada', balance=100)"
