# L3-05 · k-Nearest Neighbors

**Level:** 3 · **Topics:** vectorized distances, voting, tie-breaking · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `class KNNClassifier(k=5, metric="euclidean", weights="uniform")` and `class KNNRegressor(...)` (same args)
- `metric`: `"euclidean"` or `"manhattan"`; `weights`: `"uniform"` or `"distance"`; `k < 1` → `ValueError`;
  unknown option → `ValueError` (in the constructor).
- `fit(X, y)` stores the data (returns `self`); classifier sets `classes_` (sorted unique labels).
- `kneighbors(X) -> (distances, indices)`, shapes `(n_query, k_eff)` with `k_eff = min(k, n_train)`, neighbors
  ordered by distance; equal distances → lower training index first (use a **stable** sort).
  Must be vectorized (a test uses 2 000 × 2 000 points).
- Neighbor weights: uniform → `1`; distance → `1 / d`. **Special case:** if any of a query's neighbors has
  distance `0`, use only the zero-distance neighbors, each with weight `1`.
- Classifier: `predict_proba(X)` → `(n_query, n_classes)` normalized weight per class (columns follow `classes_`);
  `predict(X)` = class with the highest probability, ties → the smallest class (first in `classes_`).
- Regressor: `predict(X)` = weighted mean of neighbor targets.
