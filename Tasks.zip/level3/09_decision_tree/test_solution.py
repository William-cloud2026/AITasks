import time

import numpy as np

from starter import DecisionTreeClassifier


def test_simple_split():
    t = DecisionTreeClassifier().fit([[1.0], [2.0], [3.0], [4.0]], [0, 0, 1, 1])
    assert t.root_split() == (0, 2.5)
    assert t.get_depth() == 1 and t.get_n_leaves() == 2
    assert list(t.predict([[0.0], [2.4], [2.6], [9.0]])) == [0, 0, 1, 1]


def test_tie_prefers_lower_feature():
    X = [[1, 5], [2, 6], [3, 1], [4, 2]]
    t = DecisionTreeClassifier().fit(X, ["a", "a", "b", "b"])
    assert t.root_split() == (0, 2.5)


def test_best_feature_chosen():
    X = [[1, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6]]
    y = [0, 1, 0, 1, 1, 1]
    Xs = [[a, b * (1 if c else -1)] for (a, b), c in zip(X, y)]
    t = DecisionTreeClassifier().fit(Xs, y)
    assert t.root_split()[0] == 1 and np.isclose(t.root_split()[1], 0.5)


def test_pure_and_constant():
    t = DecisionTreeClassifier().fit([[1], [2]], [3, 3])
    assert t.root_split() is None and t.get_depth() == 0
    t = DecisionTreeClassifier().fit([[1], [1], [1]], [0, 1, 1])
    assert t.root_split() is None
    np.testing.assert_allclose(t.predict_proba([[5]]), [[1 / 3, 2 / 3]])
    assert t.predict([[5]])[0] == 1


def test_depth_and_leaf_limits():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(300, 3))
    y = ((X[:, 0] > 0) ^ (X[:, 1] > 0.5) ^ (rng.random(300) < 0.1)).astype(int)
    full = DecisionTreeClassifier().fit(X, y)
    assert np.mean(full.predict(X) == y) == 1.0
    stump = DecisionTreeClassifier(max_depth=1).fit(X, y)
    assert stump.get_depth() == 1 and stump.get_n_leaves() == 2
    leafy = DecisionTreeClassifier(min_samples_leaf=20).fit(X, y)
    assert leafy.get_n_leaves() < full.get_n_leaves() and leafy.get_n_leaves() <= 300 // 20
    big = DecisionTreeClassifier(min_samples_split=1000).fit(X, y)
    assert big.get_n_leaves() == 1


def test_proba_columns_and_generalization():
    rng = np.random.default_rng(1)
    X = rng.uniform(-1, 1, size=(400, 2))
    y = np.where(X[:, 0] + X[:, 1] > 0, "pos", "neg")
    t = DecisionTreeClassifier(max_depth=6).fit(X[:300], y[:300])
    assert list(t.classes_) == ["neg", "pos"]
    assert np.mean(t.predict(X[300:]) == y[300:]) > 0.85
    P = t.predict_proba(X[300:])
    assert P.shape == (100, 2) and np.allclose(P.sum(1), 1)


def test_speed():
    rng = np.random.default_rng(2)
    X = rng.normal(size=(400, 5))
    y = rng.integers(0, 3, size=400)
    t0 = time.perf_counter()
    DecisionTreeClassifier().fit(X, y)
    assert time.perf_counter() - t0 < 10
