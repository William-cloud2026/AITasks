# L1-02 · Word Frequency Counter

**Level:** 1 · **Topics:** strings, regex, dict counting, sorting · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
Implement `word_frequency(text, top_k=None) -> list[tuple[str, int]]`.

1. Lower-case the text.
2. Tokens are maximal runs matching the regex `[a-z0-9']+`.
3. Strip leading/trailing apostrophes from each token; drop tokens that become empty.
4. Count tokens and return `(word, count)` pairs sorted by **count descending**, then **word ascending**.
5. If `top_k` is given, return only the first `top_k` pairs. `top_k=0` returns `[]`.

## Errors
- `top_k < 0` → `ValueError`

## Example
```python
word_frequency("Don't stop. don't STOP! 'go'")
# [("don't", 2), ('stop', 2), ('go', 1)]
```
