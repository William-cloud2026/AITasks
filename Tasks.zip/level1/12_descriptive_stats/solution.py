import math
from collections import Counter


def _check(xs):
    xs = list(xs)
    if not xs:
        raise ValueError("empty data")
    return xs


def mean(xs):
    """Arithmetic mean."""
    xs = _check(xs)
    return sum(xs) / len(xs)


def median(xs):
    """Median (mean of middle two for even n)."""
    xs = sorted(_check(xs))
    n = len(xs)
    mid = n // 2
    return float(xs[mid]) if n % 2 else (xs[mid - 1] + xs[mid]) / 2


def mode(xs):
    """Most frequent value, smallest on ties."""
    counts = Counter(_check(xs))
    best = max(counts.values())
    return min(v for v, c in counts.items() if c == best)


def variance(xs, sample=False):
    """Population (default) or sample variance."""
    xs = _check(xs)
    n = len(xs)
    if sample and n < 2:
        raise ValueError("sample variance needs at least 2 values")
    m = sum(xs) / n
    return sum((x - m) ** 2 for x in xs) / (n - 1 if sample else n)


def stdev(xs, sample=False):
    """Square root of variance."""
    return math.sqrt(variance(xs, sample))


def zscores(xs):
    """Standardized scores using population stdev."""
    xs = _check(xs)
    m, s = mean(xs), stdev(xs)
    if s == 0:
        return [0.0] * len(xs)
    return [(x - m) / s for x in xs]
