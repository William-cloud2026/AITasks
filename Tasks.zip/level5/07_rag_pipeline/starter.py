# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re

def build_prompt(question, chunks, max_context_tokens, count_tokens=None):
    """Pack chunks into a prompt within a token budget."""
    raise NotImplementedError('TODO')

def extract_citations(answer):
    """Sorted unique citation numbers."""
    raise NotImplementedError('TODO')

class RAGPipeline:
    """Retrieve, pack, generate, validate citations."""

    def __init__(self, retriever, llm, max_context_tokens=500, top_k=5, count_tokens=None):
        raise NotImplementedError('TODO')

    def answer(self, question):
        """Answer a question with citations."""
        raise NotImplementedError('TODO')
