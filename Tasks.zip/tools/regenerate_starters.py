"""Rebuild starter stubs (levelX/*/starter.py) from the solutions (levelX/*/solution.py).

Every public function/method keeps its signature and docstring; its body becomes
`raise NotImplementedError('TODO')`. Private helpers (leading underscore) are dropped,
except private classes used as base classes. WARNING: overwrites levelX/*/starter.py.

Usage: python tools/regenerate_starters.py [levelX/NN_task ...]
"""
import ast
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

HEADER = (
    "# Starter file - implement everything marked TODO.\n"
    "# Read README.md for the full specification. Do not rename public functions/classes.\n\n"
)


def _stub_function(node):
    body = []
    if (node.body and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str)):
        body.append(node.body[0])
    body.append(ast.parse("raise NotImplementedError('TODO')").body[0])
    node.body = body
    return node


def _is_private(name):
    return name.startswith("_") and not (name.startswith("__") and name.endswith("__"))


def _keep(n):
    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and _is_private(n.name):
        return False
    if isinstance(n, ast.Assign) and all(isinstance(t, ast.Name) and _is_private(t.id) for t in n.targets):
        return False
    if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and _is_private(n.target.id):
        return False
    return True


def make_starter(src):
    tree = ast.parse(src)
    bases = {b.id for n in tree.body if isinstance(n, ast.ClassDef) for b in n.bases if isinstance(b, ast.Name)}
    body = []
    for n in tree.body:
        if not _keep(n) and not (isinstance(n, ast.ClassDef) and n.name in bases):
            continue
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            n = _stub_function(n)
        elif isinstance(n, ast.ClassDef):
            new = []
            for m in n.body:
                if not _keep(m):
                    continue
                if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    m = _stub_function(m)
                new.append(m)
            n.body = new or [ast.Pass()]
        body.append(n)
    tree.body = body
    return HEADER + ast.unparse(tree) + "\n"


def main(targets):
    refs = sorted(ROOT.glob("level*/*/solution.py"))
    if targets:
        wanted = {pathlib.Path(t).as_posix().strip("/") for t in targets}
        refs = [r for r in refs if r.parent.relative_to(ROOT).as_posix() in wanted]
    for ref in refs:
        out = ref.parent / "starter.py"
        out.write_text(make_starter(ref.read_text(encoding="utf-8")), encoding="utf-8")
        print("regenerated", out.relative_to(ROOT).as_posix())


if __name__ == "__main__":
    main(sys.argv[1:])
