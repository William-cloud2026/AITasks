# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def skipgram_pairs(ids, window):
    """(center, context) pairs."""
    raise NotImplementedError('TODO')

def noise_distribution(counts, power=0.75):
    """Smoothed unigram distribution."""
    raise NotImplementedError('TODO')

def sgns_loss_and_grads(v_c, u_o, U_neg):
    """Negative-sampling loss and gradients."""
    raise NotImplementedError('TODO')

class SkipGramNS:
    """Skip-gram with negative sampling."""

    def __init__(self, vocab_size, dim=16, seed=0):
        raise NotImplementedError('TODO')

    def train(self, pairs, noise_probs, epochs=5, lr=0.05, k=5):
        """SGD over (center, context) pairs."""
        raise NotImplementedError('TODO')

    def most_similar(self, word_id, topn=5):
        """Nearest words by cosine similarity."""
        raise NotImplementedError('TODO')
