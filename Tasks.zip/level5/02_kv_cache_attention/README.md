# L5-02 · KV-Cached Incremental Attention (with Sliding Window)

**Level:** 5 · **Topics:** LLM inference optimization, caching, attention masks · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class CachedSelfAttention(Wq, Wk, Wv, Wo, n_heads, window=None)` — a multi-head causal self-attention
layer (no biases) with an incremental decoding cache. Weights are `(d, d)` with `x @ W` convention; head `h` uses
feature columns `h·dh:(h+1)·dh`.

- `forward_full(x)`: `x (T, d)` → `(T, d)` with a causal mask; if `window` is set, query `i` may only attend to keys
  `j` with `i − window < j <= i` (sliding-window attention). Does **not** touch the cache.
- `step(x_t)`: `x_t (d,)` is the next token's input. Append its key/value to the cache and return the output `(d,)`
  for that position. Results must equal the corresponding rows of `forward_full` on the whole sequence so far.
- With `window`, the cache must **never hold more than `window` entries** (evict the oldest).
- `cache_len` property; `reset()` clears the cache.
- `prefill(x)`: `x (T, d)` — same as calling `step` for each row, returns `(T, d)`, but should be computed in one batched
  pass (then leave the cache in the same state as after `T` steps).
