# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def confusion_matrix(y_true, y_pred):
    """Return tp/fp/tn/fn counts."""
    raise NotImplementedError('TODO')

def accuracy(y_true, y_pred):
    """Fraction correct."""
    raise NotImplementedError('TODO')

def precision(y_true, y_pred):
    """tp / (tp + fp)."""
    raise NotImplementedError('TODO')

def recall(y_true, y_pred):
    """tp / (tp + fn)."""
    raise NotImplementedError('TODO')

def fbeta_score(y_true, y_pred, beta):
    """F-beta score."""
    raise NotImplementedError('TODO')

def f1_score(y_true, y_pred):
    """F1 score."""
    raise NotImplementedError('TODO')
