# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class _KNNBase:

    def __init__(self, k=5, metric='euclidean', weights='uniform'):
        raise NotImplementedError('TODO')

    def kneighbors(self, X):
        """Distances and indices of the k nearest training points."""
        raise NotImplementedError('TODO')

class KNNClassifier(_KNNBase):
    """k-NN classifier."""

    def fit(self, X, y):
        """Store training data."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Class probability estimates."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predicted labels."""
        raise NotImplementedError('TODO')

class KNNRegressor(_KNNBase):
    """k-NN regressor."""

    def fit(self, X, y):
        """Store training data."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Weighted mean of neighbor targets."""
        raise NotImplementedError('TODO')
