# L3-06 · k-Means Clustering (k-means++)

**Level:** 3 · **Topics:** unsupervised learning, randomized init, convergence · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class KMeans(n_clusters, init="k-means++", n_init=10, max_iter=300, tol=1e-6, seed=0)`.

- `fit(X)`: run `n_init` independent runs (all drawing from **one** `np.random.default_rng(seed)`), keep the run with
  the lowest inertia. Returns `self`. `n_clusters > n_samples` or `< 1` → `ValueError`.
- Initialization:
  - `"random"`: choose `n_clusters` distinct samples uniformly.
  - `"k-means++"`: first center uniform; each next center sampled with probability ∝ squared distance to the nearest
    chosen center.
- Lloyd iterations: assign each point to the nearest center (ties → lowest index), recompute means.
  If a cluster becomes **empty**, move its center to the point farthest from its currently assigned center.
  Stop when the total squared center shift `<= tol` or after `max_iter` iterations.
- Attributes: `cluster_centers_ (k, d)`, `labels_ (n,)`, `inertia_` (sum of squared distances to assigned
  centers), `n_iter_`.
- `predict(X)` → nearest center index; `transform(X)` → `(n, k)` Euclidean distances to the centers.
