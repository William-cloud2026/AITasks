_PAIRS = {")": "(", "]": "[", "}": "{"}


def first_error_index(s):
    """Index of the first bracket error, or -1."""
    stack = []
    for i, c in enumerate(s):
        if c in "([{":
            stack.append(i)
        elif c in _PAIRS:
            if not stack or s[stack[-1]] != _PAIRS[c]:
                return i
            stack.pop()
    return stack[0] if stack else -1


def is_balanced(s):
    """True if brackets are balanced."""
    return first_error_index(s) == -1
