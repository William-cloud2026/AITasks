from starter import word_frequency


def test_example():
    assert word_frequency("Don't stop. don't STOP! 'go'") == [("don't", 2), ("stop", 2), ("go", 1)]


def test_tie_break_alphabetical():
    assert word_frequency("b a c b a c") == [("a", 2), ("b", 2), ("c", 2)]


def test_top_k():
    text = "the cat and the hat and the bat"
    assert word_frequency(text, top_k=2) == [("the", 3), ("and", 2)]
    assert word_frequency(text, top_k=0) == []
    assert len(word_frequency(text, top_k=100)) == 5


def test_numbers_and_apostrophes():
    assert word_frequency("'''  42 42 rock'n'roll ''") == [("42", 2), ("rock'n'roll", 1)]


def test_empty():
    assert word_frequency("") == []
    assert word_frequency("!!! ...") == []


def test_negative_top_k():
    try:
        word_frequency("a", top_k=-1)
    except ValueError:
        return
    raise AssertionError("expected ValueError")
