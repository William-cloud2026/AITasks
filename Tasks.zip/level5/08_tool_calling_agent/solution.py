import json
import re


class ToolError(Exception):
    """Raised when a tool call is invalid or fails."""


_TYPES = {
    "string": lambda v: isinstance(v, str),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
}


class ToolRegistry:
    """Named tools with argument schemas."""

    def __init__(self):
        self._tools = {}

    def register(self, name, fn, schema, description=""):
        """Add a tool."""
        if name in self._tools:
            raise ValueError(f"tool {name!r} already registered")
        self._tools[name] = (fn, schema, description)

    def call(self, name, arguments):
        """Validate arguments and run a tool."""
        if name not in self._tools:
            raise ToolError(f"unknown tool {name!r}")
        if not isinstance(arguments, dict):
            raise ToolError("arguments must be an object")
        fn, schema, _ = self._tools[name]
        for p, spec in schema.items():
            if p not in arguments:
                if spec.get("required", True):
                    raise ToolError(f"missing required argument {p!r}")
            elif not _TYPES[spec["type"]](arguments[p]):
                raise ToolError(f"argument {p!r} must be of type {spec['type']}")
        for p in arguments:
            if p not in schema:
                raise ToolError(f"unexpected argument {p!r}")
        try:
            return fn(**arguments)
        except Exception as exc:
            raise ToolError(str(exc)) from exc

    def describe(self):
        """Human/LLM-readable tool list."""
        lines = []
        for name in sorted(self._tools):
            _, schema, desc = self._tools[name]
            params = ", ".join(f"{p}{'' if s.get('required', True) else '?'}: {s['type']}" for p, s in schema.items())
            lines.append(f"- {name}({params}): {desc}")
        return "\n".join(lines)


def parse_action(text):
    """Classify an LLM reply as final / tool / invalid."""
    if "FINAL:" in text:
        return ("final", text.split("FINAL:", 1)[1].strip())
    m = re.search(r"```(?:json)?\s*\n?(.*?)```", text, re.S)
    if m:
        payload = m.group(1)
    elif text.strip().startswith("{"):
        payload = text.strip()
    else:
        return ("invalid", "no tool call or final answer found")
    try:
        obj = json.loads(payload)
    except json.JSONDecodeError as e:
        return ("invalid", f"malformed JSON: {e.msg}")
    if not isinstance(obj, dict) or not isinstance(obj.get("tool"), str):
        return ("invalid", "tool call must be an object with a string 'tool'")
    args = obj.get("arguments", {})
    if not isinstance(args, dict):
        return ("invalid", "'arguments' must be an object")
    return ("tool", obj["tool"], args)


class Agent:
    """ReAct-style loop over an injected LLM."""

    def __init__(self, llm, registry, max_steps=5, system_prompt=None):
        self.llm, self.registry, self.max_steps = llm, registry, max_steps
        self.system_prompt = system_prompt

    def run(self, task):
        """Run the agent until a final answer or max_steps."""
        system = self.system_prompt or (
            "You are a helpful agent. Use tools by replying with a JSON code block "
            '{"tool": ..., "arguments": {...}}. When done reply with FINAL: <answer>.\nTools:\n'
            + self.registry.describe())
        messages = [{"role": "system", "content": system}, {"role": "user", "content": task}]
        steps = []
        for _ in range(self.max_steps):
            reply = self.llm(messages)
            messages.append({"role": "assistant", "content": reply})
            action = parse_action(reply)
            if action[0] == "final":
                return {"answer": action[1], "stopped": "final", "steps": steps, "messages": messages}
            if action[0] == "tool":
                _, name, args = action
                try:
                    result = self.registry.call(name, args)
                    payload, step = {"tool": name, "result": result}, {"tool": name, "arguments": args, "result": result}
                except ToolError as exc:
                    payload, step = {"tool": name, "error": str(exc)}, {"tool": name, "arguments": args, "error": str(exc)}
                messages.append({"role": "tool", "content": json.dumps(payload)})
                steps.append(step)
            else:
                reason = action[1]
                messages.append({"role": "user", "content":
                                 f"Invalid action: {reason}. Reply with a JSON tool call or FINAL: <answer>."})
                steps.append({"tool": None, "arguments": None, "error": reason})
        return {"answer": None, "stopped": "max_steps", "steps": steps, "messages": messages}
