# L4-06 · MLP Classifier Trained from Scratch

**Level:** 4 · **Topics:** end-to-end training, mini-batching, initialization, Adam · **Time:** ~75 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class MLPClassifier(hidden_sizes=(64, 64), lr=0.01, epochs=200, batch_size=32, l2=0.0, seed=0)`.
The architecture and training details are **your design**, but the following contract is tested:

- Hidden layers use ReLU; the output is a softmax over `classes_` (sorted unique labels, any hashable type).
- `fit(X, y)` returns `self`, trains with mini-batches (shuffled each epoch), all randomness from `seed`
  (two fits with the same seed give identical predictions). Records the mean training loss of each epoch in
  `loss_history_` (length `epochs`).
- `predict_proba(X)` `(n, n_classes)` rows sum to 1; `predict(X)` labels.
- On the 3-arm **spiral** dataset used in the tests (300 points, not linearly separable) the training accuracy
  must be **≥ 0.95** with the default hyper-parameters, within 60 s.

Hints: He initialization, Adam optimizer, numerically stable softmax cross-entropy.
