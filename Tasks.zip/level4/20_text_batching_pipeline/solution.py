from collections import Counter

import numpy as np


class Vocab:
    """Token <-> id mapping with special tokens."""

    def __init__(self, itos):
        self.itos = list(itos)
        self.stoi = {t: i for i, t in enumerate(self.itos)}
        self.specials = []

    @classmethod
    def build(cls, token_lists, min_freq=1, max_size=None, specials=("<pad>", "<unk>")):
        """Build from tokenized texts."""
        if "<unk>" not in specials:
            raise ValueError("'<unk>' must be a special token")
        counts = Counter(t for toks in token_lists for t in toks)
        words = sorted((t for t, c in counts.items() if c >= min_freq and t not in specials),
                       key=lambda t: (-counts[t], t))
        itos = list(specials) + words
        if max_size is not None:
            itos = itos[:max_size]
        v = cls(itos)
        v.specials = list(specials)
        return v

    def __len__(self):
        return len(self.itos)

    def __getitem__(self, token):
        return self.stoi.get(token, self.unk_id)

    @property
    def unk_id(self):
        return self.stoi["<unk>"]

    @property
    def pad_id(self):
        return self.stoi.get("<pad>")

    def lookup_token(self, idx):
        """Id -> token."""
        return self.itos[idx]

    def encode(self, tokens):
        """Tokens -> ids."""
        return [self[t] for t in tokens]

    def decode(self, ids, skip_specials=False):
        """Ids -> tokens."""
        toks = [self.itos[i] for i in ids]
        return [t for t in toks if t not in self.specials] if skip_specials else toks


def collate(sequences, pad_id, max_len=None, padding_side="right", truncation_side="right"):
    """Pad/truncate sequences into (ids, mask) arrays."""
    if not sequences:
        raise ValueError("empty batch")
    if padding_side not in ("left", "right") or truncation_side not in ("left", "right"):
        raise ValueError("invalid side")
    L = max(len(s) for s in sequences)
    if max_len is not None:
        L = min(L, max_len)
    ids = np.full((len(sequences), L), pad_id, dtype=np.int64)
    mask = np.zeros((len(sequences), L), dtype=np.int64)
    for i, s in enumerate(sequences):
        s = list(s)
        if len(s) > L:
            s = s[:L] if truncation_side == "right" else s[len(s) - L:]
        n = len(s)
        if n == 0:
            continue
        if padding_side == "right":
            ids[i, :n], mask[i, :n] = s, 1
        else:
            ids[i, L - n:], mask[i, L - n:] = s, 1
    return ids, mask


def bucket_batches(lengths, batch_size, shuffle=False, seed=None):
    """Length-sorted batches of indices."""
    order = sorted(range(len(lengths)), key=lambda i: lengths[i])
    batches = [order[i:i + batch_size] for i in range(0, len(order), batch_size)]
    if shuffle:
        perm = np.random.default_rng(seed).permutation(len(batches))
        batches = [batches[i] for i in perm]
    return batches
