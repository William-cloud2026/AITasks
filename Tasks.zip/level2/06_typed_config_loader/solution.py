import dataclasses
import types
import typing


class ConfigError(ValueError):
    """Raised for any config validation problem."""


def _convert(tp, value, path):
    origin = typing.get_origin(tp)
    args = typing.get_args(tp)
    if origin in (typing.Union, types.UnionType):
        if value is None and type(None) in args:
            return None
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) != 1:
            raise ConfigError(f"{path}: unsupported union type")
        if value is None:
            raise ConfigError(f"{path}: expected {non_none[0]}, got None")
        return _convert(non_none[0], value, path)
    if dataclasses.is_dataclass(tp):
        if not isinstance(value, dict):
            raise ConfigError(f"{path}: expected dict, got {type(value).__name__}")
        return _build(tp, value, path)
    if origin is list:
        if not isinstance(value, list):
            raise ConfigError(f"{path}: expected list, got {type(value).__name__}")
        return [_convert(args[0], v, f"{path}[{i}]") for i, v in enumerate(value)]
    if origin is dict:
        if not isinstance(value, dict):
            raise ConfigError(f"{path}: expected dict, got {type(value).__name__}")
        out = {}
        for k, v in value.items():
            if not isinstance(k, str):
                raise ConfigError(f"{path}: dict keys must be str")
            out[k] = _convert(args[1], v, f"{path}[{k}]")
        return out
    if tp is float:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ConfigError(f"{path}: expected float, got {type(value).__name__}")
        return float(value)
    if tp is int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"{path}: expected int, got {type(value).__name__}")
        return value
    if tp in (str, bool):
        if type(value) is not tp:
            raise ConfigError(f"{path}: expected {tp.__name__}, got {type(value).__name__}")
        return value
    raise ConfigError(f"{path}: unsupported type {tp!r}")


def _build(cls, data, prefix):
    hints = typing.get_type_hints(cls)
    fields = {f.name: f for f in dataclasses.fields(cls)}
    for key in data:
        if key not in fields:
            raise ConfigError(f"{prefix or '<root>'}: unknown key {key!r}")
    kwargs = {}
    for name, f in fields.items():
        path = f"{prefix}.{name}" if prefix else name
        if name in data:
            kwargs[name] = _convert(hints[name], data[name], path)
        elif f.default is dataclasses.MISSING and f.default_factory is dataclasses.MISSING:
            raise ConfigError(f"{path}: missing required field")
    return cls(**kwargs)


def from_dict(cls, data):
    """Build dataclass `cls` from a dict, validating types."""
    if not dataclasses.is_dataclass(cls):
        raise TypeError("cls must be a dataclass")
    if not isinstance(data, dict):
        raise ConfigError(f"<root>: expected dict, got {type(data).__name__}")
    return _build(cls, data, "")
