import numpy as np


class ALSRecommender:
    """Explicit-feedback matrix factorization via ALS."""

    def __init__(self, n_factors=5, reg=0.1, n_iters=20, seed=0):
        self.n_factors, self.reg, self.n_iters, self.seed = n_factors, reg, n_iters, seed

    @staticmethod
    def _solve_rows(R, mask, F, reg):
        k = F.shape[1]
        out = np.zeros((R.shape[0], k))
        for r in range(R.shape[0]):
            obs = mask[r]
            if obs.any():
                Fo = F[obs]
                out[r] = np.linalg.solve(Fo.T @ Fo + reg * np.eye(k), Fo.T @ R[r, obs])
        return out

    def fit(self, R):
        """Alternate user/item least-squares updates."""
        R = np.asarray(R, dtype=float)
        mask = ~np.isnan(R)
        Rz = np.where(mask, R, 0.0)
        rng = np.random.default_rng(self.seed)
        U = rng.normal(scale=0.1, size=(R.shape[0], self.n_factors))
        V = rng.normal(scale=0.1, size=(R.shape[1], self.n_factors))
        self.loss_history_ = []
        for _ in range(self.n_iters):
            U = self._solve_rows(Rz, mask, V, self.reg)
            V = self._solve_rows(Rz.T, mask.T, U, self.reg)
            err = (Rz - U @ V.T)[mask]
            self.loss_history_.append(float(err @ err + self.reg * ((U ** 2).sum() + (V ** 2).sum())))
        self.user_factors_, self.item_factors_ = U, V
        self._seen = mask
        return self

    def predict(self, u, i):
        """Predicted rating."""
        return float(self.user_factors_[u] @ self.item_factors_[i])

    def predict_all(self):
        """Full predicted matrix."""
        return self.user_factors_ @ self.item_factors_.T

    def rmse(self, R):
        """RMSE over observed entries of R."""
        R = np.asarray(R, dtype=float)
        mask = ~np.isnan(R)
        diff = (self.predict_all() - np.where(mask, R, 0.0))[mask]
        return float(np.sqrt(np.mean(diff ** 2)))

    def recommend(self, u, n=5, exclude_seen=True):
        """Top-n item indices for user u."""
        scores = self.predict_all()[u]
        order = np.argsort(-scores, kind="stable")
        if exclude_seen:
            order = [i for i in order if not self._seen[u, i]]
        return [int(i) for i in order[:n]]
