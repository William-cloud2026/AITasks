from starter import merge_intervals, total_covered


def test_example():
    assert merge_intervals([(8, 10), (1, 3), (2, 6), (15, 18)]) == [(1, 6), (8, 10), (15, 18)]


def test_touching():
    assert merge_intervals([(3, 5), (1, 3)]) == [(1, 5)]


def test_contained_and_lists():
    assert merge_intervals([[1, 10], [2, 3], [4, 5]]) == [(1, 10)]


def test_empty_and_points():
    assert merge_intervals([]) == []
    assert merge_intervals([(2, 2), (2, 2)]) == [(2, 2)]


def test_floats_total():
    assert abs(total_covered([(0.5, 1.5), (1.0, 2.0), (3, 4)]) - 2.5) < 1e-12
    assert total_covered([]) == 0


def test_no_mutation():
    data = [[5, 6], [1, 2]]
    merge_intervals(data)
    assert data == [[5, 6], [1, 2]]


def test_invalid():
    try:
        merge_intervals([(3, 1)])
    except ValueError:
        return
    raise AssertionError("expected ValueError")
