# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import heapq

class OutOfBlocksError(Exception):
    """Raised when not enough free blocks are available."""

class PagedKVCache:
    """Block allocator with reference counting and copy-on-write."""

    def __init__(self, num_blocks, block_size):
        raise NotImplementedError('TODO')

    @property
    def num_free_blocks(self):
        raise NotImplementedError('TODO')

    def refcount(self, block):
        """Reference count of a physical block."""
        raise NotImplementedError('TODO')

    def add_sequence(self, seq_id):
        """Register an empty sequence."""
        raise NotImplementedError('TODO')

    def append_tokens(self, seq_id, n=1):
        """Grow a sequence by n tokens."""
        raise NotImplementedError('TODO')

    def fork(self, src_id, dst_id):
        """Share src's blocks with a new sequence dst."""
        raise NotImplementedError('TODO')

    def free_sequence(self, seq_id):
        """Release a sequence's blocks."""
        raise NotImplementedError('TODO')

    def block_table(self, seq_id):
        """Copy of the block table."""
        raise NotImplementedError('TODO')

    def length(self, seq_id):
        """Number of tokens."""
        raise NotImplementedError('TODO')

    def slot(self, seq_id, pos):
        """Physical slot of a token position."""
        raise NotImplementedError('TODO')
