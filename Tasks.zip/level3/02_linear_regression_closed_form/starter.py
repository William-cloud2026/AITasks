# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def r2_score(y_true, y_pred):
    """Coefficient of determination."""
    raise NotImplementedError('TODO')

class LinearRegression:
    """OLS / ridge regression via closed form."""

    def __init__(self, fit_intercept=True, alpha=0.0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Fit coefficients."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Predict targets."""
        raise NotImplementedError('TODO')

    def score(self, X, y):
        """R^2 of predictions."""
        raise NotImplementedError('TODO')
