# L2-05 · Inference Log Analytics

**Level:** 2 · **Topics:** JSON lines, aggregation, percentiles, robustness · **Time:** ~35 min · **Allowed:** Python stdlib

## Task
An inference server writes one JSON object per line:
`{"ts": "...", "level": "INFO", "endpoint": "/v1/chat", "latency_ms": 123.4, "status": 200}`

Implement `analyze_logs(lines) -> dict` where `lines` is any iterable of strings.

- Blank / whitespace-only lines are ignored (not counted anywhere).
- A line is **malformed** if it is not valid JSON, is not a JSON object, lacks any of `level`, `endpoint`,
  `latency_ms`, `status`, or if `latency_ms` is not a number (`int`/`float`, not `bool`) or `status` is not an `int`.
- Return:
```python
{
  "total": <valid lines>,
  "malformed": <malformed lines>,
  "by_level": {level: count, ...},
  "endpoints": {
     endpoint: {"count": int, "p50": float, "p95": float, "error_rate": float}, ...
  },
}
```
- Percentiles use the **nearest-rank** method: sort values, `rank = ceil(p / 100 * n)`, value = `sorted[rank - 1]`.
- `error_rate` = fraction of that endpoint's requests with `status >= 500`.
