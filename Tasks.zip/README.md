# Python & AI Engineering Test Tasks

100 hands-on coding tasks for evaluating **software and AI engineers** in Python — 5 difficulty levels × 20 tasks.
Every task is **fully offline**: no internet, no model downloads, no API keys, no datasets to fetch. Data is
synthetic or embedded, and LLMs/embedding models are replaced by small injected functions.

| Level | Theme | Allowed libraries | Typical time / task |
|---|---|---|---|
| **1** | Python fundamentals (strings, collections, OOP, basic ML data handling) | stdlib only | 15–30 min |
| **2** | Intermediate Python & data structures (decorators, generators, parsing, search, NLP utilities) | stdlib only | 30–60 min |
| **3** | Classical machine learning from scratch | stdlib + numpy | 30–60 min |
| **4** | Deep learning & NLP building blocks from scratch (autograd, backprop, CNN, attention, tokenizers) | stdlib + numpy | 35–75 min |
| **5** | Advanced AI engineering (transformer inference, RAG, agents, serving, quantization, distributed) | stdlib + numpy | 50–90 min |

## Requirements
- Python **3.10+** (developed on 3.11)
- `numpy` (Levels 3–5). `pytest` is optional — a built-in runner is included.

No other packages are needed or allowed (scikit-learn, torch, etc. are **not** available to candidates).

New to some of the topics? **[CONCEPTS.md](CONCEPTS.md)** explains the ideas behind the tasks (RAG, attention,
KV cache, LoRA, ...) and maps each concept to the tasks that practise it.

Setting up a machine without internet? See **[SETUP_OFFLINE.md](SETUP_OFFLINE.md)** — the Python installer and the
NumPy wheel are included in this folder.

## Layout
```
level1/ … level5/
    NN_task_name/
        README.md          # the specification (read this first)
        starter.py         # signatures + docstrings, bodies raise NotImplementedError -> implement here
        solution.py        # correct reference solution (passes every test) — remove before handing out
        test_solution.py   # automated tests (the grading criteria); they test starter.py
run_tests.py               # offline test runner (no pytest needed)
tools/
    make_candidate_package.py   # copy the suite without any solution.py
    regenerate_starters.py      # rebuild starter.py from solution.py
```

## For candidates
1. Open a task folder and read `README.md`.
2. Implement everything in `starter.py`. Keep the public names and signatures; you may add helpers.
3. Run the tests:
   ```bash
   python run_tests.py level3/05_knn          # one task
   python run_tests.py level3 -v              # whole level, show failure tracebacks
   cd level3/05_knn && python -m pytest -q    # alternative, if pytest is installed
   ```
Rules: only the allowed libraries for the level; no network access; do not edit the tests.

## For assessors
- **Scoring:** the share of tests passed per task (`run_tests.py` prints `passed/total` and a grand total). Tests
  cover the specified behaviour, edge cases, error handling and, where relevant, performance (vectorization or
  algorithmic complexity, with generous time limits).
- **Suggested use:** pick 2–4 tasks from the target level (or a mix of adjacent levels), e.g. 90–180 minutes in total.
  Review code quality (readability, numerical stability, API design) alongside the test score.
- **Before distributing:** every task folder contains `solution.py` — candidates must **not** get it. Create a clean
  copy with `python tools/make_candidate_package.py <output_dir> [level3 level4 ...]`; it copies everything except
  the `solution.py` files and `tools/`.
- **Verifying the suite:** `python run_tests.py --solution` runs every test against the `solution.py` files
  (all 567 tests pass; ~25 s). Without `--solution` the runner tests `starter.py`.
- **Editing tasks:** change `levelX/NN_task/solution.py`, update tests/README, then run
  `python tools/regenerate_starters.py` to rebuild the stubs (overwrites `levelX/*/starter.py`!).
- Level 5 task 01 ships a fixture `expected_logits.json` produced by its `solution.py`.

## Task catalog

### Level 1 — Python fundamentals
| # | Task | Topics | Time |
|---|---|---|---|
| 01 | [FizzBuzz with Custom Rules](level1/01_fizzbuzz_rules/README.md) | loops, conditionals, input validation | ~15 min |
| 02 | [Word Frequency Counter](level1/02_word_frequency/README.md) | strings, regex, dict counting, sorting | ~20 min |
| 03 | [Palindromes](level1/03_palindromes/README.md) | strings, two pointers, expand-around-center | ~25 min |
| 04 | [Flatten Nested Sequences](level1/04_flatten_nested/README.md) | recursion, type checks | ~15 min |
| 05 | [Merge Intervals](level1/05_merge_intervals/README.md) | sorting, greedy | ~20 min |
| 06 | [Roman Numerals](level1/06_roman_numerals/README.md) | mapping tables, validation | ~25 min |
| 07 | [Caesar & Vigenère Ciphers](level1/07_classic_ciphers/README.md) | ord/chr, modular arithmetic | ~25 min |
| 08 | [Pure-Python Matrix Basics](level1/08_matrix_basics/README.md) | nested lists, comprehensions, validation | ~25 min |
| 09 | [CSV Parsing with Type Inference](level1/09_csv_type_inference/README.md) | parsing, regex, csv module | ~30 min |
| 10 | [Chunking & Sliding Windows](level1/10_chunk_and_window/README.md) | generators, iterators, laziness | ~20 min |
| 11 | [Deep Merge of Config Dicts](level1/11_deep_merge/README.md) | recursion, dicts, immutability | ~20 min |
| 12 | [Descriptive Statistics from Scratch](level1/12_descriptive_stats/README.md) | math, numeric edge cases | ~25 min |
| 13 | [Group Anagrams](level1/13_group_anagrams/README.md) | hashing, canonical keys, ordering | ~15 min |
| 14 | [Run-Length Encoding](level1/14_run_length_encoding/README.md) | string scanning, parsing, validation | ~20 min |
| 15 | [Bank Account (OOP & Exceptions)](level1/15_bank_account_oop/README.md) | classes, properties, custom exceptions | ~25 min |
| 16 | [Balanced Brackets](level1/16_balanced_brackets/README.md) | stacks | ~20 min |
| 17 | [Text Normalization for NLP](level1/17_text_normalization/README.md) | unicode, `unicodedata`, preprocessing | ~25 min |
| 18 | [Label Encoder & One-Hot](level1/18_label_encoding/README.md) | classes, state, validation, ML preprocessing | ~25 min |
| 19 | [Train/Test Split](level1/19_train_test_split/README.md) | randomness, reproducibility, ML data handling | ~25 min |
| 20 | [Binary Classification Metrics](level1/20_binary_classification_metrics/README.md) | ML evaluation, edge cases | ~20 min |

### Level 2 — Intermediate Python, data structures & AI utilities
| # | Task | Topics | Time |
|---|---|---|---|
| 01 | [LRU Cache](level2/01_lru_cache/README.md) | hash map + ordering, O(1) operations | ~30 min |
| 02 | [Retry Decorator with Exponential Backoff](level2/02_retry_decorator/README.md) | decorators, closures, exceptions, dependency injection | ~30 min |
| 03 | [Section Profiler (Context Managers)](level2/03_section_profiler/README.md) | context managers, nesting, injected clocks | ~30 min |
| 04 | [Trie Autocomplete](level2/04_trie_autocomplete/README.md) | trees, recursion, ranking | ~35 min |
| 05 | [Inference Log Analytics](level2/05_log_analytics/README.md) | JSON lines, aggregation, percentiles, robustness | ~35 min |
| 06 | [Typed Config Loader (dataclasses + type hints)](level2/06_typed_config_loader/README.md) | dataclasses, `typing` introspection, recursion, error paths | ~45 min |
| 07 | [Shortest Paths (BFS & Dijkstra)](level2/07_shortest_paths/README.md) | graphs, queues, heaps | ~35 min |
| 08 | [ML Pipeline DAG Scheduler](level2/08_pipeline_dag_scheduler/README.md) | topological sort, cycle detection, heaps | ~35 min |
| 09 | [Token-Bucket Rate Limiter](level2/09_token_bucket_rate_limiter/README.md) | time-based algorithms, injected clocks, API quotas | ~30 min |
| 10 | [Streaming Data Loader](level2/10_streaming_data_loader/README.md) | generators, files, buffered shuffling | ~40 min |
| 11 | [Safe Arithmetic Expression Evaluator](level2/11_expression_evaluator/README.md) | tokenizing, recursive-descent parsing, precedence | ~50 min |
| 12 | [Immutable Vector Class](level2/12_vector_class/README.md) | operator overloading, dunder methods, immutability, hashing | ~35 min |
| 13 | [Bag-of-Words Search Index](level2/13_bow_search_index/README.md) | inverted index, cosine similarity, ranking | ~40 min |
| 14 | [TF-IDF Vectorizer](level2/14_tfidf_vectorizer/README.md) | NLP feature extraction, vocabulary building, normalization | ~40 min |
| 15 | [CSR Sparse Matrix](level2/15_csr_sparse_matrix/README.md) | sparse data structures, index arithmetic | ~45 min |
| 16 | [Component Registry & Config-Driven Builder](level2/16_component_registry/README.md) | decorators, factories, recursion, plugin patterns | ~35 min |
| 17 | [Record Schema Validator](level2/17_record_schema_validator/README.md) | recursion, data validation, error reporting | ~45 min |
| 18 | [Near-Duplicate Detection with MinHash + LSH](level2/18_minhash_dedup/README.md) | hashing, probabilistic data structures, dataset deduplication | ~50 min |
| 19 | [Binary Search Toolkit](level2/19_binary_search_toolkit/README.md) | binary search invariants, predicates, complexity | ~40 min |
| 20 | [Prompt Template Engine](level2/20_prompt_template_engine/README.md) | parsing, recursion, LLM prompt construction | ~60 min |

### Level 3 — Classical machine learning from scratch
| # | Task | Topics | Time |
|---|---|---|---|
| 01 | [Feature Scalers](level3/01_feature_scalers/README.md) | numpy broadcasting, fit/transform API | ~30 min |
| 02 | [Linear & Ridge Regression (Closed Form)](level3/02_linear_regression_closed_form/README.md) | linear algebra, normal equations, regularization | ~35 min |
| 03 | [Linear Regression with (Mini-batch) Gradient Descent](level3/03_linear_regression_gd/README.md) | gradients, optimization loops, reproducibility | ~40 min |
| 04 | [Logistic Regression](level3/04_logistic_regression/README.md) | numerical stability, cross-entropy, gradient descent | ~40 min |
| 05 | [k-Nearest Neighbors](level3/05_knn/README.md) | vectorized distances, voting, tie-breaking | ~40 min |
| 06 | [k-Means Clustering (k-means++)](level3/06_kmeans/README.md) | unsupervised learning, randomized init, convergence | ~45 min |
| 07 | [Gaussian Naive Bayes](level3/07_gaussian_naive_bayes/README.md) | probabilistic models, log-space arithmetic, log-sum-exp | ~35 min |
| 08 | [Multinomial Naive Bayes Text Classifier](level3/08_multinomial_naive_bayes/README.md) | NLP, count features, Laplace smoothing | ~40 min |
| 09 | [Decision Tree Classifier (CART / Gini)](level3/09_decision_tree/README.md) | recursion, greedy search, efficient split finding | ~60 min |
| 10 | [Principal Component Analysis](level3/10_pca/README.md) | SVD, variance, dimensionality reduction | ~35 min |
| 11 | [Probabilistic & Ranking Metrics](level3/11_ranking_metrics/README.md) | ROC, precision-recall, ties, O(n log n) algorithms | ~45 min |
| 12 | [Cross-Validation Splitters](level3/12_cross_validation/README.md) | evaluation protocol, index bookkeeping, stratification | ~40 min |
| 13 | [Softmax (Multinomial Logistic) Regression](level3/13_softmax_regression/README.md) | multiclass classification, stable softmax, cross-entropy gradients | ~45 min |
| 14 | [Polynomial Feature Expansion](level3/14_polynomial_features/README.md) | combinatorics, feature engineering, exact ordering specs | ~30 min |
| 15 | [Numerical Gradient Checking](level3/15_gradient_checking/README.md) | finite differences, debugging backprop | ~30 min |
| 16 | [Linear SVM with Pegasos (SGD on Hinge Loss)](level3/16_linear_svm_pegasos/README.md) | convex optimization, SGD, margins | ~40 min |
| 17 | [Imputation & One-Hot Encoding](level3/17_tabular_preprocessing/README.md) | missing data, categorical features, robust APIs | ~45 min |
| 18 | [Statistical Anomaly Detection](level3/18_anomaly_detection/README.md) | robust statistics, covariance, Mahalanobis distance | ~40 min |
| 19 | [Matrix Factorization Recommender (ALS)](level3/19_als_recommender/README.md) | collaborative filtering, alternating least squares, masking | ~50 min |
| 20 | [Hyperparameter Grid Search with Cross-Validation](level3/20_grid_search_cv/README.md) | experiment orchestration, model selection | ~40 min |

### Level 4 — Deep learning & NLP from scratch
| # | Task | Topics | Time |
|---|---|---|---|
| 01 | [Scalar Autograd Engine](level4/01_scalar_autograd/README.md) | computational graphs, reverse-mode autodiff, operator overloading | ~60 min |
| 02 | [Activation Functions (Forward & Backward)](level4/02_activation_functions/README.md) | non-linearities, derivatives, numerical stability | ~40 min |
| 03 | [Linear Layers, Sequential & Backprop](level4/03_linear_layer_backprop/README.md) | matrix calculus, modular backprop, API design | ~50 min |
| 04 | [Optimizers: SGD (Momentum/Nesterov), RMSProp, Adam, AdamW](level4/04_optimizers/README.md) | optimization algorithms, in-place updates, state management | ~50 min |
| 05 | [Learning-Rate Schedules](level4/05_lr_schedulers/README.md) | training dynamics, exact formula implementation | ~35 min |
| 06 | [MLP Classifier Trained from Scratch](level4/06_mlp_classifier/README.md) | end-to-end training, mini-batching, initialization, Adam | ~75 min |
| 07 | [2-D Convolution (Forward & Backward)](level4/07_conv2d/README.md) | CNNs, im2col / strided tricks, vectorization | ~75 min |
| 08 | [Pooling Layers (Forward & Backward)](level4/08_pooling_layers/README.md) | CNNs, gradient routing, vectorization | ~45 min |
| 09 | [Batch Normalization](level4/09_batchnorm/README.md) | normalization layers, train/eval modes, running statistics, backprop | ~50 min |
| 10 | [Dropout & Weight Initialization](level4/10_dropout_and_init/README.md) | regularization, variance preservation, reproducible randomness | ~40 min |
| 11 | [Byte-Level BPE Tokenizer](level4/11_bpe_tokenizer/README.md) | tokenization, greedy merges, UTF-8 bytes | ~60 min |
| 12 | [Word2Vec: Skip-Gram with Negative Sampling](level4/12_word2vec_sgns/README.md) | embeddings, sampling, SGD, numerically stable losses | ~60 min |
| 13 | [N-gram Language Model with Add-k Smoothing](level4/13_ngram_language_model/README.md) | language modeling, smoothing, perplexity, sampling | ~50 min |
| 14 | [Scaled Dot-Product & Multi-Head Attention](level4/14_attention_mechanism/README.md) | transformers, masking, batched tensor ops | ~60 min |
| 15 | [Positional Encodings: Sinusoidal, RoPE, ALiBi](level4/15_positional_encodings/README.md) | transformers, rotary embeddings, relative position | ~45 min |
| 16 | [LayerNorm & RMSNorm (Forward & Backward)](level4/16_layernorm_rmsnorm/README.md) | normalization, Jacobians, broadcasting over leading dims | ~50 min |
| 17 | [Vanilla RNN with Backprop Through Time](level4/17_rnn_bptt/README.md) | recurrent networks, BPTT, gradient clipping | ~60 min |
| 18 | [Cross-Entropy with Label Smoothing & ignore_index](level4/18_cross_entropy_label_smoothing/README.md) | loss functions, masking, token-level LM losses | ~40 min |
| 19 | [Training Loop with Callbacks (Early Stopping & Checkpointing)](level4/19_trainer_callbacks/README.md) | framework design, hooks, state management | ~50 min |
| 20 | [Vocabulary, Padding & Length Bucketing](level4/20_text_batching_pipeline/README.md) | NLP data pipelines, attention masks, efficient batching | ~45 min |

### Level 5 — Advanced AI engineering
| # | Task | Topics | Time |
|---|---|---|---|
| 01 | [Mini-GPT Forward Pass](level5/01_mini_gpt_forward/README.md) | transformer architecture, weight layouts, causal LM inference | ~90 min |
| 02 | [KV-Cached Incremental Attention (with Sliding Window)](level5/02_kv_cache_attention/README.md) | LLM inference optimization, caching, attention masks | ~60 min |
| 03 | [Decoding Strategies: Greedy, Top-k/Top-p Sampling, Beam Search](level5/03_decoding_strategies/README.md) | LLM text generation, probability filtering, search | ~75 min |
| 04 | [Sentence-Aware Text Chunker for RAG](level5/04_rag_text_chunker/README.md) | retrieval-augmented generation, text segmentation, offset bookkeeping | ~60 min |
| 05 | [BM25 & Hybrid Retrieval with Reciprocal Rank Fusion](level5/05_bm25_hybrid_retrieval/README.md) | information retrieval, ranking functions, rank fusion | ~50 min |
| 06 | [Vector Index: Flat & IVF (Inverted File) Search](level5/06_ivf_vector_index/README.md) | approximate nearest neighbors, clustering, recall/latency trade-offs | ~75 min |
| 07 | [RAG Pipeline: Context Packing & Citation Validation](level5/07_rag_pipeline/README.md) | retrieval-augmented generation, prompt budgeting, output validation | ~60 min |
| 08 | [Tool-Calling Agent Loop](level5/08_tool_calling_agent/README.md) | LLM agents, tool schemas, robust parsing, conversation state | ~75 min |
| 09 | [PII Detection & Redaction Guardrail](level5/09_pii_redaction/README.md) | LLM guardrails, regex engineering, checksum validation, overlap resolution | ~60 min |
| 10 | [Post-Training Quantization (INT8 / INT4)](level5/10_int8_quantization/README.md) | model compression, fixed-point arithmetic, per-channel scaling | ~60 min |
| 11 | [LoRA Adapter for a Linear Layer](level5/11_lora_adapter/README.md) | parameter-efficient fine-tuning, low-rank updates, weight merging | ~60 min |
| 12 | [Async Dynamic Batching for Model Inference](level5/12_dynamic_batching_server/README.md) | asyncio, concurrency, throughput/latency trade-offs, error propagation | ~75 min |
| 13 | [Semantic Cache for LLM Responses](level5/13_semantic_cache/README.md) | embeddings, similarity search, LRU + TTL eviction, cost optimization | ~50 min |
| 14 | [Generation Evaluation Metrics: EM, F1, BLEU, ROUGE-L](level5/14_generation_eval_metrics/README.md) | LLM evaluation, n-gram statistics, dynamic programming | ~60 min |
| 15 | [Mixture-of-Experts Layer with Top-k Routing & Capacity](level5/15_mixture_of_experts/README.md) | sparse models, routing, load balancing, vectorized gather/scatter | ~75 min |
| 16 | [Ring All-Reduce & Data-Parallel Gradients](level5/16_ring_allreduce/README.md) | distributed training, collective communication, simulation | ~60 min |
| 17 | [Speculative Decoding (Greedy Verification)](level5/17_speculative_decoding/README.md) | LLM inference acceleration, draft/target models, exactness guarantees | ~60 min |
| 18 | [Paged KV-Cache Block Manager (vLLM-style)](level5/18_paged_kv_cache/README.md) | memory management, reference counting, copy-on-write, LLM serving | ~75 min |
| 19 | [Grammar-Constrained Decoding with a Trie](level5/19_constrained_decoding/README.md) | structured generation, logit masking, prefix trees | ~60 min |
| 20 | [Model Calibration: ECE, Reliability Bins, Temperature Scaling](level5/20_model_calibration/README.md) | uncertainty, evaluation, 1-D optimization | ~60 min |
