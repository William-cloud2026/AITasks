# L5-12 · Async Dynamic Batching for Model Inference

**Level:** 5 · **Topics:** asyncio, concurrency, throughput/latency trade-offs, error propagation · **Time:** ~75 min · **Allowed:** Python stdlib

## Task
Inference servers group concurrent requests into batches. Implement
`class DynamicBatcher(model_fn, max_batch_size=8, max_wait_ms=5.0)`.

- `model_fn(list_of_inputs)` returns a list of outputs **of the same length** (it may be a regular function or an
  `async def` coroutine function — if calling it returns an awaitable, await it).
- `await start()` launches a single background worker task; `await stop()` lets the worker **finish all queued
  requests**, then stops it. Also usable as `async with DynamicBatcher(...) as b:`.
- `await submit(x)` enqueues one request and returns its result. Calling `submit` before `start` (or after `stop`)
  → `RuntimeError`.
- Worker: wait for the first queued request; then keep collecting until the batch has `max_batch_size` items **or**
  `max_wait_ms` has elapsed since the first item was taken; call `model_fn` once; deliver each output to the matching
  request. Append the batch size to `batch_sizes` (a list attribute).
- If `model_fn` raises, every request in that batch raises the **same exception**. If it returns the wrong number of
  outputs, every request in the batch raises `ValueError`. The worker keeps running after errors.
