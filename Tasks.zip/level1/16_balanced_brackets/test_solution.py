from starter import first_error_index, is_balanced


def test_balanced():
    for s in ["", "()", "([]{})", "def f(x): return [x[0], {'a': (1, 2)}]"]:
        assert is_balanced(s)
        assert first_error_index(s) == -1


def test_mismatch():
    assert first_error_index("(]") == 1
    assert first_error_index("([)]") == 2
    assert first_error_index(")") == 0


def test_unclosed():
    assert first_error_index("f(a[1]) + {x") == 10
    assert first_error_index("((()") == 0
    assert first_error_index("()(") == 2


def test_is_balanced_false():
    assert not is_balanced("{")
    assert not is_balanced("}{")


def test_long():
    s = "(" * 10000 + ")" * 10000
    assert is_balanced(s)
    assert first_error_index(s + ")") == 20000
