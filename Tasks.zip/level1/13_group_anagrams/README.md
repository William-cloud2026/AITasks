# L1-13 · Group Anagrams

**Level:** 1 · **Topics:** hashing, canonical keys, ordering · **Time:** ~15 min · **Allowed:** Python stdlib

## Task
Implement `group_anagrams(words) -> list[list[str]]`.

- Two words are anagrams if their **letters** (characters where `str.isalpha()` is True), lower-cased, form the
  same multiset. Other characters (spaces, punctuation, digits) are ignored.
- Each group keeps the **original** strings in **input order** (duplicates kept).
- Groups are ordered by the position of their **first** member in the input.

## Example
```python
group_anagrams(["listen", "Google", "Silent", "enlist", "gogole", "cat"])
# [['listen', 'Silent', 'enlist'], ['Google', 'gogole'], ['cat']]
```
