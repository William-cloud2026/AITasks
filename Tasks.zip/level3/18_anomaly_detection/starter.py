# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def zscore_outliers(x, threshold=3.0):
    """Boolean mask of z-score outliers."""
    raise NotImplementedError('TODO')

def iqr_outliers(x, k=1.5):
    """Boolean mask of IQR (Tukey fence) outliers."""
    raise NotImplementedError('TODO')

class GaussianAnomalyDetector:
    """Multivariate Gaussian / Mahalanobis anomaly detector."""

    def __init__(self, contamination=0.05, reg=1e-06):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Estimate mean, covariance and threshold."""
        raise NotImplementedError('TODO')

    def score_samples(self, X):
        """Mahalanobis distances."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """1 for anomalies, 0 otherwise."""
        raise NotImplementedError('TODO')
