# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def to_roman(n):
    """Convert 1..3999 to a canonical Roman numeral."""
    raise NotImplementedError('TODO')

def from_roman(s):
    """Parse a canonical upper-case Roman numeral; raise ValueError otherwise."""
    raise NotImplementedError('TODO')
