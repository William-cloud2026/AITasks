# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

from collections import deque
from itertools import islice

def chunked(iterable, n):
    """Lazily yield lists of n items (last may be shorter)."""
    raise NotImplementedError('TODO')

def sliding_window(iterable, n):
    """Lazily yield n-tuples of consecutive items."""
    raise NotImplementedError('TODO')
