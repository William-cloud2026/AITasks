import numpy as np


def ring_allreduce(arrays):
    """Simulated ring all-reduce (sum)."""
    W = len(arrays)
    shape = np.shape(arrays[0])
    if any(np.shape(a) != shape for a in arrays):
        raise ValueError("all arrays must have the same shape")
    if W == 1:
        return [np.array(arrays[0], dtype=float)], []
    chunks = [[c.copy() for c in np.array_split(np.asarray(a, dtype=float).ravel(), W)] for a in arrays]
    schedule = []
    for s in range(W - 1):
        msgs = [(r, (r + 1) % W, (r - s) % W) for r in range(W)]
        payload = [chunks[src][c].copy() for src, _, c in msgs]
        for (src, dst, c), data in zip(msgs, payload):
            chunks[dst][c] += data
        schedule.append(msgs)
    for s in range(W - 1):
        msgs = [(r, (r + 1) % W, (r + 1 - s) % W) for r in range(W)]
        payload = [chunks[src][c].copy() for src, _, c in msgs]
        for (src, dst, c), data in zip(msgs, payload):
            chunks[dst][c] = data
        schedule.append(msgs)
    return [np.concatenate(ch).reshape(shape) for ch in chunks], schedule


def data_parallel_gradient(grad_fn, params, X, y, n_workers):
    """Mean gradient computed by simulated data-parallel workers."""
    shards = np.array_split(np.arange(len(X)), n_workers)
    local = [grad_fn(params, X[idx], y[idx]) for idx in shards]
    reduced, _ = ring_allreduce(local)
    return reduced[0] / len(X)
