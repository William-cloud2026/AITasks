import math

from starter import Vector


def raises(fn, exc):
    try:
        fn()
    except exc:
        return True
    return False


def test_arithmetic():
    v, w = Vector([1, 2, 3]), Vector([4, 5, 6])
    assert v + w == Vector([5, 7, 9])
    assert w - v == Vector([3, 3, 3])
    assert v * 2 == 2 * v == Vector([2, 4, 6])
    assert w / 2 == Vector([2.0, 2.5, 3.0])
    assert -v == Vector([-1, -2, -3])
    assert v @ w == 32


def test_norm_cosine():
    v = Vector([3, 4])
    assert abs(v) == 5.0
    assert math.isclose(abs(v.normalized()), 1.0)
    assert math.isclose(Vector([1, 0]).cosine(Vector([0, 2])), 0.0)
    assert math.isclose(Vector([1, 1]).cosine(Vector([2, 2])), 1.0)


def test_sequence_protocol():
    v = Vector([1, 2.5, 3])
    assert len(v) == 3 and list(v) == [1, 2.5, 3] and v[1] == 2.5
    assert v[1:] == Vector([2.5, 3])
    assert repr(Vector([1, 2.5])) == "Vector([1, 2.5])"


def test_hash_eq():
    assert hash(Vector([1, 2])) == hash(Vector([1, 2]))
    assert len({Vector([1, 2]), Vector([1, 2]), Vector([2, 1])}) == 2
    assert Vector([1, 2]) != [1, 2]


def test_errors():
    v = Vector([1, 2])
    assert raises(lambda: v + Vector([1, 2, 3]), ValueError)
    assert raises(lambda: v @ Vector([1]), ValueError)
    assert raises(lambda: v + [1, 2], TypeError)
    assert raises(lambda: v * "a", TypeError)
    assert raises(lambda: v / 0, ZeroDivisionError)
    assert raises(lambda: Vector([0, 0]).normalized(), ValueError)
    assert raises(lambda: Vector([]), ValueError)
    assert raises(lambda: Vector(["a"]), TypeError)
    assert raises(lambda: Vector([True]), TypeError)


def test_immutable():
    v = Vector([1, 2])

    def set_item():
        v[0] = 5

    def set_attr():
        v.x = 1

    assert raises(set_item, TypeError)
    assert raises(set_attr, AttributeError)
    assert v == Vector([1, 2])
