import time

import numpy as np

from starter import conv2d_backward, conv2d_forward

rng = np.random.default_rng(0)


def naive(x, w, b, stride, pad):
    N, C, H, W = x.shape
    F, _, KH, KW = w.shape
    xp = np.pad(x, ((0, 0), (0, 0), (pad, pad), (pad, pad)))
    Ho, Wo = (H + 2 * pad - KH) // stride + 1, (W + 2 * pad - KW) // stride + 1
    out = np.zeros((N, F, Ho, Wo))
    for n in range(N):
        for f in range(F):
            for i in range(Ho):
                for j in range(Wo):
                    out[n, f, i, j] = b[f] + np.sum(xp[n, :, i * stride:i * stride + KH, j * stride:j * stride + KW] * w[f])
    return out


def test_forward_matches_naive():
    for stride, pad, (KH, KW), (H, W) in [(1, 0, (3, 3), (5, 5)), (2, 1, (3, 3), (7, 6)), (1, 2, (2, 4), (4, 5)),
                                          (3, 0, (1, 1), (7, 7))]:
        x = rng.normal(size=(2, 3, H, W))
        w = rng.normal(size=(4, 3, KH, KW))
        b = rng.normal(size=4)
        out, _ = conv2d_forward(x, w, b, stride, pad)
        np.testing.assert_allclose(out, naive(x, w, b, stride, pad), atol=1e-10)


def test_backward_numeric():
    x = rng.normal(size=(2, 2, 5, 5))
    w = rng.normal(size=(3, 2, 3, 3))
    b = rng.normal(size=3)
    for stride, pad in [(1, 1), (2, 0), (2, 1)]:
        out, cache = conv2d_forward(x, w, b, stride, pad)
        g = rng.normal(size=out.shape)
        dx, dw, db = conv2d_backward(g, cache)
        assert dx.shape == x.shape and dw.shape == w.shape and db.shape == b.shape
        eps = 1e-6
        for arr, grad in ((x, dx), (w, dw), (b, db)):
            num = np.zeros_like(arr)
            for idx in np.ndindex(arr.shape):
                old = arr[idx]
                arr[idx] = old + eps
                lp = (conv2d_forward(x, w, b, stride, pad)[0] * g).sum()
                arr[idx] = old - eps
                lm = (conv2d_forward(x, w, b, stride, pad)[0] * g).sum()
                arr[idx] = old
                num[idx] = (lp - lm) / (2 * eps)
            np.testing.assert_allclose(grad, num, rtol=1e-5, atol=1e-6)


def test_errors():
    for fn in (lambda: conv2d_forward(np.zeros((1, 3, 4, 4)), np.zeros((2, 2, 3, 3)), np.zeros(2)),
               lambda: conv2d_forward(np.zeros((1, 1, 2, 2)), np.zeros((1, 1, 5, 5)), np.zeros(1))):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_speed():
    x = rng.normal(size=(8, 3, 32, 32))
    w = rng.normal(size=(16, 3, 3, 3))
    b = np.zeros(16)
    t0 = time.perf_counter()
    out, cache = conv2d_forward(x, w, b, 1, 1)
    conv2d_backward(np.ones_like(out), cache)
    assert out.shape == (8, 16, 32, 32)
    assert time.perf_counter() - t0 < 3.0
