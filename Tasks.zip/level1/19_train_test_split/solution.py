import math
import random


def _n_test(n, test_size):
    if n < 2:
        raise ValueError("need at least 2 items")
    if isinstance(test_size, bool):
        raise ValueError("invalid test_size")
    if isinstance(test_size, float):
        if not 0 < test_size < 1:
            raise ValueError("float test_size must be in (0, 1)")
        k = math.ceil(n * test_size)
    elif isinstance(test_size, int):
        k = test_size
    else:
        raise ValueError("invalid test_size")
    if not 1 <= k <= n - 1:
        raise ValueError("test size out of range")
    return k


def train_test_split(data, test_size=0.25, seed=None, shuffle=True, stratify=None):
    """Split data into (train, test) lists."""
    data = list(data)
    n = len(data)
    k = _n_test(n, test_size)
    if not shuffle:
        if stratify is not None:
            raise ValueError("stratify requires shuffle=True")
        return data[:n - k], data[n - k:]
    rng = random.Random(seed)
    if stratify is None:
        idx = list(range(n))
        rng.shuffle(idx)
        test_idx = set(idx[:k])
    else:
        stratify = list(stratify)
        if len(stratify) != n:
            raise ValueError("stratify length mismatch")
        by_label = {}
        for i, lab in enumerate(stratify):
            by_label.setdefault(lab, []).append(i)
        test_idx = set()
        for lab in sorted(by_label, key=repr):
            members = by_label[lab]
            rng.shuffle(members)
            test_idx.update(members[:round(len(members) * k / n)])
    train = [d for i, d in enumerate(data) if i not in test_idx]
    test = [d for i, d in enumerate(data) if i in test_idx]
    return train, test
