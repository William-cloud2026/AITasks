import numpy as np


def numerical_gradient(f, x, eps=1e-6):
    """Central-difference gradient of scalar f at x."""
    x = np.array(x, dtype=float)
    g = np.zeros_like(x)
    flat, gflat = x.reshape(-1), g.reshape(-1)
    for i in range(flat.size):
        old = flat[i]
        flat[i] = old + eps
        fp = f(x)
        flat[i] = old - eps
        fm = f(x)
        flat[i] = old
        gflat[i] = (fp - fm) / (2 * eps)
    return g


def relative_error(a, b):
    """Max element-wise relative error."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    return float(np.max(np.abs(a - b) / np.maximum(1e-8, np.abs(a) + np.abs(b))))


def check_gradient(f, grad_f, x, tol=1e-5, eps=1e-6):
    """Compare analytic and numerical gradients."""
    x = np.asarray(x, dtype=float)
    err = relative_error(grad_f(x.copy()), numerical_gradient(f, x, eps))
    return err < tol, err


def jacobian(f, x, eps=1e-6):
    """Central-difference Jacobian (m, n)."""
    x = np.array(x, dtype=float)
    cols = []
    for i in range(x.size):
        e = np.zeros_like(x)
        e[i] = eps
        cols.append((np.asarray(f(x + e), dtype=float) - np.asarray(f(x - e), dtype=float)) / (2 * eps))
    return np.stack(cols, axis=1)
