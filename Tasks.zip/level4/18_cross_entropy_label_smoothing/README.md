# L4-18 · Cross-Entropy with Label Smoothing & ignore_index

**Level:** 4 · **Topics:** loss functions, masking, token-level LM losses · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
Implement `cross_entropy(logits, targets, label_smoothing=0.0, ignore_index=-100, reduction="mean") -> (loss, dlogits)`
matching PyTorch's `F.cross_entropy`.

- `logits (..., C)`, integer `targets (...)` (e.g. `(B, T, C)` and `(B, T)` for language modeling).
- Target distribution per position: `q = (1 − ε)·onehot(target) + ε / C`. Per-position loss: `−Σ_c q_c · log_softmax(logits)_c`
  (computed stably).
- Positions with `target == ignore_index` contribute **0** loss and **0** gradient.
- `reduction`:
  - `"mean"`: sum over non-ignored positions / number of non-ignored positions (all ignored → loss `0.0`, zero grad).
  - `"sum"`: sum over positions.
  - `"none"`: per-position loss array shaped like `targets`; `dlogits` is then the gradient of the **sum**.
- `dlogits` has the shape of `logits`. Target outside `[0, C)` (and not ignored) → `ValueError`;
  invalid `reduction` → `ValueError`.
