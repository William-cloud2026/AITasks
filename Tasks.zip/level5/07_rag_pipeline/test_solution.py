from starter import RAGPipeline, build_prompt, extract_citations

CHUNKS = [
    {"id": "doc1#0", "text": "Paris is the capital of France.", "score": 0.9},
    {"id": "doc2#3", "text": "France is in Western Europe and uses the euro.", "score": 0.8},
    {"id": "doc7#1", "text": "The Eiffel Tower was completed in 1889.", "score": 0.5},
]


def test_prompt_format():
    prompt, used = build_prompt("What is the capital?", CHUNKS[:2], 100)
    assert prompt == ("Answer the question using only the context below. Cite sources as [n].\n\nContext:\n"
                      "[1] Paris is the capital of France.\n[2] France is in Western Europe and uses the euro.\n\n"
                      "Question: What is the capital?\nAnswer:")
    assert used == CHUNKS[:2]


def test_budget_stops_at_first_overflow():
    _, used = build_prompt("q", CHUNKS, 14)
    assert [c["id"] for c in used] == ["doc1#0"]
    _, used = build_prompt("q", CHUNKS, 15, count_tokens=lambda t: 5)
    assert len(used) == 3
    prompt, used = build_prompt("q", CHUNKS, 2)
    assert used == [] and "Context:\n\nQuestion: q" in prompt


def test_extract_citations():
    assert extract_citations("Paris [1]. Euro [2][1]. Both [1, 3] and [2,4].") == [1, 2, 3, 4]
    assert extract_citations("no cites, [x] [] [1a]") == []


def test_pipeline_flow():
    calls = []

    def retriever(q, k):
        calls.append(("retrieve", q, k))
        return CHUNKS

    def llm(prompt):
        calls.append(("llm", prompt))
        return "  Paris [1], see also [3] and [5].  "

    rag = RAGPipeline(retriever, llm, max_context_tokens=100, top_k=3)
    out = rag.answer("Capital of France?")
    assert calls[0] == ("retrieve", "Capital of France?", 3)
    assert out["answer"] == "Paris [1], see also [3] and [5]."
    assert out["used_chunks"] == ["doc1#0", "doc2#3", "doc7#1"]
    assert out["citations"] == ["doc1#0", "doc7#1"]
    assert out["invalid_citations"] == [5]
    assert out["prompt"] == calls[1][1]


def test_no_context_no_llm_call():
    def llm(prompt):
        raise AssertionError("LLM must not be called")

    out = RAGPipeline(lambda q, k: [], llm).answer("anything")
    assert out == {"answer": "I don't know.", "used_chunks": [], "citations": [], "invalid_citations": [],
                   "prompt": None}
    out = RAGPipeline(lambda q, k: CHUNKS, llm, max_context_tokens=1).answer("anything")
    assert out["answer"] == "I don't know."
