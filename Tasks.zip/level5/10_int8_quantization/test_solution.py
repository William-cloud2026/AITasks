import numpy as np

from starter import dequantize, quantize_asymmetric, quantize_linear_layer, quantize_symmetric, quantized_matmul

rng = np.random.default_rng(0)


def test_symmetric_per_tensor():
    x = np.array([-1.0, -0.5, 0.0, 0.25, 0.5])
    q, s = quantize_symmetric(x)
    assert q.dtype == np.int8 and np.isclose(s, 1 / 127)
    np.testing.assert_array_equal(q, [-127, -64, 0, 32, 64])
    assert np.max(np.abs(dequantize(q, s) - x)) <= s / 2 + 1e-12
    q4, s4 = quantize_symmetric(x, bits=4)
    np.testing.assert_array_equal(q4, [-7, -4, 0, 2, 4])


def test_symmetric_zero_and_bits():
    q, s = quantize_symmetric(np.zeros(4))
    assert s == 1.0 and np.all(q == 0)
    for b in (1, 9):
        try:
            quantize_symmetric(np.ones(3), bits=b)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_per_channel_better():
    W = rng.normal(size=(64, 8)) * np.array([0.01, 0.1, 1, 10, 0.5, 2, 0.05, 5])
    qt, st = quantize_symmetric(W)
    qc, sc = quantize_linear_layer(W)
    assert sc.shape == (1, 8)
    np.testing.assert_allclose(sc[0], np.abs(W).max(0) / 127)
    err_t = np.abs(dequantize(qt, st) - W).mean(0)
    err_c = np.abs(dequantize(qc, sc) - W).mean(0)
    assert np.all(err_c <= err_t + 1e-12) and err_c[0] < err_t[0] / 10
    q0, s0 = quantize_symmetric(W, axis=0)
    assert s0.shape == (64, 1)


def test_asymmetric():
    x = np.array([0.0, 0.5, 1.0, 2.0])
    q, s, zp = quantize_asymmetric(x)
    assert q.dtype == np.uint8 and zp == 0 and np.isclose(s, 2 / 255)
    np.testing.assert_array_equal(q, [0, 64, 128, 255])
    x = np.array([-1.0, 0.0, 3.0])
    q, s, zp = quantize_asymmetric(x)
    assert np.isclose(s, 4 / 255) and zp == 64
    np.testing.assert_array_equal(q, [0, 64, 255])
    assert np.max(np.abs(dequantize(q, s, zp) - x)) <= s / 2 + 1e-9
    y = rng.uniform(-0.2, 5, size=1000)
    q, s, zp = quantize_asymmetric(y, bits=4)
    assert q.max() <= 15 and np.max(np.abs(dequantize(q, s, zp) - y)) <= s / 2 + 1e-9


def test_quantized_matmul_int32_accumulation():
    xq = np.full((2, 1000), 127, dtype=np.int8)
    wq = np.full((1000, 3), -127, dtype=np.int8)
    out = quantized_matmul(xq, 0.5, wq, 0.25)
    np.testing.assert_allclose(out, np.full((2, 3), -127 * 127 * 1000 * 0.125))


def test_quantized_linear_close_to_float():
    X = rng.normal(size=(32, 64))
    W = rng.normal(size=(64, 16)) * rng.uniform(0.1, 3, size=16)
    xq, xs = quantize_symmetric(X)
    wq, ws = quantize_linear_layer(W)
    approx = quantized_matmul(xq, xs, wq, ws)
    exact = X @ W
    rel = np.linalg.norm(approx - exact) / np.linalg.norm(exact)
    assert rel < 0.02
