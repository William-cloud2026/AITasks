def shape(m):
    """Validate and return (rows, cols)."""
    if not isinstance(m, list) or not m or not all(isinstance(r, list) and r for r in m):
        raise ValueError("matrix must be a non-empty list of non-empty lists")
    cols = len(m[0])
    if any(len(r) != cols for r in m):
        raise ValueError("ragged matrix")
    return len(m), cols


def transpose(m):
    """Return the transpose."""
    shape(m)
    return [list(col) for col in zip(*m)]


def matmul(a, b):
    """Matrix product a @ b."""
    (n, k1), (k2, p) = shape(a), shape(b)
    if k1 != k2:
        raise ValueError("inner dimensions differ")
    bt = transpose(b)
    return [[sum(x * y for x, y in zip(row, col)) for col in bt] for row in a]


def identity(n):
    """n x n identity matrix."""
    if not isinstance(n, int) or n < 1:
        raise ValueError("n must be >= 1")
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]


def scale(m, k):
    """Multiply every element by k."""
    shape(m)
    return [[x * k for x in r] for r in m]
