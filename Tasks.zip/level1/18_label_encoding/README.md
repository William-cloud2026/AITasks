# L1-18 · Label Encoder & One-Hot

**Level:** 1 · **Topics:** classes, state, validation, ML preprocessing · **Time:** ~25 min · **Allowed:** Python stdlib

## Task
### `class LabelEncoder`
| Method | Behaviour |
|---|---|
| `fit(labels)` | learns `classes_` = **sorted** unique labels; returns `self` |
| `transform(labels)` | list of int ids; unknown label → `ValueError` |
| `inverse_transform(ids)` | list of labels; out-of-range id → `ValueError` |
| `fit_transform(labels)` | fit then transform |
| `classes_` | list attribute, available after `fit` |

Calling `transform`/`inverse_transform` before `fit` → `RuntimeError`.

### `one_hot(ids, num_classes) -> list[list[int]]`
Each id becomes a list of `num_classes` ints with a single `1`. Id outside `0..num_classes-1` → `ValueError`.

## Example
```python
enc = LabelEncoder().fit(["dog", "cat", "dog", "bird"])
enc.classes_                     # ['bird', 'cat', 'dog']
enc.transform(["cat", "dog"])    # [1, 2]
one_hot([1, 0], 3)               # [[0, 1, 0], [1, 0, 0]]
```
