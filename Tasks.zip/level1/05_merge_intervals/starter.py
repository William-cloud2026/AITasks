# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def merge_intervals(intervals):
    """Merge overlapping/touching intervals; return sorted list of tuples."""
    raise NotImplementedError('TODO')

def total_covered(intervals):
    """Total length of the union of intervals."""
    raise NotImplementedError('TODO')
