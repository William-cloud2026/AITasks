# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

def conv2d_forward(x, w, b, stride=1, padding=0):
    """Cross-correlation over NCHW input."""
    raise NotImplementedError('TODO')

def conv2d_backward(dout, cache):
    """Gradients of conv2d_forward."""
    raise NotImplementedError('TODO')
