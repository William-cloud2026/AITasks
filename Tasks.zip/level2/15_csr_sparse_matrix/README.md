# L2-15 · CSR Sparse Matrix

**Level:** 2 · **Topics:** sparse data structures, index arithmetic · **Time:** ~45 min · **Allowed:** Python stdlib

## Task
Implement `class CSRMatrix` using the standard **Compressed Sparse Row** layout (identical to `scipy.sparse.csr_matrix`):

- `data`: non-zero values row by row; `indices`: column index of each value (ascending within a row);
  `indptr`: length `rows + 1`, row `i` occupies `data[indptr[i]:indptr[i+1]]`; `shape`: `(rows, cols)`.

| Member | Behaviour |
|---|---|
| `CSRMatrix(data, indices, indptr, shape)` | store as lists/tuple (no validation required) |
| `CSRMatrix.from_dense(rows)` | classmethod; zeros are not stored |
| `CSRMatrix.from_coo(row_idx, col_idx, values, shape)` | classmethod; **duplicates are summed**; entries summing to 0 are dropped; out-of-range index → `IndexError` |
| `to_dense()` | list of lists |
| `nnz` | property: number of stored values |
| `matvec(x)` / `m @ x` | `x` is a list of length `cols` (else `ValueError`); returns list of length `rows` |
| `transpose()` | returns a new `CSRMatrix` |
| `get(i, j)` | element value (0 if not stored) |
