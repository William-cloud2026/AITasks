import math
import re


class EvalError(Exception):
    """Raised for any evaluation problem."""


_TOKEN = re.compile(r"\s*(?:(\d+\.\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?|\d+[eE][+-]?\d+)|(\d+)"
                    r"|([A-Za-z_]\w*)|(\*\*|//|[-+*/%(),]))")
_FUNCS = {"abs": abs, "min": min, "max": max, "round": round, "sqrt": math.sqrt}


def _tokenize(expr):
    pos, out = 0, []
    expr = expr.rstrip()
    while pos < len(expr):
        m = _TOKEN.match(expr, pos)
        if not m:
            raise EvalError(f"unexpected character at {pos}")
        flt, integer, name, op = m.groups()
        if flt is not None:
            out.append(("num", float(flt)))
        elif integer is not None:
            out.append(("num", int(integer)))
        elif name is not None:
            out.append(("name", name))
        else:
            out.append(("op", op))
        pos = m.end()
    return out


class _Parser:
    def __init__(self, tokens, variables):
        self.toks = tokens
        self.i = 0
        self.vars = variables

    def peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else (None, None)

    def take_op(self, *ops):
        kind, val = self.peek()
        if kind == "op" and val in ops:
            self.i += 1
            return val
        return None

    def expect(self, op):
        if not self.take_op(op):
            raise EvalError(f"expected {op!r}")

    def expr(self):
        v = self.term()
        while (op := self.take_op("+", "-")):
            r = self.term()
            v = v + r if op == "+" else v - r
        return v

    def term(self):
        v = self.unary()
        while (op := self.take_op("*", "/", "//", "%")):
            r = self.unary()
            if op == "*":
                v = v * r
            else:
                if r == 0:
                    raise EvalError("division by zero")
                v = v / r if op == "/" else v // r if op == "//" else v % r
        return v

    def unary(self):
        op = self.take_op("+", "-")
        if op:
            v = self.unary()
            return -v if op == "-" else +v
        return self.power()

    def power(self):
        base = self.atom()
        if self.take_op("**"):
            exp = self.unary()
            try:
                return base ** exp
            except (ZeroDivisionError, OverflowError) as e:
                raise EvalError(str(e)) from None
        return base

    def atom(self):
        kind, val = self.peek()
        if kind == "num":
            self.i += 1
            return val
        if kind == "name":
            self.i += 1
            if self.take_op("("):
                if val not in _FUNCS:
                    raise EvalError(f"unknown function {val!r}")
                args = []
                if not self.take_op(")"):
                    args.append(self.expr())
                    while self.take_op(","):
                        args.append(self.expr())
                    self.expect(")")
                try:
                    return _FUNCS[val](*args)
                except (TypeError, ValueError) as e:
                    raise EvalError(str(e)) from None
            if val not in self.vars:
                raise EvalError(f"unknown name {val!r}")
            return self.vars[val]
        if self.take_op("("):
            v = self.expr()
            self.expect(")")
            return v
        raise EvalError("unexpected token")


def evaluate(expr, variables=None):
    """Safely evaluate an arithmetic expression."""
    tokens = _tokenize(expr)
    if not tokens:
        raise EvalError("empty expression")
    p = _Parser(tokens, variables or {})
    v = p.expr()
    if p.i != len(tokens):
        raise EvalError("unexpected trailing tokens")
    return v
