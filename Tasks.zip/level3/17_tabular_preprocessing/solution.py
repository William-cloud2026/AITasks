import numpy as np


class SimpleImputer:
    """Fill NaNs column-wise."""

    def __init__(self, strategy="mean", fill_value=None):
        if strategy not in ("mean", "median", "most_frequent", "constant"):
            raise ValueError("unknown strategy")
        if strategy == "constant" and fill_value is None:
            raise ValueError("fill_value required for constant strategy")
        self.strategy, self.fill_value = strategy, fill_value

    def fit(self, X):
        """Compute per-column fill values."""
        X = np.asarray(X, dtype=float)
        stats = []
        for col in X.T:
            vals = col[~np.isnan(col)]
            if self.strategy == "constant":
                stats.append(self.fill_value)
                continue
            if len(vals) == 0:
                raise ValueError("column has no observed values")
            if self.strategy == "mean":
                stats.append(vals.mean())
            elif self.strategy == "median":
                stats.append(np.median(vals))
            else:
                u, c = np.unique(vals, return_counts=True)
                stats.append(u[np.argmax(c)])
        self.statistics_ = np.array(stats, dtype=float)
        return self

    def transform(self, X):
        """Replace NaNs."""
        X = np.array(X, dtype=float)
        mask = np.isnan(X)
        X[mask] = np.broadcast_to(self.statistics_, X.shape)[mask]
        return X

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)


class OneHotEncoder:
    """One-hot encode categorical columns."""

    def __init__(self, handle_unknown="error"):
        if handle_unknown not in ("error", "ignore"):
            raise ValueError("handle_unknown must be 'error' or 'ignore'")
        self.handle_unknown = handle_unknown

    def fit(self, X):
        """Learn sorted categories per column."""
        X = np.asarray(X, dtype=object)
        self.categories_ = [np.array(sorted(set(col.tolist()))) for col in X.T]
        return self

    def transform(self, X):
        """Encode X."""
        X = np.asarray(X, dtype=object)
        blocks = []
        for j, cats in enumerate(self.categories_):
            lookup = {c: i for i, c in enumerate(cats.tolist())}
            block = np.zeros((len(X), len(cats)))
            for r, v in enumerate(X[:, j].tolist()):
                i = lookup.get(v)
                if i is None:
                    if self.handle_unknown == "error":
                        raise ValueError(f"unknown category {v!r} in column {j}")
                    continue
                block[r, i] = 1.0
            blocks.append(block)
        return np.hstack(blocks)

    def fit_transform(self, X):
        """Fit then transform."""
        return self.fit(X).transform(X)

    def get_feature_names_out(self, input_features=None):
        """Output column names."""
        feats = input_features or [f"x{j}" for j in range(len(self.categories_))]
        return [f"{f}_{c}" for f, cats in zip(feats, self.categories_) for c in cats.tolist()]

    def inverse_transform(self, Z):
        """Decode one-hot blocks."""
        Z = np.asarray(Z)
        out = np.empty((len(Z), len(self.categories_)), dtype=object)
        start = 0
        for j, cats in enumerate(self.categories_):
            block = Z[:, start:start + len(cats)]
            for r in range(len(Z)):
                out[r, j] = cats.tolist()[int(np.argmax(block[r]))] if block[r].any() else None
            start += len(cats)
        return out
