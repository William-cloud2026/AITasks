# L2-18 · Near-Duplicate Detection with MinHash + LSH

**Level:** 2 · **Topics:** hashing, probabilistic data structures, dataset deduplication · **Time:** ~50 min · **Allowed:** Python stdlib

## Task
LLM pre-training pipelines remove near-duplicate documents. Implement:

### `shingles(text, k=5) -> set[str]`
Normalize: lower-case and collapse whitespace runs to one space (strip ends). Return the set of all character
`k`-grams. If the normalized text is non-empty but shorter than `k`, return `{text}`; empty → `set()`.

### `jaccard(a, b) -> float`
`|a ∩ b| / |a ∪ b|`; two empty sets → `1.0`.

### `class MinHasher(num_perm=128, seed=0)`
- Base hash of a shingle: `int.from_bytes(hashlib.md5(s.encode("utf-8")).digest()[:8], "little")`.
- `P = 2**61 - 1`. Using `rng = random.Random(seed)`, for each of the `num_perm` permutations draw
  `a = rng.randint(1, P - 1)` **then** `b = rng.randint(0, P - 1)`.
- `signature(shingle_set) -> list[int]`: element `i` = `min((a_i * h + b_i) % P for h in base hashes)`.
  Empty set → `ValueError`.

### `estimate_jaccard(sig1, sig2) -> float`
Fraction of positions where the signatures are equal. Length mismatch → `ValueError`.

### `find_near_duplicates(docs, threshold=0.8, num_perm=128, bands=32, k=5, seed=0) -> list[tuple]`
`docs` is `{doc_id: text}` (ids are mutually comparable). LSH banding: split each signature into `bands` bands of
`r = num_perm // bands` rows (`num_perm % bands != 0` → `ValueError`); documents sharing an identical band (same
band index, same values) are candidates. Return sorted `(id1, id2)` pairs with `id1 < id2` whose
**estimated** Jaccard `>= threshold`. Documents with no shingles are ignored.
