import numpy as np

from starter import Vocab, bucket_batches, collate

DATA = [["the", "cat", "sat"], ["the", "dog", "sat", "down"], ["a", "cat", "<unk>"]]


def test_vocab_build_order():
    v = Vocab.build(DATA)
    assert [v.lookup_token(i) for i in range(len(v))] == ["<pad>", "<unk>", "cat", "sat", "the", "a", "dog", "down"]
    assert v.pad_id == 0 and v.unk_id == 1
    assert v["zebra"] == 1 and v["cat"] == 2


def test_min_freq_and_max_size():
    v = Vocab.build(DATA, min_freq=2)
    assert len(v) == 5
    v = Vocab.build(DATA, max_size=4)
    assert [v.lookup_token(i) for i in range(4)] == ["<pad>", "<unk>", "cat", "sat"]
    v = Vocab.build(DATA, specials=("<unk>", "<bos>"))
    assert v.unk_id == 0 and v.pad_id is None


def test_encode_decode():
    v = Vocab.build(DATA)
    ids = v.encode(["the", "zebra", "<pad>"])
    assert ids == [4, 1, 0]
    assert v.decode(ids) == ["the", "<unk>", "<pad>"]
    assert v.decode(ids, skip_specials=True) == ["the"]


def test_vocab_requires_unk():
    try:
        Vocab.build(DATA, specials=("<pad>",))
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_collate_right():
    ids, mask = collate([[5, 6, 7], [8], []], pad_id=0)
    np.testing.assert_array_equal(ids, [[5, 6, 7], [8, 0, 0], [0, 0, 0]])
    np.testing.assert_array_equal(mask, [[1, 1, 1], [1, 0, 0], [0, 0, 0]])
    assert ids.dtype == np.int64 and mask.dtype == np.int64


def test_collate_left_and_truncation():
    ids, mask = collate([[1, 2, 3, 4, 5], [9]], pad_id=-1, max_len=3, padding_side="left", truncation_side="left")
    np.testing.assert_array_equal(ids, [[3, 4, 5], [-1, -1, 9]])
    np.testing.assert_array_equal(mask, [[1, 1, 1], [0, 0, 1]])
    ids, _ = collate([[1, 2, 3, 4, 5]], pad_id=0, max_len=2)
    np.testing.assert_array_equal(ids, [[1, 2]])
    ids, _ = collate([[1, 2], [3]], pad_id=0, max_len=10)
    assert ids.shape == (2, 2)


def test_collate_errors():
    for kw in ({"sequences": []}, {"sequences": [[1]], "padding_side": "middle"}):
        try:
            collate(pad_id=0, **kw)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_bucket_batches():
    lengths = [5, 2, 9, 2, 7, 1, 3]
    assert bucket_batches(lengths, 3) == [[5, 1, 3], [6, 0, 4], [2]]
    sh = bucket_batches(lengths, 3, shuffle=True, seed=0)
    perm = np.random.default_rng(0).permutation(3)
    base = bucket_batches(lengths, 3)
    assert sh == [base[i] for i in perm]
    assert sorted(i for b in sh for i in b) == list(range(7))
