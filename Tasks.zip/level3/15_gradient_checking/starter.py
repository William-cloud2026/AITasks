# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def numerical_gradient(f, x, eps=1e-06):
    """Central-difference gradient of scalar f at x."""
    raise NotImplementedError('TODO')

def relative_error(a, b):
    """Max element-wise relative error."""
    raise NotImplementedError('TODO')

def check_gradient(f, grad_f, x, tol=1e-05, eps=1e-06):
    """Compare analytic and numerical gradients."""
    raise NotImplementedError('TODO')

def jacobian(f, x, eps=1e-06):
    """Central-difference Jacobian (m, n)."""
    raise NotImplementedError('TODO')
