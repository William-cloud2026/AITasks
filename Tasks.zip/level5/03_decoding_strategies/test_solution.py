from collections import Counter

import numpy as np

from starter import beam_search, filter_logits, greedy_decode, sample_decode

V = 5
rng = np.random.default_rng(0)
TABLE = rng.normal(size=(V, V)) * 2


def model(tokens):
    return TABLE[tokens[-1]]


def test_filter_top_k():
    lg = np.array([1.0, 3.0, 3.0, 0.5, 2.0])
    out = filter_logits(lg, top_k=2)
    np.testing.assert_array_equal(np.isfinite(out), [False, True, True, False, False])
    out = filter_logits(np.array([2.0, 1.0, 2.0, 2.0]), top_k=2)
    np.testing.assert_array_equal(np.isfinite(out), [True, False, True, False])
    np.testing.assert_array_equal(filter_logits(lg, top_k=10), lg)


def test_filter_top_p():
    lg = np.log(np.array([0.5, 0.2, 0.15, 0.1, 0.05]))
    np.testing.assert_array_equal(np.isfinite(filter_logits(lg, top_p=0.7)), [True, True, False, False, False])
    np.testing.assert_array_equal(np.isfinite(filter_logits(lg, top_p=0.71)), [True, True, True, False, False])
    np.testing.assert_array_equal(np.isfinite(filter_logits(lg, top_p=0.01)), [True, False, False, False, False])
    np.testing.assert_array_equal(np.isfinite(filter_logits(lg, top_k=3, top_p=0.9)), [True, True, True, False, False])


def test_greedy():
    seq = greedy_decode(model, [0], 6)
    expected = [0]
    for _ in range(6):
        expected.append(int(np.argmax(TABLE[expected[-1]])))
    assert seq == expected
    eos = expected[2]
    assert greedy_decode(model, [0], 6, eos_id=eos) == expected[:3]


def test_sampling_reproducible_and_temperature_zero():
    a = sample_decode(model, [1], 20, seed=5)
    assert a == sample_decode(model, [1], 20, seed=5) and len(a) == 21
    assert sample_decode(model, [1], 6, temperature=0) == greedy_decode(model, [1], 6)
    try:
        sample_decode(model, [1], 3, temperature=-1)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


def test_sampling_respects_filters():
    flat = lambda toks: np.array([0.0, 0.1, 0.2, 5.0, 4.9])
    seqs = [sample_decode(flat, [0], 1, top_k=2, seed=s)[-1] for s in range(200)]
    assert set(seqs) <= {3, 4} and len(set(seqs)) == 2
    seqs = [sample_decode(flat, [0], 1, top_p=0.3, seed=s)[-1] for s in range(50)]
    assert set(seqs) == {3}
    counts = Counter(sample_decode(lambda t: np.log(np.array([0.7, 0.3])), [0], 1, seed=s)[-1] for s in range(2000))
    assert 0.65 < counts[0] / 2000 < 0.75


def test_beam_finds_better_than_greedy():
    # token 0 = EOS. From start: greedy picks 1 (0.6) then poor continuation; beam finds 2 -> strong path.
    def lp(tokens):
        last = tokens[-1]
        table = {
            9: [0.0, 0.6, 0.4, 0.0],
            1: [0.3, 0.35, 0.35, 0.0],
            2: [0.0, 0.0, 0.0, 1.0],
            3: [1.0, 0.0, 0.0, 0.0],
        }
        p = np.array(table.get(last, [1.0, 0, 0, 0]), dtype=float)
        with np.errstate(divide="ignore"):
            return np.log(p)

    seq, score = beam_search(lp, [9], beam_width=2, max_new_tokens=4, eos_id=0, length_penalty=0.0)
    assert seq == [9, 2, 3, 0]
    assert np.isclose(score, np.log(0.4))
    g = greedy_decode(lambda t: lp(t), [9], 4, eos_id=0)
    assert g[:2] == [9, 1]
    seq1, _ = beam_search(lp, [9], beam_width=1, max_new_tokens=4, eos_id=0, length_penalty=0.0)
    assert seq1[:2] == [9, 1]


def test_beam_length_penalty():
    def lp(tokens):
        n = len(tokens)
        if n == 1:
            return np.log(np.array([0.5, 0.5]))
        return np.log(np.array([0.9, 0.1]))

    short, s1 = beam_search(lp, [1], 2, 5, eos_id=0, length_penalty=0.0)
    assert short == [1, 0]
    longer, s2 = beam_search(lp, [1], 2, 5, eos_id=0, length_penalty=1.0)
    assert np.isclose(s2, (np.log(0.5) + np.log(0.9)) / 2) and longer == [1, 1, 0]
