from starter import parse_csv


def test_example():
    assert parse_csv("name, age ,score\nAda, 36, 9.5\nBob,,TRUE\n") == [
        {"name": "Ada", "age": 36, "score": 9.5},
        {"name": "Bob", "age": None, "score": True},
    ]


def test_types():
    rows = parse_csv("v\n-7\n+3\n.5\n1e3\n2.\nfalse\nnan\n12abc\n")
    vals = [r["v"] for r in rows]
    assert vals == [-7, 3, 0.5, 1000.0, 2.0, False, "nan", "12abc"]
    assert type(vals[0]) is int and type(vals[3]) is float


def test_quoting_and_blank_lines():
    text = 'a,b\n\n"x, y", 5\n   \n"7",z\n'
    assert parse_csv(text) == [{"a": "x, y", "b": 5}, {"a": 7, "b": "z"}]


def test_delimiter():
    assert parse_csv("a;b\n1;2", delimiter=";") == [{"a": 1, "b": 2}]


def test_header_only_and_empty():
    assert parse_csv("a,b\n") == []
    assert parse_csv("") == []


def test_bad_row_line_number():
    try:
        parse_csv("a,b\n1,2\n\n3\n")
    except ValueError as e:
        assert "line 4" in str(e)
    else:
        raise AssertionError("expected ValueError")


def test_bad_header():
    for text in ["a,a\n1,2", "a,\n1,2"]:
        try:
            parse_csv(text)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
