# L3-08 · Multinomial Naive Bayes Text Classifier

**Level:** 3 · **Topics:** NLP, count features, Laplace smoothing · **Time:** ~40 min · **Allowed:** Python stdlib + numpy

## Task
### `count_vectorize(docs, vocabulary=None) -> (X, vocabulary)`
Tokens: `re.findall(r"\w+", doc.lower())`. If `vocabulary` is `None`, build it as `{token: index}` with tokens in
**alphabetical** order. Return a dense `int` count matrix `X` of shape `(n_docs, len(vocabulary))`; tokens not in
the vocabulary are ignored.

### `class MultinomialNB(alpha=1.0)`
- `fit(X, y)` with non-negative counts (negative → `ValueError`). Sets `classes_`, `class_count_`,
  `feature_count_ (n_classes, n_features)`, `class_log_prior_ = log(class_count_ / n)`,
  `feature_log_prob_ = log((feature_count_ + α) / (feature_count_.sum(1) + α·n_features))`.
- `predict_log_proba(X)` (normalized, stable), `predict_proba(X)`, `predict(X)`.

## Example
```python
X, vocab = count_vectorize(["free money now", "meeting at noon"])
clf = MultinomialNB().fit(X, ["spam", "ham"])
clf.predict(count_vectorize(["free money"], vocab)[0])  # ['spam']
```
