# L5-17 · Speculative Decoding (Greedy Verification)

**Level:** 5 · **Topics:** LLM inference acceleration, draft/target models, exactness guarantees · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Implement `speculative_decode(target_logits_fn, draft_logits_fn, prompt, max_new_tokens, k=4, eos_id=None)
-> (tokens, stats)`.

- `target_logits_fn(seq) -> (len(seq), V)`: logits at **every** position (row `i` predicts token `i + 1`), i.e. one
  expensive forward pass verifies many tokens at once.
- `draft_logits_fn(seq) -> (V,)`: cheap next-token logits.
- argmax ties → lowest token id.

Algorithm (repeat while fewer than `max_new_tokens` tokens have been generated):
1. Draft greedily up to `min(k, remaining)` proposal tokens (each draft call counts in `draft_calls`); stop drafting
   early if a proposal equals `eos_id`.
2. One target call on `seq + proposals`. Let `preds[j]` = target argmax at the position predicting proposal `j`
   (and `preds[len(proposals)]` = the "bonus" prediction after the last proposal).
3. Accept the longest prefix of proposals that equals `preds`; then append `preds[n_accepted]` (correction or bonus).
4. Truncate the new tokens to the remaining budget and cut everything after an `eos_id`; stop once `eos_id` is emitted.

Return the full sequence (prompt + generated) and
`stats = {"target_calls", "draft_calls", "proposed", "accepted"}` (`proposed`/`accepted` count draft tokens).

**The output must be identical to plain greedy decoding with the target model.**
