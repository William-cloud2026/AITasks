import numpy as np


def causal_mask(T):
    """Lower-triangular boolean mask."""
    return np.tril(np.ones((T, T), dtype=bool))


def scaled_dot_product_attention(q, k, v, mask=None):
    """Masked softmax attention."""
    q, k, v = (np.asarray(a, dtype=float) for a in (q, k, v))
    scores = q @ np.swapaxes(k, -1, -2) / np.sqrt(q.shape[-1])
    if mask is not None:
        mask = np.broadcast_to(mask, scores.shape)
        scores = np.where(mask, scores, -np.inf)
    m = scores.max(-1, keepdims=True)
    m = np.where(np.isfinite(m), m, 0.0)
    e = np.exp(scores - m)
    if mask is not None:
        e = np.where(mask, e, 0.0)
    s = e.sum(-1, keepdims=True)
    w = np.divide(e, s, out=np.zeros_like(e), where=s > 0)
    return w @ v, w


class MultiHeadAttention:
    """Multi-head attention with learned projections."""

    def __init__(self, d_model, n_heads, seed=0):
        if d_model % n_heads:
            raise ValueError("d_model must be divisible by n_heads")
        self.d_model, self.n_heads, self.d_head = d_model, n_heads, d_model // n_heads
        rng = np.random.default_rng(seed)
        self.Wq, self.Wk, self.Wv, self.Wo = (rng.normal(0, 0.02, size=(d_model, d_model)) for _ in range(4))
        self.bq, self.bk, self.bv, self.bo = (np.zeros(d_model) for _ in range(4))

    def _split(self, x):
        B, T, _ = x.shape
        return x.reshape(B, T, self.n_heads, self.d_head).transpose(0, 2, 1, 3)

    def forward(self, x_q, x_kv=None, mask=None):
        """Attention forward pass."""
        x_q = np.asarray(x_q, dtype=float)
        x_kv = x_q if x_kv is None else np.asarray(x_kv, dtype=float)
        q = self._split(x_q @ self.Wq + self.bq)
        k = self._split(x_kv @ self.Wk + self.bk)
        v = self._split(x_kv @ self.Wv + self.bv)
        out, self.last_attn = scaled_dot_product_attention(q, k, v, mask)
        B, H, T, Dh = out.shape
        return out.transpose(0, 2, 1, 3).reshape(B, T, H * Dh) @ self.Wo + self.bo
