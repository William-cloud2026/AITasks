import heapq
import math
from collections import deque


def bfs_path(graph, start, goal):
    """Shortest unweighted path or None."""
    if start == goal:
        return [start]
    prev = {start: None}
    q = deque([start])
    while q:
        u = q.popleft()
        for v in graph.get(u, []):
            if v not in prev:
                prev[v] = u
                if v == goal:
                    path = [v]
                    while prev[path[-1]] is not None:
                        path.append(prev[path[-1]])
                    return path[::-1]
                q.append(v)
    return None


def dijkstra(graph, start):
    """Single-source shortest paths with non-negative weights."""
    if start not in graph:
        raise KeyError(start)
    for u, nbrs in graph.items():
        for v, w in nbrs.items():
            if w < 0:
                raise ValueError(f"negative weight on edge {u}->{v}")
    dist = {start: 0}
    prev = {}
    heap = [(0, 0, start)]
    counter = 1
    done = set()
    while heap:
        d, _, u = heapq.heappop(heap)
        if u in done:
            continue
        done.add(u)
        for v, w in graph.get(u, {}).items():
            nd = d + w
            if v not in dist or nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, counter, v))
                counter += 1
    return dist, prev


def shortest_path(graph, start, goal):
    """(cost, path) from start to goal."""
    dist, prev = dijkstra(graph, start)
    if goal not in dist:
        return math.inf, []
    path = [goal]
    while path[-1] != start:
        path.append(prev[path[-1]])
    return dist[goal], path[::-1]
