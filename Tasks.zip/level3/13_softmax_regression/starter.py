# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def softmax(Z, axis=-1):
    """Stable softmax."""
    raise NotImplementedError('TODO')

def cross_entropy_and_grad(X, Y, W, b, l2=0.0):
    """Mean cross-entropy with L2 and gradients."""
    raise NotImplementedError('TODO')

class SoftmaxRegression:
    """Multiclass logistic regression."""

    def __init__(self, lr=0.1, epochs=500, l2=0.0):
        raise NotImplementedError('TODO')

    def fit(self, X, y):
        """Fit by full-batch gradient descent."""
        raise NotImplementedError('TODO')

    def predict_proba(self, X):
        """Class probabilities."""
        raise NotImplementedError('TODO')

    def predict(self, X):
        """Most likely labels."""
        raise NotImplementedError('TODO')
