import math
import re
from collections import Counter


def _tokens(doc):
    return re.findall(r"\w+", doc.lower())


class TfidfVectorizer:
    """TF-IDF with smooth idf and L2 normalization."""

    def __init__(self, min_df=1, max_features=None, sublinear_tf=False):
        self.min_df = min_df
        self.max_features = max_features
        self.sublinear_tf = sublinear_tf
        self.vocabulary_ = None
        self.idf_ = None

    def fit(self, docs):
        """Learn vocabulary and idf."""
        docs = list(docs)
        n = len(docs)
        df = Counter()
        for d in docs:
            df.update(set(_tokens(d)))
        terms = [t for t, c in df.items() if c >= self.min_df]
        if self.max_features is not None:
            terms = sorted(terms, key=lambda t: (-df[t], t))[:self.max_features]
        terms.sort()
        self.vocabulary_ = {t: i for i, t in enumerate(terms)}
        self.idf_ = [math.log((1 + n) / (1 + df[t])) + 1 for t in terms]
        return self

    def transform(self, docs):
        """Dense L2-normalized tf-idf rows."""
        if self.vocabulary_ is None:
            raise RuntimeError("not fitted")
        rows = []
        for d in docs:
            row = [0.0] * len(self.vocabulary_)
            for t, c in Counter(_tokens(d)).items():
                j = self.vocabulary_.get(t)
                if j is not None:
                    tf = 1 + math.log(c) if self.sublinear_tf else c
                    row[j] = tf * self.idf_[j]
            norm = math.sqrt(sum(x * x for x in row))
            rows.append([x / norm for x in row] if norm else row)
        return rows

    def fit_transform(self, docs):
        """Fit then transform."""
        docs = list(docs)
        return self.fit(docs).transform(docs)

    def get_feature_names_out(self):
        """Terms in index order."""
        if self.vocabulary_ is None:
            raise RuntimeError("not fitted")
        return sorted(self.vocabulary_, key=self.vocabulary_.get)
