# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

def flatten(nested, depth=None):
    """Flatten lists/tuples up to `depth` levels (None = fully)."""
    raise NotImplementedError('TODO')
