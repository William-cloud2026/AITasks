# L4-20 · Vocabulary, Padding & Length Bucketing

**Level:** 4 · **Topics:** NLP data pipelines, attention masks, efficient batching · **Time:** ~45 min · **Allowed:** Python stdlib + numpy

## Task
### `class Vocab`
- `Vocab.build(token_lists, min_freq=1, max_size=None, specials=("<pad>", "<unk>"))` (classmethod):
  specials first (ids `0..`), then tokens with frequency `>= min_freq` sorted by frequency **desc**, token **asc**;
  `max_size` caps the **total** size (specials included). `"<unk>"` must be in specials → else `ValueError`.
  Specials appearing in the data are not duplicated.
- `len(vocab)`, `vocab[token]` → id (unknown → `unk_id`), `vocab.lookup_token(id)`, `encode(tokens)`,
  `decode(ids, skip_specials=False)` → list of tokens.
- Properties `pad_id` (id of `"<pad>"`, or `None` if absent) and `unk_id`.

### `collate(sequences, pad_id, max_len=None, padding_side="right", truncation_side="right") -> (ids, mask)`
- `L = longest sequence length`, capped at `max_len` if given. Sequences longer than `L` are truncated:
  `truncation_side="right"` keeps the **first** `L` ids, `"left"` keeps the **last** `L`.
- Shorter sequences are padded with `pad_id` on `padding_side` (`"right"` or `"left"`).
- Returns `ids` (`int64` array `(B, L)`) and `mask` (`int64`, `1` = real token, `0` = pad).
- Empty `sequences` → `ValueError`; invalid side → `ValueError`.

### `bucket_batches(lengths, batch_size, shuffle=False, seed=None) -> list[list[int]]`
Sort indices by length (stable, ascending), cut into consecutive batches of `batch_size` (last may be smaller).
If `shuffle`, permute the **order of batches** with `np.random.default_rng(seed).permutation`.
