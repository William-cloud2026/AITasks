import math

import numpy as np


def _log_softmax(logits, temperature=1.0):
    z = np.asarray(logits, dtype=float) / temperature
    z = z - z.max(1, keepdims=True)
    return z - np.log(np.exp(z).sum(1, keepdims=True))


def softmax(logits, temperature=1.0):
    """Row-wise softmax with temperature."""
    return np.exp(_log_softmax(logits, temperature))


def nll(logits, labels, temperature=1.0):
    """Mean negative log-likelihood."""
    lp = _log_softmax(logits, temperature)
    labels = np.asarray(labels)
    return float(-lp[np.arange(len(labels)), labels].mean())


def _conf_pred(probs):
    p = np.asarray(probs, dtype=float)
    if p.ndim == 1:
        return np.maximum(p, 1 - p), (p >= 0.5).astype(int)
    return p.max(1), p.argmax(1)


def reliability_bins(probs, labels, n_bins=15):
    """Per-bin accuracy and confidence."""
    conf, pred = _conf_pred(probs)
    correct = (pred == np.asarray(labels)).astype(float)
    idx = np.clip(np.ceil(conf * n_bins).astype(int) - 1, 0, n_bins - 1)
    out = []
    for b in range(n_bins):
        m = idx == b
        if m.any():
            out.append({"bin": b, "lower": b / n_bins, "upper": (b + 1) / n_bins, "count": int(m.sum()),
                        "accuracy": float(correct[m].mean()), "confidence": float(conf[m].mean())})
    return out


def expected_calibration_error(probs, labels, n_bins=15):
    """ECE with equal-width bins."""
    n = len(labels)
    return float(sum(b["count"] / n * abs(b["accuracy"] - b["confidence"]) for b in reliability_bins(probs, labels, n_bins)))


def fit_temperature(logits, labels, t_min=0.05, t_max=20.0, tol=1e-5):
    """Golden-section search for the NLL-optimal temperature."""
    a, b = math.log(t_min), math.log(t_max)
    g = (math.sqrt(5) - 1) / 2
    c, d = b - g * (b - a), a + g * (b - a)
    fc, fd = nll(logits, labels, math.exp(c)), nll(logits, labels, math.exp(d))
    while b - a > tol:
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - g * (b - a)
            fc = nll(logits, labels, math.exp(c))
        else:
            a, c, fc = c, d, fd
            d = a + g * (b - a)
            fd = nll(logits, labels, math.exp(d))
    return math.exp((a + b) / 2)
