# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class ConstrainedDecoder:
    """Restrict generation to a fixed set of strings."""

    def __init__(self, vocab, allowed, eos_id):
        raise NotImplementedError('TODO')

    def allowed_mask(self, prefix):
        """Boolean mask of tokens that keep the output on a valid path."""
        raise NotImplementedError('TODO')

    def decode(self, logits_fn, max_steps=64):
        """Greedy constrained decoding."""
        raise NotImplementedError('TODO')
