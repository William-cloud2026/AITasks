# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import re
from collections import Counter

class TfidfVectorizer:
    """TF-IDF with smooth idf and L2 normalization."""

    def __init__(self, min_df=1, max_features=None, sublinear_tf=False):
        raise NotImplementedError('TODO')

    def fit(self, docs):
        """Learn vocabulary and idf."""
        raise NotImplementedError('TODO')

    def transform(self, docs):
        """Dense L2-normalized tf-idf rows."""
        raise NotImplementedError('TODO')

    def fit_transform(self, docs):
        """Fit then transform."""
        raise NotImplementedError('TODO')

    def get_feature_names_out(self):
        """Terms in index order."""
        raise NotImplementedError('TODO')
