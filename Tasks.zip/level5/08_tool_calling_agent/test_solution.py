import json

from starter import Agent, ToolError, ToolRegistry, parse_action


def make_registry():
    reg = ToolRegistry()
    reg.register("add", lambda a, b: a + b, {"a": {"type": "number"}, "b": {"type": "number"}}, "Add two numbers")
    reg.register("search", lambda query, limit=3: [f"{query}-{i}" for i in range(limit)],
                 {"query": {"type": "string"}, "limit": {"type": "integer", "required": False}}, "Search docs")
    reg.register("fail", lambda: 1 / 0, {}, "Always fails")
    return reg


def raises_tool_error(fn):
    try:
        fn()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ToolError:
        return True
    return False


def test_registry_validation():
    reg = make_registry()
    assert reg.call("add", {"a": 1, "b": 2.5}) == 3.5
    assert reg.call("search", {"query": "x"}) == ["x-0", "x-1", "x-2"]
    assert raises_tool_error(lambda: reg.call("nope", {}))
    assert raises_tool_error(lambda: reg.call("add", {"a": 1}))
    assert raises_tool_error(lambda: reg.call("add", {"a": 1, "b": "2"}))
    assert raises_tool_error(lambda: reg.call("add", {"a": True, "b": 2}))
    assert raises_tool_error(lambda: reg.call("add", {"a": 1, "b": 2, "c": 3}))
    assert raises_tool_error(lambda: reg.call("search", {"query": "x", "limit": 2.0}))
    assert raises_tool_error(lambda: reg.call("add", [1, 2]))
    assert raises_tool_error(lambda: reg.call("fail", {}))
    try:
        reg.register("add", print, {})
    except NotImplementedError:
        raise AssertionError("not implemented")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


def test_describe():
    assert make_registry().describe() == ("- add(a: number, b: number): Add two numbers\n"
                                          "- fail(): Always fails\n"
                                          "- search(query: string, limit?: integer): Search docs")


def test_parse_action():
    assert parse_action("Thinking...\nFINAL:  42 ") == ("final", "42")
    assert parse_action('I will add.\n```json\n{"tool": "add", "arguments": {"a": 1, "b": 2}}\n```') == \
        ("tool", "add", {"a": 1, "b": 2})
    assert parse_action('```\n{"tool": "fail"}\n```') == ("tool", "fail", {})
    assert parse_action(' {"tool": "add", "arguments": {"a": 1, "b": 1}} ') == ("tool", "add", {"a": 1, "b": 1})
    for bad in ["just chatting", "```json\n{broken\n```", '{"name": "add"}', '{"tool": "add", "arguments": [1]}']:
        assert parse_action(bad)[0] == "invalid"


def scripted(replies, seen):
    it = iter(replies)

    def llm(messages):
        seen.append([dict(m) for m in messages])
        return next(it)

    return llm


def test_agent_happy_path():
    seen = []
    llm = scripted(['```json\n{"tool": "add", "arguments": {"a": 2, "b": 3}}\n```',
                    '```json\n{"tool": "search", "arguments": {"query": "5"}}\n```',
                    "The sum is 5. FINAL: 5"], seen)
    out = Agent(llm, make_registry()).run("What is 2+3?")
    assert out["answer"] == "5" and out["stopped"] == "final"
    assert out["steps"] == [{"tool": "add", "arguments": {"a": 2, "b": 3}, "result": 5},
                            {"tool": "search", "arguments": {"query": "5"}, "result": ["5-0", "5-1", "5-2"]}]
    msgs = out["messages"]
    assert msgs[0]["role"] == "system" and make_registry().describe() in msgs[0]["content"]
    assert msgs[1] == {"role": "user", "content": "What is 2+3?"}
    assert msgs[3] == {"role": "tool", "content": json.dumps({"tool": "add", "result": 5})}
    assert [m["role"] for m in msgs] == ["system", "user", "assistant", "tool", "assistant", "tool", "assistant"]
    assert len(seen) == 3 and len(seen[1]) == 4


def test_agent_errors_and_recovery():
    seen = []
    llm = scripted(["hmm", '```json\n{"tool": "fail", "arguments": {}}\n```', "FINAL: gave up"], seen)
    out = Agent(llm, make_registry(), system_prompt="SYS").run("t")
    assert out["messages"][0] == {"role": "system", "content": "SYS"}
    assert out["steps"][0]["tool"] is None and out["steps"][0]["error"]
    assert out["messages"][3]["role"] == "user" and out["messages"][3]["content"].startswith("Invalid action: ")
    tool_msg = json.loads(out["messages"][5]["content"])
    assert tool_msg["tool"] == "fail" and "division" in tool_msg["error"]
    assert out["steps"][1]["error"] == tool_msg["error"]
    assert out["answer"] == "gave up"


def test_agent_max_steps():
    llm = scripted(['{"tool": "add", "arguments": {"a": 1, "b": 1}}'] * 10, [])
    out = Agent(llm, make_registry(), max_steps=3).run("loop forever")
    assert out["answer"] is None and out["stopped"] == "max_steps" and len(out["steps"]) == 3
