_TABLE = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
          (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
_VALUES = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}


def to_roman(n):
    """Convert 1..3999 to a canonical Roman numeral."""
    if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= 3999:
        raise ValueError("n must be an int in 1..3999")
    out = []
    for value, sym in _TABLE:
        q, n = divmod(n, value)
        out.append(sym * q)
    return "".join(out)


def from_roman(s):
    """Parse a canonical upper-case Roman numeral; raise ValueError otherwise."""
    if not isinstance(s, str) or not s or any(c not in _VALUES for c in s):
        raise ValueError(f"invalid roman numeral: {s!r}")
    total = 0
    for i, c in enumerate(s):
        v = _VALUES[c]
        if i + 1 < len(s) and _VALUES[s[i + 1]] > v:
            total -= v
        else:
            total += v
    if not 1 <= total <= 3999 or to_roman(total) != s:
        raise ValueError(f"non-canonical roman numeral: {s!r}")
    return total
