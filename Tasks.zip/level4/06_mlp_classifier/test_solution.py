import time

import numpy as np

from starter import MLPClassifier


def spirals(n_per_class=100, classes=3, seed=0):
    rng = np.random.default_rng(seed)
    X, y = [], []
    for c in range(classes):
        r = np.linspace(0.0, 1, n_per_class)
        t = np.linspace(c * 4, (c + 1) * 4, n_per_class) + rng.normal(scale=0.2, size=n_per_class)
        X.append(np.column_stack([r * np.sin(t), r * np.cos(t)]))
        y += [f"arm{c}"] * n_per_class
    return np.vstack(X), np.array(y)


X, y = spirals()


def test_spiral_accuracy():
    t0 = time.perf_counter()
    m = MLPClassifier().fit(X, y)
    assert time.perf_counter() - t0 < 60
    acc = np.mean(m.predict(X) == y)
    assert acc >= 0.95, acc
    assert list(m.classes_) == ["arm0", "arm1", "arm2"]


def test_proba_and_history():
    m = MLPClassifier(epochs=30).fit(X, y)
    P = m.predict_proba(X)
    assert P.shape == (300, 3) and np.allclose(P.sum(1), 1)
    assert len(m.loss_history_) == 30 and m.loss_history_[-1] < m.loss_history_[0]


def test_reproducible():
    a = MLPClassifier(epochs=10, seed=3).fit(X, y).predict_proba(X)
    b = MLPClassifier(epochs=10, seed=3).fit(X, y).predict_proba(X)
    c = MLPClassifier(epochs=10, seed=4).fit(X, y).predict_proba(X)
    np.testing.assert_array_equal(a, b)
    assert not np.allclose(a, c)


def test_linear_problem_quick():
    rng = np.random.default_rng(1)
    Xl = rng.normal(size=(200, 5))
    yl = (Xl @ np.array([1, -1, 0.5, 0, 2]) > 0).astype(int)
    m = MLPClassifier(hidden_sizes=(16,), epochs=50).fit(Xl, yl)
    assert np.mean(m.predict(Xl) == yl) > 0.95
