# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import math
import re
import string
from collections import Counter

def normalize_answer(s):
    """SQuAD-style normalization."""
    raise NotImplementedError('TODO')

def exact_match(prediction, golds):
    """Max exact match over gold answers."""
    raise NotImplementedError('TODO')

def token_f1(prediction, golds):
    """Max token-level F1 over gold answers."""
    raise NotImplementedError('TODO')

def corpus_bleu(candidates, references, max_n=4, smooth=False):
    """Corpus-level BLEU with brevity penalty."""
    raise NotImplementedError('TODO')

def rouge_l(prediction, reference):
    """ROUGE-L F1 via LCS."""
    raise NotImplementedError('TODO')
