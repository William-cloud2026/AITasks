from dataclasses import dataclass, field
from typing import Optional

from starter import ConfigError, from_dict


@dataclass
class Optim:
    lr: float = 1e-3
    betas: list[float] = field(default_factory=lambda: [0.9, 0.999])


@dataclass
class Model:
    layers: list[int]
    dropout: float = 0.1
    act: str = "relu"


@dataclass
class Config:
    model: Model
    optim: Optim = field(default_factory=Optim)
    name: Optional[str] = None
    seed: int | None = 0
    tags: dict[str, int] = field(default_factory=dict)
    debug: bool = False


def err(data):
    try:
        from_dict(Config, data)
    except ConfigError as e:
        return str(e)
    raise AssertionError("expected ConfigError")


def test_example_and_defaults():
    cfg = from_dict(Config, {"model": {"layers": [64, 32], "dropout": 0}})
    assert cfg == Config(model=Model(layers=[64, 32], dropout=0.0))
    assert isinstance(cfg.model.dropout, float)
    assert cfg.optim.betas == [0.9, 0.999]


def test_full():
    cfg = from_dict(Config, {"model": {"layers": [1], "act": "gelu"}, "optim": {"lr": 0.1, "betas": [0.8, 1]},
                             "name": "run1", "seed": None, "tags": {"a": 1}, "debug": True})
    assert cfg.optim.betas == [0.8, 1.0] and cfg.seed is None and cfg.tags == {"a": 1} and cfg.debug is True


def test_error_paths():
    assert err({"model": {"layers": [1, "x"]}}).startswith("model.layers[1]: ")
    assert err({}).startswith("model: ")
    assert err({"model": {"layers": []}, "optim": {"betas2": []}}).startswith("optim: ")
    assert err({"model": {"layers": []}, "tags": {"k": 1.5}}).startswith("tags[k]: ")
    assert err({"model": {"layers": []}, "seed": "1"}).startswith("seed: ")
    assert err({"model": {"layers": []}, "debug": 1}).startswith("debug: ")


def test_bool_is_not_int():
    assert err({"model": {"layers": [True]}}).startswith("model.layers[0]: ")
    assert err({"model": {"layers": [], "dropout": False}}).startswith("model.dropout: ")


def test_error_is_value_error():
    assert issubclass(ConfigError, ValueError)


def test_nested_type_errors():
    assert err({"model": [1]}).startswith("model: ")
    assert err({"model": {"layers": 5}}).startswith("model.layers: ")
    assert err({"model": {"layers": []}, "name": 3}).startswith("name: ")
