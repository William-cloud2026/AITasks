class InsufficientFundsError(Exception):
    """Raised when a withdrawal exceeds the balance."""


class BankAccount:
    """A simple bank account with history."""

    def __init__(self, owner, balance=0):
        if balance < 0:
            raise ValueError("initial balance must be >= 0")
        self.owner = owner
        self._balance = balance
        self._history = []

    @property
    def balance(self):
        """Current balance (read-only)."""
        return self._balance

    @property
    def history(self):
        """Copy of the transaction history."""
        return list(self._history)

    def _check_amount(self, amount):
        if amount <= 0:
            raise ValueError("amount must be positive")

    def deposit(self, amount):
        """Add money; return new balance."""
        self._check_amount(amount)
        self._balance += amount
        self._history.append(("deposit", amount, self._balance))
        return self._balance

    def withdraw(self, amount):
        """Remove money; return new balance."""
        self._check_amount(amount)
        if amount > self._balance:
            raise InsufficientFundsError(f"balance {self._balance} < {amount}")
        self._balance -= amount
        self._history.append(("withdraw", amount, self._balance))
        return self._balance

    def transfer_to(self, other, amount):
        """Atomically move money to another account."""
        if not isinstance(other, BankAccount) or other is self:
            raise ValueError("invalid target account")
        self._check_amount(amount)
        if amount > self._balance:
            raise InsufficientFundsError(f"balance {self._balance} < {amount}")
        self._balance -= amount
        other._balance += amount
        self._history.append(("transfer_out", amount, self._balance))
        other._history.append(("transfer_in", amount, other._balance))

    def __repr__(self):
        return f"BankAccount(owner={self.owner!r}, balance={self._balance!r})"
