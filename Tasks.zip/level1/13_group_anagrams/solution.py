def group_anagrams(words):
    """Group words whose letters are anagrams, preserving input order."""
    groups = {}
    for w in words:
        key = "".join(sorted(c.lower() for c in w if c.isalpha()))
        groups.setdefault(key, []).append(w)
    return list(groups.values())
