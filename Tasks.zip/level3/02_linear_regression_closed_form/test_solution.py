import numpy as np

from starter import LinearRegression, r2_score

rng = np.random.default_rng(0)
X = rng.normal(size=(100, 3))
TRUE_W = np.array([2.0, -1.0, 0.5])
y = X @ TRUE_W + 3.0 + rng.normal(scale=0.01, size=100)


def test_ols_recovers_weights():
    m = LinearRegression().fit(X, y)
    np.testing.assert_allclose(m.coef_, TRUE_W, atol=0.01)
    assert abs(m.intercept_ - 3.0) < 0.01
    assert m.score(X, y) > 0.9999


def test_no_intercept():
    m = LinearRegression(fit_intercept=False).fit(X, y)
    ref = np.linalg.lstsq(X, y, rcond=None)[0]
    np.testing.assert_allclose(m.coef_, ref, atol=1e-8)
    assert m.intercept_ == 0.0


def test_ridge_formula():
    alpha = 5.0
    m = LinearRegression(alpha=alpha).fit(X, y)
    Xc, yc = X - X.mean(0), y - y.mean()
    ref = np.linalg.solve(Xc.T @ Xc + alpha * np.eye(3), Xc.T @ yc)
    np.testing.assert_allclose(m.coef_, ref, atol=1e-10)
    np.testing.assert_allclose(m.intercept_, y.mean() - X.mean(0) @ ref)
    assert np.linalg.norm(m.coef_) < np.linalg.norm(LinearRegression().fit(X, y).coef_)


def test_rank_deficient_min_norm():
    Xd = np.column_stack([X[:, 0], X[:, 0]])
    yd = 4 * X[:, 0]
    m = LinearRegression(fit_intercept=False).fit(Xd, yd)
    np.testing.assert_allclose(m.coef_, [2.0, 2.0], atol=1e-8)


def test_r2():
    assert r2_score([1, 2, 3], [1, 2, 3]) == 1.0
    assert abs(r2_score([1, 2, 3], [2, 2, 2]) - 0.0) < 1e-12
    assert r2_score([5, 5], [5, 5]) == 1.0
    assert r2_score([5, 5], [4, 5]) == 0.0


def test_errors():
    for fn in (lambda: LinearRegression(alpha=-1), lambda: LinearRegression().fit(X, y[:10])):
        try:
            fn()
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")
