import math

from starter import Value


def num_grad(f, xs, i, eps=1e-6):
    a = list(xs)
    b = list(xs)
    a[i] += eps
    b[i] -= eps
    return (f(*a) - f(*b)) / (2 * eps)


def check(f_value, f_float, xs):
    vs = [Value(x) for x in xs]
    out = f_value(*vs)
    assert math.isclose(out.data, f_float(*xs), rel_tol=1e-9, abs_tol=1e-12)
    out.backward()
    for i, v in enumerate(vs):
        assert math.isclose(v.grad, num_grad(f_float, xs, i), rel_tol=1e-5, abs_tol=1e-7), (i, v.grad)


def test_arithmetic():
    check(lambda x, y: x * y + x ** 2 - y / x, lambda x, y: x * y + x ** 2 - y / x, [2.0, -3.0])
    check(lambda x, y: 2 * x - 1 - y + 3 / y, lambda x, y: 2 * x - 1 - y + 3 / y, [0.5, 1.5])
    check(lambda x: -x ** 3 + x ** 0.5, lambda x: -x ** 3 + x ** 0.5, [1.7])


def test_unary_ops():
    check(lambda x: (x * 2).tanh() + x.exp() + x.log(), lambda x: math.tanh(2 * x) + math.exp(x) + math.log(x), [0.7])
    check(lambda x, y: (x * y).sigmoid(), lambda x, y: 1 / (1 + math.exp(-x * y)), [0.3, -2.0])
    check(lambda x: x.relu() * 3, lambda x: max(0.0, x) * 3, [1.2])
    v = Value(-1.0)
    v.relu().backward()
    assert v.grad == 0.0


def test_reuse_accumulates():
    x = Value(3.0)
    y = x * x + x
    y.backward()
    assert x.grad == 7.0
    a = Value(2.0)
    b = a * 3
    c = b + b * a
    c.backward()
    assert math.isclose(a.grad, 3 + 6 * a.data)


def test_sigmoid_extreme():
    assert Value(-1000).sigmoid().data == 0.0 and Value(1000).sigmoid().data == 1.0


def test_pow_value_exponent_rejected():
    try:
        Value(2.0) ** Value(3.0)
    except NotImplementedError:
        raise AssertionError("not implemented")
    except TypeError:
        return
    raise AssertionError("expected TypeError")


def test_deep_chain():
    x = Value(1.0)
    y = x
    for _ in range(5000):
        y = y * 1.0001 + 0.0
    y.backward()
    assert math.isclose(x.grad, 1.0001 ** 5000, rel_tol=1e-9)


def test_tiny_training_loop():
    xs = [(1.0, 3.0), (2.0, 5.0), (3.0, 7.0)]
    w, b = Value(0.0), Value(0.0)
    for _ in range(300):
        loss = sum((w * x + b - y) ** 2 for x, y in xs) / len(xs)
        w.grad = b.grad = 0.0
        loss.backward()
        w.data -= 0.05 * w.grad
        b.data -= 0.05 * b.grad
    assert abs(w.data - 2) < 0.05 and abs(b.data - 1) < 0.1
