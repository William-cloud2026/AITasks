# L4-16 · LayerNorm & RMSNorm (Forward & Backward)

**Level:** 4 · **Topics:** normalization, Jacobians, broadcasting over leading dims · **Time:** ~50 min · **Allowed:** Python stdlib + numpy

## Task
Both layers normalize over the **last** dimension of inputs of shape `(..., d)`.

### `class LayerNorm(d, eps=1e-5)`
`gamma` ones, `beta` zeros. `y = gamma · (x − mean) / sqrt(var + eps) + beta` (biased variance).
`backward(dout)` → `dx`; sets `dgamma`, `dbeta` (summed over all leading dims).

### `class RMSNorm(d, eps=1e-6)`
`gamma` ones. `y = gamma · x / sqrt(mean(x²) + eps)`. `backward(dout)` → `dx`; sets `dgamma`.
