# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class StandardScaler:
    """Standardize features to zero mean and unit variance."""

    def __init__(self, with_mean=True, with_std=True):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Compute mean and std."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Standardize X."""
        raise NotImplementedError('TODO')

    def inverse_transform(self, X):
        """Undo standardization."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')

class MinMaxScaler:
    """Scale features to a given range."""

    def __init__(self, feature_range=(0, 1)):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Compute per-feature min/max."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Scale X."""
        raise NotImplementedError('TODO')

    def inverse_transform(self, X):
        """Undo scaling."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')
