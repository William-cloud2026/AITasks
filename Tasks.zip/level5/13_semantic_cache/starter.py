# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import time
from collections import OrderedDict
import numpy as np

class SemanticCache:
    """Embedding-similarity cache with LRU and TTL eviction."""

    def __init__(self, embed_fn, threshold=0.9, max_entries=100, ttl=None, clock=time.monotonic):
        raise NotImplementedError('TODO')

    def put(self, query, response):
        """Store a response."""
        raise NotImplementedError('TODO')

    def get(self, query):
        """Return a cached response for a semantically similar query, or None."""
        raise NotImplementedError('TODO')

    def __len__(self):
        raise NotImplementedError('TODO')
