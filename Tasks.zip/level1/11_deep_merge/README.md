# L1-11 · Deep Merge of Config Dicts

**Level:** 1 · **Topics:** recursion, dicts, immutability · **Time:** ~20 min · **Allowed:** Python stdlib

## Task
Implement `deep_merge(base, override, list_strategy="replace") -> dict`.

- Returns a **new** dict; neither input (nor any nested object inside them) may be mutated, and the result must
  not share nested dicts/lists with the inputs (mutating the result must not affect inputs).
- When both sides have a key whose values are both `dict` → merge recursively.
- When both values are `list`:
  - `"replace"` → the override list wins
  - `"concat"` → `base_list + override_list`
- Otherwise the override value wins.
- Unknown `list_strategy` → `ValueError`.

## Example
```python
deep_merge({"model": {"lr": 0.1, "layers": [64]}}, {"model": {"layers": [128]}, "seed": 1})
# {'model': {'lr': 0.1, 'layers': [128]}, 'seed': 1}
```
