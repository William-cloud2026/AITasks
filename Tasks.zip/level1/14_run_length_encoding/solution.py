import re
from itertools import groupby


def rle_encode(s):
    """Encode runs as <count><char>."""
    if any(c.isdigit() for c in s):
        raise ValueError("input must not contain digits")
    return "".join(f"{len(list(g))}{ch}" for ch, g in groupby(s))


def rle_decode(s):
    """Decode <count><char> pairs."""
    pos, out = 0, []
    pattern = re.compile(r"(\d+)(\D)", re.S)
    while pos < len(s):
        m = pattern.match(s, pos)
        if not m or int(m.group(1)) == 0:
            raise ValueError(f"malformed RLE at position {pos}")
        out.append(m.group(2) * int(m.group(1)))
        pos = m.end()
    return "".join(out)
