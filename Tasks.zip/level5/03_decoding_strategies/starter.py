# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

def filter_logits(logits, top_k=None, top_p=None):
    """Top-k then top-p filtering."""
    raise NotImplementedError('TODO')

def greedy_decode(next_logits, prompt, max_new_tokens, eos_id=None):
    """Argmax decoding."""
    raise NotImplementedError('TODO')

def sample_decode(next_logits, prompt, max_new_tokens, temperature=1.0, top_k=None, top_p=None, seed=None, eos_id=None):
    """Temperature / top-k / top-p sampling."""
    raise NotImplementedError('TODO')

def beam_search(next_logprobs, prompt, beam_width, max_new_tokens, eos_id=None, length_penalty=1.0):
    """Beam search with length-normalized final scoring."""
    raise NotImplementedError('TODO')
