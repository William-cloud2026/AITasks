# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class PCA:
    """PCA via SVD."""

    def __init__(self, n_components=None, whiten=False):
        raise NotImplementedError('TODO')

    def fit(self, X):
        """Compute principal components."""
        raise NotImplementedError('TODO')

    def transform(self, X):
        """Project onto components."""
        raise NotImplementedError('TODO')

    def inverse_transform(self, Z):
        """Map back to input space."""
        raise NotImplementedError('TODO')

    def fit_transform(self, X):
        """Fit then transform."""
        raise NotImplementedError('TODO')
