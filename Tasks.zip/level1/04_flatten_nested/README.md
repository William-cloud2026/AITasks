# L1-04 · Flatten Nested Sequences

**Level:** 1 · **Topics:** recursion, type checks · **Time:** ~15 min · **Allowed:** Python stdlib

## Task
Implement `flatten(nested, depth=None) -> list`.

- Only `list` and `tuple` objects are flattened. Everything else (including `str`, `bytes`, `dict`, `set`)
  is treated as an atomic item.
- `depth=None` flattens completely. `depth=k` flattens at most `k` levels (`depth=0` returns a shallow
  `list(nested)` copy).
- The outer `nested` argument must be a list or tuple → otherwise `TypeError`.
- `depth < 0` → `ValueError`.
- Must handle nesting deeper than Python's recursion limit is **not** required, but 500 levels must work.

## Example
```python
flatten([1, [2, (3, [4])], "ab"])          # [1, 2, 3, 4, 'ab']
flatten([1, [2, [3, [4]]]], depth=1)       # [1, 2, [3, [4]]]
```
