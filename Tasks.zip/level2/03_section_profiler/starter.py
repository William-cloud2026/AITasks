# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import contextlib
import functools
import time

class Profiler:
    """Accumulates timings for nested named sections."""

    def __init__(self, clock=time.perf_counter):
        raise NotImplementedError('TODO')

    @contextlib.contextmanager
    def section(self, name):
        """Context manager timing a named (possibly nested) section."""
        raise NotImplementedError('TODO')

    def timed(self, name):
        """Decorator timing each call as a section."""
        raise NotImplementedError('TODO')

    def report(self):
        """Return {key: {calls, total, mean}}."""
        raise NotImplementedError('TODO')

    def reset(self):
        """Clear all recorded data."""
        raise NotImplementedError('TODO')
