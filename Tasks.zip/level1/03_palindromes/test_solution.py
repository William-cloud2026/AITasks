from starter import is_palindrome, longest_palindrome


def test_is_palindrome_basic():
    assert is_palindrome("A man, a plan, a canal: Panama")
    assert is_palindrome("No 'x' in Nixon")
    assert not is_palindrome("race a car")


def test_is_palindrome_edge():
    assert is_palindrome("")
    assert is_palindrome("!!!")
    assert is_palindrome("a")
    assert is_palindrome("12321")
    assert not is_palindrome("ab")


def test_longest_basic():
    assert longest_palindrome("babad") == "bab"
    assert longest_palindrome("cbbd") == "bb"
    assert longest_palindrome("forgeeksskeegfor") == "geeksskeeg"


def test_longest_edge():
    assert longest_palindrome("") == ""
    assert longest_palindrome("a") == "a"
    assert longest_palindrome("abc") == "a"


def test_longest_case_sensitive():
    assert longest_palindrome("Aba") == "A"


def test_longest_performance():
    s = "ab" * 400 + "x" + "ba" * 400
    assert longest_palindrome(s) == s
