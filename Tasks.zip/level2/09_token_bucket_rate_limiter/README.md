# L2-09 · Token-Bucket Rate Limiter

**Level:** 2 · **Topics:** time-based algorithms, injected clocks, API quotas · **Time:** ~30 min · **Allowed:** Python stdlib

## Task
Implement `class TokenBucket(rate, capacity, clock=time.monotonic)` — e.g. to respect an LLM API's
tokens-per-second quota.

- `rate` (> 0): tokens added per second; `capacity` (> 0): maximum tokens. Invalid → `ValueError`.
- The bucket starts **full**. Refill is continuous: on every call, add `rate * (now - last)` tokens capped at
  `capacity`.
- `try_acquire(tokens=1) -> bool`: if enough tokens, consume them and return `True`; else return `False` and
  consume nothing.
- `wait_time(tokens=1) -> float`: seconds until `tokens` would be available (`0.0` if available now). Does not consume.
- `available() -> float`: current token count after refill.
- Requests for `tokens <= 0` or `tokens > capacity` → `ValueError`.

### `class MultiKeyLimiter(rate, capacity, clock=time.monotonic)`
Keeps an independent `TokenBucket` per key (e.g. per user). `try_acquire(key, tokens=1)`.
