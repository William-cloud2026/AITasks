import time
from collections import OrderedDict

import numpy as np


class SemanticCache:
    """Embedding-similarity cache with LRU and TTL eviction."""

    def __init__(self, embed_fn, threshold=0.9, max_entries=100, ttl=None, clock=time.monotonic):
        self.embed_fn, self.threshold, self.max_entries = embed_fn, threshold, max_entries
        self.ttl, self.clock = ttl, clock
        self._entries = OrderedDict()
        self.hits = 0
        self.misses = 0

    @staticmethod
    def _unit(v):
        v = np.asarray(v, dtype=float)
        n = np.linalg.norm(v)
        return v / n if n > 0 else np.zeros_like(v)

    def _purge(self):
        if self.ttl is None:
            return
        now = self.clock()
        for q in [q for q, (_, _, t) in self._entries.items() if now - t >= self.ttl]:
            del self._entries[q]

    def put(self, query, response):
        """Store a response."""
        emb = self._unit(self.embed_fn(query))
        self._purge()
        if query in self._entries:
            del self._entries[query]
        self._entries[query] = (emb, response, self.clock())
        while len(self._entries) > self.max_entries:
            self._entries.popitem(last=False)

    def get(self, query):
        """Return a cached response for a semantically similar query, or None."""
        emb = self._unit(self.embed_fn(query))
        self._purge()
        best_q, best_s = None, -np.inf
        for q, (e, _, _) in reversed(self._entries.items()):
            s = float(e @ emb)
            if s > best_s:
                best_q, best_s = q, s
        if best_q is not None and best_s >= self.threshold:
            self._entries.move_to_end(best_q)
            self.hits += 1
            return self._entries[best_q][1]
        self.misses += 1
        return None

    def __len__(self):
        self._purge()
        return len(self._entries)
