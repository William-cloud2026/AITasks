# L5-06 · Vector Index: Flat & IVF (Inverted File) Search

**Level:** 5 · **Topics:** approximate nearest neighbors, clustering, recall/latency trade-offs · **Time:** ~75 min · **Allowed:** Python stdlib + numpy

## Task
### `class FlatIndex(dim, metric="cosine")` — exact search
- `metric`: `"cosine"`, `"ip"` (inner product), or `"l2"` (squared Euclidean). Unknown → `ValueError`.
- `add(vectors, ids=None)`: `vectors (n, dim)` (wrong dim → `ValueError`); ids default to consecutive integers
  continuing from the number of vectors already stored.
- `search(queries, k) -> (scores, ids)`: arrays `(n_queries, k)`. For `cosine`/`ip` higher is better (sorted desc);
  for `l2` return squared distances sorted asc. Ties → smaller insertion position first. If fewer than `k` vectors
  exist, pad ids with `-1` and scores with `-inf` (`cosine`/`ip`) or `+inf` (`l2`).
- `len(index)`.

### `class IVFIndex(dim, n_lists, metric="l2", n_probe=1, seed=0)`
- `train(vectors)`: run k-means (your implementation; `seed` for init) to get `n_lists` centroids. `is_trained`.
- `add(vectors, ids=None)`: assign each vector to its nearest centroid's list (by squared L2 to centroids).
  Adding before training → `RuntimeError`.
- `search(queries, k)`: probe the `n_probe` nearest centroids per query and search exactly within those lists; same
  output conventions as `FlatIndex`. `n_probe` is a mutable attribute.
- With `n_probe == n_lists` results must equal exact search. A recall test checks `n_probe` trade-offs.
