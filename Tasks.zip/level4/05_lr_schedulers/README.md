# L4-05 · Learning-Rate Schedules

**Level:** 4 · **Topics:** training dynamics, exact formula implementation · **Time:** ~35 min · **Allowed:** Python stdlib (+ numpy optional)

## Task
All functions take a 0-based integer `step` (`step < 0` → `ValueError`) and return a float.

| Function | Formula |
|---|---|
| `step_lr(step, base_lr, step_size, gamma=0.1)` | `base_lr · gamma^(step // step_size)` |
| `exponential_lr(step, base_lr, gamma)` | `base_lr · gamma^step` |
| `warmup_cosine_lr(step, base_lr, total_steps, warmup_steps=0, min_lr=0.0)` | warm-up: if `step < warmup_steps` → `base_lr · (step + 1) / warmup_steps`. Afterwards `progress = (step − warmup_steps) / max(1, total_steps − warmup_steps)` clipped to `[0, 1]`; `min_lr + 0.5·(base_lr − min_lr)·(1 + cos(π·progress))` |
| `warmup_linear_lr(step, base_lr, total_steps, warmup_steps=0)` | warm-up as above; then `base_lr · max(0, (total_steps − step) / max(1, total_steps − warmup_steps))` |
| `inverse_sqrt_lr(step, base_lr, warmup_steps)` | warm-up as above; then `base_lr · sqrt(warmup_steps / (step + 1))` |

### `class LambdaScheduler(optimizer, lr_fn)`
`optimizer` is any object with a mutable `lr` attribute; `lr_fn(step)` returns the learning rate.
On construction set `optimizer.lr = lr_fn(0)` and `last_step = 0`; each `step()` increments `last_step` and sets
`optimizer.lr = lr_fn(last_step)`. `get_last_lr()` returns the current lr.
