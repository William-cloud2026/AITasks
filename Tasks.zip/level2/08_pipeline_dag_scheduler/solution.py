import heapq


class CycleError(ValueError):
    """Raised when the dependency graph has a cycle."""


def _nodes(deps):
    nodes = set(deps)
    for ds in deps.values():
        nodes.update(ds)
    return nodes


def topo_order(deps):
    """Lexicographically smallest topological order."""
    nodes = _nodes(deps)
    indeg = {n: 0 for n in nodes}
    users = {n: [] for n in nodes}
    for step, ds in deps.items():
        for d in set(ds):
            indeg[step] += 1
            users[d].append(step)
    heap = [n for n in nodes if indeg[n] == 0]
    heapq.heapify(heap)
    order = []
    while heap:
        n = heapq.heappop(heap)
        order.append(n)
        for u in users[n]:
            indeg[u] -= 1
            if indeg[u] == 0:
                heapq.heappush(heap, u)
    if len(order) != len(nodes):
        raise CycleError("dependency cycle detected")
    return order


def stages(deps):
    """Parallel execution stages."""
    level = {}
    for n in topo_order(deps):
        ds = deps.get(n, [])
        level[n] = 1 + max((level[d] for d in ds), default=-1)
    out = [[] for _ in range(max(level.values(), default=-1) + 1)]
    for n, lv in level.items():
        out[lv].append(n)
    return [sorted(s) for s in out]


def find_cycle(deps):
    """Return a cycle [s0, ..., sk] or None."""
    color = {}
    for root in sorted(_nodes(deps)):
        if root in color:
            continue
        stack = [(root, iter(sorted(set(deps.get(root, [])))))]
        path = [root]
        color[root] = 1
        while stack:
            node, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                color[node] = 2
                stack.pop()
                path.pop()
                continue
            if color.get(nxt) == 1:
                return path[path.index(nxt):]
            if nxt not in color:
                color[nxt] = 1
                path.append(nxt)
                stack.append((nxt, iter(sorted(set(deps.get(nxt, []))))))
    return None
