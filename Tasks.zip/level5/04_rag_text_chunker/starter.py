# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import re

def chunk_text(text, max_tokens, overlap=0):
    """Split text into sentence-aligned, token-bounded chunks."""
    raise NotImplementedError('TODO')
