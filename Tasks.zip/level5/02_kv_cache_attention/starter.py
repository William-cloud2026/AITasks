# Starter file - implement everything marked TODO.
# Read README.md for the full specification. Do not rename public functions/classes.

import numpy as np

class CachedSelfAttention:
    """Causal multi-head self-attention with a KV cache."""

    def __init__(self, Wq, Wk, Wv, Wo, n_heads, window=None):
        raise NotImplementedError('TODO')

    def reset(self):
        """Clear the cache."""
        raise NotImplementedError('TODO')

    @property
    def cache_len(self):
        raise NotImplementedError('TODO')

    def forward_full(self, x):
        """Causal (optionally windowed) attention over a full sequence."""
        raise NotImplementedError('TODO')

    def prefill(self, x):
        """Process several tokens at once, filling the cache."""
        raise NotImplementedError('TODO')

    def step(self, x_t):
        """Process one token."""
        raise NotImplementedError('TODO')
