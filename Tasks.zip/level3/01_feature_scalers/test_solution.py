import numpy as np

from starter import MinMaxScaler, StandardScaler

X = np.array([[1.0, 10.0, 5.0], [2.0, 20.0, 5.0], [3.0, 60.0, 5.0], [6.0, 30.0, 5.0]])


def expect(fn, exc):
    try:
        fn()
    except NotImplementedError:
        raise AssertionError("not implemented")
    except exc:
        return
    raise AssertionError(f"expected {exc.__name__}")


def test_standard_scaler():
    s = StandardScaler()
    Z = s.fit_transform(X)
    np.testing.assert_allclose(s.mean_, X.mean(0))
    np.testing.assert_allclose(Z[:, :2].mean(0), 0, atol=1e-12)
    np.testing.assert_allclose(Z[:, :2].std(0), 1)
    np.testing.assert_allclose(Z[:, 2], 0)
    np.testing.assert_allclose(s.scale_[2], 1.0)
    np.testing.assert_allclose(s.inverse_transform(Z), X)


def test_standard_flags():
    Z = StandardScaler(with_mean=False).fit_transform(X)
    np.testing.assert_allclose(Z[:, 0], X[:, 0] / X[:, 0].std())
    Z = StandardScaler(with_std=False).fit_transform(X)
    np.testing.assert_allclose(Z, X - X.mean(0))


def test_minmax():
    s = MinMaxScaler()
    Z = s.fit_transform(X)
    np.testing.assert_allclose(Z[:, 0], [0, 0.2, 0.4, 1.0])
    np.testing.assert_allclose(Z[:, 2], 0)
    np.testing.assert_allclose(s.inverse_transform(Z), X)
    Z = MinMaxScaler((-1, 1)).fit(X).transform([[6.0, 60.0, 5.0], [0.0, 10.0, 7.0]])
    np.testing.assert_allclose(Z, [[1, 1, -1], [-1.4, -1, 3]])


def test_no_mutation_lists_ok():
    data = [[1, 2], [3, 4]]
    StandardScaler().fit_transform(data)
    assert data == [[1, 2], [3, 4]]
    arr = X.copy()
    MinMaxScaler().fit_transform(arr)
    np.testing.assert_array_equal(arr, X)


def test_errors():
    expect(lambda: StandardScaler().transform(X), RuntimeError)
    expect(lambda: MinMaxScaler().transform(X), RuntimeError)
    expect(lambda: StandardScaler().fit(X).transform(X[:, :2]), ValueError)
    expect(lambda: StandardScaler().fit([1, 2, 3]), ValueError)
    expect(lambda: MinMaxScaler((1, 1)), ValueError)
