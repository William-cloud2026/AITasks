# L3-14 · Polynomial Feature Expansion

**Level:** 3 · **Topics:** combinatorics, feature engineering, exact ordering specs · **Time:** ~30 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class PolynomialFeatures(degree=2, include_bias=True, interaction_only=False)` (same output order as
scikit-learn).

- `fit(X)` → `self`; sets `n_features_in_` and `powers_` — an int array `(n_output, n_features_in_)` whose row `k`
  gives the exponent of every input feature in output feature `k`.
- Output order: the bias column (all-zero powers) if `include_bias`; then for `deg = 1..degree`, the index tuples
  from `itertools.combinations_with_replacement(range(d), deg)` (or `itertools.combinations` when
  `interaction_only`) in their natural order.
- `transform(X)` → `(n, n_output)` with `prod_j x_j ** powers_[k, j]`. Feature-count mismatch → `ValueError`.
- `fit_transform(X)`.
- `get_feature_names_out(input_features=None)`: default names `x0, x1, ...`; bias is `"1"`; a term lists its
  variables in index order separated by a single space, with `^p` for powers `> 1` (e.g. `"x0^2 x1"`).
- `degree < 1` → `ValueError`.

## Example
```python
PolynomialFeatures(2).fit([[1, 2]]).get_feature_names_out(["a", "b"])
# ['1', 'a', 'b', 'a^2', 'a b', 'b^2']
```
