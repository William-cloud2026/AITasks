# L5-11 · LoRA Adapter for a Linear Layer

**Level:** 5 · **Topics:** parameter-efficient fine-tuning, low-rank updates, weight merging · **Time:** ~60 min · **Allowed:** Python stdlib + numpy

## Task
Implement `class LoRALinear(W, b, r=4, alpha=8.0, seed=0)` wrapping a **frozen** linear layer `y = x @ W + b`
(`W (in, out)`, `b (out,)` — keep your own copies, never mutate the caller's arrays).

- Trainable low-rank factors: `A = rng.normal(0, 0.02, (in, r))` and `B = zeros((r, out))` with
  `rng = np.random.default_rng(seed)`. `scaling = alpha / r`. `r < 1` or `r > min(in, out)` → `ValueError`.
- `forward(x)` (`x (N, in)`): `x @ W + b + scaling · (x @ A) @ B` (so a fresh adapter equals the base layer).
- `backward(dout)` → `dx`; sets `dA` and `dB` only (`W`, `b` are frozen). After `merge()` → `RuntimeError`.
- `merge()`: fold the adapter into `W` (`W += scaling · A @ B`), `merged = True`; forward then uses only `W, b`.
  Merging twice → `RuntimeError`. `unmerge()` reverses it (only when merged, else `RuntimeError`).
- `trainable_parameters()` → `r · (in + out)`; `delta_weight()` → `scaling · A @ B`.
