import numpy as np


class GaussianNB:
    """Gaussian naive Bayes classifier."""

    def __init__(self, var_smoothing=1e-9):
        self.var_smoothing = var_smoothing

    def fit(self, X, y):
        """Estimate per-class Gaussians."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        self.epsilon_ = self.var_smoothing * np.var(X, axis=0).max()
        self.theta_ = np.array([X[y == c].mean(0) for c in self.classes_])
        self.var_ = np.array([X[y == c].var(0) for c in self.classes_]) + self.epsilon_
        self.class_prior_ = np.array([np.mean(y == c) for c in self.classes_])
        return self

    def _joint_log_likelihood(self, X):
        X = np.asarray(X, dtype=float)
        ll = -0.5 * np.log(2 * np.pi * self.var_).sum(1)[None, :]
        ll = ll - 0.5 * (((X[:, None, :] - self.theta_[None]) ** 2) / self.var_[None]).sum(-1)
        return ll + np.log(self.class_prior_)[None, :]

    def predict_log_proba(self, X):
        """Normalized log posteriors."""
        jll = self._joint_log_likelihood(X)
        m = jll.max(1, keepdims=True)
        return jll - (m + np.log(np.exp(jll - m).sum(1, keepdims=True)))

    def predict_proba(self, X):
        """Posterior probabilities."""
        return np.exp(self.predict_log_proba(X))

    def predict(self, X):
        """Most probable class."""
        return self.classes_[np.argmax(self._joint_log_likelihood(X), axis=1)]
