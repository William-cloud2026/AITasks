import numpy as np

from starter import LinearRegressionGD, mse_loss_and_grad

rng = np.random.default_rng(1)
X = rng.normal(size=(200, 4))
W = np.array([1.5, -2.0, 0.0, 0.7])
y = X @ W - 1.0 + rng.normal(scale=0.05, size=200)


def numeric_grad(f, v, eps=1e-6):
    g = np.zeros_like(v)
    for i in range(v.size):
        e = np.zeros_like(v)
        e[i] = eps
        g[i] = (f(v + e) - f(v - e)) / (2 * eps)
    return g


def test_loss_value_and_grad():
    w, b = rng.normal(size=4), 0.3
    loss, gw, gb = mse_loss_and_grad(X, y, w, b, l2=0.1)
    r = X @ w + b - y
    assert np.isclose(loss, r @ r / 400 + 0.05 * w @ w)
    np.testing.assert_allclose(gw, numeric_grad(lambda v: mse_loss_and_grad(X, y, v, b, 0.1)[0], w), rtol=1e-5)
    num_b = (mse_loss_and_grad(X, y, w, b + 1e-6, 0.1)[0] - mse_loss_and_grad(X, y, w, b - 1e-6, 0.1)[0]) / 2e-6
    assert np.isclose(gb, num_b, rtol=1e-5)


def test_full_batch_converges():
    m = LinearRegressionGD(lr=0.1, epochs=500).fit(X, y)
    ref = np.linalg.lstsq(np.column_stack([X, np.ones(200)]), y, rcond=None)[0]
    np.testing.assert_allclose(m.coef_, ref[:4], atol=1e-3)
    assert abs(m.intercept_ - ref[4]) < 1e-3
    h = np.array(m.loss_history_)
    assert len(h) == 500 and np.all(np.diff(h) <= 1e-12)


def test_minibatch_reproducible():
    a = LinearRegressionGD(lr=0.05, epochs=30, batch_size=16, seed=7).fit(X, y)
    b = LinearRegressionGD(lr=0.05, epochs=30, batch_size=16, seed=7).fit(X, y)
    c = LinearRegressionGD(lr=0.05, epochs=30, batch_size=16, seed=8).fit(X, y)
    np.testing.assert_array_equal(a.coef_, b.coef_)
    assert not np.array_equal(a.coef_, c.coef_)
    np.testing.assert_allclose(a.coef_, W, atol=0.05)


def test_minibatch_exact_first_epoch():
    m = LinearRegressionGD(lr=0.1, epochs=1, batch_size=64, seed=3).fit(X, y)
    perm = np.random.default_rng(3).permutation(200)
    w, b = np.zeros(4), 0.0
    for i in range(0, 200, 64):
        idx = perm[i:i + 64]
        _, gw, gb = mse_loss_and_grad(X[idx], y[idx], w, b)
        w, b = w - 0.1 * gw, b - 0.1 * gb
    np.testing.assert_allclose(m.coef_, w)
    assert np.isclose(m.intercept_, b)


def test_early_stopping_and_l2():
    m = LinearRegressionGD(lr=0.1, epochs=5000, tol=1e-10).fit(X, y)
    assert m.n_epochs_ < 5000 and m.n_epochs_ == len(m.loss_history_)
    big = LinearRegressionGD(lr=0.1, epochs=500, l2=1.0).fit(X, y)
    assert np.linalg.norm(big.coef_) < np.linalg.norm(m.coef_)
    assert big.predict(X).shape == (200,)
