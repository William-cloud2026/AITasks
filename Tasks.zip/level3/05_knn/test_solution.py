import time

import numpy as np

from starter import KNNClassifier, KNNRegressor

Xtr = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [5.0, 5.0], [6.0, 5.0], [5.0, 6.0]])
ytr = np.array(["a", "a", "a", "b", "b", "b"])


def test_basic_predict():
    m = KNNClassifier(k=3).fit(Xtr, ytr)
    assert list(m.predict([[0.2, 0.2], [5.5, 5.5]])) == ["a", "b"]
    np.testing.assert_allclose(m.predict_proba([[0.2, 0.2]]), [[1.0, 0.0]])


def test_kneighbors_order_and_stable_ties():
    m = KNNClassifier(k=2).fit([[1.0], [-1.0], [3.0]], [0, 1, 0])
    d, i = m.kneighbors([[0.0]])
    np.testing.assert_allclose(d, [[1.0, 1.0]])
    np.testing.assert_array_equal(i, [[0, 1]])
    m = KNNClassifier(k=10).fit(Xtr, ytr)
    assert m.kneighbors([[0, 0]])[1].shape == (1, 6)


def test_manhattan():
    m = KNNClassifier(k=1, metric="manhattan").fit([[0, 0], [3, 3]], [0, 1])
    d, _ = m.kneighbors([[1, 2]])
    np.testing.assert_allclose(d, [[3.0]])


def test_vote_tie_smallest_class():
    m = KNNClassifier(k=2).fit([[-1.0], [1.0]], ["z", "y"])
    assert m.predict([[0.0]])[0] == "y"


def test_distance_weights_and_zero():
    m = KNNClassifier(k=3, weights="distance").fit([[0.0], [1.0], [1.1]], [0, 1, 1])
    p = m.predict_proba([[0.1]])[0]
    w0, w1 = 1 / 0.1, 1 / 0.9 + 1 / 1.0
    np.testing.assert_allclose(p, [w0 / (w0 + w1), w1 / (w0 + w1)])
    m = KNNClassifier(k=3, weights="distance").fit([[0.0], [0.0], [1.0]], [1, 0, 0])
    np.testing.assert_allclose(m.predict_proba([[0.0]]), [[0.5, 0.5]])


def test_regressor():
    r = KNNRegressor(k=2).fit([[0.0], [1.0], [10.0]], [0.0, 2.0, 100.0])
    np.testing.assert_allclose(r.predict([[0.4]]), [1.0])
    r = KNNRegressor(k=2, weights="distance").fit([[0.0], [1.0], [10.0]], [0.0, 2.0, 100.0])
    np.testing.assert_allclose(r.predict([[0.25], [1.0]]), [(0 / 0.25 + 2 / 0.75) / (1 / 0.25 + 1 / 0.75), 2.0])


def test_validation():
    for kw in ({"k": 0}, {"metric": "cosine"}, {"weights": "rank"}):
        try:
            KNNClassifier(**kw)
        except NotImplementedError:
            raise AssertionError("not implemented")
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_vectorized_speed():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(2000, 16))
    y = (X[:, 0] > 0).astype(int)
    m = KNNClassifier(k=7, weights="distance").fit(X, y)
    t0 = time.perf_counter()
    acc = np.mean(m.predict(X[:2000] + 0.01) == y)
    assert time.perf_counter() - t0 < 5.0
    assert acc > 0.9
